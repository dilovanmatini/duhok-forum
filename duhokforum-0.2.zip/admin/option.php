<?
/*//////////////////////////////////////////////////////////
// ######################################################///
// # DuhokForum 0.2                                     # //
// ###################################################### //
// #                                                    # //
// #       --  DUHOK FORUM IS FREE SOFTWARE  --         # //
// #                                                    # //
// #   ========= Programming By Dilovan ==============  # //
// # Copyright � 2007 Dilovan. All Rights Reserved      # //
// #----------------------------------------------------# //
// #----------------------------------------------------# //
// # If you want any support vist down address:-        # //
// # Email: df@duhoktimes.com                           # //
// # Site: http://df.duhoktimes.com/index.php           # //
// ###################################################### //
//////////////////////////////////////////////////////////*/

if ($CPMlevel == 4) {



if ($method == "") {

 if ($type == "") {

echo'
<center>
<table class="grid" border="0" cellspacing="1" cellpadding="4" width="80%">
<form method="post" action="cp_home.php?mode=option&type=insert_data">
	<tr class="fixed">
		<td class="cat" colspan="2"><nobr>����� ������ �����</nobr></td>
	</tr>
	<tr class="fixed">
		<td class="list"><nobr>��� �������</nobr></td>
		<td class="middle"><input type="text" name="forum_name" size="40" value="'.$forum_title.'"></td>
	</tr>
 	<tr class="fixed">
		<td class="list"><nobr>����� ������</nobr></td>
		<td class="middle"><input type="text" dir="ltr" name="site_address" size="40" value="'.$site_name.'"></td>
	</tr>
 	<tr class="fixed">
		<td class="list"><nobr>���� �������</nobr></td>
		<td class="middle"><input type="text" dir="ltr" name="admin_email" size="40" value="'.$admin_email.'"></td>
	</tr>
 	<tr class="fixed">
		<td class="list"><nobr>���� �������</nobr></td>
		<td class="middle"><input type="text" dir="ltr" name="copy_right" size="40" value="'.$copy_right.'"></td>
	</tr>
 	<tr class="fixed">
		<td class="list"><nobr>��� ���� ���</nobr></td>
		<td class="middle"><input type="text" dir="ltr" name="image_folder" size="40" value="'.$image_folder.'"></td>
	</tr>
 	<tr class="fixed">
		<td class="list"><nobr>��� ���� �������</nobr></td>
		<td class="middle"><input type="text" dir="ltr" name="admin_folder" size="40" value="'.$admin_folder.'"></td>
	</tr>
 	<tr class="fixed">
		<td align="middle" colspan="2"><input type="submit" value="����� ������">&nbsp;&nbsp;&nbsp;<input type="reset" value="����� �� ������"></td>
	</tr>
</form>
</table>
</center>';
 }

 if ($type == "insert_data") {

$Admin_ForumTitle = $_POST["forum_name"];
$Admin_SiteAddress = $_POST["site_address"];
$Admin_CopyRight = $_POST["copy_right"];
$Admin_ImageFolder = $_POST["image_folder"];
$Admin_AdminFolder = $_POST["admin_folder"];
$Admin_AdminEmail = $_POST["admin_email"];

    if ($error != "") {
	                echo'<br><center>
	                <table bordercolor="#ffffff" width="99%" border="1">
	                   <tr class="normal">
	                       <td class="list_center" colSpan="10"><font size="5" color="red"><br>���<br>'.$error.'..</font><br><br>
	                       <a href="JavaScript:history.go(-1)">-- ���� ��� ������ --</a><br><br>
	                       </td>
	                   </tr>
	                </table>
	                </center>';
    }


    if ($error == "") {

updata_mysql("FORUM_TITLE", $Admin_ForumTitle);
updata_mysql("SITE_ADDRESS", $Admin_SiteAddress);
updata_mysql("COPY_RIGHT", $Admin_CopyRight);
updata_mysql("IMAGE_FOLDER", $Admin_ImageFolder);
updata_mysql("ADMIN_FOLDER", $Admin_AdminFolder);
updata_mysql("ADMIN_EMAIL", $Admin_AdminEmail);

rename($admin_folder.".php", $Admin_AdminFolder.".php");

                    echo'<br><br>
	                <center>
	                <table bordercolor="#ffffff" width="50%" border="1">
	                   <tr class="normal">
	                       <td class="list_center" colSpan="10"><font size="5"><br>�� ����� ������ �����..</font><br><br>
                           <meta http-equiv="Refresh" content="2; URL=cp_home.php?mode=option">
                           <a href="cp_home.php?mode=option">-- ���� ��� ������ ��� ���� ������� --</a><br><br>
	                       </td>
	                   </tr>
	                </table>
	                </center>';
    }

 }

}



if ($method == "other") {

 if ($type == "") {

echo'
<center>
<table class="grid" border="0" cellspacing="1" cellpadding="4" width="80%">
<form method="post" action="cp_home.php?mode=option&method=other&type=insert_data">
	<tr class="fixed">
		<td class="cat" colspan="2"><nobr>������ ����</nobr></td>
	</tr>
 	<tr class="fixed">
		<td class="list"><nobr>��� ����� �� �� ����</nobr></td>
		<td class="middle"><input type="text" name="page_number" size="10" value="'.$max_page.'"></td>
	</tr>
 	<tr class="fixed">
		<td class="list"><nobr>��� ����� ���� ���� 24 ����</nobr></td>
		<td class="middle"><input type="text" name="total_pm_msg" size="10" value="'.$total_pm_message.'"></td>
	</tr>
 	<tr class="fixed">
		<td align="middle" colspan="2"><input type="submit" value="����� ������">&nbsp;&nbsp;&nbsp;<input type="reset" value="����� �� ������"></td>
	</tr>
</form>
</table>
</center>';
 }

 if ($type == "insert_data") {

$Admin_PageNumber = $_POST["page_number"];
$Admin_TotalPmMsg = $_POST["total_pm_msg"];

    if ($error != "") {
	                echo'<br><center>
	                <table bordercolor="#ffffff" width="99%" border="1">
	                   <tr class="normal">
	                       <td class="list_center" colSpan="10"><font size="5" color="red"><br>���<br>'.$error.'..</font><br><br>
	                       <a href="JavaScript:history.go(-1)">-- ���� ��� ������ --</a><br><br>
	                       </td>
	                   </tr>
	                </table>
	                </center>';
    }


    if ($error == "") {

updata_mysql("PAGE_NUMBER", $Admin_PageNumber);
updata_mysql("TOTAL_PM_MSG", $Admin_TotalPmMsg);

                    echo'<br><br>
	                <center>
	                <table bordercolor="#ffffff" width="50%" border="1">
	                   <tr class="normal">
	                       <td class="list_center" colSpan="10"><font size="5"><br>�� ����� ������ �����..</font><br><br>
                           <meta http-equiv="Refresh" content="2; URL=cp_home.php?mode=option&method=other">
                           <a href="cp_home.php?mode=option&method=other">-- ���� ��� ������ ��� ���� ������� --</a><br><br>
	                       </td>
	                   </tr>
	                </table>
	                </center>';
    }

 }

}
 
 
 
 
 
 
 
 
}
else {
    go_to("index.php");
}
?>
