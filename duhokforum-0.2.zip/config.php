<?php
/*//////////////////////////////////////////////////////////
// ######################################################///
// # DuhokForum 0.2                                     # //
// ###################################################### //
// #                                                    # //
// #       --  DUHOK FORUM IS FREE SOFTWARE  --         # //
// #                                                    # //
// #   ========= Programming By Dilovan ==============  # //
// # Copyright � 2007 Dilovan. All Rights Reserved      # //
// #----------------------------------------------------# //
// #----------------------------------------------------# //
// # If you want any support vist down address:-        # //
// # Email: df@duhoktimes.com                           # //
// # Site: http://df.duhoktimes.com/index.php           # //
// ###################################################### //
//////////////////////////////////////////////////////////*/

require("connect.php");

$forum_title = open_mysql("FORUM_TITLE");     // ��� �����
$site_name = open_mysql("SITE_ADDRESS");      // ����� ����
$copy_right = open_mysql("COPY_RIGHT");       // ���� �����
$image_folder = open_mysql("IMAGE_FOLDER");   // ���� ���
$max_page = open_mysql("PAGE_NUMBER");        // ��� ����� �� �� ����
$admin_folder = open_mysql("ADMIN_FOLDER");   // ��� ���� �������
$admin_email = open_mysql("ADMIN_EMAIL");     // ��� ���� �������
$forum_version = open_mysql("FORUM_VERSION"); // ����� �������
$total_pm_message = open_mysql("TOTAL_PM_MSG"); // ����� �������
$mod_add_titles = open_mysql("MOD_ADD_TITLES"); // ����� �������

$Title=array(
open_mysql("TITLE_0"),
open_mysql("TITLE_1"),
open_mysql("TITLE_2"),
open_mysql("TITLE_3"),
open_mysql("TITLE_4"),
open_mysql("TITLE_5"),
open_mysql("TITLE_6"),
open_mysql("TITLE_7"),
open_mysql("TITLE_8"),
open_mysql("TITLE_9"),
open_mysql("TITLE_10"),
open_mysql("TITLE_11"),
open_mysql("TITLE_12"),
open_mysql("TITLE_13")
);

$StarsNomber=array(
open_mysql("STARS_NUMBER_0"),
open_mysql("STARS_NUMBER_1"),
open_mysql("STARS_NUMBER_2"),
open_mysql("STARS_NUMBER_3"),
open_mysql("STARS_NUMBER_4"),
open_mysql("STARS_NUMBER_5"),
open_mysql("STARS_NUMBER_6"),
open_mysql("STARS_NUMBER_7"),
open_mysql("STARS_NUMBER_8"),
open_mysql("STARS_NUMBER_9"),
open_mysql("STARS_NUMBER_10")
);

$StarsColor=array(
open_mysql("MLV_STARS_COLOR_0"),
open_mysql("MLV_STARS_COLOR_1"),
open_mysql("MLV_STARS_COLOR_2"),
open_mysql("MLV_STARS_COLOR_3"),
open_mysql("MLV_STARS_COLOR_4")
);

?>
