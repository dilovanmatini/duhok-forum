/*//////////////////////////////////////////////////////////
// ######################################################///
// # DuhokForum 0.2                                     # //
// ###################################################### //
// #                                                    # //
// #       --  DUHOK FORUM IS FREE SOFTWARE  --         # //
// #                                                    # //
// #   ========= Programming By Dilovan ==============  # //
// # Copyright � 2007 Dilovan. All Rights Reserved      # //
// #----------------------------------------------------# //
// #----------------------------------------------------# //
// # If you want any support vist down address:-        # //
// # Email: df@duhoktimes.com                           # //
// # Site: http://df.duhoktimes.com/index.php           # //
// ###################################################### //
//////////////////////////////////////////////////////////*/

function AddSmiles(NewSmile) {
        document.add_post.message.value+=NewSmile;
        document.add_post.message.focus();
}

function happy(){
        Smile='~happy~';
        AddSmiles(Smile);
}
function big(){
        Smile='~big~';
        AddSmiles(Smile);
}
function cool(){
        Smile='~cool~';
        AddSmiles(Smile);
}
function blush(){
        Smile='~blush~';
        AddSmiles(Smile);
}
function tongue(){
        Smile='~tongue~';
        AddSmiles(Smile);
}
function evil(){
        Smile='~evil~';
        AddSmiles(Smile);
}
function wink(){
        Smile='~wink~';
        AddSmiles(Smile);
}
function clown(){
        Smile='~clown~';
        AddSmiles(Smile);
}
function blackeye(){
        Smile='~blackeye~';
        AddSmiles(Smile);
}
function ball(){
        Smile='~ball~';
        AddSmiles(Smile);
}
function sad(){
        Smile='~sad~';
        AddSmiles(Smile);
}
function shy(){
        Smile='~shy~';
        AddSmiles(Smile);
}
function shock(){
        Smile='~shock~';
        AddSmiles(Smile);
}
function angry(){
        Smile='~angry~';
        AddSmiles(Smile);
}
function dead(){
        Smile='~dead~';
        AddSmiles(Smile);
}
function kisses(){
        Smile='~kisses~';
        AddSmiles(Smile);
}
function approve(){
        Smile='~approve~';
        AddSmiles(Smile);
}
function dissapprove(){
        Smile='~dissapprove~';
        AddSmiles(Smile);
}
function sleepy(){
        Smile='~sleepy~';
        AddSmiles(Smile);
}
function question(){
        Smile='~question~';
        AddSmiles(Smile);
}
function rotating(){
        Smile='~rotating~';
        AddSmiles(Smile);
}
function eyebrows(){
        Smile='~eyebrows~';
        AddSmiles(Smile);
}
function hearteyes(){
        Smile='~hearteyes~';
        AddSmiles(Smile);
}
function crying(){
        Smile='~crying~';
        AddSmiles(Smile);
}
function nono(){
        Smile='~nono~';
        AddSmiles(Smile);
}
function wailing(){
        Smile='~wailing~';
        AddSmiles(Smile);
}

function joker(){
        Smile='~joker~';
        AddSmiles(Smile);
}

