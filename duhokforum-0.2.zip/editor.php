<?
/*//////////////////////////////////////////////////////////
// ######################################################///
// # DuhokForum 0.2                                     # //
// ###################################################### //
// #                                                    # //
// #       --  DUHOK FORUM IS FREE SOFTWARE  --         # //
// #                                                    # //
// #   ========= Programming By Dilovan ==============  # //
// # Copyright � 2007 Dilovan. All Rights Reserved      # //
// #----------------------------------------------------# //
// #----------------------------------------------------# //
// # If you want any support vist down address:-        # //
// # Email: df@duhoktimes.com                           # //
// # Site: http://df.duhoktimes.com/index.php           # //
// ###################################################### //
//////////////////////////////////////////////////////////*/

$HTTP_REFERER = $_SERVER['HTTP_REFERER'];

$HTTP_HOST = $_SERVER['HTTP_HOST'];

$Monitor_all = chk_monitor($DBMemberID, $c);
$Moderator_all = chk_moderator($DBMemberID, $f);

if ($method == "topic") {
    $txt = "����� �����";
}
if ($method == "edit") {
    $txt = "����� �����";
}
if ($method == "reply") {
    $txt = "����� ��";
}
if ($method == "editreply") {
    $txt = "����� ��";
}

 $cat = mysql_query("SELECT * FROM " . $Prefix . "CATEGORY WHERE CAT_ID = '$c' ") or die (mysql_error());

 if(mysql_num_rows($cat) > 0){

 $rsc = mysql_fetch_array($cat);

 $C_CatID = $rsc['CAT_ID'];
 $C_CatStatus = $rsc['CAT_STATUS'];

 }

 $forum = mysql_query("SELECT * FROM " . $Prefix . "FORUM WHERE FORUM_ID = '$f' ") or die (mysql_error());

 if(mysql_num_rows($forum) > 0){

 $rsf = mysql_fetch_array($forum);

 $F_CatID = $rsf['CAT_ID'];
 $F_ForumID = $rsf['FORUM_ID'];
 $F_ForumStatus = $rsf['F_STATUS'];
 $F_ForumSubject = $rsf['F_SUBJECT'];
 $F_ForumLogo = $rsf['F_LOGO'];

 }

 	$topic = "SELECT * FROM " . $Prefix . "TOPICS ";
    $topic .= " WHERE TOPIC_ID = '$t' ";
	$Rtopic = mysql_query($topic, $connection) or die (mysql_error());

 if(mysql_num_rows($Rtopic) > 0){

 $rst = mysql_fetch_array($Rtopic);

 $T_TopicID = $rst['TOPIC_ID'];
 $T_TopicSubject = $rst['T_SUBJECT'];
 $T_TopicMessage = $rst['T_MESSAGE'];
 $T_TopicAuthor = $rst['T_AUTHOR'];
 $T_TopicStatus = $rst['T_STATUS'];
 $T_TopicSticky = $rst['T_STICKY'];
 $T_TopicHidden = $rst['T_HIDDEN'];

 }
 
 	$Tmember = "SELECT * FROM " . $Prefix . "MEMBERS ";
    $Tmember .= " WHERE MEMBER_ID = '$T_TopicAuthor' ";
	$RTmember = mysql_query($Tmember, $connection) or die (mysql_error());

 if(mysql_num_rows($RTmember) > 0){

 $rstm = mysql_fetch_array($RTmember);

 $T_MemberID = $rstm['MEMBER_ID'];
 $T_MemberName = $rstm['M_NAME'];

 }
 
 	$Reply = "SELECT * FROM " . $Prefix . "REPLY ";
    $Reply .= " WHERE REPLY_ID = '$r' ";
	$RReplyr = mysql_query($Reply, $connection) or die (mysql_error());

 if(mysql_num_rows($RReplyr) > 0){

 $rsR = mysql_fetch_array($RReplyr);

 $R_ReplyID = $rsR['REPLY_ID'];
 $R_ReplyMessage = $rsR['R_MESSAGE'];

 }
 

 $SIG = mysql_query("SELECT * FROM " . $Prefix . "MEMBERS WHERE MEMBER_ID = '$DBMemberID' ") or die (mysql_error());

 if(mysql_num_rows($SIG) > 0){

 $rsSIG = mysql_fetch_array($SIG);

 $SIG_MemberID = $rsSIG['MEMBER_ID'];
 $SIG_MemberName = $rsSIG['M_NAME'];
 $SIG_MemberSig = $rsSIG['M_SIG'];

 }

 $ReplyMsg = mysql_query("SELECT * FROM " . $Prefix . "PM WHERE PM_ID = '$msg' ") or die (mysql_error());

 if(mysql_num_rows($ReplyMsg) > 0){

 $rsRM = mysql_fetch_array($ReplyMsg);

 $RM_PmID = $rsRM['PM_ID'];
 $RM_To = $rsRM['PM_TO'];
 $RM_From = $rsRM['PM_FROM'];
 $RM_Subject = $rsRM['PM_SUBJECT'];

 }
 
if ($method == "replymsg") {
  if ($RM_From > 0) {

    $MEMBER_FROM = mysql_query("SELECT * FROM ".$Prefix."MEMBERS WHERE MEMBER_ID = '$RM_From' ") or die (mysql_error());

    if(mysql_num_rows($MEMBER_FROM) > 0){

    $rsMF=mysql_fetch_array($MEMBER_FROM);

    $MF_MemberID = $rsMF['MEMBER_ID'];
    $MF_MemberName = $rsMF['M_NAME'];
    }
  }
  if ($RM_From < 0) {

    $id = abs($RM_From);

    $FORUM_FROM = mysql_query("SELECT * FROM ".$Prefix."FORUM WHERE FORUM_ID = '$id' ") or die (mysql_error());

    if(mysql_num_rows($FORUM_FROM) > 0){

    $rsFF=mysql_fetch_array($FORUM_FROM);

    $FF_ForumID = $rsFF['FORUM_ID'];
    $FF_ForumSubject = $rsFF['F_SUBJECT'];

    $MF_MemberID = '-'.$FF_ForumID;
    $MF_MemberName = '����� '.$FF_ForumSubject;

    }
  }
}
    
    
    
if ($method == "sendmsg") {
  if ($m > 0) {

    $MEMBER_FROM = mysql_query("SELECT * FROM ".$Prefix."MEMBERS WHERE MEMBER_ID = '$m' ") or die (mysql_error());

    if(mysql_num_rows($MEMBER_FROM) > 0){

    $rsMF=mysql_fetch_array($MEMBER_FROM);

    $MF_MemberID = $rsMF['MEMBER_ID'];
    $MF_MemberName = $rsMF['M_NAME'];
    }
  }
  if ($m < 0) {

    $id = abs($m);
    
    $FORUM_FROM = mysql_query("SELECT * FROM ".$Prefix."FORUM WHERE FORUM_ID = '$id' ") or die (mysql_error());

    if(mysql_num_rows($FORUM_FROM) > 0){

    $rsFF=mysql_fetch_array($FORUM_FROM);

    $FF_ForumID = $rsFF['FORUM_ID'];
    $FF_ForumSubject = $rsFF['F_SUBJECT'];

    $MF_MemberID = '-'.$FF_ForumID;
    $MF_MemberName = '����� '.$FF_ForumSubject;
    
    }
  }
}
    

if ($Mlevel > 0) {



if ($method == "topic") {
    if ($Mlevel == 1 AND $C_CatStatus == 0) {
    go_to("index.php?mode=msg&err=1");
    }
    if ($Mlevel == 1 AND $F_ForumStatus == 0) {
    go_to("index.php?mode=msg&err=2");
    }
}
if ($method == "edit") {
    if ($Mlevel == 1 AND $C_CatStatus == 0) {
    go_to("index.php?mode=msg&err=3");
    }
    if ($Mlevel == 1 AND $F_ForumStatus == 0) {
    go_to("index.php?mode=msg&err=4");
    }
    if ($Mlevel == 1 AND $T_TopicStatus == 0) {
    go_to("index.php?mode=msg&err=5");
    }
    if ($Mlevel == 1 AND $T_TopicAuthor != $DBMemberID) {
    go_to("index.php?mode=msg&err=6");
    }
}
if ($method == "reply") {
    if ($Mlevel == 1 AND $C_CatStatus == 0) {
    go_to("index.php?mode=msg&err=7");
    }
    if ($Mlevel == 1 AND $F_ForumStatus == 0) {
    go_to("index.php?mode=msg&err=8");
    }
    if ($Mlevel == 1 AND $T_TopicStatus == 0) {
    go_to("index.php?mode=msg&err=9");
    }
    if ($Mlevel == 1 AND $T_TopicHidden == 1 AND $T_TopicAuthor != $DBMemberID) {
    go_to("index.php?mode=msg&err=10");
    }
}
if ($method == "editreply") {
    if ($Mlevel == 1 AND $C_CatStatus == 0) {
    go_to("index.php?mode=msg&err=11");
    }
    if ($Mlevel == 1 AND $F_ForumStatus == 0) {
    go_to("index.php?mode=msg&err=12");
    }
}
if ($method == "replymsg") {
$PM_TO = $RM_From;
}
if ($method == "sendmsg") {
$PM_TO = $MF_MemberID;
}
echo'
<SCRIPT language=JavaScript src="editor.js"></SCRIPT>
<table class="topholder" height="100%" cellSpacing="0" cellPadding="0" width="100%" border="0">
	<tr>
		<td>
		<table class="topholder" dir="rtl" cellSpacing="2" width="100%" border="0">
        <form name="add_post" method="post" action="index.php?mode=post_info">

		<input name="method" type="hidden" value="'.$method.'">
		<input name="r" type="hidden" value="'.$r.'">
		<input name="t" type="hidden" value="'.$t.'">
		<input name="f" type="hidden" value="'.$f.'">
		<input name="c" type="hidden" value="'.$c.'">
        <input name="m" type="hidden" value="'.$m.'">
        <input name="pm_to" type="hidden" value="'.$PM_TO.'">
        <input name="msg" type="hidden" value="'.$RM_PmID.'">
		<input name="refer" type="hidden" value="'.$HTTP_REFERER.'">
        <input name="host" type="hidden" value="'.$HTTP_HOST.'">';


if ($method == "topic" OR $method == "edit" OR $method == "editreply" OR $method == "reply") {

$Photo =  '<a class="menu" href="index.php?mode=f&f='.$F_ForumID.'">'.icons($image_folder."forum-logo/".$F_ForumLogo, "", "").'</a>';
$Subject = '<a href="index.php?mode=f&f='.$F_ForumID.'">'.$F_ForumSubject.'</a></font>&nbsp;&nbsp;-&nbsp;'.$txt.'&nbsp;&nbsp;&nbsp;';
}
if ($method == "sig") {
$Photo =  '<a class="menu" href="index.php?mode=profile&type=details">'.icons($details, "", "").'</a>';
$Subject = '<a class="menu" href="index.php?mode=profile&type=details">����� ����� �����</a></font>';
}
if ($method == "replymsg") {
  if ($PM_TO > 0) {
    $Photo =  '<a class="menu" href="index.php?mode=pm&mail=msg&msg='.$msg.'">'.icons($monitor, "", "").'</a>';
    $Subject = '<a class="menu" href="index.php?mode=pm&mail=msg&msg='.$msg.'">����� ���:</a></font>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<a href="index.php?mode=profile&id='.$MF_MemberID.'"><font color="red" size="+1">'.$MF_MemberName.'</font></a>';
    $Subject .= '<br><nobr>����� �������: <input maxLength="100" name="subject" value="'.$RM_Subject.'" style="WIDTH: 400px"></nobr>';
  }
  if ($PM_TO < 0) {

  $MF_MemberID = abs($PM_TO);

    $Photo =  '<a class="menu" href="index.php?mode=pm&mail=msg&msg='.$msg.'">'.icons($monitor, "", "").'</a>';
    $Subject = '<a class="menu" href="index.php?mode=pm&mail=msg&msg='.$msg.'">����� ���:</a></font>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<a href="index.php?mode=f&f='.$MF_MemberID.'"><font color="red" size="+1">'.$MF_MemberName.'</font></a>';
    $Subject .= '<br><nobr>����� �������: <input maxLength="100" name="subject" value="'.$RM_Subject.'" style="WIDTH: 400px"></nobr>';
  }
}

if ($method == "sendmsg") {
  if ($m > 0) {
    $Photo =  '<a href="index.php?mode=profile&id='.$MF_MemberID.'">'.icons($monitor, "", "").'</a>';
    $Subject = '<a class="menu" href="index.php?mode=profile&id='.$MF_MemberID.'">����� ���:</a></font>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<a href="index.php?mode=profile&id='.$MF_MemberID.'"><font color="red" size="+1">'.$MF_MemberName.'</font></a>';
    $Subject .= '<br><nobr>����� �������: <input maxLength="100" name="subject" value="������� �� '.$DBUserName.' ��� '.$MF_MemberName.'" style="WIDTH: 400px"></nobr>';
  }
  if ($m < 0) {

  $MF_MemberID = abs($m);
  
    $Photo =  '<a href="index.php?mode=f&f='.$MF_MemberID.'">'.icons($monitor, "", "").'</a>';
    $Subject = '<a class="menu" href="index.php?mode=f&f='.$MF_MemberID.'">����� ���:</a></font>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<a href="index.php?mode=f&f='.$MF_MemberID.'"><font color="red" size="+1">'.$MF_MemberName.'</font></a>';
    $Subject .= '<br><nobr>����� �������: <input maxLength="100" name="subject" value="������� �� '.$DBUserName.' ��� '.$MF_MemberName.'" style="WIDTH: 400px"></nobr>';
  }
}

            echo'
            <tr>
                <td>'.$Photo.'</td>

                <td class="main" vAlign="center" width="100%"><font size="+1">'.$Subject;

if ($Mlevel == 4 OR $Monitor_all == 1 OR $Moderator_all == 1) {

if ($method == "edit") {
    if ($T_TopicHidden == 1) {
           echo'<input name="hidden" class="checkbox" type="checkbox" value="1" checked><font color="black" size="2">&nbsp;����&nbsp;&nbsp;</font>';
    }
    if ($T_TopicHidden == 0) {
           echo'<input name="hidden" class="checkbox" type="checkbox" value="1"><font color="black" size="2">&nbsp;����&nbsp;&nbsp;</font>';
    }
    if ($T_TopicStatus == 0) {
           echo'<input name="lock" class="checkbox" type="checkbox" value="1" checked><font color="black" size="2">&nbsp;����&nbsp;&nbsp;</font>';
    }
    if ($T_TopicStatus == 1) {
           echo'<input name="lock" class="checkbox" type="checkbox" value="1"><font color="black" size="2">&nbsp;����&nbsp;&nbsp;</font>';
    }
    if ($T_TopicSticky == 1) {
           echo'<input name="sticky" class="checkbox" type="checkbox" value="1" checked><font color="black" size="2">&nbsp;����</font>';
    }
    if ($T_TopicSticky == 0) {
           echo'<input name="sticky" class="checkbox" type="checkbox" value="1"><font color="black" size="2">&nbsp;����</font>';
    }
}
if ($method == "topic") {
           
           echo'<input name="hidden" class="checkbox" type="checkbox" value="1"><font color="black" size="2">&nbsp;����&nbsp;&nbsp;</font>';
           echo'<input name="lock" class="checkbox" type="checkbox" value="1"><font color="black" size="2">&nbsp;����&nbsp;&nbsp;</font>';
           echo'<input name="sticky" class="checkbox" type="checkbox" value="1"><font color="black" size="2">&nbsp;����</font>';
}

}
                echo'
                </td>';
if ($method == "topic" OR $method == "edit" OR $method == "editreply" OR $method == "reply") {
                echo'
                <td class="menu" align="middle"><nobr><a target="_new" href="index.php?mode=rules">���� ���<br>������ ����<br>���������</a></nobr></td>';
}
            echo'
            </tr>';
if ($method == "sig") {
$T_TopicMessage = $SIG_MemberSig;
}
if ($method == "reply" OR $method == "editreply") {
            echo'
            <tr>
                <td class="main" colSpan="2"><font size="3"><a href="index.php?mode=t&t='.$T_TopicID.'">�������: '.$T_TopicSubject.'</a></font> - ������: '.$T_MemberName.'</td>
            </tr>';
$T_TopicMessage = $R_ReplyMessage;
}
if ($method == "topic" OR $method == "edit") {

            echo'
            <tr>
                <td colSpan="2">����� �������: <input maxLength="100" name="subject" value="'.$T_TopicSubject.'" style="WIDTH: 400px"></td>
            </tr>';
}
?>
        </table>
        </td>
    </tr>
	<tr>
		<td>
		    <table style="display: block; border-left: 1px solid #d9d9d9; border-right: 1px solid #e0e0e0; border-top: 1px solid #d9d9d9; background: #f2f2f6" cellSpacing="0" cellPadding="1" width="100%" border="0" valign="center">
			<tr>
                <td width="100%"></td>                         
			</tr>
		</table>
		</td>
	</tr>
    <tr>
		<td height="100%">
		<table height="100%" cellSpacing="0" cellPadding="0" width="100%">
			<tr>
				<td>
				<table height="100%" cellSpacing="0" cellPadding="0" width="100%" border="0">
					<tr>
						<td vAlign="top"><textarea style="width: 913px; HEIGHT: 100%; BACKGROUND: #ffffff" name="message"><? print $T_TopicMessage; ?></textarea></td>
						<td vAlign="top" align="middle" width="90" bgColor="orange">
                        <table width="90" cellSpacing="0" cellPadding="2">
                            <tr>
                                <td height="10" colspan="3"></td>
                            </tr>
                            <tr>
                                <td align="middle"><a href="javascript:happy()"><img border="0" width="25" height="25" src="images/smiles/icon_smile_happy.gif"></a></td>
                                <td align="middle"><a href="javascript:big()"><img border="0" width="25" height="25" src="images/smiles/icon_smile_big.gif"></a></td>
                                <td align="middle"><a href="javascript:cool()"><img border="0" width="25" height="25" src="images/smiles/icon_smile_cool.gif"></a></td>
                            </tr>
                            <tr>
                                <td align="middle"><a href="javascript:blush()"><img border="0" width="25" height="25" src="images/smiles/icon_smile_blush.gif"></a></td>
                                <td align="middle"><a href="javascript:tongue()"><img border="0" width="25" height="25" src="images/smiles/icon_smile_tongue.gif"></a></td>
                                <td align="middle"><a href="javascript:evil()"><img border="0" width="25" height="25" src="images/smiles/icon_smile_evil.gif"></a></td>
                            </tr>
                            <tr>
                                <td align="middle"><a href="javascript:wink()"><img border="0" width="25" height="25" src="images/smiles/icon_smile_wink.gif"></a></td>
                                <td align="middle"><a href="javascript:clown()"><img border="0" width="25" height="25" src="images/smiles/icon_smile_clown.gif"></a></td>
                                <td align="middle"><a href="javascript:blackeye()"><img border="0" width="25" height="25" src="images/smiles/icon_smile_blackeye.gif"></a></td>
                            </tr>
                            <tr>
                                <td align="middle"><a href="javascript:ball()"><img border="0" width="25" height="25" src="images/smiles/icon_smile_ball.gif"></a></td>
                                <td align="middle"><a href="javascript:sad()"><img border="0" width="25" height="25" src="images/smiles/icon_smile_sad.gif"></a></td>
                                <td align="middle"><a href="javascript:shy()"><img border="0" width="25" height="25" src="images/smiles/icon_smile_shy.gif"></a></td>
                            </tr>
                            <tr>
                                <td align="middle"><a href="javascript:shock()"><img border="0" width="25" height="25" src="images/smiles/icon_smile_shock.gif"></a></td>
                                <td align="middle"><a href="javascript:angry()"><img border="0" width="25" height="25" src="images/smiles/icon_smile_angry.gif"></a></td>
                                <td align="middle"><a href="javascript:dead()"><img border="0" width="25" height="25" src="images/smiles/icon_smile_dead.gif"></a></td>
                            </tr>
                            <tr>
                                <td align="middle"><a href="javascript:kisses()"><img border="0" width="25" height="25" src="images/smiles/icon_smile_kisses.gif"></a></td>
                                <td align="middle"><a href="javascript:approve()"><img border="0" width="25" height="25" src="images/smiles/icon_smile_approve.gif"></a></td>
                                <td align="middle"><a href="javascript:dissapprove()"><img border="0" width="25" height="25" src="images/smiles/icon_smile_dissapprove.gif"></a></td>
                            </tr>
                            <tr>
                                <td align="middle"><a href="javascript:sleepy()"><img border="0" width="25" height="25" src="images/smiles/icon_smile_sleepy.gif"></a></td>
                                <td align="middle"><a href="javascript:question()"><img border="0" width="25" height="25" src="images/smiles/icon_smile_question.gif"></a></td>
                                <td align="middle"><a href="javascript:rotating()"><img border="0" width="25" height="25" src="images/smiles/icon_smile_rotating.gif"></a></td>
                            </tr>
                            <tr>
                                <td align="middle"><a href="javascript:eyebrows()"><img border="0" width="25" height="25" src="images/smiles/icon_smile_eyebrows.gif"></a></td>
                                <td align="middle"><a href="javascript:hearteyes()"><img border="0" width="25" height="25" src="images/smiles/icon_smile_hearteyes.gif"></a></td>
                                <td align="middle"><a href="javascript:crying()"><img border="0" width="25" height="25" src="images/smiles/icon_smile_crying.gif"></a></td>
                            </tr>
                            <tr>
                                <td align="middle"><a href="javascript:nono()"><img border="0" width="25" height="25" src="images/smiles/icon_smile_nono.gif"></a></td>
                                <td align="middle"><a href="javascript:wailing()"><img border="0" width="25" height="25" src="images/smiles/icon_smile_wailing.gif"></a></td>
                                <td align="middle"><a href="javascript:joker()"><img border="0" width="25" height="25" src="images/smiles/icon_smile_joker.gif"></a></td>
                            </tr>
                        </table>
                        </td>
					</tr>
				</table>
				</td>
			</tr>
			<tr height="22">
				<td vAlign="top" noWrap width="100%">
					<table dir="rtl" style="border-left: 1px solid #d9d9d9; border-right: 1px solid #e0e0e0; border-top: 1px solid #d9d9d9; background: #f2f2f6" cellSpacing="0" cellPadding="3" width="100%" border="0">
					<tr>
						<td align="left" width="100%">
                        <input type="submit" value="����� ����">&nbsp;&nbsp;
                        <input type="reset" value="����� ���� ������">&nbsp;&nbsp;
                        <input type="button" value="���� ��������" onclick="window.close();"></td>
					</tr>
				</table>
				</td>
			</tr>
		</table>
		</td>
	</tr>
</table>

<?

}
else {
redirect();
}
    
mysql_close();
?>
