<?
/*//////////////////////////////////////////////////////////
// ######################################################///
// # DuhokForum 0.2                                     # //
// ###################################################### //
// #                                                    # //
// #       --  DUHOK FORUM IS FREE SOFTWARE  --         # //
// #                                                    # //
// #   ========= Programming By Dilovan ==============  # //
// # Copyright � 2007 Dilovan. All Rights Reserved      # //
// #----------------------------------------------------# //
// #----------------------------------------------------# //
// # If you want any support vist down address:-        # //
// # Email: df@duhoktimes.com                           # //
// # Site: http://df.duhoktimes.com/index.php           # //
// ###################################################### //
//////////////////////////////////////////////////////////*/

if ($f == "") {
 redirect();
}

if(!isset($_GET['pg']))
{
$pag = 1;
}
else
{
$pag = $_GET['pg'];
}

$start = (($pag * $max_page) - $max_page);
$f = $_GET['f'];
$total_res = mysql_result(mysql_query("SELECT COUNT(TOPIC_ID) FROM " . $Prefix . "TOPICS WHERE FORUM_ID = '$f'"),0);
$total_col = ceil($total_res / $max_page);

if ($pg == "p") {

$pg = $_POST["numpg"];
$f = $_GET['f'];

 echo'<script language="JavaScript" type="text/javascript">
 window.location = "index.php?mode=f&f='.$f.'&pg='.$pg.'";
 </script>';

}

function paging($total_col, $pag) {


$f = $_GET['f'];

		echo '
        <form method="post" action="index.php?mode=f&f='.$f.'&pg=p">
        <td class="optionsbar_menus">

		<b>������ :</b>
        <select name="numpg" size="1" onchange="submit();">';


        for($i = 1; $i <= $total_col; $i++) {
            if(($pag) == $i) {
		        echo '<option selected value="'.$i.'">'.$i.' �� '.$total_col.'</option>';
            }
            else {
		        echo '<option value="'.$i.'">'.$i.' �� '.$total_col.'</option>';
            }
        }

		echo '
        </select>

		</td>
		</form>';

}

$queryF = "SELECT * FROM " . $Prefix . "FORUM WHERE FORUM_ID = '$f' ";
$resultF = mysql_query($queryF, $connection) or die (mysql_error());

if(mysql_num_rows($resultF) > 0){
$rsF=mysql_fetch_array($resultF);

$F_CatID = $rsF['CAT_ID'];
$F_ForumID = $rsF['FORUM_ID'];
$F_ForumSubject = $rsF['F_SUBJECT'];
$F_ForumLogo = $rsF['F_LOGO'];

}

$Monitor = chk_monitor($DBMemberID, cat_id($f));
$Moderator = chk_moderator($DBMemberID, $f);


//##################################### �������� ########################################

 	$queryMod = "SELECT mo.MOD_ID, mo.FORUM_ID, mo.MEMBER_ID, me.MEMBER_ID, me.M_NAME FROM " . $Prefix . "MODERATOR AS mo INNER JOIN " . $Prefix . "MEMBERS AS me ";
    $queryMod .= " WHERE mo.FORUM_ID = ".$F_ForumID." AND mo.MEMBER_ID = me.MEMBER_ID ";
	$queryMod .= " ORDER BY mo.MOD_ID ASC";
	$resultMod = mysql_query($queryMod, $connection) or die (mysql_error());

	$numMod = mysql_num_rows($resultMod);

$iMod=0;
while ($iMod < $numMod) {

    $Mod['mod_id'] = mysql_result($resultMod, $iMod, "mo.MOD_ID");
    $Mod['forum_id'] = mysql_result($resultMod, $iMod, "mo.FORUM_ID");
    $Mod['MOmember_id'] = mysql_result($resultMod, $iMod, "mo.MEMBER_ID");
    $Mod['MEmember_id'] = mysql_result($resultMod, $iMod, "me.MEMBER_ID");
    $Mod['member_name'] = mysql_result($resultMod, $iMod, "me.M_NAME");




 if ($numMod == 1){
     $ForumModerator = "<nobr>".normal_profile($Mod['member_name'], $Mod['MEmember_id'])."</nobr>";
 }
 else {
     $ForumModerator = $ForumModerator;
     if ($ForumModerator != "") {
        $ForumModerator .= "<nobr>  +  ";
     }
     $ForumModerator .= normal_profile($Mod['member_name'], $Mod['MEmember_id'])."</nobr>";
 }


    ++$iMod;
}
//##################################### �������� ########################################

$f_c_id = '-'.$F_ForumID;
$forum_new_pm = mysql_query("SELECT count(*) FROM ".$Prefix."PM WHERE PM_MID = '$f_c_id' AND PM_OUT = '0' AND PM_READ = '0' AND PM_STATUS = '1' ") or die(mysql_error());
$new_pm_count = mysql_result($forum_new_pm, 0, "count(*)");
if ($new_pm_count > 0) {
$new_pm_count = '(<font color="red">'.$new_pm_count.'</font>)<br>';
}
else {
$new_pm_count = '';
}

echo'
<center>
<table dir="rtl" cellSpacing="0" cellPadding="0" width="99%" border="0">
	<tr>
		<td>
		<table cellSpacing="2" width="100%" border="0">
			<tr>
				<td><a class="menu" href="index.php?mode=f&f='.$F_ForumID.'">'.icons($image_folder."forum-logo/".$F_ForumLogo, "", "").'</a></td>
                <td class="main" vAlign="center" width="100%">
                <a class="menu" href="index.php?mode=f&f='.$F_ForumID.'"><nobr><font color="red" size="+1">'.$F_ForumSubject.'</font></nobr></a>
                <font size="-1">
				<table class="mods" cellSpacing="0" cellPadding="0">
					<tr>';
                    if ($ForumModerator != "") {
                        echo'
						<td><nobr>&nbsp;������:&nbsp;</nobr></td>
						<td>'.$ForumModerator.'</td>';
                    }
                    echo'
					</tr>
				</table></font>
				</td>
                <td width="100%">&nbsp;</td>';
            if ($Mlevel > 0) {
                echo'<td class="optionsbar_menus"><a href="index.php?mode=editor&method=topic&f='.$F_ForumID.'&c='.$F_CatID.'"><nobr><img src="'.$folder_new.'" border="0"><br>����� ����</nobr></a></td>';
                echo'<td class="optionsbar_menus"><a href="index.php?mode=editor&method=sendmsg&m=-'.$F_ForumID.'"><nobr>���� ����� <br>������<br>��� �������</nobr></a></td>';
            }
            if ($Mlevel == 4 OR $Monitor == 1 OR $Moderator == 1) {
                echo'<td class="optionsbar_menus"><a href="index.php?mode=pm&mail=in&m=-'.$F_ForumID.'&c='.$F_CatID.'"><nobr>'.$new_pm_count.'����<br>�������</nobr></a></td>';
            }
            if ($total_res > 0) {
                paging($total_col, $pag);
            }
                include("go_to.php");
            echo'
			</tr>
		</table>
		<table class="grid" dir="rtl" cellSpacing="0" cellPadding="0" width="100%" align="center" border="0">
			<tr>
				<td>
				<table dir="rtl" cellSpacing="1" cellPadding="2" width="100%" border="0">
					<tr>
						<td class="cat" colSpan="2">��������</td>
						<td class="cat">������</td>
						<td class="cat">������</td>
						<td class="cat">����</td>
						<td class="cat">��� ��</td>';
                   if ($Mlevel > 0) {
						echo'<td class="cat">��������</td>';
                   }
				echo'</tr>';

 	$queryT = "SELECT * FROM " . $Prefix . "TOPICS AS T INNER JOIN  " . $Prefix . "MEMBERS AS M ";
    $queryT .= " WHERE T.CAT_ID = '$F_CatID' AND T.FORUM_ID = '$F_ForumID' AND M.MEMBER_ID = T.T_AUTHOR ";
	$queryT .= " ORDER BY T.T_STICKY DESC, T.T_LAST_POST_DATE DESC, T.T_DATE DESC LIMIT $start, $max_page";

	$resultT = mysql_query($queryT, $connection) or die (mysql_error());

	$numT = mysql_num_rows($resultT);


	if ($numT <= 0) {


                      echo'
                      <tr>
                          <td class="f1" vAlign="center" align="middle" colspan="20"><br><br>�� ���� ��� ������ �� ��� �������<br><br><br></td>
                      </tr>';
	}

$iT=0;
while ($iT < $numT) {

    $T_CatID = mysql_result($resultT, $iT, "T.CAT_ID");
    $T_ForumID = mysql_result($resultT, $iT, "T.FORUM_ID");
    $T_TopicID = mysql_result($resultT, $iT, "T.TOPIC_ID");
    $T_TopicStatus = mysql_result($resultT, $iT, "T.T_STATUS");
    $T_TopicSubject = mysql_result($resultT, $iT, "T.T_SUBJECT");
    $T_TopicAuthor = mysql_result($resultT, $iT, "T.T_AUTHOR");
    $T_TopicReplies = mysql_result($resultT, $iT, "T.T_REPLIES");
    $T_TopicCount = mysql_result($resultT, $iT, "T.T_COUNTS");
    $T_TopicLastPostDate = mysql_result($resultT, $iT, "T.T_LAST_POST_DATE");
    $T_TopicDate = mysql_result($resultT, $iT, "T.T_DATE");
    $T_TopicLastPostAuthor = mysql_result($resultT, $iT, "T.T_LAST_POST_AUTHOR");
    $T_TopicArchiveFlag = mysql_result($resultT, $iT, "T.T_ARCHIVE_FLAG");
    $T_TopicSticky = mysql_result($resultT, $iT, "T.T_STICKY");
    $T_TopicHidden = mysql_result($resultT, $iT, "T.T_HIDDEN");
    $T_TopicTop = mysql_result($resultT, $iT, "T.T_TOP");
    $T_TopicLinkForum = mysql_result($resultT, $iT, "T.T_LINKFORUM");
    $T_TopicMemberID = mysql_result($resultT, $iT, "M.MEMBER_ID");
    $T_TopicMemberName = mysql_result($resultT, $iT, "M.M_NAME");


 $queryMM = "SELECT * FROM " . $Prefix . "MEMBERS WHERE MEMBER_ID = '" .$T_TopicLastPostAuthor."' ";
 $resultMM = mysql_query($queryMM, $connection) or die (mysql_error());

 if(mysql_num_rows($resultMM) > 0){
 $rsMM = mysql_fetch_array($resultMM);

 $R_MemberID = $rsMM['MEMBER_ID'];
 $R_MemberName = $rsMM['M_NAME'];
 }
if ($T_TopicHidden == 1) {

    if ($Mlevel == 4 OR $Monitor == 1 OR $Moderator == 1 OR $T_TopicAuthor == $DBMemberID) {

                    echo'
					<tr class="deleted">
						<td class="list_center">&nbsp;<nobr><a href="index.php?mode=t&t='.$T_TopicID.'"><img hspace="0"';
      
                    if ($T_TopicStatus == 0 AND $T_TopicReplies < 20) {
                        echo 'alt="����� ����" src="'.$folder_new_locked.'"';
                    }
                    elseif ($T_TopicStatus == 0 AND $T_TopicReplies >= 20) {
                        echo 'alt="����� ��� �����" src="'.$folder_new_locked.'"';
                    }
                    elseif ($T_TopicStatus == 1 AND $T_TopicReplies < 20) {
                        echo 'alt="" src="'.$folder_new.'"';
                    }
                    elseif ($T_TopicStatus == 1 AND $T_TopicReplies >= 20) {
                        echo 'alt="����� ���" src="'.$folder_new_hot.'"';
                    }
                    else {
                        echo 'alt="" src="'.$folder.'"';
                    }
                    
                        echo'border="0"></a></nobr></td>
						<td class="list">
						<table cellPadding="0" cellsapcing="0">
							<tr>
								<td><a href="index.php?mode=t&t='.$T_TopicID.'">'.$T_TopicSubject.'</a>&nbsp;</td>
							</tr>
						</table>
						</td>
      
						<td class="list_small" noWrap>'.normal_time($T_TopicDate).'<br>'.link_profile($T_TopicMemberName, $T_TopicMemberID, $Prefix).'</td>
						<td class="list_small">'.$T_TopicReplies.'</td>
						<td class="list_small">'.$T_TopicCount.'</td>
						<td class="list_small" noWrap>';
						
                    if ($T_TopicReplies > 0) {
                        echo '<font color="red">'.normal_time($T_TopicLastPostDate).'</font><br>'.link_profile($R_MemberName, $T_TopicLastPostAuthor, $Prefix);
                    }
                        echo '</td>';
                        
                    if ($Mlevel > 0) {

						echo'<td class="list_small" noWrap>';
      
                if ($Mlevel == 4 OR $Monitor == 1 OR $Moderator == 1) {
                    if ($T_TopicStatus == 1) {
                        echo'<a href="index.php?mode=lock&type=t&t='.$T_TopicID.'&f='.$T_ForumID.'&c='.$T_CatID.'"  onclick="return confirm(\'�� ��� ����� ��� ���� ��� ��� ������� �\');"><img hspace="2" alt="��� �������" src="'.$icon_lock.'" border="0"></a>';
                    }
                    if ($T_TopicStatus == 0) {
                        echo'<a href="index.php?mode=open&type=t&t='.$T_TopicID.'&f='.$T_ForumID.'&c='.$T_CatID.'"  onclick="return confirm(\'�� ��� ����� ��� ���� ��� ��� ������� �\');"><img hspace="2" alt="��� �������" src="'.$icon_unlock.'" border="0"></a>';
                    }
                    if ($T_TopicSticky == 0) {
                        echo'<a href="index.php?mode=lock&type=s&t='.$T_TopicID.'&f='.$T_ForumID.'&c='.$T_CatID.'"  onclick="return confirm(\'�� ��� ����� ��� ���� ����� ��� ������� �\');"><img hspace="2" alt="����� �������" src="'.$folder_topic_sticky.'" border="0"></a>';
                    }
                    if ($T_TopicSticky == 1) {
                        echo'<a href="index.php?mode=open&type=s&t='.$T_TopicID.'&f='.$T_ForumID.'&c='.$T_CatID.'"  onclick="return confirm(\'�� ��� ����� ��� ���� ����� ����� ��� ������� �\');"><img hspace="2" alt="����� ����� �������" src="'.$folder_topic_unsticky.'" border="0"></a>';
                    }
                        echo'<a href="index.php?mode=open&type=h&t='.$T_TopicID.'&f='.$T_ForumID.'&c='.$T_CatID.'"  onclick="return confirm(\'�� ��� ����� ��� ���� ����� ��� ������� �\');"><img hspace="2" alt="����� �������" src="'.$icon_unhidden.'" border="0"></a>';
                }
                if ($Mlevel == 4 OR $Monitor == 1 OR $Moderator == 1 OR $T_TopicStatus == 1 AND $T_TopicAuthor == $DBMemberID) {
                        echo'<a href="index.php?mode=editor&method=edit&t='.$T_TopicID.'&f='.$F_ForumID.'&c='.$F_CatID.'"><img hspace="2" alt="����� �������" src="'.$icon_edit.'" border="0"></a>';
                }
                if ($Mlevel == 4 OR $Monitor == 1) {
                        echo'<a href="index.php?mode=delete&type=t&t='.$T_TopicID.'&f='.$T_ForumID.'&c='.$T_CatID.'"  onclick="return confirm(\'�� ��� ����� ��� ���� ��� ��� ������� �\');""><img hspace="2" alt="��� �������" src="'.$icon_trash.'" border="0"></a>';
                }
                if ($Mlevel > 0 OR $T_TopicStatus == 1) {
                        echo'<a href="index.php?mode=editor&method=reply&t='.$T_TopicID.'&f='.$F_ForumID.'&c='.$F_CatID.'"><img hspace="2" alt="�� ��� �������" src="'.$icon_reply_topic.'" border="0"></a>';
                }
                        echo'</td>';
                    }

                    echo'
					</tr>';
    }
}
else {

if ($T_TopicSticky == 1) {
$TrClass = "fixed";
}
else {
$TrClass = "normal";
}


                    echo'
					<tr class="'.$TrClass.'">
						<td class="list_center">&nbsp;<nobr><a href="index.php?mode=t&t='.$T_TopicID.'"><img hspace="0"';

                    if ($T_TopicStatus == 0 AND $T_TopicReplies < 20) {
                        echo 'alt="����� ����" src="'.$folder_new_locked.'"';
                    }
                    elseif ($T_TopicStatus == 0 AND $T_TopicReplies >= 20) {
                        echo 'alt="����� ��� �����" src="'.$folder_new_locked.'"';
                    }
                    elseif ($T_TopicStatus == 1 AND $T_TopicReplies < 20) {
                        echo 'alt="" src="'.$folder_new.'"';
                    }
                    elseif ($T_TopicStatus == 1 AND $T_TopicReplies >= 20) {
                        echo 'alt="����� ���" src="'.$folder_new_hot.'"';
                    }
                    else {
                        echo 'alt="" src="'.$folder.'"';
                    }

                        echo'border="0"></a></nobr></td>
						<td class="list">
						<table cellPadding="0" cellsapcing="0">
							<tr>
								<td><a href="index.php?mode=t&t='.$T_TopicID.'">'.$T_TopicSubject.'</a>&nbsp;</td>
							</tr>
						</table>
						</td>

						<td class="list_small" noWrap>'.normal_time($T_TopicDate).'<br>'.link_profile($T_TopicMemberName, $T_TopicMemberID, $Prefix).'</a></td>
						<td class="list_small">'.$T_TopicReplies.'</td>
						<td class="list_small">'.$T_TopicCount.'</td>
						<td class="list_small" noWrap>';
                    if ($T_TopicReplies > 0) {
                        echo '<font color="red">'.normal_time($T_TopicLastPostDate).'</font><br>'.link_profile($R_MemberName, $T_TopicLastPostAuthor, $Prefix);
                    }
                        echo '</td>';

                    if ($Mlevel > 0) {

						echo'<td class="list_small" noWrap>';

                if ($Mlevel == 4 OR $Monitor == 1 OR $Moderator == 1) {
                    if ($T_TopicStatus == 1) {
                        echo'<a href="index.php?mode=lock&type=t&t='.$T_TopicID.'&f='.$T_ForumID.'&c='.$T_CatID.'"  onclick="return confirm(\'�� ��� ����� ��� ���� ��� ��� ������� �\');"><img hspace="2" alt="��� �������" src="'.$icon_lock.'" border="0"></a>';
                    }
                    if ($T_TopicStatus == 0) {
                        echo'<a href="index.php?mode=open&type=t&t='.$T_TopicID.'&f='.$T_ForumID.'&c='.$T_CatID.'"  onclick="return confirm(\'�� ��� ����� ��� ���� ��� ��� ������� �\');"><img hspace="2" alt="��� �������" src="'.$icon_unlock.'" border="0"></a>';
                    }
                    if ($T_TopicSticky == 0) {
                        echo'<a href="index.php?mode=lock&type=s&t='.$T_TopicID.'&f='.$T_ForumID.'&c='.$T_CatID.'"  onclick="return confirm(\'�� ��� ����� ��� ���� ����� ��� ������� �\');"><img hspace="2" alt="����� �������" src="'.$folder_topic_sticky.'" border="0"></a>';
                    }
                    if ($T_TopicSticky == 1) {
                        echo'<a href="index.php?mode=open&type=s&t='.$T_TopicID.'&f='.$T_ForumID.'&c='.$T_CatID.'"  onclick="return confirm(\'�� ��� ����� ��� ���� ����� ����� ��� ������� �\');"><img hspace="2" alt="����� ����� �������" src="'.$folder_topic_unsticky.'" border="0"></a>';
                    }
                        echo'<a href="index.php?mode=lock&type=h&t='.$T_TopicID.'&f='.$T_ForumID.'&c='.$T_CatID.'"  onclick="return confirm(\'�� ��� ����� ��� ���� ����� ��� ������� �\');"><img hspace="2" alt="����� �������" src="'.$icon_hidden.'" border="0"></a>';
                }
                if ($Mlevel == 4 OR $Monitor == 1 OR $Moderator == 1 OR $T_TopicStatus == 1 AND $T_TopicAuthor == $DBMemberID) {
                        echo'<a href="index.php?mode=editor&method=edit&t='.$T_TopicID.'&f='.$F_ForumID.'&c='.$F_CatID.'"><img hspace="2" alt="����� �������" src="'.$icon_edit.'" border="0"></a>';
                }
                if ($Mlevel == 4 OR $Monitor == 1) {
                        echo'<a href="index.php?mode=delete&type=t&t='.$T_TopicID.'&f='.$T_ForumID.'&c='.$T_CatID.'"  onclick="return confirm(\'�� ��� ����� ��� ���� ��� ��� ������� �\');""><img hspace="2" alt="��� �������" src="'.$icon_trash.'" border="0"></a>';
                }
                if ($Mlevel > 0 OR $T_TopicStatus == 1) {
                        echo'<a href="index.php?mode=editor&method=reply&t='.$T_TopicID.'&f='.$F_ForumID.'&c='.$F_CatID.'"><img hspace="2" alt="�� ��� �������" src="'.$icon_reply_topic.'" border="0"></a>';
                }
                        echo'</td>';
                    }

                    echo'
					</tr>';
}
     
      ++$iT;
}
                echo'
				</table>
				</td>
			</tr>
		</table>
		</td>
	</tr>
</table>
</center>
';

mysql_close();
?>
