<?
/*//////////////////////////////////////////////////////////
// ######################################################///
// # DuhokForum 0.2                                     # //
// ###################################################### //
// #                                                    # //
// #       --  DUHOK FORUM IS FREE SOFTWARE  --         # //
// #                                                    # //
// #   ========= Programming By Dilovan ==============  # //
// # Copyright � 2007 Dilovan. All Rights Reserved      # //
// #----------------------------------------------------# //
// #----------------------------------------------------# //
// # If you want any support vist down address:-        # //
// # Email: df@duhoktimes.com                           # //
// # Site: http://df.duhoktimes.com/index.php           # //
// ###################################################### //
//////////////////////////////////////////////////////////*/

 session_start();

$user_name = $HTTP_POST_VARS["user_name"];
$user_pass = $HTTP_POST_VARS["user_pass"];
 
if ($method == "login") {
 $_SESSION['DFName'] = $user_name;
 $_SESSION['DFPass'] = $user_pass;
 head('index.php');
}

if ($method == "logout") {
 session_unset();
 session_destroy();
 head('index.php');
}

$load_user_name = $_SESSION['DFName'];
$load_user_pass = $_SESSION['DFPass'];
$load_user_pass = MD5($load_user_pass);

echo'
<html dir="rtl">
<head>
<title>'.$forum_title.'</title>
<META http-equiv=Content-Type content="text/html; charset=windows-1256">
<META content="DUHOK FORUM 1.0: Copyright (C) 2007-2008 Dilovan." name=copyright>
<META http-equiv="Page-Enter" content="blendTrans(Duration=0)">
<META http-equiv="Page-Exit" content="blendTrans(Duration=0)">
<link rel="stylesheet" href="styles/style_green.CSS">
<script type="text/javascript">
function load_body(){parent.document.title = ("'.$DF.' - "+parent.document.title);}
</script>
</head>
<BODY dir="rtl" onload="load_body();" leftMargin="0" topMargin="0" marginheight="0" marginwidth="0">';
$coda = codding($forum_title, $site_name, $copy_right);

 $Start = mysql_query("SELECT * FROM ".$Prefix."MEMBERS WHERE M_NAME = '$load_user_name' AND M_PASSWORD = '$load_user_pass' AND M_STATUS = 1 ") or die (mysql_error());

 if(mysql_num_rows($Start) > 0){
 $rsStart = mysql_fetch_array($Start);

 $DBMemberID = $rsStart['MEMBER_ID'];
 $DBUserName = $rsStart['M_NAME'];
 $DBPassword = $rsStart['M_PASSWORD'];
 $DBMemberPosts = $rsStart['M_POSTS'];
 $Mlevel = $rsStart['M_LEVEL'];
 }
 else {
 $DBMemberID = "0";
 $DBUserName = "0";
 $DBPassword = "0";
 $DBMemberPosts = "0";
 $Mlevel = "0";
 }

 if ($DBUserName == $load_user_name AND $DBPassword == $load_user_pass) {
 $Memberlogin = 1;
 }
 else {
 $Memberlogin = 0;
 }


$LoginLastIP = $_SERVER["REMOTE_ADDR"];
$LoginDate = time();

if ($Memberlogin == 1){
 $queryLog = "UPDATE ".$Prefix."MEMBERS SET M_LAST_IP = '$LoginLastIP', M_LAST_HERE_DATE = '$LoginDate' WHERE MEMBER_ID = '$DBMemberID' ";
 mysql_query($queryLog, $connection) or die (mysql_error());
}

if ($mode != "editor") {

echo'<table class="topholder" dir="rtl" cellSpacing="0" cellPadding="0" width="100%">
       <tr>

           <td>

           <table class="menubar" dir="rtl" cellSpacing="1" cellPadding="0" width="100%">
                  <tr>
                      <td width="100%"><a href="index.php">'.icons($logo, $forum_title, "").'</td>';

if ($Memberlogin == 1){

                      echo'<td class="optionsbar_menus2" vAlign="top"><nobr><a href="index.php">'.icons($Home, "", "").'<br>������ �������</a></nobr></td>';
                      
                      //echo'<td class="optionsbar_menus2" vAlign="top"><nobr><a href="index.php">'.icons($yourposts, "", "").'<br>��������</a></nobr></td>';

                      echo'<td class="optionsbar_menus2" vAlign="top"><nobr><a href="index.php?mode=members">'.icons($members, "", "").'<br>�������</a></nobr></td>';

                      echo'<td class="optionsbar_menus2" vAlign="top"><nobr><a href="index.php?mode=pm&mail=in">'.icons($messages, "", "").'<br>�������</a></nobr></td>';
                      
                      //echo'<td class="optionsbar_menus2" vAlign="top"><nobr><a href="index.php">'.icons($active, "", "").'<br>������ ����</a></nobr></td>';
                      
                      //echo'<td class="optionsbar_menus2" vAlign="top"><nobr><a href="index.php">'.icons($search, "", "").'<br>����</a></nobr></td>';

                      //echo'<td class="optionsbar_menus2" vAlign="top"><nobr><a href="index.php">'.icons($help, "", "").'<br>������</a></nobr></td>';

                      echo'<td class="optionsbar_menus2" vAlign="top"><nobr><a href="index.php?mode=profile&type=details">'.icons($details, "", "").'<br>�������</a></nobr></td>';

                      if ($Mlevel == 4) {
                      echo'<td class="optionsbar_menus2" vAlign="top"><nobr><a href="login.php">'.icons($admin, "", "").'<br>�������</a></nobr></td>';
                      }
                      
                      echo'<td class="optionsbar_menus2" vAlign="top"><nobr><a href="index.php?method=logout" onclick="return confirm(\'�� ��� ����� ��� ���� ����� �����̿\');">'.icons($exit, "", "").'<br>����</a></nobr></td>';

}

else {
                      echo'<td class="optionsbar_menus2" vAlign="top"><nobr><a href="index.php">'.icons($Home, "", "").'<br>������ �������</a></nobr></td>';
                      
                      echo'<td class="optionsbar_menus2" vAlign="top"><nobr><a href="index.php?mode=members">'.icons($members, "", "").'<br>�������</a></nobr></td>';
                      
                      //echo'<td class="optionsbar_menus2" vAlign="top"><nobr><a href="index.php">'.icons($active, "", "").'<br>������ ����</a></nobr></td>';
                      
                      //echo'<td class="optionsbar_menus2" vAlign="top"><nobr><a href="index.php">'.icons($help, "", "").'<br>������</a></nobr></td>';
                      
                      echo'<td class="optionsbar_menus2" vAlign="top"><nobr><a href="index.php?mode=register">'.icons($details, "", "").'<br>��� ���� ����</a></nobr></td>';

}

                  echo'</tr>
           </table>

           </td>

       </tr>

       <tr>

           <td>

 ';


if ($Memberlogin == 1){



           echo'<table class="userbar" dir="rtl" cellSpacing="0" cellPadding="0" width="100%" border="0">
                  <tr>
                      <td vAlign="center">

                      <table cellSpacing="0" cellPadding="0">

                             <tr>
                                 <td class="user" align="left"><nobr><a href="index.php?mode=profile&type=details">�����:</a></nobr></td>
                                 <td class="user"><nobr><a href="index.php?mode=profile&type=details">&nbsp;<font color="red">'.$DBUserName.'</font></a></nobr></td>
                             </tr>

                             <tr>
                                 <td class="user" align="left"><nobr><a href="index.php?mode=profile&id='.$DBMemberID.'">���������:</a></nobr></td>
                                 <td class="user"><nobr><a href="index.php?mode=profile&id='.$DBMemberID.'">&nbsp;<font color="red">'.$DBMemberPosts.'</font></a></nobr></td>
                             </tr>';
                             
    $PmCount = mysql_query("SELECT count(*) FROM ".$Prefix."PM WHERE PM_MID = '$DBMemberID' AND PM_OUT = '0' AND PM_READ = '0' AND PM_STATUS = '1' ") or die(mysql_error());
    $NewPm = mysql_result($PmCount, 0, "count(*)");

                      if ($NewPm > 0) {
                             echo'<tr>
                                 <td class="user" align="left"><nobr><a href="index.php?mode=pm&mail=new">����� �����:</a></nobr></td>
                                 <td class="user"><nobr><a href="index.php?mode=pm&mail=new">&nbsp;<font color="red">'.$NewPm.'</font></a></nobr></td>
                             </tr>';
                      }
                      echo'
                      </table>

                      </td>

                      <td width="100%">&nbsp;</td>
                      <td align="left">
                      <table border="0" cellPadding="1" cellSpacing="2">';
                      if ($Mlevel > 1) {
                             echo'
                             <tr>
                                 <td class="optionsbar_menus"><nobr><a href="index.php?mode=svc">�����</a></nobr></td>
                             </tr>';
                      }
                      echo'
                      </table>
                      </td>
                  </tr>
           </table>';

}

else {
				echo'<table class="grid" dir="rtl" height="100%" cellSpacing="0" cellPadding="0" border="0">
                     <form method="POST" action="index.php?method=login">
                     
						<tr>
							<td class="cat" align="middle" colSpan="4">���� �������</td>
						</tr>
						<tr>
							<td class="f2ts" align="left"><font color="red"><b>�����:</b></font></td>
							<td class="f2ts"><input type="text" class="small" style="WIDTH: 100px" name="user_name"></td>
							<td class="f2ts" align="left"><font color="red"><nobr><b>������ ������:</b></nobr></font></td>
							<td class="f2ts"><input type="password" class="small" style="WIDTH: 100px" name="user_pass"></td>
						</tr>
        				<tr>
          					<td colspan="3" class="f2ts" align="right">
							<select name="SavePassword">
							<option value="true">���� ���� ������ ������ �� ��� ������</option>
                            <option value="false">���� ���� - �� ���� ������� �������� �������</option>
							</select>
                            <td class="f2ts" vAlign="top" align="left"><input class="small" src="'.$login.'" type="image" border="0" value="����"></td>
						</tr>
        				<tr>
                            <td colspan="3" class="f2ts" align="right"><a class="menu" href="index.php?mode=forget_pass"> �� ���� ������ �����ɿ ���� ���..</a></td>
                            <td class="f2ts" align="right"></td>
        				</tr>
					</form>
				</table>';
}


           echo'
           <br></td>
       </tr>
</table>';


}
?>
