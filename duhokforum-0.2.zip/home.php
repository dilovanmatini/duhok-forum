<?php
/*//////////////////////////////////////////////////////////
// ######################################################///
// # DuhokForum 0.2                                     # //
// ###################################################### //
// #                                                    # //
// #       --  DUHOK FORUM IS FREE SOFTWARE  --         # //
// #                                                    # //
// #   ========= Programming By Dilovan ==============  # //
// # Copyright � 2007 Dilovan. All Rights Reserved      # //
// #----------------------------------------------------# //
// #----------------------------------------------------# //
// # If you want any support vist down address:-        # //
// # Email: df@duhoktimes.com                           # //
// # Site: http://df.duhoktimes.com/index.php           # //
// ###################################################### //
//////////////////////////////////////////////////////////*/

/*
echo'<table class="mainheader" dir="rtl" cellSpacing="0" cellPadding="5" width="100%" border="0">
       </tr>
            <td vAlign="center" align="right"><nobr>�� ������ ����:&nbsp;&nbsp; �����:<font class="online">0</font>&nbsp;&nbsp; ������: <font class="online">0</font>&nbsp;&nbsp; ����: <font class="online">0</font></nobr></td>
                <td class="main" vAlign="center" align="left"></td>
       </tr>
</table>';
*/

if ($Mlevel == 4) {

echo'
<center>
<table dir="rtl" cellSpacing="0" cellPadding="0" width="99%" border="0">
    <tr>
        <td>
        <table class="grid" dir="rtl" cellSpacing="1" cellPadding="3" width="100%" border="0">
            <tr>
                <td class="cat" align="middle">';

                echo'<a href="index.php?mode=add_cat_forum&method=add&type=c">'.icons($folder_new, "����� ��� �����", "hspace=\"3\"").'</a>';
                echo'<a href="index.php?mode=order">'.icons($folder_new_order, "����� ���� ��������", "hspace=\"3\"").'</a>';
                
                echo'</td>
            </tr>
        </table>
        </td>
    </tr>
</table>
</center>';

}


echo'<center>
<table dir="rtl" cellSpacing="0" cellPadding="0" width="99%" border="0">
       <tr>
           <td>
               <table class="grid" dir="rtl" cellSpacing="1" cellPadding="3" width="100%" border="0">';


	$query = "SELECT * FROM " . $Prefix . "CATEGORY ";
	$query .= " ORDER BY CAT_ORDER ASC";
	$result = mysql_query($query, $connection) or die (mysql_error());

	$num = mysql_num_rows($result);


	if ($num <= 0) {


                      echo'
                      <tr>
                          <td class="f1" vAlign="center" align="middle"><br><br>�� ���� ��� ���<br><br><br></td>
                      </tr>';
	}


$i=0;
while ($i < $num) {

    $CCat_ID = mysql_result($result, $i, "CAT_ID");
    $CCatName = mysql_result($result, $i, "CAT_NAME");
    $CCatStatus = mysql_result($result, $i, "CAT_STATUS");
    $CCatMonitor = mysql_result($result, $i, "CAT_MONITOR");


                      echo'<tr>
                          <td class="cat" vAlign="top" align="right">'.$CCatName.'</b></td>
                          <td class="cat" align="middle">������</td>
                          <td class="cat" align="middle">����</td>';
                          
                          //<td class="cat" align="middle"><nobr><img border="0" src="'.$icon_group.'"></nobr></td>
                          
                          echo'
                          <td class="cat" align="middle"><nobr>��� ������</nobr></td>
                          <td class="cat" align="middle" width="70">���������</td>
                          <td class="cat" align="middle">��������</td>';
                      if ($Mlevel == 4) {
                          echo'<td class="cat" align="middle">';
		

		echo'<a href="index.php?mode=add_cat_forum&method=add&type=f&c='.$CCat_ID.'">'.icons($folder_new, "����� ����� ����", "hspace=\"3\"").'</a>';
        echo'<a href="index.php?mode=add_cat_forum&method=edit&type=c&c='.$CCat_ID.'">'.icons($folder_new_edit, "����� �����", "hspace=\"3\"").'</a>';
        if ($CCatStatus == 1) {
		echo'<a href="index.php?mode=lock&type=c&c='.$CCat_ID.'"  onclick="return confirm(\'�� ��� ����� ��� ���� ��� ��� ����� �\');">'.icons($folder_new_locked, "��� �����", "hspace=\"3\"").'</a>';
        }
        if ($CCatStatus == 0) {
        echo'<a href="index.php?mode=open&type=c&c='.$CCat_ID.'"  onclick="return confirm(\'�� ��� ����� ��� ���� ��� ��� ����� �\');">'.icons($folder_new_unlocked, "��� �����", "hspace=\"3\"").'</a>';
        }
        echo'<a href="index.php?mode=delete&type=c&c='.$CCat_ID.'"  onclick="return confirm(\'�� ��� ����� ��� ���� ��� ��� ����� �\');">'.icons($folder_new_delete, "��� �����", "hspace=\"3\"").'</a>';
		echo'</td>';
                      }
                      echo'
                      </tr>';
                      
 	$query1 = "SELECT * FROM " . $Prefix . "FORUM AS F INNER JOIN " . $Prefix . "MEMBERS AS M ";
    $query1 .= " WHERE F.CAT_ID = '$CCat_ID' AND M.MEMBER_ID = F.F_LAST_POST_AUTHOR ";
	$query1 .= " ORDER BY F.F_ORDER ASC";
	$result1 = mysql_query($query1, $connection) or die (mysql_error());

	$num1 = mysql_num_rows($result1);


	if ($num1 <= 0) {


                      echo'
                      <tr>
                          <td class="f1" vAlign="center" align="middle" colspan="20"><br><br>�� ���� ��� ����� ���� �����<br><br><br></td>
                      </tr>';
	}

$i1=0;
while ($i1 < $num1) {

    $FForum_ID = mysql_result($result1, $i1, "F.FORUM_ID");
    $FCat_ID = mysql_result($result1, $i1, "F.CAT_ID");
    $FForumName = mysql_result($result1, $i1, "F.F_SUBJECT");
    $FForumStatus = mysql_result($result1, $i1, "F.F_STATUS");
    $FForumDesc = mysql_result($result1, $i1, "F.F_DESCRIPTION");
    $FForumTopics = mysql_result($result1, $i1, "F.F_TOPICS");
    $FForumReplies = mysql_result($result1, $i1, "F.F_REPLIES");
    $FForumLastPostDate = mysql_result($result1, $i1, "F.F_LAST_POST_DATE");
    $FForumLastPostAuthor = mysql_result($result1, $i1, "F.F_LAST_POST_AUTHOR");
    $FForumLogo = mysql_result($result1, $i1, "F.F_LOGO");
    $FMemberID = mysql_result($result1, $i1, "M.MEMBER_ID");
    $FMemberName = mysql_result($result1, $i1, "M.M_NAME");

//##################################### �������� ########################################

 	$queryMod = "SELECT mo.MOD_ID, mo.FORUM_ID, mo.MEMBER_ID, me.MEMBER_ID, me.M_NAME FROM " . $Prefix . "MODERATOR AS mo INNER JOIN " . $Prefix . "MEMBERS AS me ";
    $queryMod .= " WHERE mo.FORUM_ID = ".$FForum_ID." AND mo.MEMBER_ID = me.MEMBER_ID ";
	$queryMod .= " ORDER BY mo.MOD_ID ASC";
	$resultMod = mysql_query($queryMod, $connection) or die (mysql_error());

	$numMod = mysql_num_rows($resultMod);

$iMod=0;
while ($iMod < $numMod) {

    $Mod['mod_id'] = mysql_result($resultMod, $iMod, "mo.MOD_ID");
    $Mod['forum_id'] = mysql_result($resultMod, $iMod, "mo.FORUM_ID");
    $Mod['MOmember_id'] = mysql_result($resultMod, $iMod, "mo.MEMBER_ID");
    $Mod['MEmember_id'] = mysql_result($resultMod, $iMod, "me.MEMBER_ID");
    $Mod['member_name'] = mysql_result($resultMod, $iMod, "me.M_NAME");




 if ($numMod == 1){
     $ForumModerator = "<nobr>".normal_profile($Mod['member_name'], $Mod['MEmember_id'])."</nobr>";
 }
 else {
     $ForumModerator = $ForumModerator;
     if ($ForumModerator != "") {
        $ForumModerator .= "<nobr>  +  ";
     }
     $ForumModerator .= normal_profile($Mod['member_name'], $Mod['MEmember_id'])."</nobr>";
 }

 
    ++$iMod;
}

//##################################### �������� ########################################


                      echo'<tr>
                          <td class="f1">
                              <table width="100%">
                                     <tr>
                                         <td class="logo" align="middle" width="55">'.icons($image_folder."forum-logo/".$FForumLogo, "", "").'</td>
                                         <td class="f1"><a href="index.php?mode=f&f='.$FForum_ID.'">'.$FForumName.'</a><br><font size="1">'.$FForumDesc.'</font></td>
                                     </tr>
                              </table>
                          </td>
                          <td class="f2ts" vAlign="center" align="middle">
                              <table width="100%">
                                     <tr>
                                         <td>';

                                     if ($FForumStatus == 0) {
                                         echo icons($folder_locked, "����� ����", "");
                                     }
                                     else {
                                         echo icons($folder, "����� �����", "");
                                     }

                                         echo'</td>
                                         <td class="f2ts" vAlign="center" align="middle">'.$FForumTopics.'</td>
                                     </tr>
                              </table>
                          </td>
                          <td class="f2ts">'.$FForumReplies.'</td>';
                          //<td class="f2ts" width="25">0</a></td>
                          echo'<td class="f2ts">';
                      if ($FMemberName != "") {
                          if ($FForumReplies != 0) {
                          echo'
                          <nobr>'.normal_time($FForumLastPostDate).'<br>'.link_profile($FMemberName, $FMemberID, $Prefix);
                          }
                      }
                          echo'
                          </td>';
                      

 $queryMem = "SELECT * FROM " . $Prefix . "MEMBERS WHERE MEMBER_ID = '$CCatMonitor' ";
 $resultMem = mysql_query($queryMem, $connection) or die (mysql_error());

 if(mysql_num_rows($resultMem) > 0){

 $rsMem=mysql_fetch_array($resultMem);

 $MEMMemberID = $rsMem['MEMBER_ID'];
 $MEMMemberName = $rsMem['M_NAME'];
 }
 else {
 $MEMMemberID = "";
 $MEMMemberName = "";
 }

                          echo'
                          <td class="f1m" valign="top">
                              <table cellSpacing="0" cellPadding="0">
                                     <tr>
                                         <td style="FONT-SIZE: 75%" align="center" valign="top">&nbsp;<nobr>'.normal_profile($MEMMemberName, $MEMMemberID, $Prefix).'</nobr></td>
                                     </tr>
                              </table>
                          </td>';
                          
                          
                          if ($FForum_ID == $Mod['forum_id']) {
                          echo'<td dir="ltr" width="28%" class="f1m" valign="top"><div align="right">'.$ForumModerator.'</div></td>';
                          }
                          else {
                          echo'<td dir="ltr" width="28%" class="f1m" valign="top"><div align="right">&nbsp;</div></td>';
                          }



                      if ($Mlevel == 4) {
                          echo'<td class="f2ts">';

    echo'<a href="index.php?mode=editor&method=topic&f='.$FForum_ID.'&c='.$CCat_ID.'">'.icons($folder, "����� ����� ���� ���� �������", "hspace=\"3\"").'</a>';
    echo'<a href="index.php?mode=add_cat_forum&method=edit&type=f&f='.$FForum_ID.'">'.icons($folder_edit, "����� �������", "hspace=\"3\"").'</a>';
    if ($FForumStatus == 1) {
	echo'<a href="index.php?mode=lock&type=f&f='.$FForum_ID.'&c='.$CCat_ID.'"  onclick="return confirm(\'�� ��� ����� ��� ���� ��� ��� ������� �\');">'.icons($folder_locked, "��� �������", "hspace=\"3\"").'</a>';
    }
    if ($FForumStatus == 0) {
    echo'<a href="index.php?mode=open&type=f&f='.$FForum_ID.'&c='.$CCat_ID.'"  onclick="return confirm(\'�� ��� ����� ��� ���� ��� ��� ������� �\');">'.icons($folder_unlocked, "��� �������", "hspace=\"3\"").'</a>';
    }
    echo'<a href="index.php?mode=delete&type=f&f='.$FForum_ID.'&c='.$CCat_ID.'"  onclick="return confirm(\'�� ��� ����� ��� ���� ��� ��� ������� �\');">'.icons($folder_delete, "��� �������", "hspace=\"3\"").'</a>';
                          echo'</td>';
                      }
                      echo'</tr>';
                      
    ++$i1;
}
                      
    ++$i;
}
               echo'</table>
           </td>
       </tr>
</table>
</center>';
print $coda;
mysql_close();
?>

