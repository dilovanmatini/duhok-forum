<?php
/*//////////////////////////////////////////////////////////
// ######################################################///
// # DuhokForum 0.2                                     # //
// ###################################################### //
// #                                                    # //
// #       --  DUHOK FORUM IS FREE SOFTWARE  --         # //
// #                                                    # //
// #   ========= Programming By Dilovan ==============  # //
// # Copyright � 2007 Dilovan. All Rights Reserved      # //
// #----------------------------------------------------# //
// #----------------------------------------------------# //
// # If you want any support vist down address:-        # //
// # Email: df@duhoktimes.com                           # //
// # Site: http://df.duhoktimes.com/index.php           # //
// ###################################################### //
//////////////////////////////////////////////////////////*/

function redirect(){
  echo'
  <script language="JavaScript" type="text/javascript">
    window.location="index.php";
  </script>
  ';
}

function head($link){
 header('Location: '.$link);
 exit();
}

function go_to($link){
echo'<script language="JavaScript" type="text/javascript">
window.location="'.$link.'";
</script>';
}

function icons($url,$title,$any){
    $icon="<img border=\"0\" src=\"".$url."\" alt=\"".$title."\" ".$any.">";
    return($icon);
}

function normal_profile($m_name,$m_id){
    global $Prefix;
    $normal_profile="<a href=\"index.php?mode=profile&id=".$m_id."\">".$m_name."</a>";
    return($normal_profile);
}

function link_profile($m_name,$m_id){
    global $Prefix;
    $resultLP = mysql_query("SELECT * FROM ".$Prefix."MEMBERS WHERE MEMBER_ID='$m_id' ") or die(mysql_error());
    if(mysql_num_rows($resultLP)>0){
        $rsLP=mysql_fetch_array($resultLP);
        $LP_MemberID=$rsLP['MEMBER_ID'];
        $LP_MemberLevel=$rsLP['M_LEVEL'];
        $LP_MemberStatus=$rsLP['M_STATUS'];
    }
    if($LP_MemberLevel==1&&$LP_MemberStatus==1){
        $link_profile="<a href=\"index.php?mode=profile&id=".$m_id."\">".$m_name."</a>";
    }
    if($LP_MemberLevel==1&&$LP_MemberStatus==0){
        $link_profile="<a href=\"index.php?mode=profile&id=".$m_id."\"><font color=\"#999999\">".$m_name."</font></a>";
    }
    if($LP_MemberLevel==2){
        $link_profile="<a href=\"index.php?mode=profile&id=".$m_id."\"><font color=\"#cc0033\">".$m_name."</font></a>";
    }
    if($LP_MemberLevel==3){
        $link_profile="<a href=\"index.php?mode=profile&id=".$m_id."\"><font color=\"#cc8811\">".$m_name."</font></a>";
    }
    if($LP_MemberLevel==4){
        $link_profile="<a href=\"index.php?mode=profile&id=".$m_id."\"><font color=\"blue\">".$m_name."</font></a>";
    }
    return($link_profile);
}

function admin_profile($m_name,$m_id){
    global $Prefix;
    $resultLP2=mysql_query("SELECT * FROM ".$Prefix."MEMBERS WHERE MEMBER_ID='$m_id' ") or die(mysql_error());
    if(mysql_num_rows($resultLP2)>0){
        $rsLP2=mysql_fetch_array($resultLP2);
        $LP2_MemberID=$rsLP2['MEMBER_ID'];
        $LP2_MemberLevel=$rsLP2['M_LEVEL'];
        $LP2_MemberStatus=$rsLP2['M_STATUS'];
    }
    if($LP2_MemberLevel==4){
        $admin_profile="<a href=\"index.php?mode=profile&id=".$m_id."\">".$m_name."</a>";
    }
    if($LP2_MemberLevel<4){
        $admin_profile="<a href=\"index.php?mode=profile&id=".$m_id."\">".$m_name."</a>";
    }
    return($admin_profile);
}

function normal_time($date){
    $DateYear=date("Y/",$date);
    $NowYear=date("Y/");
    $NormalMonth=date("m/",$date);
    $DateDay=date("d",$date);
    $NowDay=date("d");
    $yesterday=time()-(60*1440);
    $NowDay2=date("d",$yesterday);
    $DateTime=date("H:i",$date);
    if($DateYear==$NowYear){
        $NormalYear="";
    }
    else{
        $NormalYear=$DateYear;
    }
    if($DateDay==$NowDay&&$DateYear==$NowYear){
        $normal_time=$DateTime." - �����";
    }
    elseif($DateDay==$NowDay2&&$DateYear==$NowYear){
        $normal_time=$DateTime." - ��� ���";
    }
    else{
        $normal_time=$DateTime." - ".$NormalYear.$NormalMonth.$DateDay;
    }
    return($normal_time);
}

function members_time($m_date){
    $DateYear=date("Y/",$m_date);
    $NowYear=date("Y/");
    $NormalMonth=date("m/",$m_date);
    $DateDay=date("d",$m_date);
    $NowDay=date("d");
    $yesterday=time()-(60*1440);
    $NowDay2=date("d",$yesterday);
    if($DateYear==$NowYear){
        $NormalYear="";
    }
    else{
        $NormalYear=$DateYear;
    }
    if($DateDay==$NowDay&&$DateYear==$NowYear){
        $normal_date="�����";
    }
    elseif($DateDay==$NowDay2&&$DateYear==$NowYear){
        $normal_date="��� ���";
    }
    else{
        $normal_date=$NormalYear.$NormalMonth.$DateDay;
    }
    return($normal_date);
}

function normal_date($date){

 $date = date("Y/m/d", $date);

return($date);
}

function chk_moderator($m,$f){

    global $Prefix;
    
 if ($m > 0) {

    $sql = mysql_query("SELECT * FROM ".$Prefix."MEMBERS WHERE MEMBER_ID = '$m' ") or die(mysql_error());
    $m_num = mysql_num_rows($sql);
    $m_rows = mysql_fetch_array($sql);
    if ($m_num > 0) {
      if ($m_rows[M_LEVEL] > 1) {
        $m_level = 1;
      }
      else {
        $m_level = 0;
      }
    }
    else {
      $m_level = 0;
    }

    $resultChkMod=mysql_query("SELECT * FROM ".$Prefix."MODERATOR WHERE MEMBER_ID='$m' AND FORUM_ID='$f' ") or die(mysql_error());
    if(mysql_num_rows($resultChkMod)>0){
      if ($m_level == 1) {
        $chk_mod=1;
      }
    }
    else{
        $chk_mod=0;
    }
  }
    return($chk_mod);
}

function chk_monitor($m,$c){

    global $Prefix;
    
  if ($m > 0) {

    $sql = mysql_query("SELECT * FROM ".$Prefix."MEMBERS WHERE MEMBER_ID = '$m' ") or die(mysql_error());
    $m_num = mysql_num_rows($sql);
    $m_rows = mysql_fetch_array($sql);
    if ($m_num > 0) {
      if ($m_rows[M_LEVEL] > 1) {
        $m_level = 1;
      }
      else {
        $m_level = 0;
      }
    }
    else {
      $m_level = 0;
    }

    $resultChkMon = mysql_query("SELECT * FROM ".$Prefix."CATEGORY WHERE CAT_ID='$c' AND CAT_MONITOR='$m' ") or die(mysql_error());
    if(mysql_num_rows($resultChkMon)>0){
      if ($m_level == 1) {
        $chk_mon=1;
      }
    }
    else{
        $chk_mon=0;
    }
  }
    return($chk_mon);
}

function member_total_days($m_date){
    $m_date=time()-$m_date;
    $m_date=$m_date/84600;
    $m_date=ceil($m_date);
    return($m_date);
}

function member_middle_posts($m_posts, $m_date){
    $mtd=member_total_days($m_date);
    $mmp=$m_posts/$mtd;
    $mmp=ceil($mmp);
    return($mmp);
}

function codding($text1,$text2,$text3){
    $text='<center><table width="100%"><tr><td dir="ltr" align="middle"><nobr><font color="gray" size="-2">'.$text1.'<br><font color="black">'.$text2.'<br><font color="red">&nbsp;&nbsp;� '.$text3.'</font></font></font></nobr></td><td width="100%">&nbsp;</td>'.base64_decode("PHRkIGRpcj0ibHRyIiBhbGlnbj0ibWlkZGxlIj48Zm9udCBjb2xvcj0iZ3JheSIgc2l6ZT0iLTIiPjxub2JyPuXQxyDH4ePm3tog7dPKzs/jIMjR5MfjzDwvbm9icj48L2ZvbnQ+PGJyPjxmb250IHNpemU9Ii0yIiBjb2xvcj0iYmxhY2siPjxub2JyPkR1aG9rIEZvcnVtIDEuMTwvbm9icj48L2ZvbnQ+PGJyPjxmb250IHNpemU9Ii0yIiBjb2xvcj0icmVkIj48bm9icj4mbmJzcDsmbmJzcDupIERpbG92YW4gMjAwNyAtIDIwMDg8L25vYnI+PC9mb250PjwvdGQ+PC90cj48L3RhYmxlPjwvY2VudGVyPg==");
    return($text);
}

function open_mysql($variable){

 global $Prefix;

 $sql = mysql_query("SELECT * FROM ".$Prefix."CONFIG WHERE VARIABLE = '".$variable."' ") or die (mysql_error());
 if(mysql_num_rows($sql) > 0){
 $rs = mysql_fetch_array($sql);

 $value = $rs['VALUE'];
 }
return($value);
}

function updata_mysql($variable, $value){

 global $Prefix;

 $sql = mysql_query("UPDATE ".$Prefix."CONFIG SET VALUE = '".$value."' WHERE VARIABLE = '".$variable."' ") or die (mysql_error());

}

function insert_mysql($variable, $value){

 global $Prefix;

 $sql = mysql_query("INSERT INTO ".$Prefix."CONFIG (ID, VARIABLE, VALUE) VALUES (NULL, '".$variable."', '".$value."') ") or die (mysql_error());

}

function check_radio($value1, $value2){

 if ($value1 == $value2) {
    $value = 'CHECKED';
 }
 else {
    $value = '';
 }
return($value);
}

function check_select($value1, $value2){

 if ($value1 == $value2) {
    $value = 'selected';
 }
 else {
    $value = '';
 }
return($value);
}

function member_name($id){

 global $Prefix;

 $sql = mysql_query("SELECT * FROM ".$Prefix."MEMBERS WHERE MEMBER_ID = '".$id."' ") or die (mysql_error());
 if(mysql_num_rows($sql) > 0){
 $rs = mysql_fetch_array($sql);

 $MemberName = $rs['M_NAME'];
 }
return($MemberName);
}

function forum_name($id){

 global $Prefix;

 $sql = mysql_query("SELECT * FROM ".$Prefix."FORUM WHERE FORUM_ID = '".$id."' ") or die (mysql_error());
 if(mysql_num_rows($sql) > 0){
 $rs = mysql_fetch_array($sql);

 $Forum_Subject = $rs['F_SUBJECT'];
 }
return($Forum_Subject);
}

function cat_id($f_id){

 global $Prefix;

 $sql = mysql_query("SELECT * FROM ".$Prefix."FORUM WHERE FORUM_ID = '".$f_id."' ") or die (mysql_error());
 if(mysql_num_rows($sql) > 0){
 $rs = mysql_fetch_array($sql);

 $Cat_ID = $rs['CAT_ID'];
 }
return($Cat_ID);
}

function forum_title_count($id){

  global $Prefix;
  $Forum_Title_Count = mysql_query("SELECT count(*) FROM ".$Prefix."F_TITLES WHERE T_FORUMID = '".$id."' ") or die(mysql_error());
  $Count = mysql_result($Forum_Title_Count, 0, "count(*)");

  return($Count);
}

function member_title_count($id){

  global $Prefix;
  $Member_Title_Count = mysql_query("SELECT count(*) FROM ".$Prefix."TITLES WHERE T_MEMBERID = '".$id."' ") or die(mysql_error());
  $Count = mysql_result($Member_Title_Count, 0, "count(*)");

  return($Count);
}

function reply_member_title($m_id, $f_id){

  global $Prefix;
  
$R_Titles = mysql_query("SELECT * FROM ".$Prefix."TITLES WHERE T_MEMBERID = '$m_id' AND T_STATUS = '0' AND T_FORUMID = '$f_id' ORDER BY TITLE_ID ASC ") or die (mysql_error());
$RTitles_rows = mysql_num_rows($R_Titles);


 while ($R_Trow = @mysql_fetch_array($R_Titles)) {

    $RTitles_TitleID = $R_Trow[TITLE_ID];
    $RTitles_MemberID = $R_Trow[T_MEMBERID];
    $RTitles_ForumID = $R_Trow[T_FORUMID];
    $RTitles_Status = $R_Trow[T_STATUS];
    $RTitles_Color = $R_Trow[T_COLOR];
    $RTitles_Subject = $R_Trow[T_SUBJECT];

   if ($RTitles_rows == 1) {
       $RMember_Titles = '<font color="'.$RTitles_Color.'">'.$RTitles_Subject.'</font>';
   }
   if ($RTitles_rows > 1) {
       $RMember_Titles = $RMember_Titles;
       if ($RMember_Titles != "") {
       $RMember_Titles .= '<br>';
       }
       $RMember_Titles .= '<font color="'.$RTitles_Color.'">'.$RTitles_Subject.'</font>';
   }


 }

$RR_Titles = mysql_query("SELECT * FROM ".$Prefix."TITLES WHERE T_MEMBERID = '$m_id' AND T_STATUS = '1' ORDER BY TITLE_ID ASC ") or die (mysql_error());
$RRTitles_rows = mysql_num_rows($RR_Titles);

 while ($RR_Trow = @mysql_fetch_array($RR_Titles)) {

    $RRTitles_TitleID = $RR_Trow[TITLE_ID];
    $RRTitles_MemberID = $RR_Trow[T_MEMBERID];
    $RRTitles_ForumID = $RR_Trow[T_FORUMID];
    $RRTitles_Status = $RR_Trow[T_STATUS];
    $RRTitles_Color = $RR_Trow[T_COLOR];
    $RRTitles_Subject = $RR_Trow[T_SUBJECT];

   if ($RRTitles_rows == 1) {
       $RRMember_Titles = '<font color="'.$RRTitles_Color.'">'.$RRTitles_Subject.'</font>';
   }
   if ($RRTitles_rows > 1) {
       $RRMember_Titles = $RRMember_Titles;
       if ($RRMember_Titles != "") {
       $RRMember_Titles .= '<br>';
       }
       $RRMember_Titles .= '<font color="'.$RRTitles_Color.'">'.$RRTitles_Subject.'</font>';
   }

 }


$R_MemberTitles = $RMember_Titles;
if ($RMember_Titles != "" AND $RRMember_Titles != "") {
$R_MemberTitles .= '<br>';
}
$R_MemberTitles .= $RRMember_Titles;

  return($R_MemberTitles);
}

function profile_member_title($m_id){

  global $Prefix;

$titles = mysql_query("SELECT * FROM ".$Prefix."TITLES WHERE T_MEMBERID = '$m_id' ORDER BY TITLE_ID ASC ") or die (mysql_error());
$rows = mysql_num_rows($titles);


 while ($row = @mysql_fetch_array($titles)) {

   if ($rows == 1) {
       $tmt = $row[T_SUBJECT].' - <font color="red">'.forum_name($row[T_FORUMID]).'</font>';
   }
   if ($rows > 1) {
       $tmt = $tmt;
       if ($tmt != "") {
       $tmt .= '<br>';
       }
       $tmt .= $row[T_SUBJECT].' - <font color="red">'.forum_name($row[T_FORUMID]).'</font>';
   }
    

 }
    
  return($tmt);
}


function profile_moderator_title($m_id){

  global $Prefix;

$titles = mysql_query("SELECT * FROM ".$Prefix."TITLES WHERE T_MEMBERID = '$m_id' ORDER BY TITLE_ID ASC ") or die (mysql_error());
$rows = mysql_num_rows($titles);


 while ($row = @mysql_fetch_array($titles)) {

   if ($rows == 1) {
       $tmt = $row[T_SUBJECT].' - <font color="red">'.forum_name($row[T_FORUMID]).'</font>';
   }
   if ($rows > 1) {
       $tmt = $tmt;
       if ($tmt != "") {
       $tmt .= '<br>';
       }
       $tmt .= $row[T_SUBJECT].' - <font color="red">'.forum_name($row[T_FORUMID]).'</font>';
   }


 }
   
   
$mod = mysql_query("SELECT * FROM ".$Prefix."MODERATOR WHERE MEMBER_ID = '$m_id' ORDER BY MOD_ID ASC ") or die (mysql_error());
$m_rows = mysql_num_rows($mod);


 while ($m_row = @mysql_fetch_array($mod)) {

   if ($m_rows == 1) {
       $tmf = '<a href="index.php?mode=f&f='.$m_row[FORUM_ID].'">'.forum_name($m_row[FORUM_ID]).'</a>';
   }
   if ($m_rows > 1) {
       $tmf = $tmf;
       if ($tmf != "") {
       $tmf .= '<font color="red"> + </font>';
       }
       $tmf .= '<a href="index.php?mode=f&f='.$m_row[FORUM_ID].'">'.forum_name($m_row[FORUM_ID]).'</a>';
   }
 }

$tmt = '<font color="red">����: </font>'.$tmf.'<br>'.member_title($m_id).'<br>'.$tmt;

  return($tmt);
}

function profile_monitor_title($m_id){

  global $Prefix;

$titles = mysql_query("SELECT * FROM ".$Prefix."TITLES WHERE T_MEMBERID = '$m_id' ORDER BY TITLE_ID ASC ") or die (mysql_error());
$rows = mysql_num_rows($titles);


 while ($row = @mysql_fetch_array($titles)) {

   if ($rows == 1) {
       $tmt = $row[T_SUBJECT].' - <font color="red">'.forum_name($row[T_FORUMID]).'</font>';
   }
   if ($rows > 1) {
       $tmt = $tmt;
       if ($tmt != "") {
       $tmt .= '<br>';
       }
       $tmt .= $row[T_SUBJECT].' - <font color="red">'.forum_name($row[T_FORUMID]).'</font>';
   }


 }


$mon = mysql_query("SELECT * FROM ".$Prefix."CATEGORY WHERE CAT_MONITOR = '$m_id' ORDER BY CAT_ID ASC ") or die (mysql_error());
$m_rows = mysql_num_rows($mon);


 while ($m_row = @mysql_fetch_array($mon)) {

   if ($m_rows == 1) {
       $tmf = $m_row[CAT_NAME];
   }
   if ($m_rows > 1) {
       $tmf = $tmf;
       if ($tmf != "") {
       $tmf .= '<font color="red"> + </font>';
       }
       $tmf .= $m_row[CAT_NAME];
   }
 }

$tmt = '<font color="red">�����: </font>'.$tmf.'<br>'.member_title($m_id).'<br>'.$tmt;

  return($tmt);
}


function title_color($color){
 if ($color == "") {
   $color = '�������';
 }
 if ($color == "blue") {
   $color = '<font color="'.$color.'">����</font>';
 }
 if ($color == "black") {
   $color = '<font color="'.$color.'">����</font>';
 }
 if ($color == "red") {
   $color = '<font color="'.$color.'">����</font>';
 }
 if ($color == "yellow") {
   $color = '<font color="'.$color.'">����</font>';
 }
 if ($color == "pink") {
   $color = '<font color="'.$color.'">����</font>';
 }
 if ($color == "green") {
   $color = '<font color="'.$color.'">����</font>';
 }
 if ($color == "orange") {
   $color = '<font color="'.$color.'">�������</font>';
 }
 if ($color == "purple") {
   $color = '<font color="'.$color.'">������</font>';
 }
 if ($color == "brown") {
   $color = '<font color="'.$color.'">���</font>';
 }
 if ($color == "navy") {
   $color = '<font color="'.$color.'">����</font>';
 }
 return($color);
}

function text_replace($message){

$message = HtmlSpecialchars($message);
$message=str_replace("\n","<br>",$message);
$message=str_replace("[]","",$message);
$message=str_replace("~happy~","<img src=\"images/smiles/icon_smile_happy.gif\">",$message);
$message=str_replace("~big~","<img src=\"images/smiles/icon_smile_big.gif\">",$message);
$message=str_replace("~cool~","<img src=\"images/smiles/icon_smile_cool.gif\">",$message);
$message=str_replace("~blush~","<img src=\"images/smiles/icon_smile_blush.gif\">",$message);
$message=str_replace("~tongue~","<img src=\"images/smiles/icon_smile_tongue.gif\">",$message);
$message=str_replace("~evil~","<img src=\"images/smiles/icon_smile_evil.gif\">",$message);
$message=str_replace("~wink~","<img src=\"images/smiles/icon_smile_wink.gif\">",$message);
$message=str_replace("~clown~","<img src=\"images/smiles/icon_smile_clown.gif\">",$message);
$message=str_replace("~blackeye~","<img src=\"images/smiles/icon_smile_blackeye.gif\">",$message);
$message=str_replace("~ball~","<img src=\"images/smiles/icon_smile_ball.gif\">",$message);
$message=str_replace("~sad~","<img src=\"images/smiles/icon_smile_sad.gif\">",$message);
$message=str_replace("~shy~","<img src=\"images/smiles/icon_smile_shy.gif\">",$message);
$message=str_replace("~shock~","<img src=\"images/smiles/icon_smile_shock.gif\">",$message);
$message=str_replace("~angry~","<img src=\"images/smiles/icon_smile_angry.gif\">",$message);
$message=str_replace("~dead~","<img src=\"images/smiles/icon_smile_dead.gif\">",$message);
$message=str_replace("~kisses~","<img src=\"images/smiles/icon_smile_kisses.gif\">",$message);
$message=str_replace("~approve~","<img src=\"images/smiles/icon_smile_approve.gif\">",$message);
$message=str_replace("~dissapprove~","<img src=\"images/smiles/icon_smile_dissapprove.gif\">",$message);
$message=str_replace("~sleepy~","<img src=\"images/smiles/icon_smile_sleepy.gif\">",$message);
$message=str_replace("~question~","<img src=\"images/smiles/icon_smile_question.gif\">",$message);
$message=str_replace("~rotating~","<img src=\"images/smiles/icon_smile_rotating.gif\">",$message);
$message=str_replace("~eyebrows~","<img src=\"images/smiles/icon_smile_eyebrows.gif\">",$message);
$message=str_replace("~hearteyes~","<img src=\"images/smiles/icon_smile_hearteyes.gif\">",$message);
$message=str_replace("~crying~","<img src=\"images/smiles/icon_smile_crying.gif\">",$message);
$message=str_replace("~nono~","<img src=\"images/smiles/icon_smile_nono.gif\">",$message);
$message=str_replace("~wailing~","<img src=\"images/smiles/icon_smile_wailing.gif\">",$message);
$message=str_replace("~joker~","<img src=\"images/smiles/icon_smile_joker.gif\">",$message);

return ($message);

}

function member_stars($m_id){

    global $Prefix,$StarsNomber,$StarsColor,$Stars;

    $MStars=mysql_query("SELECT * FROM ".$Prefix."MEMBERS WHERE MEMBER_ID='$m_id' ") or die(mysql_error());

    if(mysql_num_rows($MStars)>0){
        $rs_S=mysql_fetch_array($MStars);
        $S_MemberID=$rs_S['MEMBER_ID'];
        $S_MemberLevel=$rs_S['M_LEVEL'];
        $S_MemberStatus=$rs_S['M_STATUS'];
        $S_MemberPosts=$rs_S['M_POSTS'];
    }
if($S_MemberLevel==1){$star_color=$Stars[$StarsColor[1]];
}
if($S_MemberLevel==2){$star_color=$Stars[$StarsColor[2]];
}
if($S_MemberLevel==3){$star_color=$Stars[$StarsColor[3]];
}
if($S_MemberLevel==4){$star_color=$Stars[$StarsColor[4]];
}
if($S_MemberPosts<$StarsNomber[1]){$M_Stars="";
}
if($S_MemberPosts>=$StarsNomber[1]&&$S_MemberPosts<$StarsNomber[2]){$M_Stars=icons($star_color,"","");
}
if($S_MemberPosts>=$StarsNomber[2]&&$S_MemberPosts<$StarsNomber[3]){$M_Stars=icons($star_color,"","").icons($star_color,"","");
}
if($S_MemberPosts>=$StarsNomber[3]&&$S_MemberPosts<$StarsNomber[4]){$M_Stars=icons($star_color,"","").icons($star_color,"","").icons($star_color,"","");
}
if($S_MemberPosts>=$StarsNomber[4]&&$S_MemberPosts<$StarsNomber[5]){$M_Stars=icons($star_color,"","").icons($star_color,"","").icons($star_color,"","").icons($star_color,"","");
}
if($S_MemberPosts>=$StarsNomber[5]&&$S_MemberPosts<$StarsNomber[6]){$M_Stars=icons($star_color,"","").icons($star_color,"","").icons($star_color,"","").icons($star_color,"","").icons($star_color,"","");
}
if($S_MemberPosts>=$StarsNomber[6]&&$S_MemberPosts<$StarsNomber[7]){$M_Stars=icons($star_color,"","").icons($star_color,"","").icons($star_color,"","").icons($star_color,"","").icons($star_color,"","").'<br>'.icons($star_color,"","");
}
if($S_MemberPosts>=$StarsNomber[7]&&$S_MemberPosts<$StarsNomber[8]){$M_Stars=icons($star_color,"","").icons($star_color,"","").icons($star_color,"","").icons($star_color,"","").icons($star_color,"","").'<br>'.icons($star_color,"","").icons($star_color,"","");
}
if($S_MemberPosts>=$StarsNomber[8]&&$S_MemberPosts<$StarsNomber[9]){$M_Stars=icons($star_color,"","").icons($star_color,"","").icons($star_color,"","").icons($star_color,"","").icons($star_color,"","").'<br>'.icons($star_color,"","").icons($star_color,"","").icons($star_color,"","");
}
if($S_MemberPosts>=$StarsNomber[9]&&$S_MemberPosts<$StarsNomber[10]){$M_Stars=icons($star_color,"","").icons($star_color,"","").icons($star_color,"","").icons($star_color,"","").icons($star_color,"","").'<br>'.icons($star_color,"","").icons($star_color,"","").icons($star_color,"","").icons($star_color,"","");
}
if($S_MemberPosts>=$StarsNomber[10]){$M_Stars=icons($star_color,"","").icons($star_color,"","").icons($star_color,"","").icons($star_color,"","").icons($star_color,"","").'<br>'.icons($star_color,"","").icons($star_color,"","").icons($star_color,"","").icons($star_color,"","").icons($star_color,"","");
}
return($M_Stars);
}

function member_title($m_id){

  global $Prefix, $Title, $StarsNomber;

  $Titles=mysql_query("SELECT * FROM ".$Prefix."MEMBERS WHERE MEMBER_ID='$m_id' ") or die(mysql_error());
  if(mysql_num_rows($Titles)>0){
  $rs_T=mysql_fetch_array($Titles);
  $T_MemberID=$rs_T['MEMBER_ID'];
  $T_MemberLevel=$rs_T['M_LEVEL'];
  $T_MemberStatus=$rs_T['M_STATUS'];
  $T_MemberPosts=$rs_T['M_POSTS'];
  $T_MemberTitle=$rs_T['M_TITLE'];
  }
  if($T_MemberTitle==""){
    if($T_MemberPosts<$StarsNomber[1]){
		$m_title=$Title[0];
    }
    if($T_MemberPosts>=$StarsNomber[1]&&$T_MemberPosts<$StarsNomber[2]){
		$m_title=$Title[1];
    }
    if($T_MemberPosts>=$StarsNomber[2]&&$T_MemberPosts<$StarsNomber[3]){
		$m_title=$Title[2];
    }
    if($T_MemberPosts>=$StarsNomber[3]&&$T_MemberPosts<$StarsNomber[4]){
		$m_title=$Title[3];
    }
    if($T_MemberPosts>=$StarsNomber[4]&&$T_MemberPosts<$StarsNomber[5]){
		$m_title=$Title[4];
    }
    if($T_MemberPosts>=$StarsNomber[5]&&$T_MemberPosts<$StarsNomber[6]){
        $m_title=$Title[5];
	}
    if($T_MemberPosts>=$StarsNomber[6]&&$T_MemberPosts<$StarsNomber[7]){
        $m_title=$Title[6];
    }
    if($T_MemberPosts>=$StarsNomber[7]&&$T_MemberPosts<$StarsNomber[8]){
        $m_title=$Title[7];
	}
    if($T_MemberPosts>=$StarsNomber[8]&&$T_MemberPosts<$StarsNomber[9]){
        $m_title=$Title[8];
	}
    if($T_MemberPosts>=$StarsNomber[9]&&$T_MemberPosts<$StarsNomber[10]){
        $m_title=$Title[9];
	}
    if($T_MemberPosts>=$StarsNomber[10]){
        $m_title=$Title[10];
	}
    if($T_MemberLevel==1){
		$title=$m_title;
    }
    if($T_MemberLevel==2){
        $title=$Title[11];
    }
    if($T_MemberLevel==3){
        $title=$Title[12];
    }
    if($T_MemberLevel==4){
        $title=$Title[13];
    }
}
else{
    $title=$T_MemberTitle;
}

$title=text_replace($title);

return($title);
}


?>
