<?
$DF = "DUHOK FORUM";
/*//////////////////////////////////////////////////////////
// ######################################################///
// # DuhokForum 0.2                                     # //
// ###################################################### //
// #                                                    # //
// #       --  DUHOK FORUM IS FREE SOFTWARE  --         # //
// #                                                    # //
// #   ========= Programming By Dilovan ==============  # //
// # Copyright � 2007 Dilovan. All Rights Reserved      # //
// #----------------------------------------------------# //
// #----------------------------------------------------# //
// # If you want any support vist down address:-        # //
// # Email: df@duhoktimes.com                           # //
// # Site: http://df.duhoktimes.com/index.php           # //
// ###################################################### //
//////////////////////////////////////////////////////////*/

if ($DF == base64_decode("RFVIT0sgRk9SVU0=")) {
require_once("./include/function.php");
require_once("config.php");
require_once("icons.php");
require_once("converts.php");
require_once("header.php");



if (file_exists("install.php")) {
die("'
                    <br>
                    <center>
	                <table width=\"99%\" border=\"1\">
	                   <tr class=\"normal\">
	                       <td class=\"list_center\" colSpan=\"10\"><font size=\"5\" color=\"red\"><br>���<br>��� �� ��� ���� ��� install.php ���� ��� ���� �� ����� �������..</font><br><br>
	                       <a href=\"JavaScript:history.go(-1)\">-- ���� ��� ������ --</a><br><br>
	                       </td>
	                   </tr>
	                </table>
	                </center>
");
}

switch ($mode) {
     case "":
          require_once("home.php");
     break;
     case "f":
          require_once("forum.php");
     break;
     case "register":
          require_once("register.php");
     break;
     case "members":
          require_once("members.php");
     break;
     case "profile":
          require_once("profile.php");
     break;
     case "add_cat_forum":
          require_once("add_cat_forum.php");
     break;
     case "lock":
          require_once("lock.php");
     break;
     case "cat_forum_info":
          require_once("cat_forum_info.php");
     break;
     case "open":
          require_once("open.php");
     break;
     case "delete":
          require_once("delete.php");
     break;
     case "order":
          require_once("order.php");
     break;
     case "editor":
          require_once("editor.php");
     break;
     case "post_info":
          require_once("post_info.php");
     break;
     case "msg":
          require_once("msg.php");
     break;
     case $admin_folder:
          require_once($admin_folder."/index.php");
     break;
     case "t":
          require_once("topic.php");
     break;
     case "forget_pass":
          require_once("forget_pass.php");
     break;
     case "pm":
          require_once("message.php");
     break;
     case "sendmsg":
          require_once("send_message.php");
     break;
     case "mail":
          require_once("forum_mail.php");
     break;
     case "svc":
          require_once("svc.php");
     break;
     case "user_svc":
          require_once("user_svc.php");
     break;
}


require_once("footer.php");
}
else {
print '<div align="center"><font face="tahoma" size="2"><b>
'.base64_decode("ztjDPGJyPsfkyiDN0N3KIM3e5t4gx+HjyNHjzCDH4ePkys/s").'
</b></font></div>';
}
?>
