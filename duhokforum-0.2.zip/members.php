<?
/*//////////////////////////////////////////////////////////
// ######################################################///
// # DuhokForum 0.2                                     # //
// ###################################################### //
// #                                                    # //
// #       --  DUHOK FORUM IS FREE SOFTWARE  --         # //
// #                                                    # //
// #   ========= Programming By Dilovan ==============  # //
// # Copyright � 2007 Dilovan. All Rights Reserved      # //
// #----------------------------------------------------# //
// #----------------------------------------------------# //
// # If you want any support vist down address:-        # //
// # Email: df@duhoktimes.com                           # //
// # Site: http://df.duhoktimes.com/index.php           # //
// ###################################################### //
//////////////////////////////////////////////////////////*/

if(!isset($_GET['pg']))
{
$pag = 1;
}
else
{
$pag = $_GET['pg'];
}


$start = (($pag * $max_page) - $max_page);

$total_res = mysql_result(mysql_query("SELECT COUNT(MEMBER_ID) FROM " . $Prefix . "MEMBERS "),0);
$total_col = ceil($total_res / $max_page);

if ($pg == "p") {

$pg = $_POST["numpg"];

echo'<script language="JavaScript" type="text/javascript">
 window.location = "index.php?mode=members&pg='.$pg.'";
 </script>';
}

function paging($total_col, $pag) {

		echo '
        <form method="post" action="index.php?mode=members&pg=p">
        <td class="optionsbar_menus">

		<b>������ :</b>
        <select name="numpg" size="1" onchange="submit();">';


        for($i = 1; $i <= $total_col; $i++) {
            if(($pag) == $i) {
		        echo '<option selected value="'.$i.'">'.$i.' �� '.$total_col.'</option>';
            }
            else {
		        echo '<option value="'.$i.'">'.$i.' �� '.$total_col.'</option>';
            }
        }

		echo '
        </select>

		</td>
		</form>';

}


echo'
<center>
<table class="optionsbar" dir="rtl" cellSpacing="2" width="99%" border="0" id="table11">
	<tr>
		<td class="optionsbar_title" Align="middle" vAlign="center" width="100%">���� �����</td>';
  
paging($total_col, $pag);
include("go_to.php");
echo'
	</tr>
</table>
</center>

<table border="0"><tr><td height="5"></td></tr></table>
<center>
<table class="grid" dir="rtl" cellSpacing="1" cellPadding="2" width="99%" border="0">
	<tr>
		<td class="cat">�����</td>
		<td class="cat">�����</td>
		<td class="cat">������</td>
		<td class="cat">���������</td>
		<td class="cat">��� ������</td>
		<td class="cat">��� �����</td>
		<td class="cat">����� �������</td>';

        if ($Mlevel == 4) {
        echo'<td class="cat">������</td>';
        }

	echo'</tr>';

	$query = "SELECT * FROM " . $Prefix . "MEMBERS ";
    $query .= " ORDER BY M_POSTS DESC LIMIT $start, $max_page";
	$result = mysql_query($query, $connection) or die (mysql_error());

$num = mysql_num_rows($result);

if ($num == 0) {
    echo'
    <tr class="normal">
		<td class="list_center" vAlign="center" colspan="10"><br>�� ���� �� ��� ���� ���� �������<br><br></td>
    </tr>';
}


$i=0;
while ($i < $num) {


    $MMember_ID = mysql_result($result, $i, "MEMBER_ID");
    $MMemberStatus = mysql_result($result, $i, "M_STATUS");
    $MMemberName = mysql_result($result, $i, "M_NAME");
    $MMemberCountry = mysql_result($result, $i, "M_COUNTRY");
    $MMemberPosts = mysql_result($result, $i, "M_POSTS");
    $MMemberLastPostDate = mysql_result($result, $i, "M_LAST_POST_DATE");
    $MMemberLastHereDate = mysql_result($result, $i, "M_LAST_HERE_DATE");
    $MMemberDate = mysql_result($result, $i, "M_DATE");
    
    if ($i % 2) {
	    $bg_color="fixed";
    }
    else
    {
	    $bg_color="normal";
    }
    
    
	echo'
    <tr class="'.$bg_color.'">
		<td class="list_date" vAlign="center">'.$MMember_ID.'</td>
		<td class="list_names"><nobr><a href="index.php?mode=profile&id='.$MMember_ID.'">'.$MMemberName.'</a></nobr><br>'.member_title($MMember_ID).'</td>
		<td class="list_small">'.$MMemberCountry.'</td>
		<td class="list_small">'.$MMemberPosts.'<br>'.member_stars($MMember_ID).'</td>
		<td class="list_date">'.members_time($MMemberLastPostDate).'</td>
		<td class="list_small">'.members_time($MMemberLastHereDate).'</td>
		<td class="list_date">'.members_time($MMemberDate).'</td>';
  
        if ($Mlevel == 4) {
            echo'<td class="list_date">';
          if ($MMemberStatus == 1 && $MMember_ID != 1 && $MMember_ID != $DBMemberID) {
		    echo'<a href="index.php?mode=lock&type=m&m='.$MMember_ID.'"  onclick="return confirm(\'�� ��� ����� ��� ���� ��� ��� ������� �\');">'.icons($icon_lock, "��� �������", "hspace=\"2\"").'</a>';
          }
          if ($MMemberStatus == 0 && $MMember_ID != 1 && $MMember_ID != $DBMemberID) {
            echo'<a href="index.php?mode=open&type=m&m='.$MMember_ID.'"  onclick="return confirm(\'�� ��� ����� ��� ���� ��� ��� ������� �\');">'.icons($icon_unlock, "��� �������", "hspace=\"2\"").'</a>';
          }
          $edit_member = '<a href="index.php?mode=profile&type=edit_user&id='.$MMember_ID.'">'.icons($icon_edit, "����� �������", "hspace=\"2\"").'</a>';
          if ($MMember_ID == 1) {
              if ($DBMemberID == 1) {
              echo $edit_member;
              }
          }
          else {
              echo $edit_member;
          }
          if ($MMember_ID != 1 && $MMember_ID != $DBMemberID) {
            echo'<a href="index.php?mode=delete&type=m&m='.$MMember_ID.'"  onclick="return confirm(\'�� ��� ����� ��� ���� ��� ��� ������� �\');">'.icons($icon_trash, "��� �������", "hspace=\"2\"").'</a>';
          }
            echo'</td>';
        }
	echo'</tr>';
    ++$i;
}

echo '
</table>
</center>';

mysql_close();
?>
