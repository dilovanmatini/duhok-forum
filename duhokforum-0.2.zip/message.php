<?
/*//////////////////////////////////////////////////////////
// ######################################################///
// # DuhokForum 0.2                                     # //
// ###################################################### //
// #                                                    # //
// #       --  DUHOK FORUM IS FREE SOFTWARE  --         # //
// #                                                    # //
// #   ========= Programming By Dilovan ==============  # //
// # Copyright � 2007 Dilovan. All Rights Reserved      # //
// #----------------------------------------------------# //
// #----------------------------------------------------# //
// # If you want any support vist down address:-        # //
// # Email: df@duhoktimes.com                           # //
// # Site: http://df.duhoktimes.com/index.php           # //
// ###################################################### //
//////////////////////////////////////////////////////////*/

require_once("./include/pm_function.php");

if ($Mlevel > 0) {

$HTTP_HOST = $_SERVER['HTTP_HOST'];

$forum_new_pm = mysql_query("SELECT count(*) FROM ".$Prefix."PM WHERE PM_MID = '$m' AND PM_OUT = '0' AND PM_READ = '0' AND PM_STATUS = '1' ") or die(mysql_error());
$new_pm_count = mysql_result($forum_new_pm, 0, "count(*)");

if ($m != "" AND $m < 0 AND $Mlevel == 4 OR chk_monitor($DBMemberID, $c) OR chk_moderator($DBMemberID, abs($m))) {
    $DBMemberID = $m;
    $forum_id = '&m='.$m.'&c='.$c;
    $privat_text = '<font color="green">'.forum_name(abs($m)).'</font>';
    $NewPm = $new_pm_count;
}
else {
    $forum_id = '';
    $privat_text = '������� ������';
}



if(!isset($_GET['pg']))
{
$pag = 1;
}
else
{
$pag = $_GET['pg'];
}

$start = (($pag * $max_page) - $max_page);
if ($mail == "new") {
$where = "WHERE PM_MID = '$DBMemberID' AND PM_READ = '0' AND PM_OUT = '0' AND PM_STATUS = '1'";
}
if ($mail == "in") {
$where = "WHERE PM_MID = '$DBMemberID' AND PM_OUT = '0' AND PM_STATUS = '1'";
}
if ($mail == "out") {
$where = "WHERE PM_MID = '$DBMemberID' AND PM_OUT = '1' AND PM_STATUS = '1'";
}
if ($mail == "trash") {
$where = "WHERE PM_MID = '$DBMemberID' AND PM_STATUS = '0'";
}
if ($mail == "m") {
$where = "WHERE PM_MID = '$DBMemberID' AND PM_STATUS = '0'";
}
$total_res = mysql_result(mysql_query("SELECT COUNT(PM_ID) FROM ".$Prefix."PM ".$where." "),0);
$total_col = ceil($total_res / $max_page);

if ($pg == "p") {

$pg = $_POST["numpg"];

echo'<script language="JavaScript" type="text/javascript">
 window.location = "index.php?mode=pm&mail='.$mail.'&pg='.$pg.$forum_id.'";
 </script>';
}

function paging($total_col, $pag) {
        global $mail;
		echo '
        <form method="post" action="index.php?mode=pm&mail='.$mail.$forum_id.'&pg=p">
        <td class="optionsbar_menus">

		<b>������ :</b>
        <select name="numpg" size="1" onchange="submit();">';


        for($i = 1; $i <= $total_col; $i++) {
            if(($pag) == $i) {
		        echo '<option selected value="'.$i.'">'.$i.' �� '.$total_col.'</option>';
            }
            else {
		        echo '<option value="'.$i.'">'.$i.' �� '.$total_col.'</option>';
            }
        }

		echo '
        </select>

		</td>
		</form>';

}

?>
<script language="javascript">
    function submitQuickReplyForm() {
        var x = quickreply.message.value;

        while ((x.substring(0,1) == ' ') || (x.substring(0,1) == '\r') || (x.substring(0,1) == '\n') || (x.substring(0,1) == '\t'))
            x = x.substring(1);
        quickreply.message.value = x;

        if (quickreply.message.value.length < 3) return;
        quickreply.submit();
    }
    function submit_delete() {
        var where_to = confirm("������ ����� ��� ������� �� ���� ��������� ���� ������.\r\n�� ����� �� ������� ��� ������� ��� ���.");
	    if (where_to== false) {
            return;
	    }
        deletemsg.submit();
    }
</script>
<?

if ($mail == "new") {
 $title_mail = '������� ������� �������';
}
if ($mail == "in") {
 $title_mail = '������ ������';
}
if ($mail == "out") {
 $title_mail = '������ ������';
}
if ($mail == "trash") {
 $title_mail = '���� ���������';
}

 $PM_OUT = mysql_query("SELECT * FROM ".$Prefix."PM WHERE PM_ID = '$msg' AND PM_MID = '$DBMemberID' ") or die (mysql_error());

 if(mysql_num_rows($PM_OUT) > 0){

 $rs_OUT = mysql_fetch_array($PM_OUT);

 $OUT_PmID = $rs_OUT['PM_ID'];
 $OUT_Out = $rs_OUT['PM_OUT'];
 }


echo '
<center>
<table dir="rtl" cellSpacing="0" cellPadding="0" width="99%" border="0">
	<tr>
		<td>
		<table cellSpacing="2" width="100%" border="0">
			<tr>
                <td><a class="menu" href="index.php?mode=pm&mail='.$mail.$forum_id.'">'.icons($monitor, "������� ������", "").'</a></td>
				<td class="main" vAlign="center" width="100%"><a class="menu" href="index.php?mode=pm&mail='.$mail.$forum_id.'"><font color="red" size="+1">'.$privat_text.'</font></a><font color="red" size="+1"><br><font size="-1">'.$title_mail.'</font></font></td>';
if ($mail == "msg" AND $OUT_Out != 1) {
                echo'
				<td class="optionsbar_menus"><nobr><a href="index.php?mode=editor&method=replymsg&msg='.$msg.$forum_id.'">'.icons($icon_reply_topic, "�� ��� �������", "").'<br>�� ��� �������</a></nobr></td>';
}
if ($mail == "msg") {
                echo'
				<td class="optionsbar_menus"><nobr><a href="index.php?mode=delete&type=pm&msg='.$msg.$forum_id.'">'.icons($icon_trash, "���� ������� ��� ���� ���������", "").'<br>��� �������</a></nobr></td>';
}

                echo'
				<td class="optionsbar_menus"><nobr><a href="index.php?mode=sendmsg'.$forum_id.'">'.icons($folder_new, "����� �����", "").'<br>����� �����</a></nobr></td>';
if ($mail == "new" OR $mail == "in" OR $mail == "out" OR $mail == "trash" OR $mail == "m") {
    if ($total_res > 0) {
                paging($total_col, $pag);
    }
}
                require_once("go_to.php");
                echo'
			</tr>
		</table>
		<table>
			<tr>';
        if ($NewPm > 0) {
                echo'
				<td class="'.class_dis("new", $mail).'"><nobr><a href="index.php?mode=pm&mail=new'.$forum_id.'">������� ������� �������&nbsp;&nbsp;['.$NewPm.']</a></nobr></td>';
        }
                echo'
				<td class="'.class_dis("in", $mail).'"><nobr><a href="index.php?mode=pm&mail=in'.$forum_id.'">������ ������</a></nobr></td>
				<td class="'.class_dis("out", $mail).'"><nobr><a href="index.php?mode=pm&mail=out'.$forum_id.'">������ ������</a></nobr></td>
				<td class="'.class_dis("trash", $mail).'"><nobr><a href="index.php?mode=pm&mail=trash'.$forum_id.'">���� ���������</a></nobr></td>
    
    
			</tr>
		</table>';
//#################### new message #########################
if ($mail == "new") {

        echo'
		<table class="grid" dir="rtl" cellSpacing="0" cellPadding="0" width="100%" align="center" border="0">
        <form method="post" action="index.php?mode=delete&method=remove&type=pm'.$forum_id.'">
			<tr>
				<td>
				<table dir="rtl" cellSpacing="1" cellPadding="2" width="100%" border="0">
					<tr>
						<td class="cat" colSpan="2">&nbsp;</td>
						<td class="cat"><nobr>&nbsp;�������&nbsp;</nobr></td>
						<td class="cat"><nobr>&nbsp;��&nbsp;</nobr></td>
						<td class="cat"><nobr>&nbsp;���&nbsp;</nobr></td>
						<td class="cat"><nobr>&nbsp;����� �������&nbsp;</nobr></td>
						<td class="cat"><nobr>&nbsp;</nobr></td>';


	$NEW_PM = mysql_query("SELECT * FROM ".$Prefix."PM WHERE PM_MID = '$DBMemberID' AND PM_READ = '0' AND PM_OUT = '0' AND PM_STATUS = '1' ORDER BY PM_DATE DESC LIMIT $start, $max_page ") or die (mysql_error());
    $num = mysql_num_rows($NEW_PM);

if ($num == 0) {
    echo'
    <tr class="normal">
		<td class="list_center" vAlign="center" colspan="10"><br>�� ���� ��� ����� �� ��� ������<br><br></td>
    </tr>';
}


$i=0;
while ($i < $num) {

    $NEW_PmID = mysql_result($NEW_PM, $i, "PM_ID");
    $NEW_Status = mysql_result($NEW_PM, $i, "PM_STATUS");
    $NEW_To = mysql_result($NEW_PM, $i, "PM_TO");
    $NEW_From = mysql_result($NEW_PM, $i, "PM_FROM");
    $NEW_Read = mysql_result($NEW_PM, $i, "PM_READ");
    $NEW_Reply = mysql_result($NEW_PM, $i, "PM_REPLY");
    $NEW_Subject = mysql_result($NEW_PM, $i, "PM_SUBJECT");
    $NEW_Message = mysql_result($NEW_PM, $i, "PM_MESSAGE");
    $NEW_Date = mysql_result($NEW_PM, $i, "PM_DATE");
    
    
  if ($NEW_From > 0) {
    $MEMBER_FROM = mysql_query("SELECT * FROM ".$Prefix."MEMBERS WHERE MEMBER_ID = '$NEW_From' ") or die (mysql_error());
    if(mysql_num_rows($MEMBER_FROM) > 0){
    $rsMF=mysql_fetch_array($MEMBER_FROM);
    $MF_MemberID = $rsMF['MEMBER_ID'];
    $MF_MemberName = $rsMF['M_NAME'];
    }
    $FromName = link_profile($MF_MemberName, $MF_MemberID);
  }
  if ($NEW_From < 0) {
    $f_id = abs($NEW_From);
    $FORUM_FROM = mysql_query("SELECT * FROM ".$Prefix."FORUM WHERE FORUM_ID = '$f_id' ") or die (mysql_error());
    if(mysql_num_rows($FORUM_FROM) > 0){
    $rsFF=mysql_fetch_array($FORUM_FROM);
    $FF_ForumID = $rsFF['FORUM_ID'];
    $FF_ForumSubject = $rsFF['F_SUBJECT'];
    }
    $FromName = '����� '.$FF_ForumSubject;
  }

  if ($NEW_To > 0) {
    $MEMBER_TO = mysql_query("SELECT * FROM ".$Prefix."MEMBERS WHERE MEMBER_ID = '$NEW_To' ") or die (mysql_error());
    if(mysql_num_rows($MEMBER_TO) > 0){
    $rsMT=mysql_fetch_array($MEMBER_TO);
    $MT_MemberID = $rsMT['MEMBER_ID'];
    $MT_MemberName = $rsMT['M_NAME'];
    }
    $ToName = link_profile($MT_MemberName, $MT_MemberID);
  }
  if ($NEW_To < 0) {
    $f_id = abs($NEW_To);
    $FORUM_TO = mysql_query("SELECT * FROM ".$Prefix."FORUM WHERE FORUM_ID = '$f_id' ") or die (mysql_error());
    if(mysql_num_rows($FORUM_TO) > 0){
    $rsFT=mysql_fetch_array($FORUM_TO);
    $FT_ForumID = $rsFT['FORUM_ID'];
    $FT_ForumSubject = $rsFT['F_SUBJECT'];
    }
    $ToName = '����� '.$FT_ForumSubject;
  }
    
 if ($NEW_Reply == 0 OR $NEW_Reply == 2) {
     $reply_icon = '';
 }
 else {
     $reply_icon = icons($icon_reply_topic, "��� ������� �� ��� ����� �����", "").'&nbsp;';
 }
                    echo'
					</tr>
						<tr class="fixed">
						<td class="list_center"><nobr>&nbsp;<input class="small" type="checkbox" name="remove[]" value="'.$NEW_PmID.'"></nobr></td>
						<td class="list_center"><nobr>&nbsp;<a href="index.php?mode=pm&mail=msg&msg='.$NEW_PmID.$forum_id.'">'.icons($icon, "����� �����", "").'</a>&nbsp;</nobr></td>
						<td class="list_small"><nobr>&nbsp;<font color="green">'.normal_time($NEW_Date).'</font>&nbsp;</nobr></td>
						<td class="list_small"><nobr>&nbsp;'.$FromName.'&nbsp;</nobr></td>
						<td class="list_small"><nobr>&nbsp;'.$ToName.'&nbsp;</nobr></td>
						<td class="list" width="90%"><a href="index.php?mode=pm&mail=msg&msg='.$NEW_PmID.$forum_id.'">'.$reply_icon.$NEW_Subject.'</a></td>
						<td class="list_small"><nobr>&nbsp;<a href="index.php?mode=editor&method=replymsg&msg='.$NEW_PmID.$forum_id.'">'.icons($icon_reply_topic, "�� ��� �������", "").'</a>&nbsp;&nbsp;<a href="index.php?mode=delete&type=pm&msg='.$NEW_PmID.$forum_id.'">'.icons($icon_trash, "���� ������� ��� ���� ���������", "").'</a></nobr></td>
					</tr>';

    ++$i;
}
     
                echo'
				</table>
				</td>
			</tr>
		</table>';
    if ($num > 0) {
        echo'
		<center>
		<table border="0" cellpadding="2" border="0" cellspacing="0" width="100%">
			<tr>
				<td align="center"><br><input type="submit" value="���� ������� �������� ��� ���� �������"><br><br></td>
			</tr>
		</form>
		</table>
		</center>';
    }
}
//#################### in message #########################
if ($mail == "in") {

        echo'
		<table class="grid" dir="rtl" cellSpacing="0" cellPadding="0" width="100%" align="center" border="0">
        <form method="post" action="index.php?mode=delete&method=remove&type=pm'.$forum_id.'">
			<tr>
				<td>
				<table dir="rtl" cellSpacing="1" cellPadding="2" width="100%" border="0">
					<tr>
						<td class="cat" colSpan="2">&nbsp;</td>
						<td class="cat"><nobr>&nbsp;�������&nbsp;</nobr></td>
						<td class="cat"><nobr>&nbsp;��&nbsp;</nobr></td>
						<td class="cat"><nobr>&nbsp;���&nbsp;</nobr></td>
						<td class="cat"><nobr>&nbsp;����� �������&nbsp;</nobr></td>
						<td class="cat"><nobr>&nbsp;</nobr></td>';


	$NEW_PM = mysql_query("SELECT * FROM ".$Prefix."PM WHERE PM_MID = '$DBMemberID' AND PM_OUT = '0' AND PM_STATUS = '1' ORDER BY PM_DATE DESC LIMIT $start, $max_page") or die (mysql_error());
    $num = mysql_num_rows($NEW_PM);

if ($num == 0) {
    echo'
    <tr class="normal">
		<td class="list_center" vAlign="center" colspan="10"><br>�� ���� ��� ����� �� ��� ������<br><br></td>
    </tr>';
}


$i=0;
while ($i < $num) {

    $NEW_PmID = mysql_result($NEW_PM, $i, "PM_ID");
    $NEW_Status = mysql_result($NEW_PM, $i, "PM_STATUS");
    $NEW_To = mysql_result($NEW_PM, $i, "PM_TO");
    $NEW_From = mysql_result($NEW_PM, $i, "PM_FROM");
    $NEW_Read = mysql_result($NEW_PM, $i, "PM_READ");
    $NEW_Reply = mysql_result($NEW_PM, $i, "PM_REPLY");
    $NEW_Subject = mysql_result($NEW_PM, $i, "PM_SUBJECT");
    $NEW_Message = mysql_result($NEW_PM, $i, "PM_MESSAGE");
    $NEW_Date = mysql_result($NEW_PM, $i, "PM_DATE");

  if ($NEW_From > 0) {
    $MEMBER_FROM = mysql_query("SELECT * FROM ".$Prefix."MEMBERS WHERE MEMBER_ID = '$NEW_From' ") or die (mysql_error());
    if(mysql_num_rows($MEMBER_FROM) > 0){
    $rsMF=mysql_fetch_array($MEMBER_FROM);
    $MF_MemberID = $rsMF['MEMBER_ID'];
    $MF_MemberName = $rsMF['M_NAME'];
    }
    $FromName = link_profile($MF_MemberName, $MF_MemberID);
  }
  if ($NEW_From < 0) {
    $f_id = abs($NEW_From);
    $FORUM_FROM = mysql_query("SELECT * FROM ".$Prefix."FORUM WHERE FORUM_ID = '$f_id' ") or die (mysql_error());
    if(mysql_num_rows($FORUM_FROM) > 0){
    $rsFF=mysql_fetch_array($FORUM_FROM);
    $FF_ForumID = $rsFF['FORUM_ID'];
    $FF_ForumSubject = $rsFF['F_SUBJECT'];
    }
    $FromName = '����� '.$FF_ForumSubject;
  }

  if ($NEW_To > 0) {
    $MEMBER_TO = mysql_query("SELECT * FROM ".$Prefix."MEMBERS WHERE MEMBER_ID = '$NEW_To' ") or die (mysql_error());
    if(mysql_num_rows($MEMBER_TO) > 0){
    $rsMT=mysql_fetch_array($MEMBER_TO);
    $MT_MemberID = $rsMT['MEMBER_ID'];
    $MT_MemberName = $rsMT['M_NAME'];
    }
    $ToName = link_profile($MT_MemberName, $MT_MemberID);
  }
  if ($NEW_To < 0) {
    $f_id = abs($NEW_To);
    $FORUM_TO = mysql_query("SELECT * FROM ".$Prefix."FORUM WHERE FORUM_ID = '$f_id' ") or die (mysql_error());
    if(mysql_num_rows($FORUM_TO) > 0){
    $rsFT=mysql_fetch_array($FORUM_TO);
    $FT_ForumID = $rsFT['FORUM_ID'];
    $FT_ForumSubject = $rsFT['F_SUBJECT'];
    }
    $ToName = '����� '.$FT_ForumSubject;
  }
    
    

 if ($NEW_Read == 0) {
     $tr_class = 'fixed';
     $pm_icon = icons($icon, "����� �����", "");
 }
 else {
     $tr_class = 'normal';
     
    if ($NEW_Reply == 2) {
        $pm_icon = icons($icon_reply_topic, "�� ���� �����", "");
    }
    else {
        $pm_icon = icons($icon_private_message, "", "");
    }
 }
 if ($NEW_Reply == 0 OR $NEW_Reply == 2) {
     $reply_icon = '';
 }
 else {
     $reply_icon = icons($icon_reply_topic, "��� ������� �� ��� ����� �����", "").'&nbsp;';
 }

                    echo'
					</tr>
						<tr class="'.$tr_class.'">
						<td class="list_center"><nobr>&nbsp;<input class="small" type="checkbox" name="remove[]" value="'.$NEW_PmID.'"></nobr></td>
						<td class="list_center"><nobr>&nbsp;<a href="index.php?mode=pm&mail=msg&msg='.$NEW_PmID.$forum_id.'">'.$pm_icon.'</a>&nbsp;</nobr></td>
						<td class="list_small"><nobr>&nbsp;<font color="green">'.normal_time($NEW_Date).'</font>&nbsp;</nobr></td>
						<td class="list_small"><nobr>&nbsp;'.$FromName.'&nbsp;</nobr></td>
						<td class="list_small"><nobr>&nbsp;'.$ToName.'&nbsp;</nobr></td>
						<td class="list" width="90%"><a href="index.php?mode=pm&mail=msg&msg='.$NEW_PmID.$forum_id.'">'.$reply_icon.$NEW_Subject.'</a></td>
						<td class="list_small"><nobr>&nbsp;<a href="index.php?mode=editor&method=replymsg&msg='.$NEW_PmID.$forum_id.'">'.icons($icon_reply_topic, "�� ��� �������", "").'</a>&nbsp;&nbsp;<a href="index.php?mode=delete&type=pm&msg='.$NEW_PmID.$forum_id.'">'.icons($icon_trash, "���� ������� ��� ���� ���������", "").'</a></nobr></td>
					</tr>';

    ++$i;
}

                echo'
				</table>
				</td>
			</tr>
		</table>';
    if ($num > 0) {
        echo'
		<center>
		<table border="0" cellpadding="2" border="0" cellspacing="0" width="100%">
			<tr>
				<td align="center"><br><input type="submit" value="���� ������� �������� ��� ���� �������"><br><br></td>
			</tr>
		</form>
		</table>
		</center>';
    }
}
//#################### out message #########################
if ($mail == "out") {

        echo'
		<table class="grid" dir="rtl" cellSpacing="0" cellPadding="0" width="100%" align="center" border="0">
        <form method="post" action="index.php?mode=delete&method=remove&type=pm'.$forum_id.'">
			<tr>
				<td>
				<table dir="rtl" cellSpacing="1" cellPadding="2" width="100%" border="0">
					<tr>
						<td class="cat" colSpan="2">&nbsp;</td>
						<td class="cat"><nobr>&nbsp;�������&nbsp;</nobr></td>
						<td class="cat"><nobr>&nbsp;��&nbsp;</nobr></td>
						<td class="cat"><nobr>&nbsp;���&nbsp;</nobr></td>
						<td class="cat"><nobr>&nbsp;����� �������&nbsp;</nobr></td>
						<td class="cat"><nobr>&nbsp;</nobr></td>';


	$NEW_PM = mysql_query("SELECT * FROM ".$Prefix."PM WHERE PM_MID = '$DBMemberID' AND PM_OUT = '1' AND PM_STATUS = '1' ORDER BY PM_DATE DESC LIMIT $start, $max_page") or die (mysql_error());
    $num = mysql_num_rows($NEW_PM);

if ($num == 0) {
    echo'
    <tr class="normal">
		<td class="list_center" vAlign="center" colspan="10"><br>�� ���� ��� ����� �� ��� ������<br><br></td>
    </tr>';
}


$i=0;
while ($i < $num) {

    $NEW_PmID = mysql_result($NEW_PM, $i, "PM_ID");
    $NEW_Status = mysql_result($NEW_PM, $i, "PM_STATUS");
    $NEW_To = mysql_result($NEW_PM, $i, "PM_TO");
    $NEW_From = mysql_result($NEW_PM, $i, "PM_FROM");
    $NEW_Read = mysql_result($NEW_PM, $i, "PM_READ");
    $NEW_Reply = mysql_result($NEW_PM, $i, "PM_REPLY");
    $NEW_Subject = mysql_result($NEW_PM, $i, "PM_SUBJECT");
    $NEW_Message = mysql_result($NEW_PM, $i, "PM_MESSAGE");
    $NEW_Date = mysql_result($NEW_PM, $i, "PM_DATE");

  if ($NEW_From > 0) {
    $MEMBER_FROM = mysql_query("SELECT * FROM ".$Prefix."MEMBERS WHERE MEMBER_ID = '$NEW_From' ") or die (mysql_error());
    if(mysql_num_rows($MEMBER_FROM) > 0){
    $rsMF=mysql_fetch_array($MEMBER_FROM);
    $MF_MemberID = $rsMF['MEMBER_ID'];
    $MF_MemberName = $rsMF['M_NAME'];
    }
    $FromName = link_profile($MF_MemberName, $MF_MemberID);
  }
  if ($NEW_From < 0) {
    $f_id = abs($NEW_From);
    $FORUM_FROM = mysql_query("SELECT * FROM ".$Prefix."FORUM WHERE FORUM_ID = '$f_id' ") or die (mysql_error());
    if(mysql_num_rows($FORUM_FROM) > 0){
    $rsFF=mysql_fetch_array($FORUM_FROM);
    $FF_ForumID = $rsFF['FORUM_ID'];
    $FF_ForumSubject = $rsFF['F_SUBJECT'];
    }
    $FromName = '����� '.$FF_ForumSubject;
  }

  if ($NEW_To > 0) {
    $MEMBER_TO = mysql_query("SELECT * FROM ".$Prefix."MEMBERS WHERE MEMBER_ID = '$NEW_To' ") or die (mysql_error());
    if(mysql_num_rows($MEMBER_TO) > 0){
    $rsMT=mysql_fetch_array($MEMBER_TO);
    $MT_MemberID = $rsMT['MEMBER_ID'];
    $MT_MemberName = $rsMT['M_NAME'];
    }
    $ToName = link_profile($MT_MemberName, $MT_MemberID);
  }
  if ($NEW_To < 0) {
    $f_id = abs($NEW_To);
    $FORUM_TO = mysql_query("SELECT * FROM ".$Prefix."FORUM WHERE FORUM_ID = '$f_id' ") or die (mysql_error());
    if(mysql_num_rows($FORUM_TO) > 0){
    $rsFT=mysql_fetch_array($FORUM_TO);
    $FT_ForumID = $rsFT['FORUM_ID'];
    $FT_ForumSubject = $rsFT['F_SUBJECT'];
    }
    $ToName = '����� '.$FT_ForumSubject;
  }

 if ($NEW_Reply == 0 OR $NEW_Reply == 2) {
     $reply_icon = '';
 }
 else {
     $reply_icon = icons($icon_reply_topic, "�� ���� �� ����� �� ������ ���������", "").'&nbsp;';
 }

                    echo'
					</tr>
						<tr class="normal">
						<td class="list_center"><nobr>&nbsp;<input class="small" type="checkbox" name="remove[]" value="'.$NEW_PmID.'"></nobr></td>
						<td class="list_center"><nobr>&nbsp;<a href="index.php?mode=pm&mail=msg&msg='.$NEW_PmID.$forum_id.'">'.icons($icon_private_message, "", "").'</a>&nbsp;</nobr></td>
						<td class="list_small"><nobr>&nbsp;<font color="green">'.normal_time($NEW_Date).'</font>&nbsp;</nobr></td>
						<td class="list_small"><nobr>&nbsp;'.$FromName.'&nbsp;</nobr></td>
						<td class="list_small"><nobr>&nbsp;'.$ToName.'&nbsp;</nobr></td>
						<td class="list" width="90%"><a href="index.php?mode=pm&mail=msg&msg='.$NEW_PmID.$forum_id.'">'.$reply_icon.$NEW_Subject.'</a></td>
						<td class="list_small"><nobr>&nbsp;<a href="index.php?mode=delete&type=pm&msg='.$NEW_PmID.$forum_id.'">'.icons($icon_trash, "���� ������� ��� ���� ���������", "").'</a></nobr></td>
					</tr>';

    ++$i;
}

                echo'
				</table>
				</td>
			</tr>
		</table>';
    if ($num > 0) {
        echo'
		<center>
		<table border="0" cellpadding="2" border="0" cellspacing="0" width="100%">
			<tr>
				<td align="center"><br><input type="submit" value="���� ������� �������� ��� ���� �������"><br><br></td>
			</tr>
		</form>
		</table>
		</center>';
    }
}
//#################### trash message #########################
if ($mail == "trash") {

        echo'
		<table class="grid" dir="rtl" cellSpacing="0" cellPadding="0" width="100%" align="center" border="0">
        <form name="deletemsg" method="post" action="index.php?mode=delete&method=delete&type=pm'.$forum_id.'">
			<tr>
				<td>
				<table dir="rtl" cellSpacing="1" cellPadding="2" width="100%" border="0">
					<tr>
						<td class="cat" colSpan="2">&nbsp;</td>
						<td class="cat"><nobr>&nbsp;�������&nbsp;</nobr></td>
						<td class="cat"><nobr>&nbsp;��&nbsp;</nobr></td>
						<td class="cat"><nobr>&nbsp;���&nbsp;</nobr></td>
						<td class="cat"><nobr>&nbsp;����� �������&nbsp;</nobr></td>
						<td class="cat"><nobr>&nbsp;</nobr></td>';


	$NEW_PM = mysql_query("SELECT * FROM ".$Prefix."PM WHERE PM_MID = '$DBMemberID' AND PM_STATUS = '0' ORDER BY PM_DATE DESC LIMIT $start, $max_page") or die (mysql_error());
    $num = mysql_num_rows($NEW_PM);

if ($num == 0) {
    echo'
    <tr class="normal">
		<td class="list_center" vAlign="center" colspan="10"><br>�� ���� ��� ����� �� ��� ������<br><br></td>
    </tr>';
}


$i=0;
while ($i < $num) {

    $NEW_PmID = mysql_result($NEW_PM, $i, "PM_ID");
    $NEW_Status = mysql_result($NEW_PM, $i, "PM_STATUS");
    $NEW_To = mysql_result($NEW_PM, $i, "PM_TO");
    $NEW_From = mysql_result($NEW_PM, $i, "PM_FROM");
    $NEW_Read = mysql_result($NEW_PM, $i, "PM_READ");
    $NEW_Reply = mysql_result($NEW_PM, $i, "PM_REPLY");
    $NEW_Subject = mysql_result($NEW_PM, $i, "PM_SUBJECT");
    $NEW_Message = mysql_result($NEW_PM, $i, "PM_MESSAGE");
    $NEW_Date = mysql_result($NEW_PM, $i, "PM_DATE");

  if ($NEW_From > 0) {
    $MEMBER_FROM = mysql_query("SELECT * FROM ".$Prefix."MEMBERS WHERE MEMBER_ID = '$NEW_From' ") or die (mysql_error());
    if(mysql_num_rows($MEMBER_FROM) > 0){
    $rsMF=mysql_fetch_array($MEMBER_FROM);
    $MF_MemberID = $rsMF['MEMBER_ID'];
    $MF_MemberName = $rsMF['M_NAME'];
    }
    $FromName = link_profile($MF_MemberName, $MF_MemberID);
  }
  if ($NEW_From < 0) {
    $f_id = abs($NEW_From);
    $FORUM_FROM = mysql_query("SELECT * FROM ".$Prefix."FORUM WHERE FORUM_ID = '$f_id' ") or die (mysql_error());
    if(mysql_num_rows($FORUM_FROM) > 0){
    $rsFF=mysql_fetch_array($FORUM_FROM);
    $FF_ForumID = $rsFF['FORUM_ID'];
    $FF_ForumSubject = $rsFF['F_SUBJECT'];
    }
    $FromName = '����� '.$FF_ForumSubject;
  }

  if ($NEW_To > 0) {
    $MEMBER_TO = mysql_query("SELECT * FROM ".$Prefix."MEMBERS WHERE MEMBER_ID = '$NEW_To' ") or die (mysql_error());
    if(mysql_num_rows($MEMBER_TO) > 0){
    $rsMT=mysql_fetch_array($MEMBER_TO);
    $MT_MemberID = $rsMT['MEMBER_ID'];
    $MT_MemberName = $rsMT['M_NAME'];
    }
    $ToName = link_profile($MT_MemberName, $MT_MemberID);
  }
  if ($NEW_To < 0) {
    $f_id = abs($NEW_To);
    $FORUM_TO = mysql_query("SELECT * FROM ".$Prefix."FORUM WHERE FORUM_ID = '$f_id' ") or die (mysql_error());
    if(mysql_num_rows($FORUM_TO) > 0){
    $rsFT=mysql_fetch_array($FORUM_TO);
    $FT_ForumID = $rsFT['FORUM_ID'];
    $FT_ForumSubject = $rsFT['F_SUBJECT'];
    }
    $ToName = '����� '.$FT_ForumSubject;
  }

 if ($NEW_Read == 0) {
     $tr_class = 'fixed';
     $pm_icon = icons($icon, "����� �����", "");
 }
 else {
     $tr_class = 'normal';

    if ($NEW_Reply == 2) {
        $pm_icon = icons($icon_reply_topic, "�� ���� �����", "");
    }
    else {
        $pm_icon = icons($icon_private_message, "", "");
    }
 }
 if ($NEW_Reply == 0 OR $NEW_Reply == 2) {
     $reply_icon = '';
 }
 else {
     $reply_icon = icons($icon_reply_topic, "��� ������� �� ��� ����� �����", "").'&nbsp;';
 }

                    echo'
					</tr>
						<tr class="'.$tr_class.'">
						<td class="list_center"><nobr>&nbsp;<input class="small" type="checkbox" name="delete[]" value="'.$NEW_PmID.'"></nobr></td>
						<td class="list_center"><nobr>&nbsp;<a href="index.php?mode=pm&mail=msg&msg='.$NEW_PmID.$forum_id.'">'.$pm_icon.'</a>&nbsp;</nobr></td>
						<td class="list_small"><nobr>&nbsp;<font color="green">'.normal_time($NEW_Date).'</font>&nbsp;</nobr></td>
						<td class="list_small"><nobr>&nbsp;'.$FromName.'&nbsp;</nobr></td>
						<td class="list_small"><nobr>&nbsp;'.$ToName.'&nbsp;</nobr></td>
						<td class="list" width="90%"><a href="index.php?mode=pm&mail=msg&msg='.$NEW_PmID.$forum_id.'">'.$reply_icon.$NEW_Subject.'</a></td>
						<td class="list_small"><nobr>&nbsp;<a href="index.php?mode=open&type=pm&msg='.$NEW_PmID.$forum_id.'">'.icons($icon_go_up, "���� ������� ��� ������ ������", "").'</a>&nbsp;</nobr></td>
					</tr>';

    ++$i;
}

                echo'
				</table>
				</td>
			</tr>
		</table>';
    if ($num > 0) {
        echo'
		<center>
		<table border="0" cellpadding="2" border="0" cellspacing="0" width="100%">
			<tr>
				<td align="center"><br><input onclick="submit_delete()" type="button" value="��� ������� �������� �� ������ ��������� �������"></form></td>
			</tr>
		</table>
		</center>';
    }
}

//#################### me and you message #########################
if ($mail == "m") {

        echo'
		<table class="grid" dir="rtl" cellSpacing="0" cellPadding="0" width="100%" align="center" border="0">
        <form method="post" action="index.php?mode=delete&method=remove&type=pm'.$forum_id.'">
			<tr>
				<td>
				<table dir="rtl" cellSpacing="1" cellPadding="2" width="100%" border="0">
					<tr>
						<td class="cat" colSpan="2">&nbsp;</td>
						<td class="cat"><nobr>&nbsp;�������&nbsp;</nobr></td>
						<td class="cat"><nobr>&nbsp;��&nbsp;</nobr></td>
						<td class="cat"><nobr>&nbsp;���&nbsp;</nobr></td>
						<td class="cat"><nobr>&nbsp;����� �������&nbsp;</nobr></td>
						<td class="cat"><nobr>&nbsp;������&nbsp;</nobr></td>
                        <td class="cat"><nobr>&nbsp;</nobr></td>
                    </tr>';
                    
               echo'<tr><td align="center" bgcolor="yellow" colspan="10"><font color="black">��������� ���� ����: </font>'.link_profile(member_name($m), $m).'</td></tr>';

	$NEW_PM = mysql_query("SELECT * FROM ".$Prefix."PM WHERE PM_MID = '$DBMemberID' AND PM_STATUS = '1' AND PM_FROM = '$m' OR PM_TO = '$m' ORDER BY PM_DATE DESC LIMIT $start, $max_page") or die (mysql_error());
    $num = mysql_num_rows($NEW_PM);

if ($num == 0) {
    echo'
    <tr class="normal">
		<td class="list_center" vAlign="center" colspan="10"><br>�� ���� ��� ����� ���� ���� ('.member_name($m).')<br><br></td>
    </tr>';
}


$i=0;
while ($i < $num) {

    $NEW_PmID = mysql_result($NEW_PM, $i, "PM_ID");
    $NEW_Status = mysql_result($NEW_PM, $i, "PM_STATUS");
    $NEW_To = mysql_result($NEW_PM, $i, "PM_TO");
    $NEW_From = mysql_result($NEW_PM, $i, "PM_FROM");
    $NEW_Read = mysql_result($NEW_PM, $i, "PM_READ");
    $NEW_Out = mysql_result($NEW_PM, $i, "PM_OUT");
    $NEW_Reply = mysql_result($NEW_PM, $i, "PM_REPLY");
    $NEW_Subject = mysql_result($NEW_PM, $i, "PM_SUBJECT");
    $NEW_Message = mysql_result($NEW_PM, $i, "PM_MESSAGE");
    $NEW_Date = mysql_result($NEW_PM, $i, "PM_DATE");

  if ($NEW_From > 0) {
    $MEMBER_FROM = mysql_query("SELECT * FROM ".$Prefix."MEMBERS WHERE MEMBER_ID = '$NEW_From' ") or die (mysql_error());
    if(mysql_num_rows($MEMBER_FROM) > 0){
    $rsMF=mysql_fetch_array($MEMBER_FROM);
    $MF_MemberID = $rsMF['MEMBER_ID'];
    $MF_MemberName = $rsMF['M_NAME'];
    }
    $FromName = link_profile($MF_MemberName, $MF_MemberID);
  }
  if ($NEW_From < 0) {
    $f_id = abs($NEW_From);
    $FORUM_FROM = mysql_query("SELECT * FROM ".$Prefix."FORUM WHERE FORUM_ID = '$f_id' ") or die (mysql_error());
    if(mysql_num_rows($FORUM_FROM) > 0){
    $rsFF=mysql_fetch_array($FORUM_FROM);
    $FF_ForumID = $rsFF['FORUM_ID'];
    $FF_ForumSubject = $rsFF['F_SUBJECT'];
    }
    $FromName = '����� '.$FF_ForumSubject;
  }

  if ($NEW_To > 0) {
    $MEMBER_TO = mysql_query("SELECT * FROM ".$Prefix."MEMBERS WHERE MEMBER_ID = '$NEW_To' ") or die (mysql_error());
    if(mysql_num_rows($MEMBER_TO) > 0){
    $rsMT=mysql_fetch_array($MEMBER_TO);
    $MT_MemberID = $rsMT['MEMBER_ID'];
    $MT_MemberName = $rsMT['M_NAME'];
    }
    $ToName = link_profile($MT_MemberName, $MT_MemberID);
  }
  if ($NEW_To < 0) {
    $f_id = abs($NEW_To);
    $FORUM_TO = mysql_query("SELECT * FROM ".$Prefix."FORUM WHERE FORUM_ID = '$f_id' ") or die (mysql_error());
    if(mysql_num_rows($FORUM_TO) > 0){
    $rsFT=mysql_fetch_array($FORUM_TO);
    $FT_ForumID = $rsFT['FORUM_ID'];
    $FT_ForumSubject = $rsFT['F_SUBJECT'];
    }
    $ToName = '����� '.$FT_ForumSubject;
  }

 if ($NEW_Read == 0) {
     $tr_class = 'fixed';
     $pm_icon = icons($icon, "����� �����", "");
 }
 else {
     $tr_class = 'normal';

    if ($NEW_Reply == 2) {
        $pm_icon = icons($icon_reply_topic, "�� ���� �����", "");
    }
    else {
        $pm_icon = icons($icon_private_message, "", "");
    }
 }
 if ($NEW_Reply == 0 OR $NEW_Reply == 2) {
     $reply_icon = '';
 }
 else {
     $reply_icon = icons($icon_reply_topic, "��� ������� �� ��� ����� �����", "").'&nbsp;';
 }
 
 if ($NEW_Out == 0) {
    $mail_folder = '&nbsp;<font color="black">������ ������</font>&nbsp;';
    $mail_icon = '&nbsp;<a href="index.php?mode=editor&method=replymsg&msg='.$NEW_PmID.$forum_id.'">'.icons($icon_reply_topic, "�� ��� �������", "").'</a>&nbsp;&nbsp;<a href="index.php?mode=delete&type=pm&msg='.$NEW_PmID.$forum_id.'">'.icons($icon_trash, "���� ������� ��� ���� ���������", "").'</a>';
 }
 if ($NEW_Out == 1) {
    $mail_folder = '&nbsp;<font color="green">������ ������</font>&nbsp;';
    $mail_icon = '&nbsp;<a href="index.php?mode=delete&type=pm&msg='.$NEW_PmID.$forum_id.'">'.icons($icon_trash, "���� ������� ��� ���� ���������", "").'</a>';
 }
                    echo'
					</tr>
						<tr class="'.$tr_class.'">
						<td class="list_center"><nobr>&nbsp;<input class="small" type="checkbox" name="delete[]" value="'.$NEW_PmID.'"></nobr></td>
						<td class="list_center"><nobr>&nbsp;<a href="index.php?mode=pm&mail=msg&msg='.$NEW_PmID.$forum_id.'">'.$pm_icon.'</a>&nbsp;</nobr></td>
						<td class="list_small"><nobr>&nbsp;<font color="green">'.normal_time($NEW_Date).'</font>&nbsp;</nobr></td>
						<td class="list_small"><nobr>&nbsp;'.$FromName.'&nbsp;</nobr></td>
						<td class="list_small"><nobr>&nbsp;'.$ToName.'&nbsp;</nobr></td>
						<td class="list" width="90%"><a href="index.php?mode=pm&mail=msg&msg='.$NEW_PmID.$forum_id.'">'.$reply_icon.$NEW_Subject.'</a></td>
                        <td class="list_small"><nobr>'.$mail_folder.'</nobr></td>
						<td class="list_small"><nobr>'.$mail_icon.'</nobr></td>
					</tr>';

    ++$i;
}

                echo'
				</table>
				</td>
			</tr>
		</table>';
    if ($num > 0) {
        echo'
		<center>
		<table border="0" cellpadding="2" border="0" cellspacing="0" width="100%">
			<tr>
				<td align="center"><br><input type="submit" value="���� ������� �������� ��� ���� �������"><br><br></td>
			</tr>
		</form>
		</table>
		</center>';
    }
}
//#################### read msg #########################
if ($mail == "msg") {

if ($msg == "") {
 redirect();
}

    mysql_query("UPDATE " . $Prefix . "PM SET PM_READ = 1 WHERE PM_ID = '".$msg."' ") or die (mysql_error());


    $PM_READ = mysql_query("SELECT * FROM ".$Prefix."PM WHERE PM_ID = '".$msg."' AND PM_MID = '$DBMemberID' ") or die (mysql_error());

    if(mysql_num_rows($PM_READ) > 0){

    $rsPMR=mysql_fetch_array($PM_READ);

    $PMR_PmID = $rsPMR['PM_ID'];
    $PMR_Status = $rsPMR['PM_STATUS'];
    $PMR_To = $rsPMR['PM_TO'];
    $PMR_From = $rsPMR['PM_FROM'];
    $PMR_Read = $rsPMR['PM_READ'];
    $PMR_Out = $rsPMR['PM_OUT'];
    $PMR_Reply = $rsPMR['PM_REPLY'];
    $PMR_Subject = $rsPMR['PM_SUBJECT'];
    $PMR_Message = $rsPMR['PM_MESSAGE'];
    $PMR_Date = $rsPMR['PM_DATE'];

    }

  if ($PMR_From > 0) {
    $MEMBER_FROM = mysql_query("SELECT * FROM ".$Prefix."MEMBERS WHERE MEMBER_ID = '$PMR_From' ") or die (mysql_error());
    if(mysql_num_rows($MEMBER_FROM) > 0){
    $rsMF=mysql_fetch_array($MEMBER_FROM);
    $MF_MemberID = $rsMF['MEMBER_ID'];
    $MF_MemberName = $rsMF['M_NAME'];
    }
    $FromName = link_profile($MF_MemberName, $MF_MemberID);
  }
  if ($PMR_From < 0) {
    $f_id = abs($PMR_From);
    $FORUM_FROM = mysql_query("SELECT * FROM ".$Prefix."FORUM WHERE FORUM_ID = '$f_id' ") or die (mysql_error());
    if(mysql_num_rows($FORUM_FROM) > 0){
    $rsFF=mysql_fetch_array($FORUM_FROM);
    $FF_ForumID = $rsFF['FORUM_ID'];
    $FF_ForumSubject = $rsFF['F_SUBJECT'];
    }
    $FromName = '����� '.$FF_ForumSubject;
  }

  if ($PMR_To > 0) {
    $MEMBER_TO = mysql_query("SELECT * FROM ".$Prefix."MEMBERS WHERE MEMBER_ID = '$PMR_To' ") or die (mysql_error());
    if(mysql_num_rows($MEMBER_TO) > 0){
    $rsMT=mysql_fetch_array($MEMBER_TO);
    $MT_MemberID = $rsMT['MEMBER_ID'];
    $MT_MemberName = $rsMT['M_NAME'];
    }
    $ToName = link_profile($MT_MemberName, $MT_MemberID);
  }
  if ($PMR_To < 0) {
    $f_id = abs($PMR_To);
    $FORUM_TO = mysql_query("SELECT * FROM ".$Prefix."FORUM WHERE FORUM_ID = '$f_id' ") or die (mysql_error());
    if(mysql_num_rows($FORUM_TO) > 0){
    $rsFT=mysql_fetch_array($FORUM_TO);
    $FT_ForumID = $rsFT['FORUM_ID'];
    $FT_ForumSubject = $rsFT['F_SUBJECT'];
    }
    $ToName = '����� '.$FT_ForumSubject;
  }

        echo'
		<table class="grid" dir="rtl" cellSpacing="0" cellPadding="0" width="100%" align="center" border="0">
			<tr>
				<td>
				<table dir="rtl" cellSpacing="1" cellPadding="4" width="100%" border="0">
			        <tr class="normal">
				        <td class="cat" colSpan="3"><font size="+1">����� ����</font></td>
			        </tr>
			        <tr class="normal">
				        <td class="cat"><nobr><font color="yellow">����� ���</font></nobr></td>
			            <td class="list" width="100%">&nbsp;<font color="red" size="-1">����� ��� ������ �� ������ ������ ��� ����� ����� ������ �� �� ��� �� ������� ��� ���.<br>��� ����� ����� ���� ����� ������ ���� ���� ������ ������ ������ ����� ����� ��������� ����.&nbsp;</font></td>
			        </tr>
			        <tr class="normal">
				        <td class="cat"><nobr>��</nobr></td>
				        <td class="list" width="100%"><nobr>&nbsp;&nbsp;&nbsp;'.$FromName.'&nbsp;&nbsp;&nbsp;';
                        if ($PMR_From != $DBMemberID) {
                            echo '<a href="index.php?mode=pm&mail=m&m='.$PMR_From.'">'.icons($icon_profile,"�������� �� ��� �����","").'</a>';
                        }
                        echo'
                        </nobr></td>
			        </tr>
			        <tr class="normal">
				        <td class="cat"><nobr>���</nobr></td>
				        <td class="list"><nobr>&nbsp;&nbsp;&nbsp;'.$ToName.'&nbsp;&nbsp;&nbsp;';
                        if ($PMR_To != $DBMemberID) {
                            echo '<a href="index.php?mode=pm&mail=m&m='.$PMR_To.$forum_id.'">'.icons($icon_profile,"�������� �� ��� �����","").'</a>';
                        }
                        echo'
                        </nobr></td>
			        </tr>
			        <tr class="normal">
				        <td class="cat"><nobr>�������</nobr></td>
				        <td class="list"><nobr>&nbsp;&nbsp;&nbsp;<font color="green">'.normal_time($PMR_Date).'</font>&nbsp;&nbsp;&nbsp;</nobr></td>
			        </tr>
			        <tr class="fixed">
				        <td class="cat"><nobr>����� �������</nobr></td>
				        <td class="list">&nbsp;&nbsp;&nbsp;<a href="index.php?mode=pm&mail=msg&msg='.$PMR_PmID.$forum_id.'">'.$PMR_Subject.'</a>&nbsp;&nbsp;&nbsp;</td>
			        </tr>
			        <tr>
				        <td bgColor="#dddddd" colSpan="2">'.text_replace($PMR_Message).'</td>
			        </tr>';
if ($PMR_Out == 0) {
                    echo'
			        <tr>
			            <form name="quickreply" method="post" action="index.php?mode=post_info'.$forum_id.'">
				        <td vAlign="top" align="middle" bgColor="white"><br>'.icons($icon_reply_topic,"","").'<br><br><font color="red">��� <br>�� ���� </font></td>
				        <td vAlign="top" align="middle" width="100%" bgColor="white">
				        <textarea style="FONT-SIZE: 25px; WIDTH: 100%; COLOR: #006600; FONT-FAMILY: comic sans ms; HEIGHT: 250px; TEXT-ALIGN: center" name="message" rows="1" cols="20"></textarea>
                        <input name="method" type="hidden" value="replymsg">
                        <input name="type" type="hidden" value="q_reply">
                        <input name="m" type="hidden" value="'.$m.'">
                        <input name="pm_to" type="hidden" value="'.$PMR_From.'">
                        <input name="subject" type="hidden" value="'.$PMR_Subject.'">
				        <input name="host" type="hidden" value="'.$HTTP_HOST.'">
				        <input onclick="submitQuickReplyForm()" type="button" value="���� ���� ��� �������">
				        </td>
				        </form>
			        </tr>';
}
                echo'
				</table>
				</td>
			</tr>
		</table>';
}

        echo'
		</td>
	</tr>
</table>
</center>';

}
?>

