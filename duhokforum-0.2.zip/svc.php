<?php
/*//////////////////////////////////////////////////////////
// ######################################################///
// # DuhokForum 0.2                                     # //
// ###################################################### //
// #                                                    # //
// #       --  DUHOK FORUM IS FREE SOFTWARE  --         # //
// #                                                    # //
// #   ========= Programming By Dilovan ==============  # //
// # Copyright � 2007 Dilovan. All Rights Reserved      # //
// #----------------------------------------------------# //
// #----------------------------------------------------# //
// # If you want any support vist down address:-        # //
// # Email: df@duhoktimes.com                           # //
// # Site: http://df.duhoktimes.com/index.php           # //
// ###################################################### //
//////////////////////////////////////////////////////////*/

if ($Mlevel > 1) {

  if ($id != "") {
     $mem_id = '&id='.$id;
  }
  if ($c != "") {
     $cat_id = '&c='.$c;
  }
  $date = time();

if ($method != "in" AND $method != "update" AND $method != "insert" AND $method != "delete") {

echo'
<center>
<table dir="rtl" cellSpacing="0" cellPadding="0" width="99%" border="0">
  <tr>
    <td>
    <table class="optionsbar" dir="rtl" cellSpacing="2" width="100%" border="0">
      <tr>
        <td class="optionsbar_title" Align="center" width="95%">�����</td>';
        include("go_to.php");
      echo'
      </tr>
    </table>
    </td>
  </tr>
</table>
</center><br>';
}

if ($method == "") {

if ($id != "") {
 $text1 = '���� ����� ���� ���� ����� ������ ����� <font color="black">'.member_name($id).'</font>';
}
else {
 $text1 = '���� ��� ���� ����� ���� ������';
}

if ($Mlevel == 2) {
 $text2 = '������� ���� ��� ������';
}
if ($Mlevel == 3) {
 $text2 = '������� ���� ��� ������';
}
if ($Mlevel == 4) {
 $text2 = '���� �������';
}

echo'
<center>
<table width="40%" dir="rtl" cellSpacing="1" cellPadding="4">
  <tr>
    <td class="optionsbar_menus" colSpan="9"><font color="black" size="+1">'.$text2.'</font><br><font color="red" size="2">( '.$text1.' )</font></td>
  </tr>
  <tr>
    <td class="stats_h"><nobr>�����</nobr></td>
    <td class="stats_h"><nobr>��� �������</nobr></td>
  </tr>';
  
  
 if ($Mlevel == 2) {
  $f_svc = mysql_query("SELECT * FROM ".$Prefix."MODERATOR WHERE MEMBER_ID = '$DBMemberID' ORDER BY FORUM_ID ASC ") or die (mysql_error());
  $svc_num = mysql_num_rows($f_svc);
 }
 
 if ($Mlevel == 3) {
  $f_svc = mysql_query("SELECT * FROM ".$Prefix."CATEGORY WHERE CAT_MONITOR = '$DBMemberID' ") or die (mysql_error());
  $svc_num = mysql_num_rows($f_svc);
 }
 
 if ($Mlevel == 4) {
  $f_svc = mysql_query("SELECT * FROM ".$Prefix."FORUM ORDER BY FORUM_ID ASC ") or die (mysql_error());
  $svc_num = mysql_num_rows($f_svc);
 }
 
  $i=0;
  while ($i < $svc_num) {

     if ($Mlevel == 3) {

         $Mon_CatID = mysql_result($f_svc, $i, "CAT_ID");

        $F_sql = mysql_query("SELECT * FROM ".$Prefix."FORUM WHERE CAT_ID = '$Mon_CatID' ORDER BY FORUM_ID ASC  ") or die (mysql_error());
        $F_rows = mysql_num_rows($F_sql);

        $ii = 0;
        while ($ii < $F_rows) {
            $Mon_ForumID = mysql_result($F_sql, $ii, "FORUM_ID");
            $ForumSubject = mysql_result($F_sql, $ii, "F_SUBJECT");

  echo'
  <tr>
    <td class="stats_h"><nobr>'.$Mon_ForumID.'</nobr></td>
    <td class="stats_p"><nobr><a href="index.php?mode=svc&method=svc&f='.$Mon_ForumID.'&c='.$Mon_CatID.$mem_id.'">'.$ForumSubject.'</a></nobr></td>
  </tr>';


        $ii++;
        }
      }

  if ($Mlevel == 4 OR $Mlevel == 2) {

      $Mod_ForumID = mysql_result($f_svc, $i, "FORUM_ID");
      
  echo'
  <tr>
    <td class="stats_h"><nobr>'.$Mod_ForumID.'</nobr></td>
    <td class="stats_p"><nobr><a href="index.php?mode=svc&method=svc&f='.$Mod_ForumID.$mem_id.'">'.forum_name($Mod_ForumID).'</a></nobr></td>
  </tr>';
  }
  
  $i++;
  }

echo'
</table>
</center>';

}

if ($method == "svc") {
if ($Mlevel == 4 OR chk_monitor($DBMemberID,$c) == 1 OR chk_moderator($DBMemberID,$f) == 1) {

if ($svc == "") {

if ($id != "") {
 $text2 = '( ���� ���� ���� ���� ������ ����� <font color="black">'.member_name($id).'</font> )';
}
else {
 $text2 = '';
}


echo'
<center>
<table width="40%" dir="rtl" cellSpacing="1" cellPadding="4">
  <tr>
    <td class="optionsbar_menus" colSpan="9"><font color="black" size="+1">����� ����� '.forum_name($f).'</font><br><font color="red" size="2">'.$text2.'</font></td>
  </tr>
  <tr>
    <td class="stats_h"><nobr>�����</nobr></td>
  </tr>
  <tr>
    <td class="stats_g"><nobr><a href="index.php?mode=svc&method=svc&svc=titles&f='.$f.$mem_id.$cat_id.'">����� ����� '.forum_name($f).' </a><font color="red">( '.forum_title_count($f).' )</font></nobr></td>
  </tr>
</table>
</center>';
}

if ($svc == "titles") {

if ($id != "") {
 $text3 = '( ���� ��� ����� ����� ������ ����� ����� <font color="black">'.member_name($id).'</font> )';
}
else {
 $text3 = '';
}

echo'
<center>
<table dir="rtl" cellSpacing="1" cellPadding="5">
  <tr>
    <td class="optionsbar_menus" colSpan="11"><font color="black" size="+1">����� ����� ����� �������</font><br><font color="red" size="2">'.$text3.'</font></td>
  </tr>
  <tr>
    <td class="stats_h"><nobr>�����</nobr></td>
    <td class="stats_h"><nobr>����� �����</nobr></td>
    <td class="stats_h"><nobr>���� ��<br>����<br>���������</nobr></td>
    <td class="stats_h"><nobr>�����</nobr></td>
    <td class="stats_h"><nobr>�������</nobr></td>
    <td class="stats_h"><nobr>�� ���<br>��� �����</nobr></td>
    <td class="stats_h"><nobr>�����<br>�������</nobr></td>';
  if ($id != "" OR $Mlevel > 2 OR $mod_add_titles == 1) {
    echo'
    <td class="stats_h" colspan="3"><nobr>������</nobr></td>';
  }
  echo'
  </tr>';

  $FTitles = mysql_query("SELECT * FROM ".$Prefix."F_TITLES WHERE T_FORUMID = '$f' ORDER BY TITLE_ID ASC ") or die (mysql_error());
  $FT_num = mysql_num_rows($FTitles);
  if ($FT_num <= 0) {
  echo'
  <tr>
    <td class="stats_p" align="middle" colSpan="11"><font color="black" size="3"><br>�� ���� ��� ��� ���� �������<br><br></font></td>
  </tr>';
  }
  else {
  $i=0;
  while ($i < $FT_num) {

        $T_TitleID = mysql_result($FTitles, $i, "TITLE_ID");
        $T_ForumID = mysql_result($FTitles, $i, "T_FORUMID");
        $T_Status = mysql_result($FTitles, $i, "T_STATUS");
        $T_Added = mysql_result($FTitles, $i, "T_ADDED");
        $T_Color = mysql_result($FTitles, $i, "T_COLOR");
        $T_Subject = mysql_result($FTitles, $i, "T_SUBJECT");
        $T_Date = mysql_result($FTitles, $i, "T_DATE");
        
        if ($T_Status == 0) {
          $status = '��';
        }
        if ($T_Status == 1) {
          $status = '���';
        }
        
  echo'
  <tr>
    <td class="stats_h" align="middle"><font color="white" size="-1">'.$T_TitleID.'</font></td>
    <td class="stats_p" align="middle"><font color="black" size="-1">'.$T_Subject.'</font></td>
    <td class="stats_h" align="middle"><font color="yellow" size="-1">'.$status.'</font></td>
    <td class="stats_p" align="middle"><font size="-1">'.title_color($T_Color).'</font></td>
    <td class="stats_g" align="middle"><font color="white" size="-1">'.forum_name($T_ForumID).'</font></td>
    <td class="stats_p" align="middle"><font color="black" size="-1">'.link_profile(member_name($T_Added), $T_Added).'</font></td>
    <td class="stats_h" align="middle"><font color="white" size="-1">'.normal_date($T_Date).'</font></td>';
    
  if ($id != "") {
echo'<td class="stats_g" align="middle"><font color="black" size="-1"><a title="���� ��� ������� ��� ����� �����" href="index.php?mode=svc&method=in&svc=titles&id='.$id.'&t='.$T_TitleID.'&f='.$f.$cat_id.'">-- ����� ����� --</a></font></td>';
  }
  if ($Mlevel == 4 OR chk_monitor($DBMemberID,$c) == 1 OR $mod_add_titles == 1) {
echo'<td class="stats_p" align="middle"><font color="black" size="-1"><a href="index.php?mode=svc&method=edit&svc=titles&t='.$T_TitleID.'&f='.$f.$cat_id.'">'.icons($icon_edit, "����� �����", "").'</a></font></td>';
echo'<td class="stats_p" align="middle"><font color="black" size="-1"><a href="index.php?mode=svc&method=delete&svc=titles&t='.$T_TitleID.'&f='.$f.$cat_id.'">'.icons($icon_trash, "��� �����", "").'</a></font></td>';
  }
  
  echo'
  </tr>';
  
  $i++;
  }
  }
  if ($Mlevel == 4 OR chk_monitor($DBMemberID,$c) == 1 OR $mod_add_titles == 1) {
  echo'
  <tr>
     <td class="stats_p" align="middle" colspan="10">
     <table><tr><td class="optionsbar_menus"><font size="3">
     <a href="index.php?mode=svc&method=add&svc=titles&f='.$f.$cat_id.'">����� ��� ����</a>
     </font></td></tr></table>
     </td>
  </tr>';
  }
echo'
</table>
<center>';

}

}}


if ($method == "in") {
if ($Mlevel == 4 OR chk_monitor($DBMemberID,$c) == 1 OR chk_moderator($DBMemberID,$f) == 1) {


if ($svc == "titles") {


     $sql = mysql_query("SELECT * FROM ".$Prefix."F_TITLES WHERE TITLE_ID = '".$t."' ") or die (mysql_error());
     if(mysql_num_rows($sql) > 0){
     $rs = mysql_fetch_array($sql);
     $Title_Status = $rs[T_STATUS];
     $Title_Subject = $rs[T_SUBJECT];
     $Title_Color = $rs[T_COLOR];
     }

     $query = "INSERT INTO ".$Prefix."TITLES (TITLE_ID, T_MEMBERID, T_FORUMID, T_STATUS, T_MAKE, T_COLOR, T_SUBJECT, T_DATE) VALUES (NULL, ";
     $query .= " '$id', ";
     $query .= " '$f', ";
     $query .= " '$Title_Status', ";
     $query .= " '$DBMemberID', ";
     $query .= " '$Title_Color', ";
     $query .= " '$Title_Subject', ";
     $query .= " '$date') ";

     mysql_query($query, $connection) or die (mysql_error());
     
     
	                echo'<br><center>
	                <table width="99%" border="1">
	                   <tr class="normal">
	                       <td class="list_center" colSpan="10"><font size="5"><br>�� ����� ����� �����..</font><br><br>
	                       <meta http-equiv="Refresh" content="2; URL=index.php?mode=profile&id='.$id.'">
	                       <a href="index.php?mode=svc">-- ���� ��� ������ ��� ����� --</a><br><br>
                           <a href="index.php?mode=profile&id='.$id.'">-- ���� ��� ������ ��� ������ ������� --</a><br><br>
	                       </td>
	                   </tr>
	                </table>
	                </center>';


}


}}


if ($method == "add") {
if ($Mlevel == 4 OR chk_monitor($DBMemberID,$c) == 1 OR chk_moderator($DBMemberID,$f) == 1 AND $mod_add_titles == 1) {

if ($svc == "titles") {
echo'
<center>
<table class="grid" dir="rtl" cellSpacing="1" cellPadding="5">
<form method="post" action="index.php?mode=svc&method=insert&svc=titles&f='.$f.$cat_id.'">

  <tr>
    <td class="cat" colSpan="10">����� ��� ������� <br><font color="red">'.forum_name($f).'</font></td>
  </tr>
  <tr class="fixed">
    <td class="cat"><nobr>�����</nobr></td>
    <td class="userdetails_data"><input type="text" name="title_subject" size="40"></td>
  </tr>
  <tr class="fixed">
    <td class="cat"><nobr>���� �� ���� �������</nobr></td>
    <td class="userdetails_data">
    <select class="insidetitle" style="WIDTH: 100px" name="title_status" >
      <option value="0">��</option>
      <option value="1">���</option>
    </select>
    </td>
  </tr>
  <tr class="fixed">
    <td class="cat"><nobr>�����</nobr></td>
    <td class="userdetails_data">
    <select class="insidetitle" style="WIDTH: 200px" name="title_color" >
      <option value="" selected>�������</option>
      <option style="color:blue" value="blue">����</option>
      <option style="color:black" value="black">����</option>
      <option style="color:red" value="red">����</option>
      <option style="color:yellow" value="yellow">����</option>
      <option style="color:pink" value="pink">����</option>
      <option style="color:green" value="green">����</option>
      <option style="color:orange" value="orange">�������</option>
      <option style="color:purple" value="purple">������</option>
      <option style="color:brown" value="brown">���</option>
      <option style="color:navy" value="navy">����</option>
    </select>
    </td>
  </tr>
  <tr class="fixed">
	<td align="middle" colspan="2"><input type="submit" value="����� �����">&nbsp;&nbsp;&nbsp;<input type="reset" value="����� �������"></td>
  </tr>
  </form>
</table>
</center>';
}

}}

if ($method == "insert") {
if ($Mlevel == 4 OR chk_monitor($DBMemberID,$c) == 1 OR chk_moderator($DBMemberID,$f) == 1 AND $mod_add_titles == 1) {



if ($svc == "titles") {

$title_subject = HtmlSpecialchars($_POST["title_subject"]);
$title_status = $_POST["title_status"];
$title_color = $_POST["title_color"];

     $query = "INSERT INTO ".$Prefix."F_TITLES (TITLE_ID, T_FORUMID, T_STATUS, T_ADDED, T_COLOR, T_SUBJECT, T_DATE) VALUES (NULL, ";
     $query .= " '$f', ";
     $query .= " '$title_status', ";
     $query .= " '$DBMemberID', ";
     $query .= " '$title_color', ";
     $query .= " '$title_subject', ";
     $query .= " '$date') ";

     mysql_query($query, $connection) or die (mysql_error());


	                echo'<br><center>
	                <table width="99%" border="1">
	                   <tr class="normal">
	                       <td class="list_center" colSpan="10"><font size="5"><br>�� ����� ����� �����..</font><br><br>
	                       <meta http-equiv="Refresh" content="2; URL=index.php?mode=svc&method=svc&svc=titles&f='.$f.$cat_id.'">
	                       <a href="index.php?mode=svc">-- ���� ��� ������ ��� ����� --</a><br><br>
                           <a href="index.php?mode=svc&method=svc&svc=titles&f='.$f.$cat_id.'">-- ���� ��� ������ ��� ������ ������� --</a><br><br>
	                       </td>
	                   </tr>
	                </table>
	                </center>';


}




}}

if ($method == "edit") {
if ($Mlevel == 4 OR chk_monitor($DBMemberID,$c) == 1 OR chk_moderator($DBMemberID,$f) == 1 AND $mod_add_titles == 1) {

if ($svc == "titles") {

 $edit_title = mysql_query("SELECT * FROM ".$Prefix."F_TITLES WHERE TITLE_ID = '$t' ") or die (mysql_error());
 $rs_t = mysql_fetch_array($edit_title);

echo'
<center>
<table class="grid" dir="rtl" cellSpacing="1" cellPadding="5">
<form method="post" action="index.php?mode=svc&method=update&svc=titles&f='.$f.$cat_id.'">
<input type="hidden" name="title_id" value="'.$t.'">

  <tr>
    <td class="cat" colSpan="10">����� ��� ������� <br><font color="red">'.forum_name($f).'</font></td>
  </tr>
  <tr class="fixed">
    <td class="cat"><nobr>�����</nobr></td>
    <td class="userdetails_data"><input type="text" name="title_subject" size="40" value="'.$rs_t[T_SUBJECT].'"></td>
  </tr>
  <tr class="fixed">
    <td class="cat"><nobr>���� �� ���� �������</nobr></td>
    <td class="userdetails_data">
    <select class="insidetitle" style="WIDTH: 100px" name="title_status" >
      <option value="0" '.check_select($rs_t[T_STATUS], "0").'>��</option>
      <option value="1" '.check_select($rs_t[T_STATUS], "1").'>���</option>
    </select>
    </td>
  </tr>
  <tr class="fixed">
    <td class="cat"><nobr>�����</nobr></td>
    <td class="userdetails_data">
    <select class="insidetitle" style="WIDTH: 200px" name="title_color" >
      <option value="" selected>�������</option>
      <option style="color:blue" value="blue" '.check_select($rs_t[T_COLOR], "blue").'>����</option>
      <option style="color:black" value="black" '.check_select($rs_t[T_COLOR], "black").'>����</option>
      <option style="color:red" value="red" '.check_select($rs_t[T_COLOR], "red").'>����</option>
      <option style="color:yellow" value="yellow" '.check_select($rs_t[T_COLOR], "yellow").'>����</option>
      <option style="color:pink" value="pink" '.check_select($rs_t[T_COLOR], "pink").'>����</option>
      <option style="color:green" value="green" '.check_select($rs_t[T_COLOR], "green").'>����</option>
      <option style="color:orange" value="orange" '.check_select($rs_t[T_COLOR], "orange").'>�������</option>
      <option style="color:purple" value="purple" '.check_select($rs_t[T_COLOR], "purple").'>������</option>
      <option style="color:brown" value="brown" '.check_select($rs_t[T_COLOR], "brown").'>���</option>
      <option style="color:navy" value="navy" '.check_select($rs_t[T_COLOR], "navy").'>����</option>
    </select>
    </td>
  </tr>
  <tr class="fixed">
	<td align="middle" colspan="2"><input type="submit" value="����� �����">&nbsp;&nbsp;&nbsp;<input type="reset" value="����� ���� ������"></td>
  </tr>
  </form>
</table>
</center>';
}

}}


if ($method == "update") {
if ($Mlevel == 4 OR chk_monitor($DBMemberID,$c) == 1 OR chk_moderator($DBMemberID,$f) == 1 AND $mod_add_titles == 1) {



if ($svc == "titles") {
$title_id = $_POST["title_id"];
$title_subject = HtmlSpecialchars($_POST["title_subject"]);
$title_status = $_POST["title_status"];
$title_color = $_POST["title_color"];

     $query = "UPDATE ".$Prefix."F_TITLES SET ";
     $query .= "T_STATUS = '$title_status', ";
     $query .= "T_COLOR = '$title_color', ";
     $query .= "T_SUBJECT = '$title_subject' ";
     $query .= "WHERE TITLE_ID = '$title_id' ";

     mysql_query($query, $connection) or die (mysql_error());


	                echo'<br><center>
	                <table width="99%" border="1">
	                   <tr class="normal">
	                       <td class="list_center" colSpan="10"><font size="5"><br>�� ����� ����� �����..</font><br><br>
	                       <meta http-equiv="Refresh" content="2; URL=index.php?mode=svc&method=svc&svc=titles&f='.$f.$cat_id.'">
	                       <a href="index.php?mode=svc">-- ���� ��� ������ ��� ����� --</a><br><br>
                           <a href="index.php?mode=svc&method=svc&svc=titles&f='.$f.$cat_id.'">-- ���� ��� ������ ��� ������ ������� --</a><br><br>
	                       </td>
	                   </tr>
	                </table>
	                </center>';


}




}}


if ($method == "delete") {
if ($Mlevel == 4 OR chk_monitor($DBMemberID,$c) == 1 OR chk_moderator($DBMemberID,$f) == 1 AND $mod_add_titles == 1) {

if ($svc == "titles") {


		$query = "DELETE FROM " . $Prefix . "F_TITLES WHERE TITLE_ID = '$t' ";
		mysql_query($query, $connection) or die (mysql_error());


	                echo'<br><center>
	                <table width="99%" border="1">
	                   <tr class="normal">
	                       <td class="list_center" colSpan="10"><font size="5"><br>�� ��� ����� �����..</font><br><br>
	                       <meta http-equiv="Refresh" content="2; URL=index.php?mode=svc&method=svc&svc=titles&f='.$f.$cat_id.'">
	                       <a href="index.php?mode=svc">-- ���� ��� ������ ��� ����� --</a><br><br>
                           <a href="index.php?mode=svc&method=svc&svc=titles&f='.$f.$cat_id.'">-- ���� ��� ������ ��� ������ ������� --</a><br><br>
	                       </td>
	                   </tr>
	                </table>
	                </center>';


}




}}








}
?>
