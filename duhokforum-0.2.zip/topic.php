<?
/*//////////////////////////////////////////////////////////
// ######################################################///
// # DuhokForum 0.2                                     # //
// ###################################################### //
// #                                                    # //
// #       --  DUHOK FORUM IS FREE SOFTWARE  --         # //
// #                                                    # //
// #   ========= Programming By Dilovan ==============  # //
// # Copyright � 2007 Dilovan. All Rights Reserved      # //
// #----------------------------------------------------# //
// #----------------------------------------------------# //
// # If you want any support vist down address:-        # //
// # Email: df@duhoktimes.com                           # //
// # Site: http://df.duhoktimes.com/index.php           # //
// ###################################################### //
//////////////////////////////////////////////////////////*/

if ($t == "") {
 redirect();
}

$HTTP_HOST = $_SERVER['HTTP_HOST'];

$resultTop = mysql_query("SELECT * FROM ".$Prefix."TOPICS WHERE TOPIC_ID = '$t' ")
or die (mysql_error());

if(mysql_num_rows($resultTop) > 0){
$rsTop = mysql_fetch_array($resultTop);

$TOP_TopicID = $rsTop['TOPIC_ID'];
$TOP_ForumID = $rsTop['FORUM_ID'];
$TOP_CatID = $rsTop['CAT_ID'];
$TOP_TopicStatus = $rsTop['T_STATUS'];
$TOP_TopicSubject = $rsTop['T_SUBJECT'];
$TOP_TopicMessage = $rsTop['T_MESSAGE'];
$TOP_TopicAuthor = $rsTop['T_AUTHOR'];
$TOP_TopicDate = $rsTop['T_DATE'];
$TOP_TopicHidden = $rsTop['T_HIDDEN'];
}

$resultMTop = mysql_query("SELECT * FROM " . $Prefix . "MEMBERS WHERE MEMBER_ID = '$TOP_TopicAuthor' ")
or die (mysql_error());

if(mysql_num_rows($resultMTop) > 0){
$rsMTop = mysql_fetch_array($resultMTop);

$MTOP_MemberID = $rsMTop['MEMBER_ID'];
$MTOP_MemberName = $rsMTop['M_NAME'];
$MTOP_MemberStatus = $rsMTop['M_STATUS'];
$MTOP_MemberCountry = $rsMTop['M_COUNTRY'];
$MTOP_MemberTitle = $rsMTop['M_TITLE'];
$MTOP_MemberLevel = $rsMTop['M_LEVEL'];
$MTOP_MemberPosts = $rsMTop['M_POSTS'];
$MTOP_MemberDate = $rsMTop['M_DATE'];
$MTOP_MemberPhotoUrl = $rsMTop['M_PHOTO_URL'];
}

$resultFTop = mysql_query("SELECT * FROM " . $Prefix . "FORUM WHERE FORUM_ID = '$TOP_ForumID' ") or die (mysql_error());

if(mysql_num_rows($resultFTop) > 0){
$rsFTop = mysql_fetch_array($resultFTop);

$FTOP_ForumID = $rsFTop['FORUM_ID'];
$FTOP_ForumSubject = $rsFTop['F_SUBJECT'];
$FTOP_ForumLogo = $rsFTop['F_LOGO'];
}
//################################ topic titles ##########################
$T_Titles = mysql_query("SELECT * FROM ".$Prefix."TITLES WHERE T_MEMBERID = '$MTOP_MemberID' AND T_STATUS = '0' AND T_FORUMID = '$FTOP_ForumID' ORDER BY TITLE_ID ASC ") or die (mysql_error());
$Titles_rows = mysql_num_rows($T_Titles);


 while ($T_Trow = @mysql_fetch_array($T_Titles)) {

    $Titles_TitleID = $T_Trow[TITLE_ID];
    $Titles_MemberID = $T_Trow[T_MEMBERID];
    $Titles_ForumID = $T_Trow[T_FORUMID];
    $Titles_Status = $T_Trow[T_STATUS];
    $Titles_Color = $T_Trow[T_COLOR];
    $Titles_Subject = $T_Trow[T_SUBJECT];
    
    
   if ($Titles_rows == 1) {
       $Member_Titles = '<font color="'.$Titles_Color.'">'.$Titles_Subject.'</font>';
   }
   if ($Titles_rows > 1) {
       $Member_Titles = $Member_Titles;
       if ($Member_Titles != "") {
       $Member_Titles .= '<br>';
       }
       $Member_Titles .= '<font color="'.$Titles_Color.'">'.$Titles_Subject.'</font>';
   }

 }
 
$TT_Titles = mysql_query("SELECT * FROM ".$Prefix."TITLES WHERE T_MEMBERID = '$MTOP_MemberID' AND T_STATUS = '1' ORDER BY TITLE_ID ASC ") or die (mysql_error());
$TTitles_rows = mysql_num_rows($TT_Titles);


 while ($TT_Trow = @mysql_fetch_array($TT_Titles)) {

    $TTitles_TitleID = $TT_Trow[TITLE_ID];
    $TTitles_MemberID = $TT_Trow[T_MEMBERID];
    $TTitles_ForumID = $TT_Trow[T_FORUMID];
    $TTitles_Status = $TT_Trow[T_STATUS];
    $TTitles_Color = $TT_Trow[T_COLOR];
    $TTitles_Subject = $TT_Trow[T_SUBJECT];

   if ($TTitles_rows == 1) {
       $TMember_Titles = '<font color="'.$TTitles_Color.'">'.$TTitles_Subject.'</font>';
   }
   if ($TTitles_rows > 1) {
       $TMember_Titles = $TMember_Titles;
       if ($TMember_Titles != "") {
       $TMember_Titles .= '<br>';
       }
       $TMember_Titles .= '<font color="'.$TTitles_Color.'">'.$TTitles_Subject.'</font>';
   }

 }
 
 
$T_MemberTitles = $Member_Titles;
if ($Member_Titles != "" AND $TMember_Titles != "") {
$T_MemberTitles .= '<br>';
}
$T_MemberTitles .= $TMember_Titles;
//######################## topic titles ##########################

$queryCount = "UPDATE " . $Prefix . "TOPICS SET ";
$queryCount .= "T_COUNTS = T_COUNTS + 1 ";
$queryCount .= "WHERE TOPIC_ID = '$TOP_TopicID' ";

mysql_query($queryCount, $connection) or die (mysql_error());

$Monitor = chk_monitor($DBMemberID, $TOP_CatID);
$Moderator = chk_moderator($DBMemberID, $TOP_ForumID);

echo'
<center>
<table dir="rtl" cellSpacing="0" cellPadding="0" width="99%" border="0">
	<tr>
		<td>
		<table cellSpacing="2" width="100%" border="0">
			<tr>
			<td><a class="menu" href="index.php?mode=f&f='.$FTOP_ForumID.'">'.icons($image_folder."forum-logo/".$FTOP_ForumLogo, "", "").'</a></td>
			<td class="main" vAlign="center" width="100%"><a class="menu" href="index.php?mode=f&f='.$FTOP_ForumID.'"><font color="red" size="+1">'.$FTOP_ForumSubject.'</font></a></td>
			<td class="optionsbar_menus" vAlign="top"><nobr><a href="index.php?mode=editor&method=reply&t='.$TOP_TopicID.'&f='.$TOP_ForumID.'&c='.$TOP_CatID.'">'.icons($icon_reply_topic, "�� ��� �������", "").'<br>��� ��</a></nobr></td>
            <td class="optionsbar_menus" vAlign="top"><nobr><a href="index.php?mode=editor&method=topic&f='.$TOP_ForumID.'&c='.$TOP_CatID.'">'.icons($folder_new, "��� ����� ����", "").'<br>����� ����</a></nobr></td>';

            include("go_to.php");
            echo'
			</tr>
		</table>
		<table class="optionsbar" dir="rtl" cellSpacing="2" width="100%" border="0">
			<tr>
				<td vAlign="center">&nbsp;';
				if ($TOP_TopicStatus == 1) {
				    echo icons($folder, "����� �����", "");
				}
				if ($TOP_TopicStatus == 0) {
				    echo icons($folder_locked, "����� ����", "");
				}
				echo'</td>
				<td class="optionsbar_title" vAlign="center" align="middle" width="100%">&nbsp;'.$TOP_TopicSubject.'</td>
			</tr>
		</table>
		<table class="grid" dir="rtl" cellSpacing="0" cellPadding="0" width="100%" align="center" border="0">
			<tr>
				<td>
				<table dir="rtl" cellSpacing="1" cellPadding="4" width="100%" border="0">';
        
        if ($r != "") {
            echo'<tr><td align="center" bgcolor="red" colspan="5"><font color="white">���� ����� �� ���� �� ������� - ������� ������� ������� <a href="index.php?mode=t&t='.$t.'"><font color="yellow">���� ���</font></a></font></td></tr>';
        }
        if ($r == "") {
        if ($m == $TOP_TopicAuthor) {
            echo'<tr><td align="center" bgcolor="red" colspan="5"><font color="white">���� ����� ���� ��� ���� ��� �� ������� - ������� ������� ������� <a href="index.php?mode=t&t='.$t.'"><font color="yellow">���� ���</font></a></font></td></tr>';
        }
if ($TOP_TopicHidden == 1) {
    if ($Mlevel == 4 OR $Monitor == 1 OR $Moderator == 1 OR $DBMemberID == $TOP_TopicAuthor) {
                    echo'
					<tr>
						<td width="12%" vAlign="top" class="deleted"><b>'.admin_profile($MTOP_MemberName, $MTOP_MemberID, $Prefix).'</b><br>';
                    if ($MTOP_MemberStatus == 0) {
                        echo'<font size="1"><nobr>- ����� ������ -</nobr></font>';
                    }
                    else {
                        echo'<font size="-1"><nobr><small>���������: '.$MTOP_MemberPosts.'</small></nobr></font><br>';
                      if (member_stars($MTOP_MemberID) != "") {
                        echo'<font size="-1"><nobr><small>'.member_stars($MTOP_MemberID).'</small></nobr></font><br>';
                      }
                      if ($T_MemberTitles != "") {
                          echo'<font size="-1"><small>'.$T_MemberTitles.'</small></font><br>';
                      }
                      else {
                        if (member_title($MTOP_MemberID) != "") {
                          echo'<font size="-1"><small>'.member_title($MTOP_MemberID).'</small></font><br>';
                        }
                      }
                      if ($MTOP_MemberPhotoUrl != "") {
                        echo'<img onerror="this.src=\''.$icon_blank.'\';this.width=0;" src="'.$MTOP_MemberPhotoUrl.'" width="100"><br>';
                      }
                      if ($MTOP_MemberCountry != "") {
						echo'<font size="-1"><nobr><small>'.$MTOP_MemberCountry.'</small></nobr><br>';
                      }

                        echo'<font size="-1"><nobr><small>��� ������ ��� ��������: '.member_total_days($MTOP_MemberDate).'</small></nobr><br>';
                        echo'<font size="-1"><nobr><small>���� ��������� �� �����: '.member_middle_posts($MTOP_MemberPosts, $MTOP_MemberDate).'</small></nobr><br>';
      
                        echo'</td>';
                    }
                        echo'
						<td vAlign="top" width="100%" class="deleted" colSpan="3">
						<table cellSpacing="0" cellPadding="0" width="100%">
							<tr>
								<td class="posticon" bgColor="red">
								<table cellSpacing="2" width="100%">
									<tr>
										<td class="posticon"><nobr>'.normal_time($TOP_TopicDate).'</nobr></td>
										<td class="posticon"><nobr><a href="index.php?mode=profile&id='.$MTOP_MemberID.'">'.icons($icon_profile, "������� �� �����", "").'</a></nobr></td>';
                                    if ($Mlevel > 0) {
                                        echo'<td class="posticon"><nobr><a href="index.php?mode=editor&method=sendmsg&m='.$MTOP_MemberID.'">'.icons($icon_private_message, "���� ����� ���� ���� �����", "").'</a></nobr></td>';
                                    }
                                    if ($Mlevel == 4 OR $Monitor == 1 OR $Moderator == 1 OR $TOP_TopicStatus == 1 AND $DBMemberID == $TOP_TopicAuthor) {
                                        echo'<td class="posticon"><nobr><a href="index.php?mode=editor&method=edit&t='.$TOP_TopicID.'&f='.$TOP_ForumID.'&c='.$TOP_CatID.'">'.icons($icon_edit, "����� �������", "").'</a></nobr></td>';
                                    }
                                    
                                    if ($Mlevel == 4 OR $Monitor == 1 OR $Moderator == 1) {
                                      if ($TOP_TopicStatus == 1) {
                                        echo'<td class="posticon"><nobr><a href="index.php?mode=lock&type=t&t='.$TOP_TopicID.'&f='.$TOP_ForumID.'&c='.$TOP_CatID.'"  onclick="return confirm(\'�� ��� ����� ��� ���� ��� ��� ������� �\');">'.icons($folder_locked, "��� �������", "").'</a></nobr></td>';
                                      }
                                      if ($TOP_TopicStatus == 0) {
                                        echo'<td class="posticon"><nobr><a href="index.php?mode=open&type=t&t='.$TOP_TopicID.'&f='.$TOP_ForumID.'&c='.$TOP_CatID.'"  onclick="return confirm(\'�� ��� ����� ��� ���� ��� ��� ������� �\');">'.icons($folder_unlocked, "��� �������", "").'</a></nobr></td>';
                                      }
                                      if ($Mlevel == 4 OR $Monitor == 1) {
                                        echo'<td class="posticon"><nobr><a href="index.php?mode=delete&type=t&t='.$TOP_TopicID.'&f='.$TOP_ForumID.'&c='.$TOP_CatID.'"  onclick="return confirm(\'�� ��� ����� ��� ���� ��� ��� ������� �\');">'.icons($folder_delete, "��� �������", "").'</a></nobr></td>';
                                      }
                                        echo'<td class="posticon"><nobr><a href="index.php?mode=open&type=h&t='.$TOP_TopicID.'&f='.$TOP_ForumID.'&c='.$TOP_CatID.'"  onclick="return confirm(\'�� ��� ����� ��� ���� ����� ��� ������� �\');">'.icons($icon_unhidden, "����� �������", "").'</a></nobr></td>';
                                     }
                                     if ($Mlevel > 0) {
                                        echo'<td class="posticon"><nobr><a href="index.php?mode=t&t='.$t.'&m='.$MTOP_MemberID.'">'.icons($icon_group, "���� ��� ����� ���", "").'</a></nobr></td>';
                                     }
                                        echo'
										<td class="posticon" width="90%">&nbsp;</td>
									</tr>
								</table>
								</td>
							</tr>
						</table>
						<table dir="rtl" cellSpacing="1" cellPadding="4" width="100%" border="0">
						    <tr>
						        <td vAlign="top" width="100%" bgColor="#aadddd" colSpan="3">
						        <table class="optionsbar" width="100%">
						            <tr>
						                <td class="optionsbar_menus">** �� ����� ��� �������� -- ��������� �� ����� ������ ������� ����� ������� **</td>
						            </tr>
						        </table>
						        </td>
						    </tr>
						</table>
						<table style="TABLE-LAYOUT: fixed">
							<tr>
								<td>'. text_replace($TOP_TopicMessage) .'</td>
							</tr>
						</table>
						</td>
					</tr>';
    }
}
if ($TOP_TopicHidden == 0) {
                    echo'
					<tr>
						<td width="12%" vAlign="top" bgColor="#ddffdd"><b>'.admin_profile($MTOP_MemberName, $MTOP_MemberID, $Prefix).'</b><br>';
                    if ($MTOP_MemberStatus == 0) {
                        echo'<font size="1"><nobr>- ����� ������ -</nobr></font>';
                    }
                    else {
                        echo'<font size="-1"><nobr><small>���������: '.$MTOP_MemberPosts.'</small></nobr></font><br>';
                      if (member_stars($MTOP_MemberID) != "") {
                        echo'<font size="-1"><nobr><small>'.member_stars($MTOP_MemberID).'</small></nobr></font><br>';
                      }
                      if ($T_MemberTitles != "") {
                          echo'<font size="-1"><small>'.$T_MemberTitles.'</small></font><br>';
                      }
                      else {
                        if (member_title($MTOP_MemberID) != "") {
                          echo'<font size="-1"><small>'.member_title($MTOP_MemberID).'</small></font><br>';
                        }
                      }
                      if ($MTOP_MemberPhotoUrl != "") {
                        echo'<img onerror="this.src=\''.$icon_blank.'\';this.width=0;" src="'.$MTOP_MemberPhotoUrl.'" width="100"><br>';
                      }
                      if ($MTOP_MemberCountry != "") {
						echo'<font size="-1"><nobr><small>'.$MTOP_MemberCountry.'</small></nobr><br>';
                      }

                        echo'<font size="-1"><nobr><small>��� ������ ��� ��������: '.member_total_days($MTOP_MemberDate).'</small></nobr><br>';
						echo'<font size="-1"><nobr><small>���� ��������� �� �����: '.member_middle_posts($MTOP_MemberPosts, $MTOP_MemberDate).'</small></nobr><br>';

                        echo'</td>';
                    }
                        echo'
						<td vAlign="top" width="100%" bgColor="#ddffdd" colSpan="3">
						<table cellSpacing="0" cellPadding="0" width="100%">
							<tr>
								<td class="posticon" bgColor="red">
								<table cellSpacing="2" width="100%">
									<tr>
										<td class="posticon"><nobr>'.normal_time($TOP_TopicDate).'</nobr></td>
										<td class="posticon"><nobr><a href="index.php?mode=profile&id='.$MTOP_MemberID.'">'.icons($icon_profile, "������� �� �����", "").'</a></nobr></td>';
                                    if ($Mlevel > 0) {
                                        echo'<td class="posticon"><nobr><a href="index.php?mode=editor&method=sendmsg&m='.$MTOP_MemberID.'">'.icons($icon_private_message, "���� ����� ���� ���� �����", "").'</a></nobr></td>';
                                    }
                                    if ($Mlevel == 4 OR $Monitor == 1 OR $Moderator == 1 OR $TOP_TopicStatus == 1 AND $DBMemberID == $TOP_TopicAuthor) {
                                        echo'<td class="posticon"><nobr><a href="index.php?mode=editor&method=edit&t='.$TOP_TopicID.'&f='.$TOP_ForumID.'&c='.$TOP_CatID.'">'.icons($icon_edit, "����� �������", "").'</a></nobr></td>';
                                    }

                                    if ($Mlevel == 4 OR $Monitor == 1 OR $Moderator == 1) {
                                      if ($TOP_TopicStatus == 1) {
                                        echo'<td class="posticon"><nobr><a href="index.php?mode=lock&type=t&t='.$TOP_TopicID.'&f='.$TOP_ForumID.'&c='.$TOP_CatID.'"  onclick="return confirm(\'�� ��� ����� ��� ���� ��� ��� ������� �\');">'.icons($folder_locked, "��� �������", "").'</a></nobr></td>';
                                      }
                                      if ($TOP_TopicStatus == 0) {
                                        echo'<td class="posticon"><nobr><a href="index.php?mode=open&type=t&t='.$TOP_TopicID.'&f='.$TOP_ForumID.'&c='.$TOP_CatID.'"  onclick="return confirm(\'�� ��� ����� ��� ���� ��� ��� ������� �\');">'.icons($folder_unlocked, "��� �������", "").'</a></nobr></td>';
                                      }
                                      if ($Mlevel == 4 OR $Monitor == 1) {
                                        echo'<td class="posticon"><nobr><a href="index.php?mode=delete&type=t&t='.$TOP_TopicID.'&f='.$TOP_ForumID.'&c='.$TOP_CatID.'"  onclick="return confirm(\'�� ��� ����� ��� ���� ��� ��� ������� �\');">'.icons($folder_delete, "��� �������", "").'</a></nobr></td>';
                                      }
                                        echo'<td class="posticon"><nobr><a href="index.php?mode=lock&type=h&t='.$TOP_TopicID.'&f='.$TOP_ForumID.'&c='.$TOP_CatID.'"  onclick="return confirm(\'�� ��� ����� ��� ���� ����� ��� ������� �\');">'.icons($icon_hidden, "����� �������", "").'</a></nobr></td>';
                                     }
                                     if ($Mlevel > 0) {
                                        echo'<td class="posticon"><nobr><a href="index.php?mode=t&t='.$t.'&m='.$MTOP_MemberID.'">'.icons($icon_group, "���� ��� ����� ���", "").'</a></nobr></td>';
                                     }
                                        echo'
										<td class="posticon" width="90%">&nbsp;</td>
									</tr>
								</table>
								</td>
							</tr>
						</table>
						<table style="TABLE-LAYOUT: fixed">
							<tr>
								<td>'. text_replace($TOP_TopicMessage) .'</td>
							</tr>
						</table>
						</td>
					</tr>';
}
        }
 $Just = '';
if ($m != "") {
 $Just = 'AND R_AUTHOR = '.$m;
}
if ($r != "") {
 $Just = 'AND REPLY_ID = '.$r;
}
$resultRe = mysql_query("SELECT * FROM ".$Prefix."REPLY WHERE TOPIC_ID = '$TOP_TopicID' ".$Just." ORDER BY R_DATE ASC ") or die (mysql_error());

$numRe = mysql_num_rows($resultRe);

$iRe = 0;
while ($iRe < $numRe) {


    $R_ReplyID = mysql_result($resultRe, $iRe, "REPLY_ID");
    $R_CatID = mysql_result($resultRe, $iRe, "CAT_ID");
    $R_ForumID = mysql_result($resultRe, $iRe, "FORUM_ID");
    $R_TopicID = mysql_result($resultRe, $iRe, "TOPIC_ID");
    $R_Author = mysql_result($resultRe, $iRe, "R_AUTHOR");
    $R_Message = mysql_result($resultRe, $iRe, "R_MESSAGE");
    $R_Date = mysql_result($resultRe, $iRe, "R_DATE");
    $R_Hidden = mysql_result($resultRe, $iRe, "R_HIDDEN");
    
    
$resultRM = mysql_query("SELECT * FROM " . $Prefix . "MEMBERS WHERE MEMBER_ID = '$R_Author' ")
or die (mysql_error());

if(mysql_num_rows($resultRM) > 0){
$rsRM = mysql_fetch_array($resultRM);

$RM_MemberID = $rsRM['MEMBER_ID'];
$RM_MemberName = $rsRM['M_NAME'];
$RM_MemberStatus = $rsRM['M_STATUS'];
$RM_MemberCountry = $rsRM['M_COUNTRY'];
$RM_MemberTitle = $rsRM['M_TITLE'];
$RM_MemberLevel = $rsRM['M_LEVEL'];
$RM_MemberPosts = $rsRM['M_POSTS'];
$RM_MemberDate = $rsRM['M_DATE'];
$RM_MemberPhotoUrl = $rsRM['M_PHOTO_URL'];
}

$R_MemberTitles = reply_member_title($RM_MemberID, $TOP_ForumID);

if ($R_Hidden == 1) {
    if ($Mlevel == 4 OR $Monitor == 1 OR $Moderator == 1 OR $DBMemberID == $R_Author) {
        if ($m != "") {
            echo'<tr><td align="center" bgcolor="red" colspan="5"><font color="white">���� ����� ���� ��� ���� ��� �� ������� - ������� ������� ������� <a href="index.php?mode=t&t='.$t.'"><font color="yellow">���� ���</font></a></font></td></tr>';
        }
                    echo'
					<tr>
						<td width="12%" vAlign="top" class="deleted"><b>'.admin_profile($RM_MemberName, $RM_MemberID, $Prefix).'</b><br>';
                    if ($RM_MemberStatus == 0) {
                        echo'<font size="1"><nobr>- ����� ������ -</nobr></font>';
                    }
                    else {
                        echo'<font size="-1"><nobr><small>���������: '.$RM_MemberPosts.'</small></nobr></font><br>';
                      if (member_stars($RM_MemberID) != "") {
                        echo'<font size="-1"><nobr><small>'.member_stars($RM_MemberID).'</small></nobr></font><br>';
                      }
                      if ($R_MemberTitles != "") {
                          echo'<font size="-1"><small>'.$R_MemberTitles.'</small></font><br>';
                      }
                      else {
                        if (member_title($RM_MemberID) != "") {
                          echo'<font size="-1"><small>'.member_title($RM_MemberID).'</small></font><br>';
                        }
                      }
                      if ($RM_MemberPhotoUrl != "") {
                        echo'<img onerror="this.src=\''.$icon_blank.'\';this.width=0;" src="'.$RM_MemberPhotoUrl.'" width="100"><br>';
                      }
                      if ($RM_MemberCountry != "") {
						echo'<font size="-1"><nobr><small>'.$RM_MemberCountry.'</small></nobr><br>';
                      }

						echo'<font size="-1"><nobr><small>��� ������ ��� ��������: '.member_total_days($RM_MemberDate).'</small></nobr><br>';
                        echo'<font size="-1"><nobr><small>���� ��������� �� �����: '.member_middle_posts($RM_MemberPosts, $RM_MemberDate).'</small></nobr><br>';

                        echo'</td>';
                    }
                        echo'
						<td vAlign="top" width="100%" class="deleted" colSpan="3">
						<table cellSpacing="0" cellPadding="0" width="100%">
							<tr>
								<td class="posticon" bgColor="red">
								<table cellSpacing="2" width="100%">
									<tr>
										<td class="posticon"><nobr>'.normal_time($R_Date).'</nobr></td>
										<td class="posticon"><nobr><a href="index.php?mode=profile&id='.$RM_MemberID.'">'.icons($icon_profile, "������� �� �����", "").'</a></nobr></td>';
                                    if ($Mlevel > 0) {
                                        echo'<td class="posticon"><nobr><a href="index.php?mode=editor&method=sendmsg&m='.$RM_MemberID.'">'.icons($icon_private_message, "���� ����� ���� ���� �����", "").'</a></nobr></td>';
                                    }
                                    if ($Mlevel == 4 OR $Monitor == 1 OR $Moderator == 1 OR $DBMemberID == $R_Author) {
                                        echo'<td class="posticon"><nobr><a href="index.php?mode=editor&method=editreply&r='.$R_ReplyID.'&t='.$R_TopicID.'&f='.$R_ForumID.'&c='.$R_CatID.'">'.icons($icon_edit, "����� ��", "").'</a></nobr></td>';
                                    }

                                    if ($Mlevel == 4 OR $Monitor == 1 OR $R_Hidden != 1 AND $DBMemberID == $R_Author) {
                                        echo'<td class="posticon"><nobr><a href="index.php?mode=delete&type=r&r='.$R_ReplyID.'&t='.$R_TopicID.'&f='.$R_ForumID.'&c='.$R_CatID.'" onclick="return confirm(\'�� ��� ����� ��� ���� ��� ��� ���Ͽ\');">'.icons($icon_delete_reply, "��� ��", "").'</a></nobr></td>';
                                    }

                                    if ($Mlevel == 4 OR $Monitor == 1 OR $Moderator == 1) {
                                        echo'<td class="posticon"><nobr><a href="index.php?mode=open&type=hr&r='.$R_ReplyID.'&t='.$R_TopicID.'&f='.$R_ForumID.'&c='.$R_CatID.'" onclick="return confirm(\'�� ��� ����� ��� ���� ����� ��� ���� �\');">'.icons($icon_unhidden, "����� ��", "").'</a></nobr></td>';
                                    }
                                    if ($Mlevel > 0) {
                                        echo'<td class="posticon"><nobr><a href="index.php?mode=t&t='.$t.'&r='.$R_ReplyID.'">'.icons($icon_single, "��� ���� ���", "").'</a></nobr></td>';
                                        echo'<td class="posticon"><nobr><a href="index.php?mode=t&t='.$t.'&m='.$RM_MemberID.'">'.icons($icon_group, "���� ��� ����� ���", "").'</a></nobr></td>';
                                    }
                                        echo'
										<td class="posticon" width="90%">&nbsp;</td>
									</tr>
								</table>
								</td>
							</tr>
						</table>
						<table dir="rtl" cellSpacing="1" cellPadding="4" width="100%" border="0">
						    <tr>
						        <td vAlign="top" width="100%" bgColor="#aadddd" colSpan="3">
						        <table class="optionsbar" width="100%">
						            <tr>
						                <td class="optionsbar_menus">** �� ����� ��� �������� -- ��������� �� ����� ������ ������� ����� ������� **</td>
						            </tr>
						        </table>
						        </td>
						    </tr>
						</table>
						<table style="TABLE-LAYOUT: fixed">
							<tr>
								<td>'. text_replace($R_Message) .'</td>
							</tr>
						</table>
						</td>
					</tr>';

    }
}
if ($R_Hidden == 0) {

    if ($iRe % 2) {
	    $bg_color = "fixed";
    }
    else
    {
	    $bg_color = "normal";

    }
        if ($m != "") {
            echo'<tr><td align="center" bgcolor="red" colspan="5"><font color="white">���� ����� ���� ��� ���� ��� �� ������� - ������� ������� ������� <a href="index.php?mode=t&t='.$t.'"><font color="yellow">���� ���</font></a></font></td></tr>';
        }
                    echo'
					<tr>
						<td width="12%" vAlign="top" class="'.$bg_color.'"><b>'.admin_profile($RM_MemberName, $RM_MemberID, $Prefix).'</b><br>';
                    if ($RM_MemberStatus == 0) {
                        echo'<font size="1"><nobr>- ����� ������ -</nobr></font>';
                    }
                    else {
                        echo'<font size="-1"><nobr><small>���������: '.$RM_MemberPosts.'</small></nobr></font><br>';
                      if (member_stars($RM_MemberID) != "") {
                        echo'<font size="-1"><nobr><small>'.member_stars($RM_MemberID).'</small></nobr></font><br>';
                      }
                      if ($R_MemberTitles != "") {
                          echo'<font size="-1"><small>'.$R_MemberTitles.'</small></font><br>';
                      }
                      else {
                        if (member_title($RM_MemberID) != "") {
                          echo'<font size="-1"><small>'.member_title($RM_MemberID).'</small></font><br>';
                        }
                      }
                      if ($RM_MemberPhotoUrl != "") {
                        echo'<img onerror="this.src=\''.$icon_blank.'\';this.width=0;" src="'.$RM_MemberPhotoUrl.'" width="100"><br>';
                      }
                      if ($RM_MemberCountry != "") {
						echo'<font size="-1"><nobr><small>'.$RM_MemberCountry.'</small></nobr><br>';
                      }

                        echo'<font size="-1"><nobr><small>��� ������ ��� ��������: '.member_total_days($RM_MemberDate).'</small></nobr><br>';
                        echo'<font size="-1"><nobr><small>���� ��������� �� �����: '.member_middle_posts($RM_MemberPosts, $RM_MemberDate).'</small></nobr><br>';

                        echo'</td>';
                    }
                        echo'
						<td vAlign="top" width="100%" class="'.$bg_color.'" colSpan="3">
						<table cellSpacing="0" cellPadding="0" width="100%">
							<tr>
								<td class="posticon" bgColor="red">
								<table cellSpacing="2" width="100%">
									<tr>
										<td class="posticon"><nobr>'.normal_time($R_Date).'</nobr></td>
										<td class="posticon"><nobr><a href="index.php?mode=profile&id='.$RM_MemberID.'">'.icons($icon_profile, "������� �� �����", "").'</a></nobr></td>';
                                    if ($Mlevel > 0) {
                                        echo'<td class="posticon"><nobr><a href="index.php?mode=editor&method=sendmsg&m='.$RM_MemberID.'">'.icons($icon_private_message, "���� ����� ���� ���� �����", "").'</a></nobr></td>';
                                    }
                                    if ($Mlevel == 4 OR $Monitor == 1 OR $Moderator == 1 OR $DBMemberID == $R_Author) {
                                        echo'<td class="posticon"><nobr><a href="index.php?mode=editor&method=editreply&r='.$R_ReplyID.'&t='.$R_TopicID.'&f='.$R_ForumID.'&c='.$R_CatID.'">'.icons($icon_edit, "����� ��", "").'</a></nobr></td>';
                                    }
                                    
                                    if ($Mlevel == 4 OR $Monitor == 1 OR $R_Hidden != 1 AND $DBMemberID == $R_Author) {
                                        echo'<td class="posticon"><nobr><a href="index.php?mode=delete&type=r&r='.$R_ReplyID.'&t='.$R_TopicID.'&f='.$R_ForumID.'&c='.$R_CatID.'" onclick="return confirm(\'�� ��� ����� ��� ���� ��� ��� ���Ͽ\');">'.icons($icon_delete_reply, "��� ��", "").'</a></nobr></td>';
                                    }
                                    
                                    if ($Mlevel == 4 OR $Monitor == 1 OR $Moderator == 1) {
                                        echo'<td class="posticon"><nobr><a href="index.php?mode=lock&type=hr&r='.$R_ReplyID.'&t='.$R_TopicID.'&f='.$R_ForumID.'&c='.$R_CatID.'" onclick="return confirm(\'�� ��� ����� ��� ���� ����� ��� ���Ͽ\');">'.icons($icon_hidden, "����� ��", "").'</a></nobr></td>';
                                    }
                                    if ($Mlevel > 0) {
                                        echo'<td class="posticon"><nobr><a href="index.php?mode=t&t='.$t.'&r='.$R_ReplyID.'">'.icons($icon_single, "��� ���� ���", "").'</a></nobr></td>';
                                        echo'<td class="posticon"><nobr><a href="index.php?mode=t&t='.$t.'&m='.$RM_MemberID.'">'.icons($icon_group, "���� ��� ����� ���", "").'</a></nobr></td>';
                                    }
                                        echo'
										<td class="posticon" width="90%">&nbsp;</td>
									</tr>
								</table>
								</td>
							</tr>
						</table>
						<table style="TABLE-LAYOUT: fixed">
							<tr>
								<td>'. text_replace($R_Message) .'</td>
							</tr>
						</table>
						</td>
					</tr>';
    
}

    ++$iRe;
}
                if ($Mlevel == 4 OR $Monitor == 1 OR $Moderator == 1 OR $TOP_TopicStatus == 1 AND $Mlevel != 0) {
?>
<SCRIPT LANGUAGE="JavaScript">
function submitQuickReplyForm() {
 var x = quickreply.message.value;

 while ((x.substring(0,1) == ' ') || (x.substring(0,1) == '\r') || (x.substring(0,1) == '\n') || (x.substring(0,1) == '\t'))
 	 x = x.substring(1);

 quickreply.message.value = x;

 if (quickreply.message.value.length < 3) return;
 quickreply.submit();
}
</script>
<?
                echo'
					<tr>
						<form name="quickreply" method="post" action="index.php?mode=post_info">
							<td vAlign="top" align="middle" bgColor="white"><br>'.icons($icon_reply_topic,"","").'<br><br><font color="red">��� <br>�� ���� </font></td>
							<td vAlign="top" align="middle" width="100%" bgColor="white" colSpan="3">
							<textarea style="FONT-SIZE: 25px; WIDTH: 100%; COLOR: #006600; FONT-FAMILY: comic sans ms; HEIGHT: 150px; TEXT-ALIGN: center" name="message" rows="1" cols="20"></textarea>
                            <input name="method" type="hidden" value="reply">
							<input name="t" type="hidden" value="'.$TOP_TopicID.'">
							<input name="f" type="hidden" value="'.$TOP_ForumID.'">
							<input name="c" type="hidden" value="'.$TOP_CatID.'">
							<input name="host" type="hidden" value="'.$HTTP_HOST.'">
							<input name="type" type="hidden" value="q_reply">
							<input onclick="submitQuickReplyForm()" type="button" value="��� ���� �������">';
							if ($Mlevel == 4 OR $Monitor == 1 OR $Moderator == 1) {
							  if ($TOP_TopicStatus == 1) {
							    echo'&nbsp;&nbsp;<input name="ReplyAndLock" type="submit" value="��� ���� + ��� �������">';
							  }
							}
							if ($Mlevel == 4 OR $Monitor == 1 OR $Moderator == 1) {
							  if ($TOP_TopicStatus == 0) {
							    echo'&nbsp;&nbsp;<input name="ReplyAndUnLock" type="submit" value="��� �� + ��� �������">';
							  }
							}
							echo'
							</td>
						</form>
					</tr>';
				}	
					
				echo'	
				</table>
				</td>
			</tr>
		</table>
		<table class="optionsbar" dir="rtl" cellSpacing="2" width="100%" border="0">
			<tr>
				<td vAlign="center">&nbsp;';
				if ($TOP_TopicStatus == 1) {
				    echo icons($folder, "����� �����", "");
				}
				if ($TOP_TopicStatus == 0) {
				    echo icons($folder_locked, "����� ����", "");
				}
				echo'</td>
				<td class="optionsbar_title" vAlign="center" align="middle" width="100%">&nbsp;'.$TOP_TopicSubject.'</td>
			</tr>
		</table>
		<table cellSpacing="2" width="100%" border="0">
			<tr>
			<td><a class="menu" href="index.php?mode=f&f='.$FTOP_ForumID.'">'.icons($image_folder."forum-logo/".$FTOP_ForumLogo, "", "").'</a></td>
			<td class="main" vAlign="center" width="100%"><a class="menu" href="index.php?mode=f&f='.$FTOP_ForumID.'"><font color="red" size="+1">'.$FTOP_ForumSubject.'</font></a></td>
			<td class="optionsbar_menus" vAlign="top"><nobr><a href="index.php?mode=editor&method=reply&t='.$TOP_TopicID.'&f='.$TOP_ForumID.'&c='.$TOP_CatID.'">'.icons($icon_reply_topic, "�� ��� �������", "").'<br>��� ��</a></nobr></td>
            <td class="optionsbar_menus" vAlign="top"><nobr><a href="index.php?mode=editor&method=topic&f='.$TOP_ForumID.'&c='.$TOP_CatID.'">'.icons($folder_new, "��� ����� ����", "").'<br>����� ����</a></nobr></td>';

            include("go_to.php");
            echo'
			</tr>
		</table>
		</td>
	</tr>
</table>
</center>
';


?>
