<?
/*//////////////////////////////////////////////////////////
// ######################################################///
// # DuhokForum 0.4                                     # //
// ###################################################### //
// #                                                    # //
// #       --  DUHOK FORUM IS FREE SOFTWARE  --         # //
// #                                                    # //
// #   ========= Programming By Dilovan ==============  # //
// # Copyright � 2007-2008 Dilovan. All Rights Reserved # //
// #----------------------------------------------------# //
// #----------------------------------------------------# //
// # If you want any support vist down address:-        # //
// # Email: df@duhoktimes.com                           # //
// # Site: http://df.duhoktimes.com/index.php           # //
// ###################################################### //
//////////////////////////////////////////////////////////*/

if ($CPMlevel == 4) {

$question = icons($icon_question, "���� ��� ������ ������� ��� ������", "");

if ($method == "") {

 if ($type == "") {

?>
<center>
<table class="grid" border="0" cellspacing="1" cellpadding="4" width="80%">
<form method="post" action="cp_home.php?mode=option&type=insert_data">
	<tr class="fixed">
		<td class="cat" colspan="2"><nobr>����� ������ �����</nobr></td>
	</tr>
	<tr class="fixed">
		<td class="list"><nobr>��� �������</nobr></td>
		<td class="middle"><input type="text" name="forum_name" size="40" value="<? print $forum_title;?>"></td>
	</tr>
 	<tr class="fixed">
		<td class="list"><nobr>����� ������</nobr></td>
		<td class="middle"><input type="text" dir="ltr" name="site_address" size="40" value="<? print $site_name;?>"></td>
	</tr>
 	<tr class="fixed">
		<td class="list"><nobr>���� �������</nobr></td>
		<td class="middle"><input type="text" dir="ltr" name="admin_email" size="40" value="<? print $admin_email;?>"></td>
	</tr>
 	<tr class="fixed">
		<td class="list"><nobr>���� �������</nobr></td>
		<td class="middle"><input type="text" dir="ltr" name="copy_right" size="40" value="<? print $copy_right;?>"></td>
	</tr>
 	<tr class="fixed">
		<td class="list"><nobr>��� ���� ���</nobr></td>
		<td class="middle"><input type="text" dir="ltr" name="image_folder" size="40" value="<? print $image_folder;?>"></td>
	</tr>
 	<tr class="fixed">
		<td class="list"><nobr>��� ���� �������</nobr></td>
		<td class="middle"><input type="text" dir="ltr" name="admin_folder" size="40" value="<? print $admin_folder;?>"></td>
	</tr>
 	<tr class="fixed">
		<td align="middle" colspan="2"><input type="submit" value="����� ������">&nbsp;&nbsp;&nbsp;<input type="reset" value="����� �� ������"></td>
	</tr>
</form>
</table>
</center>

<?
 }

 if ($type == "insert_data") {

$Admin_ForumTitle = $_POST["forum_name"];
$Admin_SiteAddress = $_POST["site_address"];
$Admin_CopyRight = $_POST["copy_right"];
$Admin_ImageFolder = $_POST["image_folder"];
$Admin_AdminFolder = $_POST["admin_folder"];
$Admin_AdminEmail = $_POST["admin_email"];

    if ($error != "") {
	                echo'<br><center>
	                <table bordercolor="#ffffff" width="99%" border="1">
	                   <tr class="normal">
	                       <td class="list_center" colSpan="10"><font size="5" color="red"><br>���<br>'.$error.'..</font><br><br>
	                       <a href="JavaScript:history.go(-1)">-- ���� ��� ������ --</a><br><br>
	                       </td>
	                   </tr>
	                </table>
	                </center>';
    }


    if ($error == "") {

updata_mysql("FORUM_TITLE", $Admin_ForumTitle);
updata_mysql("SITE_ADDRESS", $Admin_SiteAddress);
updata_mysql("COPY_RIGHT", $Admin_CopyRight);
updata_mysql("IMAGE_FOLDER", $Admin_ImageFolder);
updata_mysql("ADMIN_FOLDER", $Admin_AdminFolder);
updata_mysql("ADMIN_EMAIL", $Admin_AdminEmail);

rename($admin_folder.".php", $Admin_AdminFolder.".php");

                    echo'<br><br>
	                <center>
	                <table bordercolor="#ffffff" width="50%" border="1">
	                   <tr class="normal">
	                       <td class="list_center" colSpan="10"><font size="5"><br>�� ����� ������ �����..</font><br><br>
                           <meta http-equiv="Refresh" content="2; URL=cp_home.php?mode=option">
                           <a href="cp_home.php?mode=option">-- ���� ��� ������ ��� ���� ������� --</a><br><br>
	                       </td>
	                   </tr>
	                </table>
	                </center>';
    }

 }

}



if ($method == "other") {

 if ($type == "") {

echo'
<center>
<table class="grid" border="0" cellspacing="1" cellpadding="4" width="80%">
<form method="post" action="cp_home.php?mode=option&method=other&type=insert_data">
	<tr class="fixed">
		<td class="cat" colspan="2"><nobr>������� ����</nobr></td>
	</tr>
 	<tr class="fixed">
		<td class="list"><nobr>��� ������� ������</nobr></td>
		<td class="userdetails_data">
        <input type="radio" value="1" name="show_admin_info" '.check_radio($show_admin_info, "1").'>���&nbsp;&nbsp;&nbsp;&nbsp;
        <input type="radio" value="0" name="show_admin_info" '.check_radio($show_admin_info, "0").'>��
        </td>
	</tr>
 	<tr class="fixed">
		<td class="list"><nobr>��� �������� �� ������ ��������</nobr></td>
		<td class="userdetails_data">
        <input type="radio" value="1" name="show_moderators" '.check_radio($show_moderators, "1").'>���&nbsp;&nbsp;&nbsp;&nbsp;
        <input type="radio" value="0" name="show_moderators" '.check_radio($show_moderators, "0").'>��
        </td>
	</tr>
	<tr class="fixed">
		<td class="cat" colspan="2"><nobr>������ ����� � �������</nobr></td>
	</tr>
 	<tr class="fixed">
		<td class="list"><nobr>������� ���������</nobr></td>
		<td class="middle">
        <select class="insidetitle" style="WIDTH: 150px" name="style_name">';
        $ch_style = mysql_query("SELECT * FROM ".$Prefix."STYLE ") or die (mysql_error());
        $style_num = mysql_num_rows($ch_style);

        if ($style_num > 0) {

            $style_i = 0;
            while ($style_i < $style_num) {

                $style_id = mysql_result($ch_style, $style_i, "S_ID");
                $style_file_name = mysql_result($ch_style, $style_i, "S_FILE_NAME");
                $style_name = mysql_result($ch_style, $style_i, "S_NAME");

                echo'<option value="'.$style_file_name.'" '.check_select($default_style, $style_file_name).'>'.$style_name.'</option>';

            ++$style_i;
            }
        }
        else {
            echo'<option value="">�� ���� �� �����</option>';
        }
        echo'
        </td>
	</tr>
 	<tr class="fixed">
		<td class="list"><nobr>����� ����������</nobr></td>
		<td class="middle">
        <select class="insidetitle" style="WIDTH: 150px" name="lang_name">';
        $ch_lang = mysql_query("SELECT * FROM ".$Prefix."LANGUAGE ") or die (mysql_error());
        $lang_num = mysql_num_rows($ch_lang);

        if ($lang_num > 0) {

            $lang_i = 0;
            while ($lang_i < $lang_num) {

                $lang_id = mysql_result($ch_lang, $lang_i, "L_ID");
                $lang_file_name = mysql_result($ch_lang, $lang_i, "L_FILE_NAME");
                $lang_name = mysql_result($ch_lang, $lang_i, "L_NAME");

                echo'<option value="'.$lang_file_name.'" '.check_select($default_language, $lang_file_name).'>'.$lang_name.'&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</option>';

            ++$lang_i;
            }
        }
        else {
            echo'<option value="">�� ���� �� ���</option>';
        }
        echo'
        </td>
	</tr>
	<tr class="fixed">
		<td class="cat" colspan="2"><nobr>������ �������</nobr></td>
	</tr>
 	<tr class="fixed">
		<td class="list"><nobr>��� ���� ����� ��� ��������</nobr></td>
		<td class="middle"><input type="text" name="change_name_max" size="10" value="'.$change_name_max.'"></td>
	</tr>
 	<tr class="fixed">
		<td class="list"><nobr>��� ����� �� �� ����</nobr></td>
		<td class="middle"><input type="text" name="page_number" size="10" value="'.$max_page.'"></td>
	</tr>
 	<tr class="fixed">
		<td class="list"><nobr>��� ����� ���� ���� 24 ����</nobr></td>
		<td class="middle"><input type="text" name="total_pm_msg" size="10" value="'.$total_pm_message.'"></td>
	</tr>
	<tr class="fixed">
		<td class="cat" colspan="2"><nobr>������ ��� ������</nobr></td>
	</tr>
 	<tr class="fixed">
		<td class="list"><nobr>���� ��� ���� ��������</nobr></td>
		<td class="middle"><input type="text" name="topic_max_size" size="10" value="'.$topic_max_size.'"><font color="black">&nbsp;����&nbsp;&nbsp;/&nbsp;&nbsp;����� ('.to_kb($topic_max_size).') ��������</font></td>
	</tr>
 	<tr class="fixed">
		<td class="list"><nobr>���� ��� ���� ������</nobr></td>
		<td class="middle"><input type="text" name="reply_max_size" size="10" value="'.$reply_max_size.'"><font color="black">&nbsp;����&nbsp;&nbsp;/&nbsp;&nbsp;����� ('.to_kb($reply_max_size).') ��������</font></td>
	</tr>
 	<tr class="fixed">
		<td class="list"><nobr>���� ��� ���� ������� ������</nobr></td>
		<td class="middle"><input type="text" name="pm_max_size" size="10" value="'.$pm_max_size.'"><font color="black">&nbsp;����&nbsp;&nbsp;/&nbsp;&nbsp;����� ('.to_kb($pm_max_size).') ��������</font></td>
	</tr>
 	<tr class="fixed">
		<td class="list"><nobr>���� ��� ���� �������</nobr></td>
		<td class="middle"><input type="text" name="sig_max_size" size="10" value="'.$sig_max_size.'"><font color="black">&nbsp;����&nbsp;&nbsp;/&nbsp;&nbsp;����� ('.to_kb($sig_max_size).') ��������</font></td>
	</tr>
 	<tr class="fixed">
		<td align="middle" colspan="2"><input type="submit" value="����� ������">&nbsp;&nbsp;&nbsp;<input type="reset" value="����� �� ������"></td>
	</tr>
</form>
</table>
</center>';
 }

 if ($type == "insert_data") {


    if ($error != "") {
	                echo'<br><center>
	                <table bordercolor="#ffffff" width="99%" border="1">
	                   <tr class="normal">
	                       <td class="list_center" colSpan="10"><font size="5" color="red"><br>���<br>'.$error.'..</font><br><br>
	                       <a href="JavaScript:history.go(-1)">-- ���� ��� ������ --</a><br><br>
	                       </td>
	                   </tr>
	                </table>
	                </center>';
    }


    if ($error == "") {

updata_mysql("DEFAULT_STYLE", $_POST["style_name"]);
updata_mysql("DEFAULT_LANGUAGE", $_POST["lang_name"]);
updata_mysql("PAGE_NUMBER", $_POST["page_number"]);
updata_mysql("TOTAL_PM_MSG", $_POST["total_pm_msg"]);
updata_mysql("TOPIC_MAX_SIZE", $_POST['topic_max_size']);
updata_mysql("REPLY_MAX_SIZE", $_POST['reply_max_size']);
updata_mysql("PM_MAX_SIZE", $_POST['pm_max_size']);
updata_mysql("SIG_MAX_SIZE", $_POST['sig_max_size']);
updata_mysql("SHOW_ADMIN_INFO", $_POST['show_admin_info']);
updata_mysql("CHANGE_NAME_MAX", $_POST['change_name_max']);
updata_mysql("SHOW_MODERATORS", $_POST['show_moderators']);

                    echo'<br><br>
	                <center>
	                <table bordercolor="#ffffff" width="50%" border="1">
	                   <tr class="normal">
	                       <td class="list_center" colSpan="10"><font size="5"><br>�� ����� ������ �����..</font><br><br>
                           <meta http-equiv="Refresh" content="2; URL=cp_home.php?mode=option&method=other">
                           <a href="cp_home.php?mode=option&method=other">-- ���� ��� ������ ��� ���� ������� --</a><br><br>
	                       </td>
	                   </tr>
	                </table>
	                </center>';
    }

 }

}


if ($method == "editor") {

 if ($type == "") {

echo'
<center>
<table class="grid" border="0" cellspacing="1" cellpadding="4" width="60%">
<form method="post" action="cp_home.php?mode=option&method=editor&type=insert_data">
	<tr class="fixed">
		<td class="cat" colspan="2"><nobr>������ ���� ������</nobr></td>
	</tr>
 	<tr class="fixed">
		<td class="list"><nobr>��� ���� ���� HTML</nobr></td>
		<td width="60%" class="userdetails_data">
        <input class="radio" type="radio" value="true" name="ed_full_html" '.check_radio($editor_full_html, "true").'>���&nbsp;&nbsp;&nbsp;&nbsp;
        <input class="radio" type="radio" value="false" name="ed_full_html" '.check_radio($editor_full_html, "false").'>��
        </td>
	</tr>
 	<tr class="fixed">
		<td class="list"><nobr>��� ������</nobr></td>
		<td class="middle"><input type="text" name="ed_width" size="10" value="'.$editor_width.'"></td>
	</tr>
 	<tr class="fixed">
		<td class="list"><nobr>������ ������</nobr></td>
		<td class="middle"><input type="text" name="ed_height" size="10" value="'.$editor_height.'"></td>
	</tr>
 	<tr class="fixed">
		<td class="cat" colspan="2"><nobr>����� ������ ������� ������</nobr></td>
	</tr>
 	<tr class="fixed">
		<td class="list"><nobr>������ ���</nobr></td>
		<td class="userdetails_data">
        <input class="radio" type="radio" value="true" name="icon_0" '.check_radio($EditorIcon[0], "true").'>���&nbsp;&nbsp;&nbsp;&nbsp;
        <input class="radio" type="radio" value="false" name="icon_0" '.check_radio($EditorIcon[0], "false").'>��
        </td>
	</tr>
    <tr class="fixed">
		<td class="list"><nobr>������ �������</nobr></td>
		<td class="userdetails_data">
        <input class="radio" type="radio" value="true" name="icon_1" '.check_radio($EditorIcon[1], "true").'>���&nbsp;&nbsp;&nbsp;&nbsp;
        <input class="radio" type="radio" value="false" name="icon_1" '.check_radio($EditorIcon[1], "false").'>��
        </td>
	</tr>
    <tr class="fixed">
		<td class="list"><nobr>������ ����� ��������</nobr></td>
		<td class="userdetails_data">
        <input class="radio" type="radio" value="true" name="icon_2" '.check_radio($EditorIcon[2], "true").'>���&nbsp;&nbsp;&nbsp;&nbsp;
        <input class="radio" type="radio" value="false" name="icon_2" '.check_radio($EditorIcon[2], "false").'>��
        </td>
	</tr>
    <tr class="fixed">
		<td class="list"><nobr>������ �����</nobr></td>
		<td class="userdetails_data">
        <input class="radio" type="radio" value="true" name="icon_3" '.check_radio($EditorIcon[3], "true").'>���&nbsp;&nbsp;&nbsp;&nbsp;
        <input class="radio" type="radio" value="false" name="icon_3" '.check_radio($EditorIcon[3], "false").'>��
        </td>
	</tr>
    <tr class="fixed">
		<td class="list"><nobr>������ ��� ������</nobr></td>
		<td class="userdetails_data">
        <input class="radio" type="radio" value="true" name="icon_4" '.check_radio($EditorIcon[4], "true").'>���&nbsp;&nbsp;&nbsp;&nbsp;
        <input class="radio" type="radio" value="false" name="icon_4" '.check_radio($EditorIcon[4], "false").'>��
        </td>
	</tr>
    <tr class="fixed">
		<td class="list"><nobr>������ ��� ����</nobr></td>
		<td class="userdetails_data">
        <input class="radio" type="radio" value="true" name="icon_5" '.check_radio($EditorIcon[5], "true").'>���&nbsp;&nbsp;&nbsp;&nbsp;
        <input class="radio" type="radio" value="false" name="icon_5" '.check_radio($EditorIcon[5], "false").'>��
        </td>
	</tr>
    <tr class="fixed">
		<td class="list"><nobr>������ ��� ����</nobr></td>
		<td class="userdetails_data">
        <input class="radio" type="radio" value="true" name="icon_6" '.check_radio($EditorIcon[6], "true").'>���&nbsp;&nbsp;&nbsp;&nbsp;
        <input class="radio" type="radio" value="false" name="icon_6" '.check_radio($EditorIcon[6], "false").'>��
        </td>
	</tr>
    <tr class="fixed">
		<td class="list"><nobr>������ ����� ����</nobr></td>
		<td class="userdetails_data">
        <input class="radio" type="radio" value="true" name="icon_7" '.check_radio($EditorIcon[7], "true").'>���&nbsp;&nbsp;&nbsp;&nbsp;
        <input class="radio" type="radio" value="false" name="icon_7" '.check_radio($EditorIcon[7], "false").'>��
        </td>
	</tr>
    <tr class="fixed">
		<td class="list"><nobr>������ ����� ����</nobr></td>
		<td class="userdetails_data">
        <input class="radio" type="radio" value="true" name="icon_8" '.check_radio($EditorIcon[8], "true").'>���&nbsp;&nbsp;&nbsp;&nbsp;
        <input class="radio" type="radio" value="false" name="icon_8" '.check_radio($EditorIcon[8], "false").'>��
        </td>
	</tr>
    <tr class="fixed">
		<td class="list"><nobr>������ ��</nobr></td>
		<td class="userdetails_data">
        <input class="radio" type="radio" value="true" name="icon_9" '.check_radio($EditorIcon[9], "true").'>���&nbsp;&nbsp;&nbsp;&nbsp;
        <input class="radio" type="radio" value="false" name="icon_9" '.check_radio($EditorIcon[9], "false").'>��
        </td>
	</tr>
    <tr class="fixed">
		<td class="list"><nobr>������ ���</nobr></td>
		<td class="userdetails_data">
        <input class="radio" type="radio" value="true" name="icon_10" '.check_radio($EditorIcon[10], "true").'>���&nbsp;&nbsp;&nbsp;&nbsp;
        <input class="radio" type="radio" value="false" name="icon_10" '.check_radio($EditorIcon[10], "false").'>��
        </td>
	</tr>
    <tr class="fixed">
		<td class="list"><nobr>������ ���</nobr></td>
		<td class="userdetails_data">
        <input class="radio" type="radio" value="true" name="icon_11" '.check_radio($EditorIcon[11], "true").'>���&nbsp;&nbsp;&nbsp;&nbsp;
        <input class="radio" type="radio" value="false" name="icon_11" '.check_radio($EditorIcon[11], "false").'>��
        </td>
	</tr>
    <tr class="fixed">
		<td class="list"><nobr>������ ����� ��� ����</nobr></td>
		<td class="userdetails_data">
        <input class="radio" type="radio" value="true" name="icon_12" '.check_radio($EditorIcon[12], "true").'>���&nbsp;&nbsp;&nbsp;&nbsp;
        <input class="radio" type="radio" value="false" name="icon_12" '.check_radio($EditorIcon[12], "false").'>��
        </td>
	</tr>
    <tr class="fixed">
		<td class="list"><nobr>������ ���� ��� ��� ����</nobr></td>
		<td class="userdetails_data">
        <input class="radio" type="radio" value="true" name="icon_13" '.check_radio($EditorIcon[13], "true").'>���&nbsp;&nbsp;&nbsp;&nbsp;
        <input class="radio" type="radio" value="false" name="icon_13" '.check_radio($EditorIcon[13], "false").'>��
        </td>
	</tr>
    <tr class="fixed">
		<td class="list"><nobr>������ �� ����</nobr></td>
		<td class="userdetails_data">
        <input class="radio" type="radio" value="true" name="icon_14" '.check_radio($EditorIcon[14], "true").'>���&nbsp;&nbsp;&nbsp;&nbsp;
        <input class="radio" type="radio" value="false" name="icon_14" '.check_radio($EditorIcon[14], "false").'>��
        </td>
	</tr>
    <tr class="fixed">
		<td class="list"><nobr>������ �� ����</nobr></td>
		<td class="userdetails_data">
        <input class="radio" type="radio" value="true" name="icon_15" '.check_radio($EditorIcon[15], "true").'>���&nbsp;&nbsp;&nbsp;&nbsp;
        <input class="radio" type="radio" value="false" name="icon_15" '.check_radio($EditorIcon[15], "false").'>��
        </td>
	</tr>
    <tr class="fixed">
		<td class="list"><nobr>������ �� ��� ����</nobr></td>
		<td class="userdetails_data">
        <input class="radio" type="radio" value="true" name="icon_16" '.check_radio($EditorIcon[16], "true").'>���&nbsp;&nbsp;&nbsp;&nbsp;
        <input class="radio" type="radio" value="false" name="icon_16" '.check_radio($EditorIcon[16], "false").'>��
        </td>
	</tr>
    <tr class="fixed">
		<td class="list"><nobr>������ �� ��� ����</nobr></td>
		<td class="userdetails_data">
        <input class="radio" type="radio" value="true" name="icon_17" '.check_radio($EditorIcon[17], "true").'>���&nbsp;&nbsp;&nbsp;&nbsp;
        <input class="radio" type="radio" value="false" name="icon_17" '.check_radio($EditorIcon[17], "false").'>��
        </td>
	</tr>
    <tr class="fixed">
		<td class="list"><nobr>������ �� �������</nobr></td>
		<td class="userdetails_data">
        <input class="radio" type="radio" value="true" name="icon_18" '.check_radio($EditorIcon[18], "true").'>���&nbsp;&nbsp;&nbsp;&nbsp;
        <input class="radio" type="radio" value="false" name="icon_18" '.check_radio($EditorIcon[18], "false").'>��
        </td>
	</tr>
    <tr class="fixed">
		<td class="list"><nobr>������ �� ������</nobr></td>
		<td class="userdetails_data">
        <input class="radio" type="radio" value="true" name="icon_19" '.check_radio($EditorIcon[19], "true").'>���&nbsp;&nbsp;&nbsp;&nbsp;
        <input class="radio" type="radio" value="false" name="icon_19" '.check_radio($EditorIcon[19], "false").'>��
        </td>
	</tr>
    <tr class="fixed">
		<td class="list"><nobr>������ ����� ����</nobr></td>
		<td class="userdetails_data">
        <input class="radio" type="radio" value="true" name="icon_20" '.check_radio($EditorIcon[20], "true").'>���&nbsp;&nbsp;&nbsp;&nbsp;
        <input class="radio" type="radio" value="false" name="icon_20" '.check_radio($EditorIcon[20], "false").'>��
        </td>
	</tr>
    <tr class="fixed">
		<td class="list"><nobr>������ �� �� ������</nobr></td>
		<td class="userdetails_data">
        <input class="radio" type="radio" value="true" name="icon_21" '.check_radio($EditorIcon[21], "true").'>���&nbsp;&nbsp;&nbsp;&nbsp;
        <input class="radio" type="radio" value="false" name="icon_21" '.check_radio($EditorIcon[21], "false").'>��
        </td>
	</tr>
    <tr class="fixed">
		<td class="list"><nobr>������ �� �� �����</nobr></td>
		<td class="userdetails_data">
        <input class="radio" type="radio" value="true" name="icon_22" '.check_radio($EditorIcon[22], "true").'>���&nbsp;&nbsp;&nbsp;&nbsp;
        <input class="radio" type="radio" value="false" name="icon_22" '.check_radio($EditorIcon[22], "false").'>��
        </td>
	</tr>
    <tr class="fixed">
		<td class="list"><nobr>������ �� �� ������</nobr></td>
		<td class="userdetails_data">
        <input class="radio" type="radio" value="true" name="icon_23" '.check_radio($EditorIcon[23], "true").'>���&nbsp;&nbsp;&nbsp;&nbsp;
        <input class="radio" type="radio" value="false" name="icon_23" '.check_radio($EditorIcon[23], "false").'>��
        </td>
	</tr>
    <tr class="fixed">
		<td class="list"><nobr>������ �� ���� ������</nobr></td>
		<td class="userdetails_data">
        <input class="radio" type="radio" value="true" name="icon_24" '.check_radio($EditorIcon[24], "true").'>���&nbsp;&nbsp;&nbsp;&nbsp;
        <input class="radio" type="radio" value="false" name="icon_24" '.check_radio($EditorIcon[24], "false").'>��
        </td>
	</tr>
    <tr class="fixed">
		<td class="list"><nobr>������ ����� �����</nobr></td>
		<td class="userdetails_data">
        <input class="radio" type="radio" value="true" name="icon_25" '.check_radio($EditorIcon[25], "true").'>���&nbsp;&nbsp;&nbsp;&nbsp;
        <input class="radio" type="radio" value="false" name="icon_25" '.check_radio($EditorIcon[25], "false").'>��
        </td>
	</tr>
    <tr class="fixed">
		<td class="list"><nobr>������ ����� ������</nobr></td>
		<td class="userdetails_data">
        <input class="radio" type="radio" value="true" name="icon_26" '.check_radio($EditorIcon[26], "true").'>���&nbsp;&nbsp;&nbsp;&nbsp;
        <input class="radio" type="radio" value="false" name="icon_26" '.check_radio($EditorIcon[26], "false").'>��
        </td>
	</tr>
    <tr class="fixed">
		<td class="list"><nobr>������ ���� ������</nobr></td>
		<td class="userdetails_data">
        <input class="radio" type="radio" value="true" name="icon_27" '.check_radio($EditorIcon[27], "true").'>���&nbsp;&nbsp;&nbsp;&nbsp;
        <input class="radio" type="radio" value="false" name="icon_27" '.check_radio($EditorIcon[27], "false").'>��
        </td>
	</tr>
    <tr class="fixed">
		<td class="list"><nobr>������ ���� ������</nobr></td>
		<td class="userdetails_data">
        <input class="radio" type="radio" value="true" name="icon_28" '.check_radio($EditorIcon[28], "true").'>���&nbsp;&nbsp;&nbsp;&nbsp;
        <input class="radio" type="radio" value="false" name="icon_28" '.check_radio($EditorIcon[28], "false").'>��
        </td>
	</tr>
    <tr class="fixed">
		<td class="list"><nobr>������ ����� ������</nobr></td>
		<td class="userdetails_data">
        <input class="radio" type="radio" value="true" name="icon_29" '.check_radio($EditorIcon[29], "true").'>���&nbsp;&nbsp;&nbsp;&nbsp;
        <input class="radio" type="radio" value="false" name="icon_29" '.check_radio($EditorIcon[29], "false").'>��
        </td>
	</tr>
    <tr class="fixed">
		<td class="list"><nobr>������ ��� ����</nobr></td>
		<td class="userdetails_data">
        <input class="radio" type="radio" value="true" name="icon_30" '.check_radio($EditorIcon[30], "true").'>���&nbsp;&nbsp;&nbsp;&nbsp;
        <input class="radio" type="radio" value="false" name="icon_30" '.check_radio($EditorIcon[30], "false").'>��
        </td>
	</tr>
    <tr class="fixed">
		<td class="list"><nobr>������ ��� ����� ����</nobr></td>
		<td class="userdetails_data">
        <input class="radio" type="radio" value="true" name="icon_31" '.check_radio($EditorIcon[31], "true").'>���&nbsp;&nbsp;&nbsp;&nbsp;
        <input class="radio" type="radio" value="false" name="icon_31" '.check_radio($EditorIcon[31], "false").'>��
        </td>
	</tr>
    <tr class="fixed">
		<td class="list"><nobr>������ ����� ������</nobr></td>
		<td class="userdetails_data">
        <input class="radio" type="radio" value="true" name="icon_32" '.check_radio($EditorIcon[32], "true").'>���&nbsp;&nbsp;&nbsp;&nbsp;
        <input class="radio" type="radio" value="false" name="icon_32" '.check_radio($EditorIcon[32], "false").'>��
        </td>
	</tr>
    <tr class="fixed">
		<td class="list"><nobr>������ ����� ���� �����</nobr></td>
		<td class="userdetails_data">
        <input class="radio" type="radio" value="true" name="icon_33" '.check_radio($EditorIcon[33], "true").'>���&nbsp;&nbsp;&nbsp;&nbsp;
        <input class="radio" type="radio" value="false" name="icon_33" '.check_radio($EditorIcon[33], "false").'>��
        </td>
	</tr>
    <tr class="fixed">
		<td class="list"><nobr>������ ����� ����� �������</nobr></td>
		<td class="userdetails_data">
        <input class="radio" type="radio" value="true" name="icon_34" '.check_radio($EditorIcon[34], "true").'>���&nbsp;&nbsp;&nbsp;&nbsp;
        <input class="radio" type="radio" value="false" name="icon_34" '.check_radio($EditorIcon[34], "false").'>��
        </td>
	</tr>
    <tr class="fixed">
		<td class="list"><nobr>������ ����� ����</nobr></td>
		<td class="userdetails_data">
        <input class="radio" type="radio" value="true" name="icon_35" '.check_radio($EditorIcon[35], "true").'>���&nbsp;&nbsp;&nbsp;&nbsp;
        <input class="radio" type="radio" value="false" name="icon_35" '.check_radio($EditorIcon[35], "false").'>��
        </td>
	</tr>
    <tr class="fixed">
		<td class="list"><nobr>������ ����� ����</nobr></td>
		<td class="userdetails_data">
        <input class="radio" type="radio" value="true" name="icon_36" '.check_radio($EditorIcon[36], "true").'>���&nbsp;&nbsp;&nbsp;&nbsp;
        <input class="radio" type="radio" value="false" name="icon_36" '.check_radio($EditorIcon[36], "false").'>��
        </td>
	</tr>
    <tr class="fixed">
		<td class="list"><nobr>������ ����</nobr></td>
		<td class="userdetails_data">
        <input class="radio" type="radio" value="true" name="icon_37" '.check_radio($EditorIcon[37], "true").'>���&nbsp;&nbsp;&nbsp;&nbsp;
        <input class="radio" type="radio" value="false" name="icon_37" '.check_radio($EditorIcon[37], "false").'>��
        </td>
	</tr>
    <tr class="fixed">
		<td class="list"><nobr>������ ���</nobr></td>
		<td class="userdetails_data">
        <input class="radio" type="radio" value="true" name="icon_38" '.check_radio($EditorIcon[38], "true").'>���&nbsp;&nbsp;&nbsp;&nbsp;
        <input class="radio" type="radio" value="false" name="icon_38" '.check_radio($EditorIcon[38], "false").'>��
        </td>
	</tr>
    <tr class="fixed">
		<td class="list"><nobr>������ ����� �� ����</nobr></td>
		<td class="userdetails_data">
        <input class="radio" type="radio" value="true" name="icon_39" '.check_radio($EditorIcon[39], "true").'>���&nbsp;&nbsp;&nbsp;&nbsp;
        <input class="radio" type="radio" value="false" name="icon_39" '.check_radio($EditorIcon[39], "false").'>��
        </td>
	</tr>
    <tr class="fixed">
		<td class="list"><nobr>������ ����� �����</nobr></td>
		<td class="userdetails_data">
        <input class="radio" type="radio" value="true" name="icon_40" '.check_radio($EditorIcon[40], "true").'>���&nbsp;&nbsp;&nbsp;&nbsp;
        <input class="radio" type="radio" value="false" name="icon_40" '.check_radio($EditorIcon[40], "false").'>��
        </td>
	</tr>
    <tr class="fixed">
		<td class="list"><nobr>������ ��� �� Word</nobr></td>
		<td class="userdetails_data">
        <input class="radio" type="radio" value="true" name="icon_41" '.check_radio($EditorIcon[41], "true").'>���&nbsp;&nbsp;&nbsp;&nbsp;
        <input class="radio" type="radio" value="false" name="icon_41" '.check_radio($EditorIcon[41], "false").'>��
        </td>
	</tr>
 	<tr class="fixed">
		<td align="middle" colspan="2"><input type="submit" value="����� ������">&nbsp;&nbsp;&nbsp;<input type="reset" value="����� �� ������"></td>
	</tr>
</form>
</table>
</center>';
 }

 if ($type == "insert_data") {

    if ($error != "") {
	                echo'<br><center>
	                <table bordercolor="#ffffff" width="99%" border="1">
	                   <tr class="normal">
	                       <td class="list_center" colSpan="10"><font size="5" color="red"><br>���<br>'.$error.'..</font><br><br>
	                       <a href="JavaScript:history.go(-1)">-- ���� ��� ������ --</a><br><br>
	                       </td>
	                   </tr>
	                </table>
	                </center>';
    }


    if ($error == "") {
updata_mysql("EDITOR_FULL_HTML", $_POST['ed_full_html']);
updata_mysql("EDITOR_WIDTH", $_POST['ed_width']);
updata_mysql("EDITOR_HEIGHT", $_POST['ed_height']);

updata_mysql("EDITOR_ICON_SAVE", $_POST['icon_0']);
updata_mysql("EDITOR_ICON_PRINT", $_POST['icon_1']);
updata_mysql("EDITOR_ICON_ZOOM", $_POST['icon_2']);
updata_mysql("EDITOR_ICON_STYLE", $_POST['icon_3']);
updata_mysql("EDITOR_ICON_PARAGRAPH", $_POST['icon_4']);
updata_mysql("EDITOR_ICON_FONT_NAME", $_POST['icon_5']);
updata_mysql("EDITOR_ICON_SIZE", $_POST['icon_6']);
updata_mysql("EDITOR_ICON_TEXT", $_POST['icon_7']);
updata_mysql("EDITOR_ICON_SELECT_ALL", $_POST['icon_8']);
updata_mysql("EDITOR_ICON_CUT", $_POST['icon_9']);
updata_mysql("EDITOR_ICON_COPY", $_POST['icon_10']);
updata_mysql("EDITOR_ICON_PASTE", $_POST['icon_11']);
updata_mysql("EDITOR_ICON_UNDO", $_POST['icon_12']);
updata_mysql("EDITOR_ICON_REDO", $_POST['icon_13']);
updata_mysql("EDITOR_ICON_BOLD", $_POST['icon_14']);
updata_mysql("EDITOR_ICON_ITALIC", $_POST['icon_15']);
updata_mysql("EDITOR_ICON_UNDER_LINE", $_POST['icon_16']);
updata_mysql("EDITOR_ICON_STRIKE", $_POST['icon_17']);
updata_mysql("EDITOR_ICON_SUPER_SCRIPT", $_POST['icon_18']);
updata_mysql("EDITOR_ICON_SUB_SCRIPT", $_POST['icon_19']);
updata_mysql("EDITOR_ICON_SYMBOL", $_POST['icon_20']);
updata_mysql("EDITOR_ICON_LEFT", $_POST['icon_21']);
updata_mysql("EDITOR_ICON_CENTER", $_POST['icon_22']);
updata_mysql("EDITOR_ICON_RIGHT", $_POST['icon_23']);
updata_mysql("EDITOR_ICON_FULL", $_POST['icon_24']);
updata_mysql("EDITOR_ICON_NUBERING", $_POST['icon_25']);
updata_mysql("EDITOR_ICON_BULLETS", $_POST['icon_26']);
updata_mysql("EDITOR_ICON_INDENT", $_POST['icon_27']);
updata_mysql("EDITOR_ICON_OUTDENT", $_POST['icon_28']);
updata_mysql("EDITOR_ICON_IMAGE", $_POST['icon_29']);
updata_mysql("EDITOR_ICON_COLOR", $_POST['icon_30']);
updata_mysql("EDITOR_ICON_BGCOLOR", $_POST['icon_31']);
updata_mysql("EDITOR_ICON_EX_LINK", $_POST['icon_32']);
updata_mysql("EDITOR_ICON_IN_LINK", $_POST['icon_33']);
updata_mysql("EDITOR_ICON_ASSET", $_POST['icon_34']);
updata_mysql("EDITOR_ICON_TABLE", $_POST['icon_35']);
updata_mysql("EDITOR_ICON_SHOW_BORDER", $_POST['icon_36']);
updata_mysql("EDITOR_ICON_ABSOLUTE", $_POST['icon_37']);
updata_mysql("EDITOR_ICON_CLEAN", $_POST['icon_38']);
updata_mysql("EDITOR_ICON_LINE", $_POST['icon_39']);
updata_mysql("EDITOR_ICON_PROPERTIES", $_POST['icon_40']);
updata_mysql("EDITOR_ICON_WORD", $_POST['icon_41']);

                    echo'<br><br>
	                <center>
	                <table bordercolor="#ffffff" width="50%" border="1">
	                   <tr class="normal">
	                       <td class="list_center" colSpan="10"><font size="5"><br>�� ����� ������ �����..</font><br><br>
                           <meta http-equiv="Refresh" content="2; URL=cp_home.php?mode=option&method=editor">
                           <a href="cp_home.php?mode=option&method=other">-- ���� ��� ������ ��� ���� ������� --</a><br><br>
	                       </td>
	                   </tr>
	                </table>
	                </center>';
    }

 }

}
 
 
//-----------------------------------------------------------------------------------------------------------------
if ($method == "files") {

 if ($type == "") {

echo'
<center>
<table class="grid" border="0" cellspacing="1" cellpadding="3" width="80%">
<form method="post" action="cp_home.php?mode=option&method=files&type=insert_data">
	<tr class="fixed">
		<td class="cat" colspan="2"><nobr>������� �������</nobr></td>
	</tr>
 	<tr class="fixed">
		<td class="list"><nobr>��� �������</nobr></td>
		<td class="middle"><input type="text" name="files_max_size" size="10" value="'.$Files_Max_Size.'"><font color="black">&nbsp;����&nbsp;&nbsp;/&nbsp;&nbsp;����� ('.to_kb($Files_Max_Size).') ��������</font></td>
	</tr>
 	<tr class="fixed">
		<td class="list"><nobr>����� ������ ��� ���</nobr></td>
		<td class="middle"><input type="text" name="files_max_allowed" size="10" value="'.$Files_Max_Allowed.'"><font color="black">&nbsp;����&nbsp;&nbsp;/&nbsp;&nbsp;����� ('.to_kb($Files_Max_Allowed).') ��������</font></td>
	</tr>
 	<tr class="fixed">
		<td align="middle" colspan="2"><input type="submit" value="����� ������">&nbsp;&nbsp;&nbsp;<input type="reset" value="����� �� ������"></td>
	</tr>
</form>
</table>
</center>';
 }

 if ($type == "insert_data") {


    if ($error != "") {
	                echo'<br><center>
	                <table bordercolor="#ffffff" width="99%" border="1">
	                   <tr class="normal">
	                       <td class="list_center" colSpan="10"><font size="5" color="red"><br>���<br>'.$error.'..</font><br><br>
	                       <a href="JavaScript:history.go(-1)">-- ���� ��� ������ --</a><br><br>
	                       </td>
	                   </tr>
	                </table>
	                </center>';
    }


    if ($error == "") {

updata_mysql("FILES_MAX_SIZE", $_POST['files_max_size']);
updata_mysql("FILES_MAX_ALLOWED", $_POST['files_max_allowed']);

                    echo'<br><br>
	                <center>
	                <table bordercolor="#ffffff" width="50%" border="1">
	                   <tr class="normal">
	                       <td class="list_center" colSpan="10"><font size="5"><br>�� ����� ������ �����..</font><br><br>
                           <meta http-equiv="Refresh" content="2; URL=cp_home.php?mode=option&method=files">
                           <a href="cp_home.php?mode=option&method=files">-- ���� ��� ������ ��� ���� ������� --</a><br><br>
	                       </td>
	                   </tr>
	                </table>
	                </center>';
    }

 }

}
//-----------------------------------------------------------------------------------------------------------------
 
 
}
else {
    go_to("index.php");
}
?>
