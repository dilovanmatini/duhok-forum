<?
/*//////////////////////////////////////////////////////////
// ######################################################///
// # DuhokForum 0.4                                     # //
// ###################################################### //
// #                                                    # //
// #       --  DUHOK FORUM IS FREE SOFTWARE  --         # //
// #                                                    # //
// #   ========= Programming By Dilovan ==============  # //
// # Copyright � 2007-2008 Dilovan. All Rights Reserved # //
// #----------------------------------------------------# //
// #----------------------------------------------------# //
// # If you want any support vist down address:-        # //
// # Email: df@duhoktimes.com                           # //
// # Site: http://df.duhoktimes.com/index.php           # //
// ###################################################### //
//////////////////////////////////////////////////////////*/

if ($DBMemberID > 0) {

if ($type == "") {

$resultCH = mysql_query("SELECT * FROM " . $Prefix . "MEMBERS WHERE MEMBER_ID = '$DBMemberID' ")
or die (mysql_error());

if(mysql_num_rows($resultCH) > 0){
$rsCH = mysql_fetch_array($resultCH);

$CH_MemberID = $rsCH['MEMBER_ID'];
$CH_MemberName = $rsCH['M_NAME'];
$CH_ChangeName_Count = $rsCH['M_CHANGENAME_COUNT'];
}

if ($CH_ChangeName_Count >= $change_name_max) {

	                echo'<center>
	                <table width="99%" border="1">
	                   <tr class="normal">
	                       <td class="list_center" colSpan="10">
	<font size="5"><br>'.$lang['all']['error'].'</font><br>
	<font size="5">'.$lang['changename']['error'].' </font><font color="red" size="5">'.$change_name_max.'</font><br><br>
	                       <a href="index.php?mode=profile&type=details">'.$lang['all']['click_here_to_go_normal_page'].'</a><br><br>
	                       </td>
	                   </tr>
	                </table>
	                </center>';


}

else {

$info = info_icon(2);

echo'
<center>
<table cellSpacing="0" cellPadding="0" width="99%" border="0" id="table1">
	<tr>
		<td><center><font color="red" size="+2">'.$lang['changename']['demande_change_username'].'</font><br>&nbsp;
			<form method="post" action="index.php?mode=changename&type=true">
            <table cellSpacing="1" cellPadding="4" bgColor="gray" border="0" id="table2">
				<tr class="fixed">
					<td class="optionheader_selected" id="row_user_name"><nobr>'.$lang['changename']['new_username'].'</nobr></td>
					<td class="list" colSpan="3"><input class="insidetitle" style="WIDTH: 300px" name="user_name" value="'.$CH_MemberName.'">'.$info.'</td>
				</tr>';
echo info_text(2,$lang['info']['change_username_info'],$lang['changename']['demande_change_username']);
			echo'	<tr class="fixed">
					<td><font color="red" size="-1">'.$lang['register']['rules_write_user_name_one'].'<br>&nbsp;</font></td>
					<td><font color="red" size="-1">'.$lang['register']['rules_write_user_name_tow'].'<br>&nbsp;</font></td>
				</tr>
				<tr class="fixed">
					<td class="list_center" colSpan="5"><input type="submit" value="'.$lang['changename']['send_demande'].'"></td>
				</tr>
			</form>
            </table>
		</td>
	</tr>
</table><br>
<b><font size="3" color="darkgreen">'.$lang['changename']['count'].'</font></b>
<b><font size="3" color="red">'.$CH_ChangeName_Count.'</font></b>
<br>
<b><font size="3" color="darkgreen">'.$lang['changename']['change_username_max'].'</font></b>
<b><font size="3" color="red">'.$change_name_max.'</font></b>
</center>';

}

}

if ($type == "true") {

$user_name = HtmlSpecialchars($_POST["user_name"]);
$CH_Date = time();

$query = "INSERT INTO " . $Prefix . "CHANGES_NAMES (CHANGE_NAME_ID, CH_MEMBERID, CH_TO, CH_ORIGINAL_NAME, CH_DATE) VALUES (NULL, '$DBMemberID', '$user_name', '$DBUserName', '$CH_Date')";
mysql_query($query, $connection) or die (mysql_error());

$query1 = "UPDATE " . $Prefix . "MEMBERS SET M_NAME = ('$user_name'), M_CHANGENAME_COUNT = M_CHANGENAME_COUNT + 1 WHERE MEMBER_ID = '$DBMemberID' ";
mysql_query($query1, $connection) or die (mysql_error());

	                echo'<center>
	                <table width="99%" border="1">
	                   <tr class="normal">
	                       <td class="list_center" colSpan="10"><font size="5"><br>'.$lang['changename']['the_newname_was_changed'].'</font><br><br>
	                       <meta http-equiv="Refresh" content="2; URL=index.php?mode=profile&type=details">
	                       <a href="index.php?mode=profile&type=details">'.$lang['all']['click_here_to_go_normal_page'].'</a><br><br>
	                       </td>
	                   </tr>
	                </table>
	                </center>';

}

}

?>