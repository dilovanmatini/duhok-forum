<?
/*//////////////////////////////////////////////////////////
// ######################################################///
// # DuhokForum 0.4                                     # //
// ###################################################### //
// #                                                    # //
// #       --  DUHOK FORUM IS FREE SOFTWARE  --         # //
// #                                                    # //
// #   ========= Programming By Dilovan ==============  # //
// # Copyright � 2007-2008 Dilovan. All Rights Reserved # //
// #----------------------------------------------------# //
// #----------------------------------------------------# //
// # If you want any support vist down address:-        # //
// # Email: df@duhoktimes.com                           # //
// # Site: http://df.duhoktimes.com/index.php           # //
// ###################################################### //
//////////////////////////////////////////////////////////*/

$http_host = $_SERVER['HTTP_HOST'];
$mode = trim($HTTP_GET_VARS[mode]);
$step = trim($HTTP_GET_VARS[step]);
$type = trim($HTTP_GET_VARS[type]);
$method = trim($HTTP_GET_VARS[method]);
$refer = trim($HTTP_GET_VARS[refer]);
$mail = trim($HTTP_GET_VARS[mail]);
$msg = trim($HTTP_GET_VARS[msg]);
$svc = trim($HTTP_GET_VARS[svc]);
$sg = trim($HTTP_GET_VARS[sg]);
$ch = trim($HTTP_GET_VARS[ch]);
$c = trim($HTTP_GET_VARS[c]);
$f = trim($HTTP_GET_VARS[f]);
$t = trim($HTTP_GET_VARS[t]);
$r = trim($HTTP_GET_VARS[r]);
$m = trim($HTTP_GET_VARS[m]);
$err = trim($HTTP_GET_VARS[err]);
$id = trim($HTTP_GET_VARS[id]);
$pg = trim($HTTP_GET_VARS[pg]);
if(!isset($pg)) {
$pg = 1;
}

?>
