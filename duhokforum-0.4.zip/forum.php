<?
/*//////////////////////////////////////////////////////////
// ######################################################///
// # DuhokForum 0.4                                     # //
// ###################################################### //
// #                                                    # //
// #       --  DUHOK FORUM IS FREE SOFTWARE  --         # //
// #                                                    # //
// #   ========= Programming By Dilovan ==============  # //
// # Copyright � 2007-2008 Dilovan. All Rights Reserved # //
// #----------------------------------------------------# //
// #----------------------------------------------------# //
// # If you want any support vist down address:-        # //
// # Email: df@duhoktimes.com                           # //
// # Site: http://df.duhoktimes.com/index.php           # //
// ###################################################### //
//////////////////////////////////////////////////////////*/

if ($f == "") {
 redirect();
}

$forum_hide = forums("HIDE", $f);
$check_forum_login = check_forum_login($f);
if ($forum_hide == 1){
	if ($check_forum_login == 0){
		redirect();
	}
}

require_once("./include/forum_function.php");

//################## paging ####################################################
echo' 
<script language="JavaScript" type="text/javascript">
	function goto_pg(){
		var pg = pg_form.pg_num.value;
		var f_id = pg_form.pg_f_id.value;
		window.location = "index.php?mode=f&f="+f_id+"&pg="+pg;
	}
</script>';

if (!isset($pg) OR empty($pg)){
	$pg = 1;
}
$pg_limit = (($pg * $max_page) - $max_page);
$pg_sql = mysql_result(mysql_query("SELECT COUNT(TOPIC_ID) FROM ".$Prefix."TOPICS WHERE FORUM_ID = '$f'"),0);
$pg_col = ceil($pg_sql / $max_page);
function paging() {
	global $f, $lang, $pg_col, $pg;
	echo '
	<form name="pg_form">
	<input type="hidden" name="pg_f_id" value="'.$f.'">
	<td class="optionsbar_menus"><b>'.$lang['forum']['page'].'&nbsp;:</b>
		<select name="pg_num" size="1" onchange="goto_pg();">';
        for($i = 1; $i <= $pg_col; $i++) {
			echo '<option value="'.$i.'" '.check_select($pg, $i).'>'.$i.'&nbsp;'.$lang['forum']['from'].'&nbsp;'.$pg_col.'</option>';
        }
		echo '
		</select>
	</td>
	</form>';
}
//################## paging ####################################################

$cat_id = forums("CAT_ID", $f);
$f_subject = forums("SUBJECT", $f);
$f_logo = forums("LOGO", $f);

$allowed = allowed($f, 2);

echo'
<center>
<table cellSpacing="0" cellPadding="0" width="99%" border="0">
	<tr>
		<td>
		<table cellSpacing="2" width="100%" border="0">
			<tr>
				<td><a class="menu" href="index.php?mode=finfo&f='.$f.'">'.icons($f_logo, "������� �� �������").'</a></td>
				<td class="main" vAlign="center" width="100%"><a class="menu" href="index.php?mode=f&f='.$f.'"><font color="red" size="+1">'.$f_subject.'</font></a><font size="-1">'.forum_mods($f).'</font></td>
				<td class="optionsbar_menus"><nobr><a href="index.php?mode=editor&method=topic&f='.$f.'&c='.$cat_id.'">'.icons($folder_new).'<br>'.$lang['forum']['new_topic'].'</a></nobr></td>
				<td class="optionsbar_menus"><nobr><a href="index.php?mode=editor&method=sendmsg&m='.abs2($f).'">'.$lang['forum']['send_message_to_forum'].'</a></nobr></td>';
			if ($allowed == 1){
				echo'
				<td class="optionsbar_menus"><nobr><a href="index.php?mode=pm&mail=in&m='.abs2($f).'&c='.$cat_id.'">'.forum_new_mail($f).$lang['forum']['forum_mail'].'</a></nobr></td>';
			}
				order_by();
				refresh_time();
				if ($pg_sql > 0){
					paging();
				}
				go_to_forum();
			echo'
			</tr>
		</table>';
		$fl_sql = mysql_query("SELECT * FROM ".$Prefix."TOPICS WHERE T_LINKFORUM > '0' AND FORUM_ID = '$f' ") or die (mysql_error()); // category mysql
		$fl_num = mysql_num_rows($fl_sql);
		if ($fl_num > 0) {
			echo'
			<table>
				<tr>';
				$fl_i = 0;
				while ($fl_i < $fl_num) {
					$fl_topic_id = mysql_result($fl_sql, $fl_i, "TOPIC_ID");
					$fl_t_subject = topics("SUBJECT", $fl_topic_id);
					$fl_t_link = topics("LINKFORUM", $fl_topic_id);
					
					if ($fl_t_link == 1){
						$td_class = "extras2";
					}
					if ($fl_t_link == 2){
						$td_class = "extras";
					}
					echo'<td class="'.$td_class.'"><nobr><a href="index.php?mode=t&t='.$fl_topic_id.'">'.$fl_t_subject.'</a></nobr></td>';
						
				++$fl_i;
				}
				echo'
				</tr>
			</table>';
		}

		echo'
		<table class="grid" cellSpacing="0" cellPadding="0" width="100%" align="center" border="0">
			<tr>
				<td>
				<table cellSpacing="1" cellPadding="2" width="100%" border="0">
					<tr>
						<td class="cat" colSpan="2">'.$lang['forum']['topics'].'</td>
						<td class="cat">'.$lang['forum']['author'].'</td>
						<td class="cat">'.$lang['forum']['posts'].'</td>
						<td class="cat">'.$lang['forum']['reads'].'</td>
						<td class="cat">'.$lang['forum']['last_post'].'</td>';
					if ($Mlevel > 0){	
						echo'
						<td class="cat">'.$lang['forum']['options'].'</td>';
					}	
					echo'
					</tr>';

				if ($order_by == "post"){
					$order_by_date = "T_LAST_POST_DATE DESC, T_DATE DESC";
				}
				else if ($order_by == "topic"){
					$order_by_date = "T_DATE DESC, T_LAST_POST_DATE DESC";
				}
				else{
					$order_by_date = "T_LAST_POST_DATE DESC, T_DATE DESC";
				}					
					
				$topics = mysql_query("SELECT * FROM ".$Prefix."TOPICS WHERE CAT_ID = '$cat_id' AND FORUM_ID = '$f' ORDER BY T_STICKY DESC, ".$order_by_date." LIMIT $pg_limit, $max_page") or die (mysql_error());
				$t_num = mysql_num_rows($topics);
				if ($t_num <= 0) {
					echo'
					<tr>
						<td class="f1" vAlign="center" align="middle" colspan="20"><br><br>'.$lang['forum']['not_topics'].'<br><br><br></td>
					</tr>';
				}
				
				$t_i = 0;
				while ($t_i < $t_num) {
					$topic_id = mysql_result($topics, $t_i, "TOPIC_ID");
					$t_hidden = topics("HIDDEN", $topic_id);
					$t_sticky = topics("STICKY", $topic_id);
					$t_author = topics("AUTHOR", $topic_id);
					
					if ($t_hidden == 1){
						$tr_class = "deleted";
					}
					else{
						if ($t_sticky == 1) {
							$tr_class = "fixed";
						}
						else{
							$tr_class = "normal";
						}
					}
					
					if (($t_hidden == 0) OR ($t_hidden == 1 AND $allowed == 1) OR ($t_hidden == 1 AND $t_author == $DBMemberID)){
						forum_func($topic_id);
					}
				++$t_i;	
				}	
				echo'
				</table>
				</td>
			</tr>
		</table>
		</td>
	</tr>
</table>
</center>';

/*
	echo'	<table class="grid" cellSpacing="0" cellPadding="0" width="100%" align="center" border="0">
			<tr>
				<td>
				<table cellSpacing="1" cellPadding="2" width="100%" border="0">
					<tr>
						<td class="cat" width="55%" colSpan="2">'.$lang['forum']['topics'].'</td>
						<td class="cat" width="12%">'.$lang['forum']['author'].'</td>
						<td class="cat" width="7%">'.$lang['forum']['posts'].'</td>
						<td class="cat" width="7%">'.$lang['forum']['reads'].'</td>
						<td class="cat" width="12%">'.$lang['forum']['last_post'].'</td>';
                   if ($Mlevel > 0) {
						echo'<td class="cat" width="6%">'.$lang['forum']['options'].'</td>';
                   }
				echo'</tr>';

 	$queryT = "SELECT * FROM " . $Prefix . "TOPICS AS T INNER JOIN  " . $Prefix . "MEMBERS AS M ";
    $queryT .= " WHERE T.CAT_ID = '$F_CatID' AND T.FORUM_ID = '$F_ForumID' AND M.MEMBER_ID = T.T_AUTHOR ";
	$queryT .= " ORDER BY T.T_STICKY DESC, T.T_LAST_POST_DATE DESC, T.T_DATE DESC LIMIT $start, $max_page";

	$resultT = mysql_query($queryT, $connection) or die (mysql_error());

	$numT = mysql_num_rows($resultT);


	if ($numT <= 0) {


                      echo'
                      <tr>
                          <td class="f1" vAlign="center" align="middle" colspan="20"><br><br>'.$lang['forum']['not_topics'].'<br><br><br></td>
                      </tr>';
	}

$iT=0;
while ($iT < $numT) {

    $T_CatID = mysql_result($resultT, $iT, "T.CAT_ID");
    $T_ForumID = mysql_result($resultT, $iT, "T.FORUM_ID");
    $T_TopicID = mysql_result($resultT, $iT, "T.TOPIC_ID");
    $T_TopicStatus = mysql_result($resultT, $iT, "T.T_STATUS");
    $T_TopicSubject = mysql_result($resultT, $iT, "T.T_SUBJECT");
    $T_TopicAuthor = mysql_result($resultT, $iT, "T.T_AUTHOR");
    $T_TopicReplies = mysql_result($resultT, $iT, "T.T_REPLIES");
    $T_TopicCount = mysql_result($resultT, $iT, "T.T_COUNTS");
    $T_TopicLastPostDate = mysql_result($resultT, $iT, "T.T_LAST_POST_DATE");
    $T_TopicDate = mysql_result($resultT, $iT, "T.T_DATE");
    $T_TopicLastPostAuthor = mysql_result($resultT, $iT, "T.T_LAST_POST_AUTHOR");
    $T_TopicArchiveFlag = mysql_result($resultT, $iT, "T.T_ARCHIVE_FLAG");
    $T_TopicSticky = mysql_result($resultT, $iT, "T.T_STICKY");
    $T_TopicHidden = mysql_result($resultT, $iT, "T.T_HIDDEN");
    $T_TopicTop = mysql_result($resultT, $iT, "T.T_TOP");
    $T_TopicLinkForum = mysql_result($resultT, $iT, "T.T_LINKFORUM");
    $T_TopicMemberID = mysql_result($resultT, $iT, "M.MEMBER_ID");
    $T_TopicMemberName = mysql_result($resultT, $iT, "M.M_NAME");


 $queryMM = "SELECT * FROM " . $Prefix . "MEMBERS WHERE MEMBER_ID = '" .$T_TopicLastPostAuthor."' ";
 $resultMM = mysql_query($queryMM, $connection) or die (mysql_error());

 if(mysql_num_rows($resultMM) > 0){
 $rsMM = mysql_fetch_array($resultMM);

 $R_MemberID = $rsMM['MEMBER_ID'];
 $R_MemberName = $rsMM['M_NAME'];
 }
if ($T_TopicHidden == 1) {

    if ($Mlevel == 4 OR $Monitor == 1 OR $Moderator == 1 OR $T_TopicAuthor == $DBMemberID) {

                    echo'
					<tr class="deleted">
						<td class="list_center">&nbsp;<nobr><a href="index.php?mode=t&t='.$T_TopicID.'"><img hspace="0"';
      
                    if ($T_TopicStatus == 0 AND $T_TopicReplies < 20) {
                        echo 'alt="'.$lang['forum']['topic_is_locked'].'" src="'.$folder_new_locked.'"';
                    }
                    elseif ($T_TopicStatus == 0 AND $T_TopicReplies >= 20) {
                        echo 'alt="'.$lang['forum']['topic_is_hot_and_locked'].'" src="'.$folder_new_locked.'"';
                    }
                    elseif ($T_TopicStatus == 1 AND $T_TopicReplies < 20) {
                        echo 'alt="" src="'.$folder_new.'"';
                    }
                    elseif ($T_TopicStatus == 1 AND $T_TopicReplies >= 20) {
                        echo 'alt="'.$lang['forum']['topic_is_hot'].'" src="'.$folder_new_hot.'"';
                    }
                    else {
                        echo 'alt="" src="'.$folder.'"';
                    }
                    
                        echo'border="0"></a></nobr></td>
						<td class="list">
						<table cellPadding="0" cellsapcing="0">
							<tr>
								<td>';
if ($DBMemberID > 0) {
if ($T_TopicTop == 1) {
		echo'	<img src="'.$red_star.'" hspace="0" border="0">';
}
if ($T_TopicTop == 2) {
		echo'	<img src="'.$icon_top_topic.'" hspace="0" border="0">';
}
if ($T_TopicTop == 3) {
		echo'	<img src="'.$icon_survey.'" hspace="0" border="0">';
}
}					
					echo'	<a href="index.php?mode=t&t='.$T_TopicID.'">'.$T_TopicSubject.'</a>&nbsp;</td>
							</tr>
						</table>
						</td>
      
						<td class="list_small" noWrap><font color="green">'.normal_time($T_TopicDate).'</font><br>'.link_profile($T_TopicMemberName, $T_TopicMemberID, $Prefix).'</td>
						<td class="list_small">'.$T_TopicReplies.'</td>
						<td class="list_small">'.$T_TopicCount.'</td>
						<td class="list_small" noWrap>';
						
                    if ($T_TopicReplies > 0) {
                        echo '<font color="red">'.normal_time($T_TopicLastPostDate).'</font><br>'.link_profile($R_MemberName, $T_TopicLastPostAuthor, $Prefix);
                    }
                        echo '</td>';
                        
                    if ($Mlevel > 0) {

						echo'<td class="list_small" noWrap>';
      
                if ($Mlevel == 4 OR $Monitor == 1 OR $Moderator == 1) {
                    if ($T_TopicStatus == 1) {
                        echo'<a href="index.php?mode=lock&type=t&t='.$T_TopicID.'&f='.$T_ForumID.'&c='.$T_CatID.'"  onclick="return confirm(\''.$lang['forum']['you_are_sure_to_lock_this_topic'].'\');"><img hspace="2" alt="'.$lang['forum']['lock_topic'].'" src="'.$icon_lock.'" border="0"></a>';
                    }
                    if ($T_TopicStatus == 0) {
                        echo'<a href="index.php?mode=open&type=t&t='.$T_TopicID.'&f='.$T_ForumID.'&c='.$T_CatID.'"  onclick="return confirm(\''.$lang['forum']['you_are_sure_to_open_this_topic'].'\');"><img hspace="2" alt="'.$lang['forum']['open_topic'].'" src="'.$icon_unlock.'" border="0"></a>';
                    }
                    if ($T_TopicSticky == 0) {
                        echo'<a href="index.php?mode=lock&type=s&t='.$T_TopicID.'&f='.$T_ForumID.'&c='.$T_CatID.'"  onclick="return confirm(\''.$lang['forum']['you_are_sure_to_sticky_this_topic'].'\');"><img hspace="2" alt="'.$lang['forum']['sticky_topic'].'" src="'.$folder_topic_sticky.'" border="0"></a>';
                    }
                    if ($T_TopicSticky == 1) {
                        echo'<a href="index.php?mode=open&type=s&t='.$T_TopicID.'&f='.$T_ForumID.'&c='.$T_CatID.'"  onclick="return confirm(\''.$lang['forum']['you_are_sure_to_un_sticky_this_topic'].'\');"><img hspace="2" alt="'.$lang['forum']['un_sticky_topic'].'" src="'.$folder_topic_unsticky.'" border="0"></a>';
                    }
                        echo'<a href="index.php?mode=open&type=h&t='.$T_TopicID.'&f='.$T_ForumID.'&c='.$T_CatID.'"  onclick="return confirm(\''.$lang['forum']['you_are_sure_to_show_this_topic'].'\');"><img hspace="2" alt="'.$lang['forum']['show_topic'].'" src="'.$icon_unhidden.'" border="0"></a>';
                }
                if ($Mlevel == 4 OR $Monitor == 1 OR $Moderator == 1) {
                        echo'<a href="index.php?mode=option&t='.$T_TopicID.'"><img hspace="2" alt="'.$lang['forum']['topic_option'].'" src="'.$icon_edit_topic.'" border="0"></a>';
                }
                if ($Mlevel == 4 OR $Monitor == 1 OR $Moderator == 1 OR $T_TopicStatus == 1 AND $T_TopicAuthor == $DBMemberID) {
                        echo'<a href="index.php?mode=editor&method=edit&t='.$T_TopicID.'&f='.$F_ForumID.'&c='.$F_CatID.'"><img hspace="2" alt="'.$lang['forum']['edit_topic'].'" src="'.$icon_edit.'" border="0"></a>';
                }
                if ($Mlevel == 4 OR $Monitor == 1) {
                        echo'<a href="index.php?mode=delete&type=t&t='.$T_TopicID.'&f='.$T_ForumID.'&c='.$T_CatID.'"  onclick="return confirm(\''.$lang['forum']['you_are_sure_to_delete_this_topic'].'\');""><img hspace="2" alt="'.$lang['forum']['delete_topic'].'" src="'.$icon_trash.'" border="0"></a>';
                }
                if ($Mlevel > 0 OR $T_TopicStatus == 1) {
                        echo'<a href="index.php?mode=editor&method=reply&t='.$T_TopicID.'&f='.$F_ForumID.'&c='.$F_CatID.'"><img hspace="2" alt="'.$lang['forum']['reply_to_this_topic'].'" src="'.$icon_reply_topic.'" border="0"></a>';
                }
                        echo'</td>';
                    }

                    echo'
					</tr>';
    }
}
else {

if ($T_TopicSticky == 1) {
$TrClass = "fixed";
}
else {
$TrClass = "normal";
}


                    echo'
					<tr class="'.$TrClass.'">
						<td class="list_center">&nbsp;<nobr><a href="index.php?mode=t&t='.$T_TopicID.'"><img hspace="0"';

                    if ($T_TopicStatus == 0 AND $T_TopicReplies < 20) {
                        echo 'alt="'.$lang['forum']['topic_is_locked'].'" src="'.$folder_new_locked.'"';
                    }
                    elseif ($T_TopicStatus == 0 AND $T_TopicReplies >= 20) {
                        echo 'alt="'.$lang['forum']['topic_is_hot_and_locked'].'" src="'.$folder_new_locked.'"';
                    }
                    elseif ($T_TopicStatus == 1 AND $T_TopicReplies < 20) {
                        echo 'alt="" src="'.$folder_new.'"';
                    }
                    elseif ($T_TopicStatus == 1 AND $T_TopicReplies >= 20) {
                        echo 'alt="'.$lang['forum']['topic_is_hot'].'" src="'.$folder_new_hot.'"';
                    }
                    else {
                        echo 'alt="" src="'.$folder.'"';
                    }

                        echo'border="0"></a></nobr></td>
						<td class="list">
						<table cellPadding="0" cellsapcing="0">
							<tr>
								<td>';
if ($DBMemberID > 0) {
if ($T_TopicTop == 1) {
		echo'	<img src="'.$red_star.'" hspace="0" border="0">';
}
if ($T_TopicTop == 2) {
		echo'	<img src="'.$icon_top_topic.'" hspace="0" border="0">';
}
if ($T_TopicTop == 3) {
		echo'	<img src="'.$icon_survey.'" hspace="0" border="0">';
}
}
					echo'	<a href="index.php?mode=t&t='.$T_TopicID.'">'.$T_TopicSubject.'</a>&nbsp;</td>
							</tr>
						</table>
						</td>

						<td class="list_small" noWrap><font color="darkgreen">'.normal_time($T_TopicDate).'</font><br>'.link_profile($T_TopicMemberName, $T_TopicMemberID, $Prefix).'</a></td>
						<td class="list_small">'.$T_TopicReplies.'</td>
						<td class="list_small">'.$T_TopicCount.'</td>
						<td class="list_small" noWrap>';
                    if ($T_TopicReplies > 0) {
                        echo '<font color="red">'.normal_time($T_TopicLastPostDate).'</font><br>'.link_profile($R_MemberName, $T_TopicLastPostAuthor, $Prefix);
                    }
                        echo '</td>';

                    if ($Mlevel > 0) {

						echo'<td class="list_small" noWrap>';

                if ($Mlevel == 4 OR $Monitor == 1 OR $Moderator == 1) {
                    if ($T_TopicStatus == 1) {
                        echo'<a href="index.php?mode=lock&type=t&t='.$T_TopicID.'&f='.$T_ForumID.'&c='.$T_CatID.'"  onclick="return confirm(\''.$lang['forum']['you_are_sure_to_lock_this_topic'].'\');"><img hspace="2" alt="'.$lang['forum']['lock_topic'].'" src="'.$icon_lock.'" border="0"></a>';
                    }
                    if ($T_TopicStatus == 0) {
                        echo'<a href="index.php?mode=open&type=t&t='.$T_TopicID.'&f='.$T_ForumID.'&c='.$T_CatID.'"  onclick="return confirm(\''.$lang['forum']['you_are_sure_to_open_this_topic'].'\');"><img hspace="2" alt="'.$lang['forum']['open_topic'].'" src="'.$icon_unlock.'" border="0"></a>';
                    }
                    if ($T_TopicSticky == 0) {
                        echo'<a href="index.php?mode=lock&type=s&t='.$T_TopicID.'&f='.$T_ForumID.'&c='.$T_CatID.'"  onclick="return confirm(\''.$lang['forum']['you_are_sure_to_sticky_this_topic'].'\');"><img hspace="2" alt="'.$lang['forum']['sticky_topic'].'" src="'.$folder_topic_sticky.'" border="0"></a>';
                    }
                    if ($T_TopicSticky == 1) {
                        echo'<a href="index.php?mode=open&type=s&t='.$T_TopicID.'&f='.$T_ForumID.'&c='.$T_CatID.'"  onclick="return confirm(\''.$lang['forum']['you_are_sure_to_un_sticky_this_topic'].'\');"><img hspace="2" alt="'.$lang['forum']['un_sticky_topic'].'" src="'.$folder_topic_unsticky.'" border="0"></a>';
                    }
                        echo'<a href="index.php?mode=lock&type=h&t='.$T_TopicID.'&f='.$T_ForumID.'&c='.$T_CatID.'"  onclick="return confirm(\''.$lang['forum']['you_are_sure_to_hide_this_topic'].'\');"><img hspace="2" alt="'.$lang['forum']['hide_topic'].'" src="'.$icon_hidden.'" border="0"></a>';
                }
                if ($Mlevel == 4 OR $Monitor == 1 OR $Moderator == 1) {
                        echo'<a href="index.php?mode=option&t='.$T_TopicID.'"><img hspace="2" alt="'.$lang['forum']['topic_option'].'" src="'.$icon_edit_topic.'" border="0"></a>';
                }
                if ($Mlevel == 4 OR $Monitor == 1 OR $Moderator == 1 OR $T_TopicStatus == 1 AND $T_TopicAuthor == $DBMemberID) {
                        echo'<a href="index.php?mode=editor&method=edit&t='.$T_TopicID.'&f='.$F_ForumID.'&c='.$F_CatID.'"><img hspace="2" alt="'.$lang['forum']['edit_topic'].'" src="'.$icon_edit.'" border="0"></a>';
                }
                if ($Mlevel == 4 OR $Monitor == 1) {
                        echo'<a href="index.php?mode=delete&type=t&t='.$T_TopicID.'&f='.$T_ForumID.'&c='.$T_CatID.'"  onclick="return confirm(\''.$lang['forum']['you_are_sure_to_delete_this_topic'].'\');""><img hspace="2" alt="'.$lang['forum']['delete_topic'].'" src="'.$icon_trash.'" border="0"></a>';
                }
                if ($Mlevel > 0 OR $T_TopicStatus == 1) {
                        echo'<a href="index.php?mode=editor&method=reply&t='.$T_TopicID.'&f='.$F_ForumID.'&c='.$F_CatID.'"><img hspace="2" alt="'.$lang['forum']['reply_to_this_topic'].'" src="'.$icon_reply_topic.'" border="0"></a>';
                }
                        echo'</td>';
                    }

                    echo'
					</tr>';
}
     
      ++$iT;
}
                echo'
				</table>
				</td>
			</tr>
		</table>
		</td>
	</tr>
</table>
</center>
';
*/

?>
