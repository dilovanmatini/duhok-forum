<?
/*//////////////////////////////////////////////////////////
// ######################################################///
// # DuhokForum 0.4                                     # //
// ###################################################### //
// #                                                    # //
// #       --  DUHOK FORUM IS FREE SOFTWARE  --         # //
// #                                                    # //
// #   ========= Programming By Dilovan ==============  # //
// # Copyright � 2007-2008 Dilovan. All Rights Reserved # //
// #----------------------------------------------------# //
// #----------------------------------------------------# //
// # If you want any support vist down address:-        # //
// # Email: df@duhoktimes.com                           # //
// # Site: http://df.duhoktimes.com/index.php           # //
// ###################################################### //
//////////////////////////////////////////////////////////*/

 session_start();

$user_name = trim($HTTP_POST_VARS["user_name"]);
$user_pass = trim($HTTP_POST_VARS["user_pass"]);

if ($method == "login") {
	$_SESSION['DFName'] = $user_name;
	$_SESSION['DFPass'] = $user_pass;
}

if ($method == "logout") {
	$_SESSION['DFName'] = '';
	$_SESSION['DFPass'] = '';
	head('index.php');
}

//##################  save active type #######################################
$active_type = "active";
$post_active_type = $HTTP_POST_VARS["active_type"];
if (!empty($post_active_type)) {
	$HTTP_SESSION_VARS['DF_active_type'] = $post_active_type;
	head($HTTP_SERVER_VARS[REQUEST_URI]);
}
$load_active_type = $HTTP_SESSION_VARS['DF_active_type'];
if (!empty($load_active_type)) {
	$active_type = $load_active_type;
}
else {
	$active_type = $active_type;
}
//##################  save active type #######################################

//##################  save refresh time #######################################
$refresh_time = 0;
$post_refresh_time = $HTTP_POST_VARS["refresh_time"];
if (!empty($post_refresh_time)) {
	$HTTP_SESSION_VARS['DF_refresh_time'] = $post_refresh_time;
	head($HTTP_SERVER_VARS[REQUEST_URI]);
}
$load_refresh_time = $HTTP_SESSION_VARS['DF_refresh_time'];
if (!empty($load_refresh_time)) {
	$refresh_time = $load_refresh_time;
}
else {
	$refresh_time = $refresh_time;
}
//##################  save refresh time #######################################

//##################  save order by #######################################
$order_by = "post";
$post_order_by = $HTTP_POST_VARS["order_by"];
if (!empty($post_order_by)) {
	$HTTP_SESSION_VARS['DF_order_by'] = $post_order_by;
	head($HTTP_SERVER_VARS[REQUEST_URI]);
}
$load_order_by = $HTTP_SESSION_VARS['DF_order_by'];
if (!empty($load_order_by)) {
	$order_by = $load_order_by;
}
else {
	$order_by = $order_by;
}
//##################  save order by #######################################

//##################  save reply num page #######################################
$reply_num_page = 30;
$post_reply_num_page = $HTTP_POST_VARS["reply_num_page"];
if (!empty($post_reply_num_page)) {
	$HTTP_SESSION_VARS['DF_reply_num_page'] = $post_reply_num_page;
	head($HTTP_SERVER_VARS[REQUEST_URI]);
}
$load_reply_num_page = $HTTP_SESSION_VARS['DF_reply_num_page'];
if (!empty($load_reply_num_page)) {
	$reply_num_page = $load_reply_num_page;
}
else {
	$reply_num_page = $reply_num_page;
}
//##################  reply num page #######################################

//######### save sig #############
if (!empty($sg)) {
 $sig = $HTTP_POST_VARS["sig"];
 $_SESSION['DF_show_sig'] = $sig;
 head('index.php?mode=t&t='.$t);
}
$load_show_sig = $_SESSION['DF_show_sig'];
//######### save sig #############

//######### save style #############
if (!empty($ch) && $ch == "style") {
 $style_name = $HTTP_POST_VARS["style_name"];
 $_SESSION['DF_choose_style'] = $style_name;
 head('index.php');
}
$load_choose_style = $_SESSION['DF_choose_style'];

if (!empty($load_choose_style)) {
$choose_style = $load_choose_style;
}
else {
$choose_style = $default_style;
}
//######### save style #############

//######### save lang #############
if (!empty($ch) && $ch == "lang") {
 $lan_name = $HTTP_POST_VARS["lan_name"];
 $_SESSION['DF_choose_language'] = $lan_name;
 head('index.php');
}
$load_choose_language = $_SESSION['DF_choose_language'];

if (!empty($load_choose_language)) {
$choose_language = $load_choose_language;
}
else {
$choose_language = $default_language;
}
require_once("./language/".$choose_language.".php");

require_once("js_variable.php");
//######### save lang #############

$load_user_name = $_SESSION['DFName'];
$load_user_pass = $_SESSION['DFPass'];
$load_user_pass = MD5($load_user_pass);
$u_p = $lang['home']['use_program'];
$function_to_day = $lang['function']['to_day'];
$function_yester_day = $lang['function']['yesterday'];
$function_moderator_title = $lang['function']['moderator_title'];
$function_monitor_title = $lang['function']['monitor_title'];
$function_default = $lang['function']['default'];
$function_blue = $lang['function']['blue'];
$function_black = $lang['function']['black'];
$function_red = $lang['function']['red'];
$function_yellow = $lang['function']['yellow'];
$function_pink = $lang['function']['pink'];
$function_green = $lang['function']['green'];
$function_orange = $lang['function']['orange'];
$function_purple = $lang['function']['purple'];
$function_brown = $lang['function']['brown'];
$function_navy = $lang['function']['navy'];
$function_more_info = $lang['function']['more_info'];

 $Start = mysql_query("SELECT * FROM ".$Prefix."MEMBERS WHERE M_NAME = '$load_user_name' AND M_PASSWORD = '$load_user_pass' AND M_STATUS = 1 ") or die (mysql_error());

 if(mysql_num_rows($Start) > 0){
 $rsStart = mysql_fetch_array($Start);

 $DBMemberID = $rsStart['MEMBER_ID'];
 $DBUserName = $rsStart['M_NAME'];
 $DBPassword = $rsStart['M_PASSWORD'];
 $DBMemberPosts = $rsStart['M_POSTS'];
 $Mlevel = $rsStart['M_LEVEL'];
 }
 else {
 $DBMemberID = "0";
 $DBUserName = "0";
 $DBPassword = "0";
 $DBMemberPosts = "0";
 $Mlevel = "0";
 }
 $coda = codding($forum_title, $site_name, $copy_right, $u_p);
 if ($DBUserName == $load_user_name AND $DBPassword == $load_user_pass) {
 $Memberlogin = 1;
 }
 else {
 $Memberlogin = 0;
 }

$ReferTo = $_SERVER["HTTP_REFERER"];
$LoginLastIP = $_SERVER["REMOTE_ADDR"];
$LoginDate = time();

if ($Memberlogin == 1){
 $queryLog = "UPDATE ".$Prefix."MEMBERS SET M_LAST_IP = '$LoginLastIP', M_LAST_HERE_DATE = '$LoginDate' WHERE MEMBER_ID = '$DBMemberID' ";
 mysql_query($queryLog, $connection) or die (mysql_error());
}

require("online.php");

$PmCount = mysql_query("SELECT count(*) FROM ".$Prefix."PM WHERE PM_MID = '$DBMemberID' AND PM_OUT = '0' AND PM_READ = '0' AND PM_STATUS = '1' ") or die(mysql_error());
$NewPm = mysql_result($PmCount, 0, "count(*)");
if ($mode == "editor") {
$html_dir = '<html>';
$onload = 'onload=LoadContent() style="font:10pt verdana,arial,sans-serif" leftMargin=0 topMargin=0 scroll=no';
}
else {
$html_dir = '<html dir="'.$lang['global']['dir'].'">';
$onload = 'leftMargin="0" topMargin="0" marginheight="0" marginwidth="0"';
}
echo'
<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.0 Transitional//EN">
'.$html_dir.'
<head>
<title>'.$forum_title.'</title>
<META http-equiv=Content-Type content="'.$lang['global']['charset'].'">
<meta http-equiv="Content-Language" content="'.$lang['global']['lang_code'].'">
<META content="DUHOK FORUM 1.0: Copyright (C) 2007-2008 Dilovan." name=copyright>
<META http-equiv="Page-Enter" content="blendTrans(Duration=0)">
<META http-equiv="Page-Exit" content="blendTrans(Duration=0)">
<link rel="stylesheet" href="styles/style_'.$choose_style.'.css">';
echo'
<SCRIPT language="javascript" src="javascript/javascript.js"></SCRIPT>';
if ($mode == "editor") {
    echo'
    <script language="javascript" src="editor/func.js"></script>
	<script language="javascript" src="editor/editor.js"></script>
	<script language="javascript" src="editor/box_color.js"></script>
	<script language="javascript">
 
function SubmitForm() {

    var method = EditorForm.method.value;

	if(obj1.displayMode == "HTML")
		{
		alert(ed_uncheck_html)
		return ;
		}

	if ((method == "topic") || (method == "edit") || (method == "sendmsg") || (method == "replymsg"))
		{
		if (EditorForm.subject.value == "")
			{
			alert(ed_need_title)
			return ;
			}
		}

	EditorForm.message.value = obj1.getContentBody()

	if ((EditorForm.message.value == "") || (EditorForm.message.value == "<P>&nbsp;</P>") || (EditorForm.message.value == "<P></P>"))
		{
		alert(ed_need_content)
		return ;
		}

    var box = EditorForm.message.value.length;
    
	if (box > your_max_size) {
		    alert(ed_too_big)
		    return ;
	}
    
    

    if ((method == "topic") || (method == "edit")) {
	  if (box > topic_max_size) {
		    alert(ed_too_big)
		    return ;
		}
	}
 
    if ((method == "reply") || (method == "editreply")) {
	  if (box > reply_max_size) {
		    alert(ed_too_big)
		    return ;
		}
	}
 
    if ((method == "sendmsg") || (method == "replymsg")) {
	  if (box > pm_max_size) {
		    alert(ed_too_big)
		    return ;
		}
	}
 
    if (method == "sig") {
	  if (box > sig_max_size) {
		    alert(ed_too_big)
		    return ;
		}
	}
 
	if (confirm(ed_confirm_submit))
		EditorForm.submit()
}
 
function LoadContent(){
    obj1.putContent(idTextarea.value)
}
	</script>
 ';
}
echo'
</head>
<BODY '.$onload.'>';

if ($mode != "editor") {

echo'<table class="topholder" cellSpacing="0" cellPadding="0" width="100%">
       <tr>

           <td>

           <table class="menubar" cellSpacing="1" cellPadding="0" width="100%">
                  <tr>
                      <td width="100%"><a href="index.php">'.icons($logo, $forum_title, "").'</td>';

if ($Memberlogin == 1){

		if($mode !== "") {
                      echo'<td class="optionsbar_menus2" vAlign="top"><nobr><a href="index.php">'.icons($Home, "", "").'<br>'.$lang['header']['home'].'</a></nobr></td>';
		}

                      //echo'<td class="optionsbar_menus2" vAlign="top"><nobr><a href="index.php">'.icons($yourposts, "", "").'<br>'.$lang['header']['your_posts'].'</a></nobr></td>';

                      echo'<td class="optionsbar_menus2" vAlign="top"><nobr><a href="index.php?mode=members">'.icons($members, "", "").'<br>'.$lang['header']['members'].'</a></nobr></td>';

                      echo'<td class="optionsbar_menus2" vAlign="top"><nobr><a href="index.php?mode=pm&mail=in">'.icons($messages, "", "").'<br>'.$lang['header']['messages'].'</a></nobr></td>';

                      echo'<td class="optionsbar_menus2" vAlign="top"><nobr><a href="index.php?mode=active">'.icons($active, "", "").'<br>'.$lang['header']['active_topics'].'</a></nobr></td>';

                      //echo'<td class="optionsbar_menus2" vAlign="top"><nobr><a href="index.php">'.icons($search, "", "").'<br>'.$lang['header']['search'].'</a></nobr></td>';

                      //echo'<td class="optionsbar_menus2" vAlign="top"><nobr><a href="index.php">'.icons($help, "", "").'<br>'.$lang['header']['help'].'</a></nobr></td>';

                      echo'<td class="optionsbar_menus2" vAlign="top"><nobr><a href="index.php?mode=profile&type=details">'.icons($details, "", "").'<br>'.$lang['header']['your_details'].'</a></nobr></td>';

                      if ($Mlevel == 4) {
                      echo'<td class="optionsbar_menus2" vAlign="top"><nobr><a href="login.php">'.icons($admin, "", "").'<br>'.$lang['header']['administration'].'</a></nobr></td>';
                      }

                      echo'<td class="optionsbar_menus2" vAlign="top"><nobr><a href="index.php?method=logout" onclick="return confirm(\''.$lang['header']['you_are_sure_to_logout'].'\');">'.icons($exit, "", "").'<br>'.$lang['header']['exit'].'</a></nobr></td>';

}

else {
                      echo'<td class="optionsbar_menus2" vAlign="top"><nobr><a href="index.php">'.icons($Home, "", "").'<br>'.$lang['header']['home'].'</a></nobr></td>';

                      echo'<td class="optionsbar_menus2" vAlign="top"><nobr><a href="index.php?mode=members">'.icons($members, "", "").'<br>'.$lang['header']['members'].'</a></nobr></td>';

                      echo'<td class="optionsbar_menus2" vAlign="top"><nobr><a href="index.php?mode=active">'.icons($active, "", "").'<br>'.$lang['header']['active_topics'].'</a></nobr></td>';

                      //echo'<td class="optionsbar_menus2" vAlign="top"><nobr><a href="index.php">'.icons($help, "", "").'<br>'.$lang['header']['help'].'</a></nobr></td>';

                      echo'<td class="optionsbar_menus2" vAlign="top"><nobr><a href="index.php?mode=register">'.icons($details, "", "").'<br>'.$lang['header']['register'].'</a></nobr></td>';

}

                  echo'</tr>
           </table>

           </td>

       </tr>

       <tr>

           <td>

 ';


if ($Memberlogin == 1){



           echo'<table class="userbar" cellSpacing="0" cellPadding="0" width="100%" border="0">
                  <tr>
                      <td vAlign="center">

                      <table cellSpacing="0" cellPadding="0">

                             <tr>
                                 <td class="user" align="left"><nobr><a href="index.php?mode=profile&type=details">'.$lang['header']['name'].'</a></nobr></td>
                                 <td class="user"><nobr><a href="index.php?mode=profile&type=details">&nbsp;<font color="red">'.$DBUserName.'</font></a></nobr></td>
                             </tr>

                             <tr>
                                 <td class="user" align="left"><nobr><a href="index.php?mode=profile&id='.$DBMemberID.'">'.$lang['header']['posts'].'</a></nobr></td>
                                 <td class="user"><nobr><a href="index.php?mode=profile&id='.$DBMemberID.'">&nbsp;<font color="red">'.$DBMemberPosts.'</font></a></nobr></td>
                             </tr>';

                      if ($NewPm > 0) {
                             echo'<tr>
                                 <td class="user" align="left"><nobr><a href="index.php?mode=pm&mail=new">'.$lang['header']['new_pm'].'</a></nobr></td>
                                 <td class="user"><nobr><a href="index.php?mode=pm&mail=new">&nbsp;<font color="red">'.$NewPm.'</font></a></nobr></td>
                             </tr>';
                      }
                      echo'
                      </table>

                      </td>
                      <td width="10%">
		      </td>
                      <td vAlign="center">';
					if($mode == "f" AND $Mlevel > 0) {
						echo '
						<table class="chatusers">
							<tr>
								<td class="forumusers" vAlign="top">
									<a href="index.php?mode=finfo&f='.$f.'">�� ��� ������� �����:</a><br>
									<a class="tiny" href="index.php?mode=finfo&f='.$f.'"><font color="red">��� �������:</font>'.forum_online_num($f).'</a>
								</td>
							</tr>
						</table>';
					}
					echo'
					</td>
                      <td align="left" width="30%">
                      <table border="0" cellPadding="1" cellSpacing="2">';
                      if ($Mlevel > 1) {
                             echo'
                             <tr>
				 <td class="optionsbar_menus"><nobr><a href="index.php?mode=files">'.$lang['header']['files'].'</a></nobr></td>
                                 <td class="optionsbar_menus"><nobr><a href="index.php?mode=svc">'.$lang['header']['services'].'</a></nobr></td>
                                 <td class="optionsbar_menus"><nobr><a href="index.php?mode=upload">'.$lang['header']['upload'].'</a></nobr></td>
                             </tr>
			     <tr>
				<td>&nbsp;</td>
			     </tr>';
                      }
                      echo'
                      </table>
                      </td>
                  </tr>
           </table>';

}

else {
				echo'<table class="grid" height="100%" cellSpacing="0" cellPadding="0" border="0">
                     <form method="POST" action="index.php?method=login">

						<tr>
							<td class="cat" align="middle" colSpan="4">'.$lang['header']['members_login'].'</td>
						</tr>
						<tr>
							<td class="f2ts" align="left"><font color="red"><b>'.$lang['header']['name'].'</b></font></td>
							<td class="f2ts"><input type="text" class="small" style="WIDTH: 100px" name="user_name"></td>
							<td class="f2ts" align="left"><font color="red"><nobr><b>'.$lang['header']['password'].'</b></nobr></font></td>
							<td class="f2ts"><input type="password" class="small" style="WIDTH: 100px" name="user_pass"></td>
						</tr>
        				<tr>
          					<td colspan="3" class="f2ts" align="right">
							<select name="SavePassword">
							<option value="true">'.$lang['header']['save_pass_and_user_name'].'</option>
                            <option value="false">'.$lang['header']['temporarily_login'].'</option>
							</select>
                            <td class="f2ts" vAlign="top" align="left"><input class="small" src="'.$login.'" type="image" border="0" value="'.$lang['header']['login'].'"></td>
						</tr>
        				<tr>
                            <td colspan="3" class="f2ts" align="right"><a class="menu" href="index.php?mode=forget_pass">'.$lang['header']['forget_password'].'</a></td>
                            <td class="f2ts" align="right"></td>
        				</tr>
					</form>
				</table>';
}


           echo'
           <br></td>
       </tr>
</table>';


}

if ($method == "login"){
	if ($Memberlogin == 1){
		echo'<br>
		<center>
		<table width="99%" border="1">
			<tr class="normal">
				<td class="list_center" colSpan="10"><font size="5"><br>����� ��
				<TABLE>
				<TBODY>
					<TR>
						<TD class="tini" style="FONT-SIZE: 20px; FONT-FAMILY: ARIAL; COLOR: #000000; FILTER: blur(add=1,direction=-90,strength=20); HEIGHT: 20px" align="center">'.$DBUserName.'</TD>
					</TR>
				</TBODY>
				</TABLE>
				</font><br>
				<meta http-equiv="Refresh" content="1; URL=index.php">
				<a href="index.php">-- ��� ������ �� ����� �������� ���� ��� --</a><br><br>
				</td>
			</tr>
		</table>
		</center><xml>';
	}
	if ($Memberlogin == 0){
		echo'<br>
		<center>
		<table width="99%" border="1">
			<tr class="normal">
				<td class="list_center" colSpan="10">
					<font size="3" color="red"><br>�� ����� ������ ��������� ��� ����� ������� �� ������ ������ ���� ���� ��� ����� ��������.<br>��� ���� ������ ������ ������ ������� ���� ������ �����<br><br>
					<a href="index.php?mode=forget_pass">-- ��� ������� ������� ������ --</a><br><br>
					<a href="JavaScript:history.go(-1)">-- ���� ��� ������ ��� ������ ������� --</a></font><br><br>
				</td>
			</tr>
		</table>
		</center><xml>';
	}
}
?>
