<?php
/*//////////////////////////////////////////////////////////
// ######################################################///
// # DuhokForum 0.4                                     # //
// ###################################################### //
// #                                                    # //
// #       --  DUHOK FORUM IS FREE SOFTWARE  --         # //
// #                                                    # //
// #   ========= Programming By Dilovan ==============  # //
// # Copyright � 2007-2008 Dilovan. All Rights Reserved # //
// #----------------------------------------------------# //
// #----------------------------------------------------# //
// # If you want any support vist down address:-        # //
// # Email: df@duhoktimes.com                           # //
// # Site: http://df.duhoktimes.com/index.php           # //
// ###################################################### //
//////////////////////////////////////////////////////////*/

function forum_mods($id){
	global $Prefix;
	$sql = mysql_query("SELECT * FROM ".$Prefix."MODERATOR WHERE FORUM_ID = '$id' ") or die(mysql_error());
	$num = mysql_num_rows($sql);
	$forum_mods = '<table class="mods" cellspacing="0" cellpadding="0"><tr>';
	$forum_mods .= '<td><nobr>&nbsp;������:</td>';
 	$j = 0;
	$i = 0;
	while ($i < $num){
		$member_id = mysql_result($sql, $i, "MEMBER_ID");
		if ($j == 3){
			$forum_mods .= '</tr></table><table class="mods" cellspacing="0" cellpadding="0"><tr>';
			$j = 0;
		}
		$forum_mods .= '<td><nobr>&nbsp;';
		if ($j){
			$forum_mods .= ' + ';
		}
		$forum_mods .= normal_profile(members("NAME", $member_id), $member_id).'</td>';
	$i++;
	$j++;
	}
	$forum_mods .= '</tr></table>';
return($forum_mods);
}

function forum_new_mail($f){
	global $Prefix;
	$f = abs2($f);
	$new_pm = mysql_query("SELECT count(*) FROM ".$Prefix."PM WHERE PM_MID = '$f' AND PM_OUT = '0' AND PM_READ = '0' AND PM_STATUS = '1' ") or die(mysql_error());
	$count = mysql_result($new_pm, 0, "count(*)");
	if ($count > 0) {
		$forum_pm = '(<font color="red">'.$count.'</font>)<br>';
	}
	else {
		$forum_pm = '';
	}

return($forum_pm);
}

function forum_func($t){
	global $tr_class, $DBMemberID, $Mlevel, $folder_new_locked,
	$lang, $folder_new, $folder_new_hot, $folder,
	$red_star, $icon_top_topic, $icon_survey, $icon_lock,
	$icon_unlock, $folder_topic_sticky, $folder_topic_unsticky, $icon_unhidden,
	$icon_hidden, $icon_folder_archive, $allowed,
	$icon_edit, $icon_trash, $icon_reply_topic;
	
	$c = topics("CAT_ID", $t);
    $f = topics("FORUM_ID", $t);
    $status = topics("STATUS", $t);
    $subject = topics("SUBJECT", $t);
    $author = topics("AUTHOR", $t);
    $replies = topics("REPLIES", $t);
    $counts = topics("COUNTS", $t);
    $lp_date = topics("LAST_POST_DATE", $t);
    $date = topics("DATE", $t);
    $lp_author = topics("LAST_POST_AUTHOR", $t);
    $sticky = topics("STICKY", $t);
    $hidden = topics("HIDDEN", $t);
    $top = topics("TOP", $t);
    $author_name = members("NAME", $author);
	$lp_author_name = members("NAME", $lp_author);

					echo'
					<tr class="'.$tr_class.'">
						<td class="list_center">&nbsp;<nobr><a href="index.php?mode=t&t='.$t.'">';
					if ($status == 0 AND $replies < 20) {
						echo icons($folder_new_locked, $lang['forum']['topic_is_locked']);
					}
					elseif ($status == 0 AND $replies >= 20) {
						echo icons($folder_new_locked, $lang['forum']['topic_is_hot_and_locked']);
					}
					elseif ($status == 1 AND $replies < 20) {
						echo icons($folder_new);
					}
					elseif ($status == 1 AND $replies >= 20) {
						echo icons($folder_new_hot, $lang['forum']['topic_is_hot']);
					}
					else {
						echo icons($folder);
					}
						echo'
						</a></nobr></td>
						<td class="list">
						<table cellPadding="0" cellsapcing="0">
							<tr>';
							if ($top == 1){
								echo'
								<td>'.icons($red_star, "��� ������� �����").'</td>';
							}
							if ($top == 2){
								echo'
								<td>'.icons($icon_top_topic, "��� ������� �����").'</td>';
							}
							if ($top == 3){
								echo'
								<td>'.icons($icon_survey).'</td>';
							}							
								echo'
								<td><a href="index.php?mode=t&t='.$t.'">'.$subject.'</a>&nbsp;'; echo topic_paging($t); echo'</td>
							</tr>
						</table>
						</td>
						<td class="list_small" noWrap><font color="green">'.normal_time($date).'</font><br>'.link_profile($author_name, $author).'</td>
						<td class="list_small">'.$replies.'</td>
						<td class="list_small">'.$counts.'</td>
						<td class="list_small" noWrap><font color="red">';
						if ($replies > 0){
							echo normal_time($lp_date).'</font><br>'.link_profile($lp_author_name, $lp_author);
						}
						echo'
						</td>';
					if ($Mlevel > 0){	
						echo'
						<td class="list_small" noWrap>';

						if ($allowed == 1) {
							if ($status == 1) {
								echo'<a href="index.php?mode=lock&type=t&t='.$t.'&f='.$f.'&c='.$c.'" onclick="return confirm(\''.$lang['forum']['you_are_sure_to_lock_this_topic'].'\');">'.icons($icon_lock, $lang['forum']['lock_topic'], "hspace=\"2\"").'</a>';
							}
							if ($status == 0) {
								echo'<a href="index.php?mode=open&type=t&t='.$t.'&f='.$f.'&c='.$c.'"  onclick="return confirm(\''.$lang['forum']['you_are_sure_to_open_this_topic'].'\');">'.icons($icon_unlock, $lang['forum']['open_topic'], "hspace=\"2\"").'</a>';
							}
							if ($sticky == 0) {
								echo'<a href="index.php?mode=lock&type=s&t='.$t.'&f='.$f.'&c='.$c.'"  onclick="return confirm(\''.$lang['forum']['you_are_sure_to_sticky_this_topic'].'\');">'.icons($folder_topic_sticky, $lang['forum']['sticky_topic'], "hspace=\"2\"").'</a>';
							}
		                    if ($sticky == 1) {
								echo'<a href="index.php?mode=open&type=s&t='.$t.'&f='.$f.'&c='.$c.'"  onclick="return confirm(\''.$lang['forum']['you_are_sure_to_un_sticky_this_topic'].'\');">'.icons($folder_topic_unsticky, $lang['forum']['un_sticky_topic'], "hspace=\"2\"").'</a>';
							}
							if ($hidden == 1){
								echo'<a href="index.php?mode=open&type=h&t='.$t.'&f='.$f.'&c='.$c.'"  onclick="return confirm(\''.$lang['forum']['you_are_sure_to_show_this_topic'].'\');">'.icons($icon_unhidden, $lang['forum']['show_topic'], "hspace=\"2\"").'</a>';
							}
							if ($hidden == 0){
								echo'<a href="index.php?mode=lock&type=h&t='.$t.'&f='.$f.'&c='.$c.'"  onclick="return confirm(\''.$lang['forum']['you_are_sure_to_hide_this_topic'].'\');">'.icons($icon_hidden, $lang['forum']['hide_topic'], "hspace=\"2\"").'</a>';
							}
							echo'<a href="index.php?mode=option&t='.$t.'">'.icons($icon_folder_archive, $lang['forum']['topic_option'], "hspace=\"2\"").'</a>';
						}
						if ($allowed == 1 OR $status == 1 AND $author == $DBMemberID) {
							echo'<a href="index.php?mode=editor&method=edit&t='.$t.'&f='.$f.'&c='.$c.'">'.icons($icon_edit, $lang['forum']['edit_topic'], "hspace=\"2\"").'</a>';
						}
						if (allowed($f, 1) == 1) {
							echo'<a href="index.php?mode=delete&type=t&t='.$t.'&f='.$f.'&c='.$c.'"  onclick="return confirm(\''.$lang['forum']['you_are_sure_to_delete_this_topic'].'\');"">'.icons($icon_trash, $lang['forum']['delete_topic'], "hspace=\"2\"").'</a>';
						}
						if ($allowed == 1 OR $status == 1) {
							echo'<a href="index.php?mode=editor&method=reply&t='.$t.'&f='.$f.'&c='.$c.'">'.icons($icon_reply_topic, $lang['forum']['reply_to_this_topic'], "hspace=\"2\"").'</a>';
						}
						
						echo'
						</td>';
					}
					echo'
					</tr>';
}


?>
