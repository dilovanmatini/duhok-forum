<?
/*//////////////////////////////////////////////////////////
// ######################################################///
// # DuhokForum 0.4                                     # //
// ###################################################### //
// #                                                    # //
// #       --  DUHOK FORUM IS FREE SOFTWARE  --         # //
// #                                                    # //
// #   ========= Programming By Dilovan ==============  # //
// # Copyright � 2007-2008 Dilovan. All Rights Reserved # //
// #----------------------------------------------------# //
// #----------------------------------------------------# //
// # If you want any support vist down address:-        # //
// # Email: df@duhoktimes.com                           # //
// # Site: http://df.duhoktimes.com/index.php           # //
// ###################################################### //
//////////////////////////////////////////////////////////*/

if(!isset($_GET['pg']))
{
$pag = 1;
}
else
{
$pag = $_GET['pg'];
}


$start = (($pag * $max_page) - $max_page);

$total_res = mysql_result(mysql_query("SELECT COUNT(MEMBER_ID) FROM " . $Prefix . "MEMBERS "),0);
$total_col = ceil($total_res / $max_page);

if ($pg == "p") {

$pg = $_POST["numpg"];

echo'<script language="JavaScript" type="text/javascript">
 window.location = "index.php?mode=members&pg='.$pg.'";
 </script>';
}

$forum_page = $lang['members']['page'];
$forum_from = $lang['members']['from'];

function paging($total_col, $pag) {
global $forum_page, $forum_from;
		echo '
        <form method="post" action="index.php?mode=members&pg=p">
        <td class="optionsbar_menus">

		<b>'.$forum_page.' :</b>
        <select name="numpg" size="1" onchange="submit();">';


        for($i = 1; $i <= $total_col; $i++) {
            if(($pag) == $i) {
		        echo '<option selected value="'.$i.'">'.$i.' '.$forum_from.' '.$total_col.'</option>';
            }
            else {
		        echo '<option value="'.$i.'">'.$i.' '.$forum_from.' '.$total_col.'</option>';
            }
        }

		echo '
        </select>

		</td>
		</form>';

}


echo'
<center>
<table class="optionsbar" cellSpacing="2" width="99%" border="0" id="table11">
	<tr>
		<td class="optionsbar_title" Align="middle" vAlign="center" width="100%">'.$lang['members']['members_page'].'</td>';
  
paging($total_col, $pag);
go_to_forum();
echo'
	</tr>
</table>
</center>

<table border="0"><tr><td height="5"></td></tr></table>
<center>
<table class="grid" cellSpacing="1" cellPadding="2" width="99%" border="0">
	<tr>
		<td class="cat">'.$lang['members']['numbers'].'</td>
		<td class="cat">'.$lang['members']['members'].'</td>
		<td class="cat">'.$lang['members']['country'].'</td>
		<td class="cat">'.$lang['members']['posts'].'</td>
		<td class="cat">'.$lang['members']['last_post'].'</td>
		<td class="cat">'.$lang['members']['last_visit'].'</td>
		<td class="cat">'.$lang['members']['rejister_date'].'</td>';

        if ($Mlevel == 4) {
        echo'<td class="cat">'.$lang['members']['options'].'</td>';
        }

	echo'</tr>';

	$query = "SELECT * FROM " . $Prefix . "MEMBERS ";
    $query .= " ORDER BY M_POSTS DESC LIMIT $start, $max_page";
	$result = mysql_query($query, $connection) or die (mysql_error());

$num = mysql_num_rows($result);

if ($num == 0) {
    echo'
    <tr class="normal">
		<td class="list_center" vAlign="center" colspan="10"><br>'.$lang['members']['non_members'].'<br><br></td>
    </tr>';
}


$i=0;
while ($i < $num) {


    $MMember_ID = mysql_result($result, $i, "MEMBER_ID");
    $MMemberStatus = mysql_result($result, $i, "M_STATUS");
    $MMemberName = mysql_result($result, $i, "M_NAME");
    $MMemberCountry = mysql_result($result, $i, "M_COUNTRY");
    $MMemberPosts = mysql_result($result, $i, "M_POSTS");
    $MMemberLastPostDate = mysql_result($result, $i, "M_LAST_POST_DATE");
    $MMemberLastHereDate = mysql_result($result, $i, "M_LAST_HERE_DATE");
    $MMemberDate = mysql_result($result, $i, "M_DATE");
	$MMemberBrowse = mysql_result($result, $i, "M_BROWSE");
    
    if ($i % 2) {
	    $bg_color="fixed";
    }
    else
    {
	    $bg_color="normal";
    }
    
    
	echo'
    <tr class="'.$bg_color.'">
		<td class="list_date" vAlign="center">'.$MMember_ID.'</td>
		<td class="list_names"><nobr><a href="index.php?mode=profile&id='.$MMember_ID.'">'.$MMemberName.'</a></nobr><br>'.member_title($MMember_ID).'</td>
		<td class="list_small">'.$MMemberCountry.'</td>
		<td class="list_small">'.$MMemberPosts.'<br>'.member_stars($MMember_ID).'</td>
		<td class="list_date">'.members_time($MMemberLastPostDate).'</td>
		<td class="list_small">';
	if ($Mlevel > 1){
		echo members_time($MMemberLastHereDate);
	}
	else{
		if ($MMemberBrowse == 1){
			echo members_time($MMemberLastHereDate);
		}
		else{
			echo '-';
		}
	}
		echo'
		</td>
		<td class="list_date">'.members_time($MMemberDate).'</td>';
  
        if ($Mlevel == 4) {
            echo'<td class="list_date">';
          if ($MMemberStatus == 1 && $MMember_ID != 1 && $MMember_ID != $DBMemberID) {
		    echo'<a href="index.php?mode=lock&type=m&m='.$MMember_ID.'"  onclick="return confirm(\''.$lang['members']['you_are_sure_to_lock_this_member'].'\');">'.icons($icon_lock, $lang['members']['lock_member'], "hspace=\"2\"").'</a>';
          }
          if ($MMemberStatus == 0 && $MMember_ID != 1 && $MMember_ID != $DBMemberID) {
            echo'<a href="index.php?mode=open&type=m&m='.$MMember_ID.'"  onclick="return confirm(\''.$lang['members']['you_are_sure_to_open_this_member'].'\');">'.icons($icon_unlock, $lang['members']['open_member'], "hspace=\"2\"").'</a>';
          }
          $edit_member = '<a href="index.php?mode=profile&type=edit_user&id='.$MMember_ID.'">'.icons($icon_edit, $lang['members']['edit_member'], "hspace=\"2\"").'</a>';
          if ($MMember_ID == 1) {
              if ($DBMemberID == 1) {
              echo $edit_member;
              }
          }
          else {
              echo $edit_member;
          }
          if ($MMember_ID != 1 && $MMember_ID != $DBMemberID) {
            echo'<a href="index.php?mode=delete&type=m&m='.$MMember_ID.'"  onclick="return confirm(\''.$lang['members']['you_are_sure_to_delete_this_member'].'\');">'.icons($icon_trash, $lang['members']['delete_member'], "hspace=\"2\"").'</a>';
          }
            echo'</td>';
        }
	echo'</tr>';
    ++$i;
}

echo '
</table>
</center>';

mysql_close();
?>
