<?
/*//////////////////////////////////////////////////////////
// ######################################################///
// # DuhokForum 0.5                                     # //
// ###################################################### //
// #                                                    # //
// #       --  DUHOK FORUM IS FREE SOFTWARE  --         # //
// #                                                    # //
// #   ========= Programming By Dilovan ==============  # //
// # Copyright � 2007-2008 Dilovan. All Rights Reserved # //
// #----------------------------------------------------# //
// #----------------------------------------------------# //
// # If you want any support vist down address:-        # //
// # Email: df@duhoktimes.com                           # //
// # Site: http://df.duhoktimes.com/index.php           # //
// ###################################################### //
//////////////////////////////////////////////////////////*/

if ($CPMlevel == 4) {

if ($method == "") {

 if ($type == "") {

echo'
<center>
<table class="grid" border="0" cellspacing="1" cellpadding="4" width="80%">
<form method="post" action="cp_home.php?mode=style&type=set">
	<tr class="fixed">
		<td class="cat" colspan="5"><nobr>������� �������</nobr></td>
	</tr>';
 
        $ch_style = mysql_query("SELECT * FROM ".$Prefix."STYLE ") or die (mysql_error());
        $style_num = mysql_num_rows($ch_style);

        if ($style_num > 0) {

            $style_i = 0;
            while ($style_i < $style_num) {

                $style_id = mysql_result($ch_style, $style_i, "S_ID");
                $style_file_name = mysql_result($ch_style, $style_i, "S_FILE_NAME");
                $style_name = mysql_result($ch_style, $style_i, "S_NAME");

                echo'
                <input type="hidden" name="style_id[]" value="'.$style_id.'">
	        	<tr class="fixed">
	        		<td class="cat"><nobr>��� �������</nobr></td>
	        		<td class="middle"><input type="text" name="style_name[]" size="15" value="'.$style_name.'"></td>
                    <td class="cat"><nobr>��� ��� �������</nobr></td>
                    <td class="middle"><input type="text" name="style_file[]" size="15" value="'.$style_file_name.'"></td>
                    <td align="middle">
                    <table>
                        <tr>
                            <td class="optionsbar_menus">
                                <font size="3"><nobr><a href="cp_home.php?mode=style&method=delete&id='.$style_id.'">��� �������</a></nobr></font>
                            </td>
                        </tr>
                    </table>
                    </td>
	        	</tr>';

            ++$style_i;
            }
        }
        else {
            echo'
	        <tr class="fixed">
		        <td class="list_center" colspan="5"><br>�� ���� �� �����<br><br></td>
	        </tr>';
 
        }
        
    echo'
	<tr class="fixed">
       <td align="middle" colspan="5">
       <table>
           <tr>
               <td class="optionsbar_menus">
                   <font size="3"><a href="cp_home.php?mode=style&method=add">����� ����� ����</a></font>
               </td>
           </tr>
       </table>
       </td>
	</tr>';
if ($style_num > 0) {
    echo'
 	<tr class="fixed">
		<td align="middle" colspan="5"><input type="submit" value="����� ������">&nbsp;&nbsp;&nbsp;<input type="reset" value="����� �� ������"></td>
	</tr>';
}
echo'
</form>
</table>
</center>';


 }

 if ($type == "set") {

    if ($error != "") {
	                echo'<br><center>
	                <table bordercolor="#ffffff" width="99%" border="1">
	                   <tr class="normal">
	                       <td class="list_center" colSpan="10"><font size="5" color="red"><br>���<br>'.$error.'..</font><br><br>
	                       <a href="JavaScript:history.go(-1)">-- ���� ��� ������ --</a><br><br>
	                       </td>
	                   </tr>
	                </table>
	                </center>';
    }


    if ($error == "") {

$style_id = $HTTP_POST_VARS["style_id"];
$style_name = $HTTP_POST_VARS["style_name"];
$style_file = $HTTP_POST_VARS["style_file"];


$i_s = 0;
$f_s = 0;
$n_s = 0;
while($i_s < count($style_id)) {

		$updatingStyle = mysql_query("UPDATE ".$Prefix."STYLE SET S_FILE_NAME = '".$style_file[$f_s]."', S_NAME = '".$style_name[$n_s]."' WHERE S_ID = ".$style_id[$i_s]." ");
        $n_s++;
        $f_s++;
        $i_s++;

}

                    echo'<br><br>
	                <center>
	                <table bordercolor="#ffffff" width="50%" border="1">
	                   <tr class="normal">
	                       <td class="list_center" colSpan="10"><font size="5"><br>�� ����� ������ �����..</font><br><br>
                           <meta http-equiv="Refresh" content="1; URL=cp_home.php?mode=style">
                           <a href="cp_home.php?mode=style">-- ���� ��� ������ ��� ���� ������� --</a><br><br>
	                       </td>
	                   </tr>
	                </table>
	                </center>';
    }

 }

}



if ($method == "add") {

 if ($type == "") {

echo'
<center>
<table class="grid" border="0" cellspacing="1" cellpadding="4" width="80%">
<form method="post" action="cp_home.php?mode=style&&method=add&type=set">
	<tr class="fixed">
		<td class="cat" colspan="2"><nobr>����� ����� ����</nobr></td>
	</tr>
	<tr class="fixed">
		<td class="list"><nobr>��� �������</nobr></td>
		<td><input type="text" name="style_name" size="20"></td>
	</tr>
 	<tr class="fixed">
		<td class="list"><nobr>��� ��� �������</nobr></td>
		<td><input type="text" dir="ltr" name="style_file" size="20"></td>
	</tr>
 	<tr class="fixed">
		<td align="middle" colspan="2"><input type="submit" value="����� �����">&nbsp;&nbsp;&nbsp;<input type="reset" value="����� �� ������"></td>
	</tr>
</form>
</table>
</center>';

 }

 if ($type == "set") {

    if ($error != "") {
	                echo'<br><center>
	                <table bordercolor="#ffffff" width="99%" border="1">
	                   <tr class="normal">
	                       <td class="list_center" colSpan="10"><font size="5" color="red"><br>���<br>'.$error.'..</font><br><br>
	                       <a href="JavaScript:history.go(-1)">-- ���� ��� ������ --</a><br><br>
	                       </td>
	                   </tr>
	                </table>
	                </center>';
    }


    if ($error == "") {

$style_name = $_POST["style_name"];
$style_file = $_POST["style_file"];

     $query = "INSERT INTO ".$Prefix."STYLE (S_ID, S_FILE_NAME, S_NAME) VALUES (NULL, ";
     $query .= " '$style_file', ";
     $query .= " '$style_name') ";

     mysql_query($query, $connection) or die (mysql_error());


                    echo'<br><br>
	                <center>
	                <table bordercolor="#ffffff" width="50%" border="1">
	                   <tr class="normal">
	                       <td class="list_center" colSpan="10"><font size="5"><br>�� ����� ������� �����..</font><br><br>
                           <meta http-equiv="Refresh" content="1; URL=cp_home.php?mode=style">
                           <a href="cp_home.php?mode=style">-- ���� ��� ������ ��� ���� ������� --</a><br><br>
	                       </td>
	                   </tr>
	                </table>
	                </center>';
    }
 }
}


if ($method == "delete") {

mysql_query("DELETE FROM ".$Prefix."STYLE WHERE S_ID = '$id' ") or die (mysql_error());

                    echo'<br><br>
	                <center>
	                <table bordercolor="#ffffff" width="50%" border="1">
	                   <tr class="normal">
	                       <td class="list_center" colSpan="10"><font size="5"><br>�� ��� ������� �����..</font><br><br>
                           <meta http-equiv="Refresh" content="1; URL=cp_home.php?mode=style">
                           <a href="cp_home.php?mode=style">-- ���� ��� ������ ��� ���� ������� --</a><br><br>
	                       </td>
	                   </tr>
	                </table>
	                </center>';
}
 
 
}
else {
    go_to("index.php");
}
?>
