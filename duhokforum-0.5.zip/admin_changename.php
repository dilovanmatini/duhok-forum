<?
/*//////////////////////////////////////////////////////////
// ######################################################///
// # DuhokForum 0.5                                     # //
// ###################################################### //
// #                                                    # //
// #       --  DUHOK FORUM IS FREE SOFTWARE  --         # //
// #                                                    # //
// #   ========= Programming By Dilovan ==============  # //
// # Copyright � 2007-2008 Dilovan. All Rights Reserved # //
// #----------------------------------------------------# //
// #----------------------------------------------------# //
// # If you want any support vist down address:-        # //
// # Email: df@duhoktimes.com                           # //
// # Site: http://df.duhoktimes.com/index.php           # //
// ###################################################### //
//////////////////////////////////////////////////////////*/

if ($Mlevel == 4) {

if ($method == "") {

echo'
<center>
<table cellSpacing="1" cellPadding="3" width="60%" border="0">
	<tr>
		<td class="optionsbar_menus" Align="middle" vAlign="center" width="100%"><font size="4" color="red">����� ����� ��� �������</font></td>';
		go_to_forum();
echo'	</tr>
</table>
	<table cellSpacing="1" cellPadding="3" width="60%" bgColor="gray" border="0">
		<tr>
			<td class="cat" width="1%">�����</td>
			<td class="cat" width="15%">�������</td>
			<td class="cat" width="17%">��</td>
			<td class="cat" width="17%">���</td>
			<td class="cat" width="20%">&nbsp;</td>
		</tr>';

	$query = "SELECT * FROM ".$Prefix."CHANGENAME_PENDING ";
	$query .= "WHERE CH_DONE = '0' AND UNDERDEMANDE = '1' ";
	$query .= "ORDER BY CH_DATE ASC ";
	$result = mysql_query($query, $connection) or die (mysql_error());

	$num = mysql_num_rows($result);

  if ($num == 0) {
  echo'
  <tr>
    <td class="f1" align="middle" colSpan="11"><font color="black" size="3"><br>�� ���� ��� ����� �����..<br><br></font></td>
  </tr>';
  }

  $i=0;
  while ($i < $num) {
	$ChangeName_ID = mysql_result($result, $i, "CHNAME_ID");
	$ChMember_ID = mysql_result($result, $i, "MEMBERID");
	$New_Name = mysql_result($result, $i, "NEW_NAME");
	$Last_Name = mysql_result($result, $i, "LAST_NAME");
	$ChName_Date = mysql_result($result, $i, "CH_DATE");
	$ChName_Done = mysql_result($result, $i, "CH_DONE");
	$UnderDemande = mysql_result($result, $i, "UNDERDEMANDE");

echo '
		<tr class="normal">
			<td class="list_small">'.$ChangeName_ID.'</td>
			<td class="list_small">'.normal_time ($ChName_Date).'</td>
			<td class="list_small">'.$Last_Name.'</td>
			<td class="list_small">'.$New_Name.'</td>
			<td class="list_small">
		<a href="index.php?mode=adminch&method=submit_data&type=accept&m='.$ChMember_ID.'&id='.$ChangeName_ID.'">�����&nbsp;&nbsp;&nbsp;&nbsp;
		<a href="index.php?mode=adminch&method=submit_data&type=refuse&m='.$ChMember_ID.'&id='.$ChangeName_ID.'">��� �����
			</td>
		</tr>';
    ++$i;
  }

echo'	</table>
</center>';

}

if ($method == "submit_data") {

$ChangeName_ID = $id;
$Chmember_ID = $m;
$date = time();

 $QCHNP = "SELECT * FROM " . $Prefix . "CHANGENAME_PENDING WHERE CHNAME_ID = '" .$id."' ";
 $RCHNP = mysql_query($QCHNP, $connection) or die (mysql_error());

 if(mysql_num_rows($RCHNP) > 0){
 $rsCHNP=mysql_fetch_array($RCHNP);

 $ChNew_Name = $rsCHNP['NEW_NAME'];
 }

	if ($type == "accept") {

     $query1 = "UPDATE " . $Prefix . "CHANGENAME_PENDING SET ";
     $query1 .= "CH_DONE = '1', ";
     $query1 .= "UNDERDEMANDE = '0', ";
     $query1 .= "CH_DATE = '$date' ";
     $query1 .= "WHERE CHNAME_ID = '$ChangeName_ID' ";

     mysql_query($query1, $connection) or die (mysql_error());

     $query2 = "UPDATE " . $Prefix . "MEMBERS SET ";
     $query2 .= "M_NAME = '$ChNew_Name', ";
     $query2 .= "M_CHANGENAME = M_CHANGENAME +1 ";
     $query2 .= "WHERE MEMBER_ID = '$Chmember_ID' ";

     mysql_query($query2, $connection) or die (mysql_error());

	                echo'<center>
	                <table width="99%" border="1">
	                   <tr class="normal">
	                       <td class="list_center" colSpan="10"><font size="5"><br>�� ����� ��� ����� �����..</font><br><br>
                           <meta http-equiv="Refresh" content="1; URL='.$HTTP_REFERER.'">
                           <a href="index.php?mode=index">'.$lang['all']['click_here_to_go_home'].'</a><br><br>
                           <a href="'.$HTTP_REFERER.'">'.$lang['all']['click_here_to_go_normal_page'].'</a><br><br>
	                       </td>
	                   </tr>
	                </table>
	                </center>';

	}

	if ($type == "refuse") {

     $query4 = "DELETE FROM " . $Prefix . "CHANGENAME_PENDING WHERE CHNAME_ID = '$ChangeName_ID' ";
     mysql_query($query4, $connection) or die (mysql_error());

	                echo'<center>
	                <table width="99%" border="1">
	                   <tr class="normal">
	                       <td class="list_center" colSpan="10"><font size="5"><br>�� ��� ����� � ���� �� ����� ��������</font><br><br>
                           <meta http-equiv="Refresh" content="1; URL='.$HTTP_REFERER.'">
                           <a href="index.php?mode=index">'.$lang['all']['click_here_to_go_home'].'</a><br><br>
                           <a href="'.$HTTP_REFERER.'">'.$lang['all']['click_here_to_go_normal_page'].'</a><br><br>
	                       </td>
	                   </tr>
	                </table>
	                </center>';

	}

}

}

mysql_close();

?>