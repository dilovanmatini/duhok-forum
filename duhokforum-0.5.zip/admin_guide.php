<?
/*//////////////////////////////////////////////////////////
// ######################################################///
// # DuhokForum 0.5                                     # //
// ###################################################### //
// #                                                    # //
// #       --  DUHOK FORUM IS FREE SOFTWARE  --         # //
// #                                                    # //
// #   ========= Programming By Dilovan ==============  # //
// # Copyright � 2007-2008 Dilovan. All Rights Reserved # //
// #----------------------------------------------------# //
// #----------------------------------------------------# //
// # If you want any support vist down address:-        # //
// # Email: df@duhoktimes.com                           # //
// # Site: http://df.duhoktimes.com/index.php           # //
// ###################################################### //
//////////////////////////////////////////////////////////*/

if ($Mlevel == 4) {

echo'
<center>
<table cellSpacing="1" cellPadding="3" width="70%" border="0">
	<tr>
		<td class="optionsbar_menus" Align="middle" vAlign="center" width="100%"><font size="4" color="red">������ ���������</font></td>';
		go_to_forum();
echo'	</tr>
</table>
<table cellSpacing="1" cellPadding="3" width="70%" bgColor="gray" border="0">
	<tr class="normal">
		<td width="50%"><br>
		<font color="black">- ����� ����� ����� ������� : </font><a class="menu" href="index.php?mode=adminch">('.changename_count (1).')</a>
		<br>&nbsp;</td>
		<td width="50%">
		<font color="red" size="-1"><br>&nbsp;</font>
		</td>
	</tr>
</table>
</center>';

}

?>