<?
/*//////////////////////////////////////////////////////////
// ######################################################///
// # DuhokForum 0.5                                     # //
// ###################################################### //
// #                                                    # //
// #       --  DUHOK FORUM IS FREE SOFTWARE  --         # //
// #                                                    # //
// #   ========= Programming By Dilovan ==============  # //
// # Copyright � 2007-2008 Dilovan. All Rights Reserved # //
// #----------------------------------------------------# //
// #----------------------------------------------------# //
// # If you want any support vist down address:-        # //
// # Email: df@duhoktimes.com                           # //
// # Site: http://df.duhoktimes.com/index.php           # //
// ###################################################### //
//////////////////////////////////////////////////////////*/

include("check.php");

?>
<html dir="rtl">
<head>
<title></title>
<meta http-equiv="Content-Type" content="text/html; charset=windows-1256">
<meta content="DUHOK FORUM 1.0: Copyright (C) 2007-2008 Dilovan." name="copyright">
<link href="<? print $admin_folder; ?>/cp_styles/cp_style_green.css" type="text/css" rel="stylesheet">
</head>
<body leftMargin="0" topMargin="0" marginheight="0" marginwidth="0">
<table class="header" cellspacing="3" cellpadding="0" height="100%" width="100%" border="0">
  <tr>
    <td class="list" width="100%">���� ������ ������ - <? print $forum_title; ?></td>
    <td class="optionsbar_menus"><nobr><a href="index.php" target="_blank">������ ��������</a></nobr></td>
    <td class="optionsbar_menus"><nobr><a onclick="return confirm('�� ��� ����� �� ��� ���� ����� ������ �');" target="_top" href="login.php?method=logout">����� ������</a></nobr></td>
  </tr>
</table>
</body>
</html>
