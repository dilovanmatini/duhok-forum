/*//////////////////////////////////////////////////////////
// ######################################################///
// # DuhokForum 0.5                                     # //
// ###################################################### //
// #                                                    # //
// #       --  DUHOK FORUM IS FREE SOFTWARE  --         # //
// #                                                    # //
// #   ========= Programming By Dilovan ==============  # //
// # Copyright � 2007-2008 Dilovan. All Rights Reserved # //
// #----------------------------------------------------# //
// #----------------------------------------------------# //
// # If you want any support vist down address:-        # //
// # Email: df@duhoktimes.com                           # //
// # Site: http://df.duhoktimes.com/index.php           # //
// ###################################################### //
//////////////////////////////////////////////////////////*/

function showTextCount() {

	if(obj1.displayMode != "HTML")
	{
	var c = updateTextCount(1);
	var notice = ed_cur_size + ": " + obj1.getContentBody().length;
	if (your_max_size > 0)	notice += "\r\n\r\n" + ed_max_size + ": " + your_max_size;
	if (obj1.getContentBody().length > your_max_size)	notice += "\r\n\r\n" + ed_too_big;
	confirm(notice);
	}
}

function updateTextCount(mode)
{
	var result = 0;

	if(obj1.displayMode == "HTML")
	{
		EditorForm.status.style.background = "#99ff99";
		EditorForm.status.style.color = "red";
		EditorForm.status.value = "H T M L";
	}
	else
	{
		var c = obj1.getContent(1);
		result = c;
		
		if ((mode == 0) && (hidecounter)) return(-1);
		
		if (c >= 0)
		{
			EditorForm.status.style.background = "#ffff99";
			EditorForm.status.style.color = "brown";
			EditorForm.status.value = ed_cur_size;
			hidecounter = true;
			return(c);

		}
		else if (your_max_size == 0)
		{
			EditorForm.status.style.background = "#ffff99";
			EditorForm.status.style.color = "brown";
			EditorForm.status.value = ed_cur_size + ": " + obj1.getContentBody().length;
		}
		else
		{
			if (obj1.getContentBody().length > your_max_size)
			{
				EditorForm.status.style.background = "red";
				EditorForm.status.style.color = "white";
			}
			else
			{
				EditorForm.status.style.background = "#ffff99";
				EditorForm.status.style.color = "brown";
			}

			EditorForm.status.value = obj1.getContentBody().length + " / " + your_max_size;
		}
	}
	
	var tmr = 600;
	
	if (result < 1000)	tmr = 1000;
	else if (result < 2000)	tmr = 2000;
	else if (result < 5000)	tmr = 3500;

	setTimeout('updateTextCount(0)',tmr);
	return(result);
}

function copy_right(){
  if (ed_copy_right != "") {
	alert(ed_copy_right);
	return;
  }
}



