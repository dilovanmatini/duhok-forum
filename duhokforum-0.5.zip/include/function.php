<?php
/*//////////////////////////////////////////////////////////
// ######################################################///
// # DuhokForum 0.5                                     # //
// ###################################################### //
// #                                                    # //
// #       --  DUHOK FORUM IS FREE SOFTWARE  --         # //
// #                                                    # //
// #   ========= Programming By Dilovan ==============  # //
// # Copyright � 2007-2008 Dilovan. All Rights Reserved # //
// #----------------------------------------------------# //
// #----------------------------------------------------# //
// # If you want any support vist down address:-        # //
// # Email: df@duhoktimes.com                           # //
// # Site: http://df.duhoktimes.com/index.php           # //
// ###################################################### //
//////////////////////////////////////////////////////////*/

function redirect(){
  echo'
  <script language="JavaScript" type="text/javascript">
    window.location="index.php";
  </script>
  ';
}

function head($link){
 header('Location: '.$link);
 exit();
}

function go_to($link){
echo'<script language="JavaScript" type="text/javascript">
window.location="'.$link.'";
</script>';
}

function icons($url, $title = "", $any = ""){
    $icon="<img border='0' src='".$url."' alt='".$title."' ".$any.">";
    return($icon);
}

function abs2($num){
 $number = "-".$num;
 return($number);
}

//#################### members mysql function ##########################
function members($name, $id){
	global $Prefix;
	$sql = mysql_query("SELECT * FROM ".$Prefix."MEMBERS WHERE MEMBER_ID = '$id' ") or die(mysql_error());
	if(mysql_num_rows($sql)>0){
		$rs = mysql_fetch_array($sql);
		$members = Array(
			$rs[M_NAME], $rs[M_STATUS], $rs[M_PASSWORD], $rs[M_EMAIL],
			$rs[M_COUNTRY], $rs[M_LEVEL], $rs[M_POSTS], $rs[M_DATE],
			$rs[M_LAST_HERE_DATE], $rs[M_LAST_POST_DATE], $rs[M_RECEIVE_EMAIL], $rs[M_LAST_IP],
			$rs[M_IP], $rs[M_OCCUPATION], $rs[M_SEX], $rs[M_AGE],
			$rs[M_BIO], $rs[M_SIG], $rs[M_MARSTATUS], $rs[M_CITY],
			$rs[M_STATE], $rs[M_PHOTO_URL], $rs[M_TITLE], $rs[M_LOGIN],
			$rs[M_PMHIDE], $rs[M_CHANGENAME_COUNT], $rs[M_BROWSE]
		);
	}
	if ($name == "NAME"){$nom = 0;}
	if ($name == "STATUS"){$nom = 1;}
	if ($name == "PASSWORD"){$nom = 2;}
	if ($name == "EMAIL"){$nom = 3;}
	if ($name == "COUNTRY"){$nom = 4;}
	if ($name == "LEVEL"){$nom = 5;}
	if ($name == "POSTS"){$nom = 6;}
	if ($name == "DATE"){$nom = 7;}
	if ($name == "LAST_HERE_DATE"){$nom = 8;}
	if ($name == "LAST_POST_DATE"){$nom = 9;}
	if ($name == "RECEIVE_EMAIL"){$nom = 10;}
	if ($name == "LAST_IP"){$nom = 11;}
	if ($name == "IP"){$nom = 12;}
	if ($name == "OCCUPATION"){$nom = 13;}
	if ($name == "SEX"){$nom = 14;}
	if ($name == "AGE"){$nom = 15;}
	if ($name == "BIO"){$nom = 16;}
	if ($name == "SIG"){$nom = 17;}
	if ($name == "MARSTATUS"){$nom = 18;}
	if ($name == "CITY"){$nom = 19;}
	if ($name == "STATE"){$nom = 20;}
	if ($name == "PHOTO_URL"){$nom = 21;}
	if ($name == "TITLE"){$nom = 22;}
	if ($name == "LOGIN"){$nom = 23;}
	if ($name == "PMHIDE"){$nom = 24;}
	if ($name == "CHANGENAME_COUNT"){$nom = 25;}
	if ($name == "BROWSE"){$nom = 26;}
	return($members[$nom]);
}
//#################### members mysql function ##########################

//#################### topics mysql function ##########################
function topics($name, $id){
	global $Prefix;
	$sql = mysql_query("SELECT * FROM ".$Prefix."TOPICS WHERE TOPIC_ID = '$id' ") or die(mysql_error());
	if(mysql_num_rows($sql)>0){
		$rs = mysql_fetch_array($sql);
		$topics = Array(
			$rs[CAT_ID], $rs[FORUM_ID], $rs[T_STATUS], $rs[T_SUBJECT],
			$rs[T_MESSAGE], $rs[T_REPLIES], $rs[T_COUNTS], $rs[T_AUTHOR],
			$rs[T_DATE], $rs[T_LAST_POST_AUTHOR], $rs[T_LAST_POST_DATE], $rs[T_ARCHIVE_FLAG],
			$rs[T_STICKY], $rs[T_HIDDEN], $rs[T_TOP], $rs[T_LINKFORUM],
			$rs[T_LASTEDIT_DATE], $rs[T_LASTEDIT_MAKE], $rs[T_LOCK_DATE], $rs[T_LOCK_MAKE],
			$rs[T_OPEN_DATE], $rs[T_OPEN_MAKE], $rs[T_ENUM], $rs[T_SURVEY]
		);
	}
	if ($name == "CAT_ID"){$nom = 0;}
	if ($name == "FORUM_ID"){$nom = 1;}
	if ($name == "STATUS"){$nom = 2;}
	if ($name == "SUBJECT"){$nom = 3;}
	if ($name == "MESSAGE"){$nom = 4;}
	if ($name == "REPLIES"){$nom = 5;}
	if ($name == "COUNTS"){$nom = 6;}
	if ($name == "AUTHOR"){$nom = 7;}
	if ($name == "DATE"){$nom = 8;}
	if ($name == "LAST_POST_AUTHOR"){$nom = 9;}
	if ($name == "LAST_POST_DATE"){$nom = 10;}
	if ($name == "ARCHIVE_FLAG"){$nom = 11;}
	if ($name == "STICKY"){$nom = 12;}
	if ($name == "HIDDEN"){$nom = 13;}
	if ($name == "TOP"){$nom = 14;}
	if ($name == "LINKFORUM"){$nom = 15;}
	if ($name == "LASTEDIT_DATE"){$nom = 16;}
	if ($name == "LASTEDIT_MAKE"){$nom = 17;}
	if ($name == "LOCK_DATE"){$nom = 18;}
	if ($name == "LOCK_MAKE"){$nom = 19;}
	if ($name == "OPEN_DATE"){$nom = 20;}
	if ($name == "OPEN_MAK"){$nom = 21;}
	if ($name == "ENUM"){$nom = 22;}
	if ($name == "SURVEY"){$nom = 23;}
	return($topics[$nom]);
}
//#################### topics mysql function ##########################

//#################### forums mysql function ##########################
function forums($name, $id){
	global $Prefix;
	$sql = mysql_query("SELECT * FROM ".$Prefix."FORUM WHERE FORUM_ID = '$id' ") or die(mysql_error());
	if(mysql_num_rows($sql)>0){
		$rs = mysql_fetch_array($sql);
		$forums = Array(
			$rs[CAT_ID], $rs[F_STATUS], $rs[F_SUBJECT], $rs[F_DESCRIPTION],
			$rs[F_TOPICS], $rs[F_REPLIES], $rs[F_LAST_POST_DATE], $rs[F_LAST_POST_AUTHOR],
			$rs[F_ORDER], $rs[F_LOGO], $rs[F_TOTAL_TOPICS], $rs[F_TOTAL_REPLIES],
			$rs[F_HIDE]
		);
	}
	if ($name == "CAT_ID"){$nom = 0;}
	if ($name == "STATUS"){$nom = 1;}
	if ($name == "SUBJECT"){$nom = 2;}
	if ($name == "DESCRIPTION"){$nom = 3;}
	if ($name == "TOPICS"){$nom = 4;}
	if ($name == "REPLIES"){$nom = 5;}
	if ($name == "LAST_POST_DATE"){$nom = 6;}
	if ($name == "LAST_POST_AUTHOR"){$nom = 7;}
	if ($name == "ORDER"){$nom = 8;}
	if ($name == "LOGO"){$nom = 9;}
	if ($name == "TOTAL_TOPICS"){$nom = 10;}
	if ($name == "TOTAL_REPLIES"){$nom = 11;}
	if ($name == "HIDE"){$nom = 12;}
	return($forums[$nom]);
}
//#################### forums mysql function ##########################

//#################### categories mysql function ##########################
function cat($name, $id){
	global $Prefix;
	$sql = mysql_query("SELECT * FROM ".$Prefix."CATEGORY WHERE CAT_ID = '$id' ") or die(mysql_error());
	if(mysql_num_rows($sql)>0){
		$rs = mysql_fetch_array($sql);
		$cat = Array(
			$rs[CAT_STATUS], $rs[CAT_NAME], $rs[CAT_ORDER], $rs[CAT_MONITOR]
		);
	}
	if ($name == "STATUS"){$nom = 0;}
	if ($name == "NAME"){$nom = 1;}
	if ($name == "ORDER"){$nom = 2;}
	if ($name == "MONITOR"){$nom = 3;}
	return($cat[$nom]);
}
//#################### categories mysql function ##########################

//#################### online mysql function ##########################
function online($name, $id){
	global $Prefix;
	$sql = mysql_query("SELECT * FROM ".$Prefix."ONLINE WHERE ONLINE_ID = '$id' ") or die(mysql_error());
	if(mysql_num_rows($sql)>0){
		$rs = mysql_fetch_array($sql);
		$online = Array(
			$rs[O_MEMBER_ID], $rs[O_FORUM_ID], $rs[O_MEMBER_LEVEL], $rs[O_MEMBER_BROWSE],
			$rs[O_IP], $rs[O_MODE], $rs[O_DATE], $rs[O_LAST_DATE]
		);
	}
	if ($name == "MEMBER_ID"){$nom = 0;}
	if ($name == "FORUM_ID"){$nom = 1;}
	if ($name == "MEMBER_LEVEL"){$nom = 2;}
	if ($name == "MEMBER_BROWSE"){$nom = 3;}
	if ($name == "IP"){$nom = 4;}
	if ($name == "MODE"){$nom = 5;}
	if ($name == "DATE"){$nom = 6;}
	if ($name == "LAST_DATE"){$nom = 7;}
	return($online[$nom]);
}
//#################### online mysql function ##########################

//#################### hide forum mysql function ##########################
function hide_forum($name, $id){
	global $Prefix;
	$sql = mysql_query("SELECT * FROM ".$Prefix."HIDE_FORUM WHERE HF_ID = '$id' ") or die(mysql_error());
	if(mysql_num_rows($sql)>0){
		$rs = mysql_fetch_array($sql);
		$hide_forum = Array(
			$rs[HF_MEMBER_ID], $rs[HF_FORUM_ID]
		);
	}
	if ($name == "MEMBER_ID"){$nom = 0;}
	if ($name == "FORUM_ID"){$nom = 1;}
	return($hide_forum[$nom]);
}
//#################### hide forum mysql function ##########################

//#################### prv topic mysql function ##########################
function prv_topic($name, $id){
	global $Prefix;
	$sql = mysql_query("SELECT * FROM ".$Prefix."PRIVATE_TOPICS WHERE P_MEMBERID = '$id' ") or die(mysql_error());
	if(mysql_num_rows($sql)>0){
		$rs = mysql_fetch_array($sql);
		$prv_topic = Array(
			$rs[PTOPIC_ID], $rs[P_MEMBERID], $rs[P_CATID], $rs[P_FORUMID], $rs[P_TOPICID],
			$rs[P_MAKE], $rs[P_DATE]
		);
	}
	if ($name == "PTOPIC_ID"){$nom = 0;}
	if ($name == "P_MEMBERID"){$nom = 1;}
	if ($name == "P_CATID"){$nom = 2;}
	if ($name == "P_FORUMID"){$nom = 3;}
	if ($name == "P_TOPICID"){$nom = 4;}
	if ($name == "P_MAKE"){$nom = 5;}
	if ($name == "P_DATE"){$nom = 6;}
	return($prv_topic[$nom]);
}
//#################### prv topic mysql function ##########################

//#################### fav topic mysql function ##########################
function fav_topic($name, $id){
	global $Prefix;
	$sql = mysql_query("SELECT * FROM ".$Prefix."FAVOURITE_TOPICS WHERE F_TOPICID = '$id' AND F_MEMBERID = '$DBMemberID' ") or die(mysql_error());
	if(mysql_num_rows($sql)>0){
		$rs = mysql_fetch_array($sql);
		$prv_topic = Array(
			$rs[FAVT_ID], $rs[F_MEMBERID], $rs[F_CATID], $rs[F_FORUMID], $rs[F_TOPICID]
		);
	}
	if ($name == "PTOPIC_ID"){$nom = 0;}
	if ($name == "MEMBERID"){$nom = 1;}
	if ($name == "CATID"){$nom = 2;}
	if ($name == "FORUMID"){$nom = 3;}
	if ($name == "TOPICID"){$nom = 4;}
	return($fav_topic[$nom]);
}
//#################### fav topic mysql function ##########################

//#################### check allowed ##########################
function allowed($f, $n){ // note: if ($n = 1) the number is just monitor but if ($n = 2)  the number is monitor and moderator.
    global $Prefix, $DBMemberID, $Mlevel;

	$cat_id = forums("CAT_ID", $f);
	$monitor = cat("MONITOR", $cat_id);

    $sql = mysql_query("SELECT * FROM ".$Prefix."MODERATOR WHERE MEMBER_ID = '$DBMemberID' AND FORUM_ID = '$f' ") or die(mysql_error());
    $num = mysql_num_rows($sql);

	if ($Mlevel == 4){
		$allowed = 1;
	}
	if ($Mlevel == 3){
		if ($DBMemberID == $monitor){
			$allowed = 1;
		}
		else{
			$allowed = 0;
		}
	}
	if ($Mlevel == 2){
		if ($n == 2){
			if ($num > 0){
				$allowed = 1;
			}
			else{
				$allowed = 0;
			}
		}
		else{
			$allowed = 0;
		}
	}
	if ($Mlevel < 2){
		$allowed = 0;
	}

    return($allowed);
}
//#################### check allowed ##########################

function info_text($id,$txt,$title){
    $txt = str_replace("{n}","<br>",$txt);
    $tr = '<tr style="display: none;" id="'.$id.'">';
    $tr .=  '<td class="deleted" colspan="20">';
    $tr .=  '<fieldset style="width: 100%">';
    $tr .=    '<legend>&nbsp;<font color="black">������� ��� ����&nbsp;( <font color="#cc0033">'.$title.'</font> )</font></legend>';
    $tr .=      '<br><font style="FONT-WEIGHT: NORMAL;  FONT-SIZE: 12px; COLOR: black; FONT-FAMILY: tahoma,arial">'.$txt.'</font><br><br>';
    $tr .=  '</fieldset>';
    $tr .=  '</td>';
    $tr .='</tr>';
    return($tr);
}

function info_icon($id){
    global $icon_question,$function_more_info;
    $url = "&nbsp;&nbsp;<a href=\"javascript:show_info(".$id.");\">".icons($icon_question, $function_more_info)."</a>";
    return($url);
}

function text_size($text){
  //if ($text == "") {
  //  $text = 0;
  //}
    $size_text = '<script>';
    $size_text .= 'var size_text = "'.$text.'";';
    $size_text .= 'document.write(size_text.length);';
    $size_text .= '</script>';
    return($size_text);
}

function to_kb($nom){
$nom = ceil($nom / 1024);
    return($nom);
}

function normal_profile($m_name,$m_id){
    global $Prefix;
    $normal_profile="<a href=\"index.php?mode=profile&id=".$m_id."\">".$m_name."</a>";
    return($normal_profile);
}

function link_profile($m_name,$m_id){
    global $Prefix;
    $resultLP = mysql_query("SELECT * FROM ".$Prefix."MEMBERS WHERE MEMBER_ID='$m_id' ") or die(mysql_error());
    if(mysql_num_rows($resultLP)>0){
        $rsLP=mysql_fetch_array($resultLP);
        $LP_MemberID=$rsLP['MEMBER_ID'];
        $LP_MemberLevel=$rsLP['M_LEVEL'];
        $LP_MemberStatus=$rsLP['M_STATUS'];
    }
    if($LP_MemberLevel==1&&$LP_MemberStatus==1){
        $link_profile="<a href=\"index.php?mode=profile&id=".$m_id."\">".$m_name."</a>";
    }
    if($LP_MemberLevel==1&&$LP_MemberStatus==0){
        $link_profile="<a href=\"index.php?mode=profile&id=".$m_id."\"><font color=\"#999999\">".$m_name."</font></a>";
    }
    if($LP_MemberLevel==2){
        $link_profile="<a href=\"index.php?mode=profile&id=".$m_id."\"><font color=\"#cc0033\">".$m_name."</font></a>";
    }
    if($LP_MemberLevel==3){
        $link_profile="<a href=\"index.php?mode=profile&id=".$m_id."\"><font color=\"#cc8811\">".$m_name."</font></a>";
    }
    if($LP_MemberLevel==4){
        $link_profile="<a href=\"index.php?mode=profile&id=".$m_id."\"><font color=\"blue\">".$m_name."</font></a>";
    }
    return($link_profile);
}

function admin_profile($m_name,$m_id){
    global $Prefix;
    $resultLP2=mysql_query("SELECT * FROM ".$Prefix."MEMBERS WHERE MEMBER_ID='$m_id' ") or die(mysql_error());
    if(mysql_num_rows($resultLP2)>0){
        $rsLP2=mysql_fetch_array($resultLP2);
        $LP2_MemberID=$rsLP2['MEMBER_ID'];
        $LP2_MemberLevel=$rsLP2['M_LEVEL'];
        $LP2_MemberStatus=$rsLP2['M_STATUS'];
    }
    if($LP2_MemberLevel==4){
        $admin_profile="<a href=\"index.php?mode=profile&id=".$m_id."\">".$m_name."</a>";
    }
    if($LP2_MemberLevel<4){
        $admin_profile="<a href=\"index.php?mode=profile&id=".$m_id."\">".$m_name."</a>";
    }
    return($admin_profile);
}

function normal_time($date){
    global $function_to_day, $function_yester_day;
    $DateYear=date("Y/",$date);
    $NowYear=date("Y/");
    $NormalMonth=date("m/",$date);
    $DateDay=date("d",$date);
    $NowDay=date("d");
    $yesterday=time()-(60*1440);
    $NowDay2=date("d",$yesterday);
    $DateTime=date("H:i",$date);
    if($DateYear==$NowYear){
        $NormalYear="";
    }
    else{
        $NormalYear=$DateYear;
    }
    if($DateDay==$NowDay&&$DateYear==$NowYear){
        $normal_time=$DateTime." - ".$function_to_day;
    }
    elseif($DateDay==$NowDay2&&$DateYear==$NowYear){
        $normal_time=$DateTime." - ".$function_yester_day;
    }
    else{
        $normal_time=$DateTime." - ".$NormalYear.$NormalMonth.$DateDay;
    }
    return($normal_time);
}

function members_time($m_date){
    global $function_to_day, $function_yester_day;
    $DateYear=date("Y/",$m_date);
    $NowYear=date("Y/");
    $NormalMonth=date("m/",$m_date);
    $DateDay=date("d",$m_date);
    $NowDay=date("d");
    $yesterday=time()-(60*1440);
    $NowDay2=date("d",$yesterday);
    if($DateYear==$NowYear){
        $NormalYear="";
    }
    else{
        $NormalYear=$DateYear;
    }
    if($DateDay==$NowDay&&$DateYear==$NowYear){
        $normal_date=$function_to_day;
    }
    elseif($DateDay==$NowDay2&&$DateYear==$NowYear){
        $normal_date=$function_yester_day;
    }
    else{
        $normal_date=$NormalYear.$NormalMonth.$DateDay;
    }
    return($normal_date);
}

function normal_date($date){

 $date = date("Y/m/d", $date);

return($date);
}

function chk_moderator($m,$f){

    global $Prefix;

 if ($m > 0) {

    $sql = mysql_query("SELECT * FROM ".$Prefix."MEMBERS WHERE MEMBER_ID = '$m' ") or die(mysql_error());
    $m_num = mysql_num_rows($sql);
    $m_rows = mysql_fetch_array($sql);
    if ($m_num > 0) {
      if ($m_rows[M_LEVEL] > 1) {
        $m_level = 1;
      }
      else {
        $m_level = 0;
      }
    }
    else {
      $m_level = 0;
    }

    $resultChkMod=mysql_query("SELECT * FROM ".$Prefix."MODERATOR WHERE MEMBER_ID='$m' AND FORUM_ID='$f' ") or die(mysql_error());
    if(mysql_num_rows($resultChkMod)>0){
      if ($m_level == 1) {
        $chk_mod=1;
      }
    }
    else{
        $chk_mod=0;
    }
  }
    return($chk_mod);
}

function chk_monitor($m,$c){

    global $Prefix;

  if ($m > 0) {

    $sql = mysql_query("SELECT * FROM ".$Prefix."MEMBERS WHERE MEMBER_ID = '$m' ") or die(mysql_error());
    $m_num = mysql_num_rows($sql);
    $m_rows = mysql_fetch_array($sql);
    if ($m_num > 0) {
      if ($m_rows[M_LEVEL] > 1) {
        $m_level = 1;
      }
      else {
        $m_level = 0;
      }
    }
    else {
      $m_level = 0;
    }

    $resultChkMon = mysql_query("SELECT * FROM ".$Prefix."CATEGORY WHERE CAT_ID='$c' AND CAT_MONITOR='$m' ") or die(mysql_error());
    if(mysql_num_rows($resultChkMon)>0){
      if ($m_level == 1) {
        $chk_mon=1;
      }
    }
    else{
        $chk_mon=0;
    }
  }
    return($chk_mon);
}

function member_total_days($m_date){
    $m_date=time()-$m_date;
    $m_date=$m_date/84600;
    $m_date=ceil($m_date);
    return($m_date);
}

function member_middle_posts($m_posts, $m_date){
    $mtd=member_total_days($m_date);
    $mmp=$m_posts/$mtd;
    $mmp=ceil($mmp);
    return($mmp);
}

function codding($text1,$text2,$text3,$u_p){
    global $forum_version;
    $text='<center><table width="100%"><tr><td dir="ltr" align="middle"><nobr><font color="gray" size="-2">'.$text1.'<br><font color="black">'.$text2.'<br><font color="red">&nbsp;&nbsp;&copy; '.$text3.'</font></font></font></nobr></td><td width="100%">&nbsp;</td>'.base64_decode("PHRkIGRpcj0ibHRyIiBhbGlnbj0ibWlkZGxlIj48Zm9udCBjb2xvcj0iZ3JheSIgc2l6ZT0iLTIiPjxub2JyPg==").$u_p.base64_decode("PC9ub2JyPjwvZm9udD48YnI+PGZvbnQgc2l6ZT0iLTIiIGNvbG9yPSJibGFjayI+PG5vYnI+RHVob2sgRm9ydW0=").'&nbsp;'.$forum_version.base64_decode("PC9ub2JyPjwvZm9udD48YnI+PGZvbnQgc2l6ZT0iLTIiIGNvbG9yPSJyZWQiPjxub2JyPg==").'&copy; '.base64_decode("RGlsb3ZhbiAyMDA3IC0gMjAwODwvbm9icj48L2ZvbnQ+PC90ZD48L3RyPjwvdGFibGU+PC9jZW50ZXI+");
    return($text);
}

function open_mysql($variable){

 global $Prefix;

 $sql = mysql_query("SELECT * FROM ".$Prefix."CONFIG WHERE VARIABLE = '".$variable."' ") or die (mysql_error());
 if(mysql_num_rows($sql) > 0){
 $rs = mysql_fetch_array($sql);

 $value = $rs['VALUE'];
 }
return($value);
}

function updata_mysql($variable, $value){

 global $Prefix;

 $sql = mysql_query("UPDATE ".$Prefix."CONFIG SET VALUE = '".$value."' WHERE VARIABLE = '".$variable."' ") or die (mysql_error());

}

function insert_mysql($variable, $value){

 global $Prefix;

 $sql = mysql_query("INSERT INTO ".$Prefix."CONFIG (ID, VARIABLE, VALUE) VALUES (NULL, '".$variable."', '".$value."') ") or die (mysql_error());

}

function check_radio($value1, $value2){

 if ($value1 == $value2) {
    $value = 'CHECKED';
 }
 else {
    $value = '';
 }
return($value);
}

function check_select($value1, $value2){

 if ($value1 == $value2) {
    $value = 'selected';
 }
 else {
    $value = '';
 }
return($value);
}

function member_name($id){

 global $Prefix;

 $sql = mysql_query("SELECT * FROM ".$Prefix."MEMBERS WHERE MEMBER_ID = '".$id."' ") or die (mysql_error());
 if(mysql_num_rows($sql) > 0){
 $rs = mysql_fetch_array($sql);

 $MemberName = $rs['M_NAME'];
 }
return($MemberName);
}

function forum_name($id){

 global $Prefix;

 $sql = mysql_query("SELECT * FROM ".$Prefix."FORUM WHERE FORUM_ID = '".$id."' ") or die (mysql_error());
 if(mysql_num_rows($sql) > 0){
 $rs = mysql_fetch_array($sql);

 $Forum_Subject = $rs['F_SUBJECT'];
 }
return($Forum_Subject);
}

function cat_id($f_id){

 global $Prefix;

 $sql = mysql_query("SELECT * FROM ".$Prefix."FORUM WHERE FORUM_ID = '".$f_id."' ") or die (mysql_error());
 if(mysql_num_rows($sql) > 0){
 $rs = mysql_fetch_array($sql);

 $Cat_ID = $rs['CAT_ID'];
 }
return($Cat_ID);
}

function forum_title_count($id){

  global $Prefix;
  $Forum_Title_Count = mysql_query("SELECT count(*) FROM ".$Prefix."F_TITLES WHERE T_FORUMID = '".$id."' ") or die(mysql_error());
  $Count = mysql_result($Forum_Title_Count, 0, "count(*)");

  return($Count);
}

function member_title_count($id){

  global $Prefix;
  $Member_Title_Count = mysql_query("SELECT count(*) FROM ".$Prefix."TITLES WHERE T_MEMBERID = '".$id."' ") or die(mysql_error());
  $Count = mysql_result($Member_Title_Count, 0, "count(*)");

  return($Count);
}

function reply_member_title($m_id, $f_id){

  global $Prefix;

$R_Titles = mysql_query("SELECT * FROM ".$Prefix."TITLES WHERE T_MEMBERID = '$m_id' AND T_STATUS = '0' AND T_FORUMID = '$f_id' ORDER BY TITLE_ID ASC ") or die (mysql_error());
$RTitles_rows = mysql_num_rows($R_Titles);


 while ($R_Trow = @mysql_fetch_array($R_Titles)) {

    $RTitles_TitleID = $R_Trow[TITLE_ID];
    $RTitles_MemberID = $R_Trow[T_MEMBERID];
    $RTitles_ForumID = $R_Trow[T_FORUMID];
    $RTitles_Status = $R_Trow[T_STATUS];
    $RTitles_Color = $R_Trow[T_COLOR];
    $RTitles_Subject = $R_Trow[T_SUBJECT];

   if ($RTitles_rows == 1) {
       $RMember_Titles = '<font color="'.$RTitles_Color.'">'.$RTitles_Subject.'</font>';
   }
   if ($RTitles_rows > 1) {
       $RMember_Titles = $RMember_Titles;
       if ($RMember_Titles != "") {
       $RMember_Titles .= '<br>';
       }
       $RMember_Titles .= '<font color="'.$RTitles_Color.'">'.$RTitles_Subject.'</font>';
   }


 }

$RR_Titles = mysql_query("SELECT * FROM ".$Prefix."TITLES WHERE T_MEMBERID = '$m_id' AND T_STATUS = '1' ORDER BY TITLE_ID ASC ") or die (mysql_error());
$RRTitles_rows = mysql_num_rows($RR_Titles);

 while ($RR_Trow = @mysql_fetch_array($RR_Titles)) {

    $RRTitles_TitleID = $RR_Trow[TITLE_ID];
    $RRTitles_MemberID = $RR_Trow[T_MEMBERID];
    $RRTitles_ForumID = $RR_Trow[T_FORUMID];
    $RRTitles_Status = $RR_Trow[T_STATUS];
    $RRTitles_Color = $RR_Trow[T_COLOR];
    $RRTitles_Subject = $RR_Trow[T_SUBJECT];

   if ($RRTitles_rows == 1) {
       $RRMember_Titles = '<font color="'.$RRTitles_Color.'">'.$RRTitles_Subject.'</font>';
   }
   if ($RRTitles_rows > 1) {
       $RRMember_Titles = $RRMember_Titles;
       if ($RRMember_Titles != "") {
       $RRMember_Titles .= '<br>';
       }
       $RRMember_Titles .= '<font color="'.$RRTitles_Color.'">'.$RRTitles_Subject.'</font>';
   }

 }


$R_MemberTitles = $RMember_Titles;
if ($RMember_Titles != "" AND $RRMember_Titles != "") {
$R_MemberTitles .= '<br>';
}
$R_MemberTitles .= $RRMember_Titles;

  return($R_MemberTitles);
}

function profile_member_title($m_id){

  global $Prefix;

$titles = mysql_query("SELECT * FROM ".$Prefix."TITLES WHERE T_MEMBERID = '$m_id' ORDER BY TITLE_ID ASC ") or die (mysql_error());
$rows = mysql_num_rows($titles);


 while ($row = @mysql_fetch_array($titles)) {

   if ($rows == 1) {
       $tmt = $row[T_SUBJECT].' - <font color="red">'.forum_name($row[T_FORUMID]).'</font>';
   }
   if ($rows > 1) {
       $tmt = $tmt;
       if ($tmt != "") {
       $tmt .= '<br>';
       }
       $tmt .= $row[T_SUBJECT].' - <font color="red">'.forum_name($row[T_FORUMID]).'</font>';
   }


 }

  return($tmt);
}


function profile_moderator_title($m_id){

  global $Prefix, $function_moderator_title;

$titles = mysql_query("SELECT * FROM ".$Prefix."TITLES WHERE T_MEMBERID = '$m_id' ORDER BY TITLE_ID ASC ") or die (mysql_error());
$rows = mysql_num_rows($titles);


 while ($row = @mysql_fetch_array($titles)) {

   if ($rows == 1) {
       $tmt = $row[T_SUBJECT].' - <font color="red">'.forum_name($row[T_FORUMID]).'</font>';
   }
   if ($rows > 1) {
       $tmt = $tmt;
       if ($tmt != "") {
       $tmt .= '<br>';
       }
       $tmt .= $row[T_SUBJECT].' - <font color="red">'.forum_name($row[T_FORUMID]).'</font>';
   }


 }


$mod = mysql_query("SELECT * FROM ".$Prefix."MODERATOR WHERE MEMBER_ID = '$m_id' ORDER BY MOD_ID ASC ") or die (mysql_error());
$m_rows = mysql_num_rows($mod);


 while ($m_row = @mysql_fetch_array($mod)) {

   if ($m_rows == 1) {
       $tmf = '<a href="index.php?mode=f&f='.$m_row[FORUM_ID].'">'.forum_name($m_row[FORUM_ID]).'</a>';
   }
   if ($m_rows > 1) {
       $tmf = $tmf;
       if ($tmf != "") {
       $tmf .= '<font color="red"> + </font>';
       }
       $tmf .= '<a href="index.php?mode=f&f='.$m_row[FORUM_ID].'">'.forum_name($m_row[FORUM_ID]).'</a>';
   }
 }

$tmt = '<font color="red">'.$function_moderator_title.' </font>'.$tmf.'<br>'.member_title($m_id).'<br>'.$tmt;

  return($tmt);
}

function profile_monitor_title($m_id){

  global $Prefix, $function_monitor_title;

$titles = mysql_query("SELECT * FROM ".$Prefix."TITLES WHERE T_MEMBERID = '$m_id' ORDER BY TITLE_ID ASC ") or die (mysql_error());
$rows = mysql_num_rows($titles);


 while ($row = @mysql_fetch_array($titles)) {

   if ($rows == 1) {
       $tmt = $row[T_SUBJECT].' - <font color="red">'.forum_name($row[T_FORUMID]).'</font>';
   }
   if ($rows > 1) {
       $tmt = $tmt;
       if ($tmt != "") {
       $tmt .= '<br>';
       }
       $tmt .= $row[T_SUBJECT].' - <font color="red">'.forum_name($row[T_FORUMID]).'</font>';
   }


 }


$mon = mysql_query("SELECT * FROM ".$Prefix."CATEGORY WHERE CAT_MONITOR = '$m_id' ORDER BY CAT_ID ASC ") or die (mysql_error());
$m_rows = mysql_num_rows($mon);


 while ($m_row = @mysql_fetch_array($mon)) {

   if ($m_rows == 1) {
       $tmf = $m_row[CAT_NAME];
   }
   if ($m_rows > 1) {
       $tmf = $tmf;
       if ($tmf != "") {
       $tmf .= '<font color="red"> + </font>';
       }
       $tmf .= $m_row[CAT_NAME];
   }
 }

$tmt = '<font color="red">'.$function_monitor_title.' </font>'.$tmf.'<br>'.member_title($m_id).'<br>'.$tmt;

  return($tmt);
}


function title_color($color){

global $function_default, $function_blue, $function_black, $function_red, $function_yellow, $function_pink, $function_green, $function_orange, $function_purple, $function_brown, $function_navy;

 if ($color == "") {
   $color = $function_default;
 }
 if ($color == "blue") {
   $color = '<font color="'.$color.'">'.$function_blue.'</font>';
 }
 if ($color == "black") {
   $color = '<font color="'.$color.'">'.$function_black.'</font>';
 }
 if ($color == "red") {
   $color = '<font color="'.$color.'">'.$function_red.'</font>';
 }
 if ($color == "yellow") {
   $color = '<font color="'.$color.'">'.$function_yellow.'</font>';
 }
 if ($color == "pink") {
   $color = '<font color="'.$color.'">'.$function_pink.'</font>';
 }
 if ($color == "green") {
   $color = '<font color="'.$color.'">'.$function_green.'</font>';
 }
 if ($color == "orange") {
   $color = '<font color="'.$color.'">'.$function_orange.'</font>';
 }
 if ($color == "purple") {
   $color = '<font color="'.$color.'">'.$function_purple.'</font>';
 }
 if ($color == "brown") {
   $color = '<font color="'.$color.'">'.$function_brown.'</font>';
 }
 if ($color == "navy") {
   $color = '<font color="'.$color.'">'.$function_navy.'</font>';
 }
 return($color);
}

function text_replace($message){

//$message = htmlspecialchars($message);

//$message=str_replace("\n","<br>",$message);
$message=str_replace("[]","",$message);

return ($message);

}

function member_stars($m_id){

    global $Prefix,$StarsNomber,$StarsColor,$Stars;

    $MStars=mysql_query("SELECT * FROM ".$Prefix."MEMBERS WHERE MEMBER_ID='$m_id' ") or die(mysql_error());

    if(mysql_num_rows($MStars)>0){
        $rs_S=mysql_fetch_array($MStars);
        $S_MemberID=$rs_S['MEMBER_ID'];
        $S_MemberLevel=$rs_S['M_LEVEL'];
        $S_MemberStatus=$rs_S['M_STATUS'];
        $S_MemberPosts=$rs_S['M_POSTS'];
    }
if($S_MemberLevel==1){$star_color=$Stars[$StarsColor[1]];
}
if($S_MemberLevel==2){$star_color=$Stars[$StarsColor[2]];
}
if($S_MemberLevel==3){$star_color=$Stars[$StarsColor[3]];
}
if($S_MemberLevel==4){$star_color=$Stars[$StarsColor[4]];
}
if($S_MemberPosts<$StarsNomber[1]){$M_Stars="";
}
if($S_MemberPosts>=$StarsNomber[1]&&$S_MemberPosts<$StarsNomber[2]){$M_Stars=icons($star_color,"","");
}
if($S_MemberPosts>=$StarsNomber[2]&&$S_MemberPosts<$StarsNomber[3]){$M_Stars=icons($star_color,"","").icons($star_color,"","");
}
if($S_MemberPosts>=$StarsNomber[3]&&$S_MemberPosts<$StarsNomber[4]){$M_Stars=icons($star_color,"","").icons($star_color,"","").icons($star_color,"","");
}
if($S_MemberPosts>=$StarsNomber[4]&&$S_MemberPosts<$StarsNomber[5]){$M_Stars=icons($star_color,"","").icons($star_color,"","").icons($star_color,"","").icons($star_color,"","");
}
if($S_MemberPosts>=$StarsNomber[5]&&$S_MemberPosts<$StarsNomber[6]){$M_Stars=icons($star_color,"","").icons($star_color,"","").icons($star_color,"","").icons($star_color,"","").icons($star_color,"","");
}
if($S_MemberPosts>=$StarsNomber[6]&&$S_MemberPosts<$StarsNomber[7]){$M_Stars=icons($star_color,"","").icons($star_color,"","").icons($star_color,"","").icons($star_color,"","").icons($star_color,"","").'<br>'.icons($star_color,"","");
}
if($S_MemberPosts>=$StarsNomber[7]&&$S_MemberPosts<$StarsNomber[8]){$M_Stars=icons($star_color,"","").icons($star_color,"","").icons($star_color,"","").icons($star_color,"","").icons($star_color,"","").'<br>'.icons($star_color,"","").icons($star_color,"","");
}
if($S_MemberPosts>=$StarsNomber[8]&&$S_MemberPosts<$StarsNomber[9]){$M_Stars=icons($star_color,"","").icons($star_color,"","").icons($star_color,"","").icons($star_color,"","").icons($star_color,"","").'<br>'.icons($star_color,"","").icons($star_color,"","").icons($star_color,"","");
}
if($S_MemberPosts>=$StarsNomber[9]&&$S_MemberPosts<$StarsNomber[10]){$M_Stars=icons($star_color,"","").icons($star_color,"","").icons($star_color,"","").icons($star_color,"","").icons($star_color,"","").'<br>'.icons($star_color,"","").icons($star_color,"","").icons($star_color,"","").icons($star_color,"","");
}
if($S_MemberPosts>=$StarsNomber[10]){$M_Stars=icons($star_color,"","").icons($star_color,"","").icons($star_color,"","").icons($star_color,"","").icons($star_color,"","").'<br>'.icons($star_color,"","").icons($star_color,"","").icons($star_color,"","").icons($star_color,"","").icons($star_color,"","");
}
return($M_Stars);
}

function member_title($m_id){

  global $Prefix, $Title, $StarsNomber;

  $Titles=mysql_query("SELECT * FROM ".$Prefix."MEMBERS WHERE MEMBER_ID='$m_id' ") or die(mysql_error());
  if(mysql_num_rows($Titles)>0){
  $rs_T=mysql_fetch_array($Titles);
  $T_MemberID=$rs_T['MEMBER_ID'];
  $T_MemberLevel=$rs_T['M_LEVEL'];
  $T_MemberStatus=$rs_T['M_STATUS'];
  $T_MemberPosts=$rs_T['M_POSTS'];
  $T_MemberTitle=$rs_T['M_TITLE'];
  }
  if($T_MemberTitle==""){
    if($T_MemberPosts<$StarsNomber[1]){
		$m_title=$Title[0];
    }
    if($T_MemberPosts>=$StarsNomber[1]&&$T_MemberPosts<$StarsNomber[2]){
		$m_title=$Title[1];
    }
    if($T_MemberPosts>=$StarsNomber[2]&&$T_MemberPosts<$StarsNomber[3]){
		$m_title=$Title[2];
    }
    if($T_MemberPosts>=$StarsNomber[3]&&$T_MemberPosts<$StarsNomber[4]){
		$m_title=$Title[3];
    }
    if($T_MemberPosts>=$StarsNomber[4]&&$T_MemberPosts<$StarsNomber[5]){
		$m_title=$Title[4];
    }
    if($T_MemberPosts>=$StarsNomber[5]&&$T_MemberPosts<$StarsNomber[6]){
        $m_title=$Title[5];
	}
    if($T_MemberPosts>=$StarsNomber[6]&&$T_MemberPosts<$StarsNomber[7]){
        $m_title=$Title[6];
    }
    if($T_MemberPosts>=$StarsNomber[7]&&$T_MemberPosts<$StarsNomber[8]){
        $m_title=$Title[7];
	}
    if($T_MemberPosts>=$StarsNomber[8]&&$T_MemberPosts<$StarsNomber[9]){
        $m_title=$Title[8];
	}
    if($T_MemberPosts>=$StarsNomber[9]&&$T_MemberPosts<$StarsNomber[10]){
        $m_title=$Title[9];
	}
    if($T_MemberPosts>=$StarsNomber[10]){
        $m_title=$Title[10];
	}
    if($T_MemberLevel==1){
		$title=$m_title;
    }
    if($T_MemberLevel==2){
        $title=$Title[11];
    }
    if($T_MemberLevel==3){
        $title=$Title[12];
    }
    if($T_MemberLevel==4){
        $title=$Title[13];
    }
}
else{
    $title=$T_MemberTitle;
}

$title=text_replace($title);

return($title);
}

//###################### ADDED BY MR TAZI #######################

function admin($m_name,$m_id,$Prefix)
	{$resultLP2=mysql_query("SELECT * FROM ".$Prefix."MEMBERS WHERE MEMBER_ID='$m_id' ") or die(mysql_error());
	if(mysql_num_rows($resultLP2)>0)
	{$rsLP2=mysql_fetch_array($resultLP2);
		$LP2_MemberID=$rsLP2['MEMBER_ID'];
		$LP2_MemberLevel=$rsLP2['M_LEVEL'];
		$LP2_MemberStatus=$rsLP2['M_STATUS'];
		}
	if($LP2_MemberLevel==4)
	{$admin="<a href=\"index.php?mode=profile&id=".$m_id."\"><font color='#FFFFFF'>".$m_name."</font></a>";}
	if($LP2_MemberLevel<4)
	{$admin="<a href=\"index.php?mode=profile&id=".$m_id."\"><font color='#FFFFFF'>".$m_name."</font></a>";}
return($admin);}

function normal_time_last($date){
    $DateYear=date("Y/",$date);
    $NowYear=date("Y/");
    $NormalMonth=date("m/",$date);
    $DateDay=date("d",$date);
    $NowDay=date("d");
    $yesterday=time()-(60*1440);
    $NowDay2=date("d",$yesterday);
    $DateTime=date("H:i",$date);
    $normal_time=$DateTime." - ".$NormalYear.$NormalMonth.$DateDay;
    return($normal_time);
}

function forum_medal_count($id){

  global $Prefix;
  $Forum_Medal_Count = mysql_query("SELECT count(*) FROM ".$Prefix."F_MEDALS WHERE M_FORUMID = '".$id."' ") or die(mysql_error());
  $Count = mysql_result($Forum_Medal_Count, 0, "count(*)");

  return($Count);
}

function member_medal_count($id){

  global $Prefix;
  $Member_Medal_Count = mysql_query("SELECT count(*) FROM ".$Prefix."MEDALS WHERE M_MEMBERID = '".$id."' ") or die(mysql_error());
  $Count = mysql_result($Member_Medal_Count, 0, "count(*)");

  return($Count);
}

function cat_name($id){

 global $Prefix;

 $sql = mysql_query("SELECT * FROM ".$Prefix."CATEGORY WHERE CAT_ID = '".$id."' ") or die (mysql_error());
 if(mysql_num_rows($sql) > 0){
 $rs = mysql_fetch_array($sql);

 $Cat_Name = $rs['CAT_NAME'];
 }
return($Cat_Name);
}

function member_medals($m_medal_id){

  global $Prefix;

$M_Medals = mysql_query("SELECT * FROM ".$Prefix."MEDALS WHERE M_MEMBERID = '$m_medal_id' ORDER BY MEDAL_ID DESC ") or die (mysql_error());
$MMedals_rows = mysql_num_rows($M_Medals);

$Member_Medals = "<table width=\"99%\"><tr>";
 while ($M_Mrow = @mysql_fetch_array($M_Medals)) {
    $MMedals_MedalID = $M_Mrow[MEDAL_ID];
    $MMedals_ForumID = $M_Mrow[M_FORUMID];
    $MMedals_Subject = $M_Mrow[M_SUBJECT];
    $MMedals_Photo = $M_Mrow[M_URL];
    $MMedals_M_Date = $M_Mrow[M_DATE];

    $Member_Medals .= '<td align="center"><img src="'.$MMedals_Photo.'" alt="'.$MMedals_Subject.'" width="100"><br><font color="red" size="1">'.forum_name($MMedals_ForumID).'</font><br><font color="black" size="1">'.$MMedals_Subject.'</font><br><font size="1" color="orange">'.normal_date($MMedals_M_Date).'</font></td>';
	$chk_br = $chk_br + 1;
	if ($chk_br == 3){
		$Member_Medals .= "</tr><tr>";
		$chk_br = 0;
	}
 }
	$Member_Medals .= "</tr></table>";
  return($Member_Medals);
}

function normal_time_files($date){
    $DateYear=date("Y/",$date);
    $NormalMonth=date("m/",$date);
    $DateDay=date("d",$date);
    $DateTime=date("H:i:s",$date);
    $normal_time=$DateTime." - ".$DateYear.$NormalMonth.$DateDay;
    return($normal_time);
}

function forum_online_num($f){
	global $Prefix;
	$online_sql = mysql_query("SELECT * FROM ".$Prefix."ONLINE WHERE O_MEMBER_LEVEL = '1' AND O_FORUM_ID = '$f' OR O_MEMBER_LEVEL = '2' AND O_FORUM_ID = '$f'  ") or die (mysql_error());
	$forum_online = mysql_num_rows($online_sql);
    return($forum_online);
}

function forum_online_name($text){
	global $Prefix;
	$online = mysql_query("SELECT * FROM ".$Prefix."ONLINE ".$text." ") or die (mysql_error());
	$num = mysql_num_rows($online);
	$i = 0;
	while ($i < $num){
		$member_id = mysql_result($online, $i, "O_MEMBER_ID");
		$member_name = normal_profile(members("NAME", $member_id), $member_id);
			if ($i > 0){
				echo'&nbsp;<font color="red">+</font>&nbsp;';
			}
			echo $member_name;
			$check_br = $check_br + 1;
			if ($check_br == 5){
				echo'<br>';
				$check_br = 0;
			}
	++$i;
	}
}

function member_topics_today($id, $f){
	global $Prefix;
	$yesterday = time()-(60*60*24);
	$sql = mysql_query("SELECT * FROM ".$Prefix."TOPICS WHERE T_AUTHOR = '$id' AND FORUM_ID = '$f' AND T_DATE > '$yesterday'  ") or die(mysql_error());
	$topics = mysql_num_rows($sql);
	return($topics );
}

function member_replies_today($id, $f){
	global $Prefix;
	$yesterday = time()-(60*60*24);
	$sql = mysql_query("SELECT * FROM ".$Prefix."REPLY WHERE R_AUTHOR = '$id' AND FORUM_ID = '$f' AND R_DATE > '$yesterday'  ") or die(mysql_error());
	$topics = mysql_num_rows($sql);
	return($topics );
}

function member_is_online($id){
	global $Prefix;
	$online_sql = mysql_query("SELECT * FROM ".$Prefix."ONLINE WHERE O_MEMBER_ID = '$id' ") or die (mysql_error());
	if (mysql_num_rows($online_sql) > 0){
		$is_online = 1;
	}
	else{
		$is_online = 0;
	}
    return($is_online);
}

function check_forum_login($f){
	global $Prefix, $DBMemberID, $Mlevel;
	$c = forums("CAT_ID", $f);
	$chk_mon = chk_monitor($DBMemberID, $c);
	$chk_mod = chk_moderator($DBMemberID, $f);

	$sql = mysql_query("SELECT * FROM ".$Prefix."HIDE_FORUM WHERE HF_MEMBER_ID = '$DBMemberID' AND HF_FORUM_ID = '$f' ") or die (mysql_error());
	if (mysql_num_rows($sql) > 0){
		$login = 1;
	}
	else{
		if ($Mlevel == 4 OR $chk_mon == 1 OR $chk_mod == 1){
			$login = 1;
		}
		else{
			$login = 0;
		}
	}
    return($login);
}

function go_to_forum($num = 1){
global $lang, $Prefix;

?>
<script language="JavaScript" type="text/javascript">
	function goto_f(num){
		if (num == 1){
			var pg = goto_form1.goto_select.value;
		}
		if (num == 2){
			var pg = goto_form2.goto_select.value;
		}
		window.location = "index.php?mode=f&f="+pg;
	}
</script>
<?
	echo'
	<form name="goto_form'.$num.'" >
	<td class="optionsbar_menus">
	<b><nobr>'.$lang['go_to']['go_to_forum'].':</nobr></b>
	<select class="forumSelect" name="goto_select" size="1" onchange="goto_f('.$num.');">
		<option value="">&nbsp;'.$lang['go_to']['choose_forum'].'</option>';

	$cat = mysql_query("SELECT * FROM ".$Prefix."CATEGORY ORDER BY CAT_ORDER ASC ") or die (mysql_error());
	$c_num = mysql_num_rows($cat);
	$c_i = 0;
	while ($c_i < $c_num) {
		$cat_id = mysql_result($cat, $c_i, "CAT_ID");
		$cat_name = mysql_result($cat, $c_i, "CAT_NAME");
		echo'
		<option value="">----------------------------</option>';
		$forum = mysql_query("SELECT * FROM ".$Prefix."FORUM WHERE CAT_ID = '$cat_id' ORDER BY F_ORDER ASC ") or die (mysql_error());
		$f_num = mysql_num_rows($forum);
		$f_i = 0;
		while ($f_i < $f_num) {
			$forum_id = mysql_result($forum, $f_i, "FORUM_ID");
			$f_subject = mysql_result($forum, $f_i, "F_SUBJECT");
			$f_hide = forums("HIDE", $forum_id);
			$check_forum_login = check_forum_login($forum_id);

			if ($f_hide == 0 OR $f_hide == 1 AND $check_forum_login == 1){
				echo'<option value="'.$forum_id.'">'.$f_subject.'</option>';
			}

		++$f_i;
		}
	++$c_i;
	}
	echo'
	</select>
	</td>
	</form>';
}

function refresh_time(){
	global $refresh_time;
	echo'
	<script language="javascript" type="text/javascript">
		function auto_reload(){
			document.reload_frm.submit()
		}
	</script>
	<form name="reload_frm" method="post" action="'.$HTTP_SERVER_VARS[REQUEST_URI].'">
	<td class="optionsbar_menus"><nobr>����� ������:</nobr><br>
		<select style="WIDTH: 75px" name="refresh_time" onchange="auto_reload();">
			<option value=00 '.check_select($refresh_time, 00).'>�� �����</option>
			<option value="1" '.check_select($refresh_time, 1).'>�� �����</option>
			<option value="5" '.check_select($refresh_time, 5).'>�� 5 �����</option>
			<option value="10" '.check_select($refresh_time, 10).'>�� 10 �����</option>
			<option value="15" '.check_select($refresh_time, 15).'>�� 15 �����</option>
		</select>
	</td>
	</form>
	<script language="javascript" type="text/javascript">
		<!--
		var ref_time = document.reload_frm.refresh_time.options[document.reload_frm.refresh_time.selectedIndex].value
		if (ref_time > 0){
			reload_time = 60000 * ref_time
			self.setInterval(\'auto_reload()\', 60000 * ref_time)
		}
		//-->
	</script>';
}

function order_by(){
	global $order_by;
			echo'
			<form method="post" action="'.$HTTP_SERVER_VARS[REQUEST_URI].'">
			<td class="optionsbar_menus"><nobr>������� ������:</nobr><br>
				<select style="WIDTH: 70px" name="order_by" onchange="submit();">
					<option value="post" '.check_select($order_by, "post").'>��� ������</option>
					<option value="topic" '.check_select($order_by, "topic").'>�������</option>
				</select>
			</td>
			</form>';
}

function topic_paging($t){
	global $Prefix, $reply_num_page, $icon_unhidden;
	$sql = mysql_query("SELECT * FROM ".$Prefix."REPLY WHERE TOPIC_ID = '$t' ") or die(mysql_error());
	$num = mysql_num_rows($sql);
	$cols = ceil($num / $reply_num_page);
	if ($cols > 1){
		echo'
		<table border="0" cellpadding="0" cellspacing="3">
			<tr>
				<td valign="bottom">'.icons($icon_unhidden).'</td>';
			$i = 0;
			while($i < $cols){
				$topic_id = mysql_result($sql, $i, "TOPIC_ID");
				$count = 0;
				$counter += 1;
				echo'
				<td align="right" valign="bottom">
					<font size="1">
						<a href="index.php?mode=t&t='.$topic_id.'&pg='.$counter.'">'.$counter.'</a>
					</font>
				</td>';
				$page = $page + 1;
				if ($page == 17){
					echo'</tr><tr>';
					$page = 0;
				}
			++$i;
			}
			echo'
			</tr>
		</table>';
	}
}

function reply_num_page(){
	global $reply_num_page;
		echo'
		<form method="post" action="'.$HTTP_SERVER_VARS[REQUEST_URI].'">
		<td class="optionsbar_menus" vAlign="top"><nobr>��� ������:<br>
          <select class="forumSelect" style="WIDTH: 65px" name="reply_num_page" onchange="submit();">
            <option value="10" '.check_select($reply_num_page, "10").'>10 ����</option>
            <option value="30" '.check_select($reply_num_page, "30").'>30 ��</option>
			<option value="50" '.check_select($reply_num_page, "50").'>50 ��</option>
			<option value="70" '.check_select($reply_num_page, "70").'>70 ��</option>
          </select></nobr>
        </td></form>';
}

//----------------------------------------------- ADDED BY Mr TAZI ---------------------------------------------------

function forum_survey_count($id){

  global $Prefix;
  $Forum_Survey_Count = mysql_query("SELECT count(*) FROM ".$Prefix."SURVEY WHERE S_FORUMID = '".$id."' ") or die(mysql_error());
  $Count = mysql_result($Forum_Survey_Count, 0, "count(*)");

  return($Count);
}


function add_new_option($svid, $option, $other){

 global $Prefix;
 $sql = mysql_query("INSERT INTO ".$Prefix."SURVEY_OPTION (SO_ID, SO_SURVEYID, SO_OPTION, SO_OTHER) VALUES (NULL,'".$svid."', '".$option."', '".$other."') ") or die (mysql_error());

}

function update_option($svid, $option, $other){

 global $Prefix;
 $sql = mysql_query("UPDATE ".$Prefix."SURVEY_OPTION SET SO_OPTION = '".$option."', SO_OTHER = '".$other."' WHERE SO_ID = '".$svid."' ") or die (mysql_error());

}

function vote($sid, $oid, $fid, $tid, $mid, $date){

 global $Prefix;
 $sql = mysql_query("INSERT INTO ".$Prefix."VOTES (VOTE_ID, V_SURVEYID, V_OPTIONID, V_FORUMID, V_TOPICID, V_MEMBERID, V_DATE) VALUES (NULL,'".$sid."', '".$oid."', '".$fid."', '".$tid."', '".$mid."', '".$date."') ") or die (mysql_error());

}

function update_vote($oid, $sid, $mid, $date){

 global $Prefix;
 $sql = mysql_query("UPDATE ".$Prefix."VOTES SET V_OPTIONID = '$oid', V_DATE = '$date' WHERE V_SURVEYID = '$sid' AND V_MEMBERID = '$mid' ") or die (mysql_error());

}

function votes_count($oid){

  global $Prefix;
  $votes_Count = mysql_query("SELECT count(*) FROM ".$Prefix."VOTES WHERE V_OPTIONID = '$oid' ") or die(mysql_error());
  $Count = mysql_result($votes_Count, 0, "count(*)");

  return($Count);
}

function total_votes($sid){

  global $Prefix;
  $total_votes = mysql_query("SELECT count(*) FROM ".$Prefix."VOTES WHERE V_SURVEYID = '$sid' ") or die(mysql_error());
  $Count = mysql_result($total_votes, 0, "count(*)");

  return($Count);
}

function option_percentage($oid, $sid){
    $option = votes_count($oid) * 100;
    $option = $option / total_votes($sid);
    $option = ceil($option);
    return($option);
}

function pb_percentage($oid, $sid){
    $pb = 100 - option_percentage($oid, $sid);
    $pb = ceil($pb);
    return($pb);
}

?>
