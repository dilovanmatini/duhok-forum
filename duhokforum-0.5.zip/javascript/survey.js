/*//////////////////////////////////////////////////////////
// ######################################################///
// # DuhokForum 0.5                                     # //
// ###################################################### //
// #                                                    # //
// #       --  DUHOK FORUM IS FREE SOFTWARE  --         # //
// #                                                    # //
// #   ========= Programming By Dilovan ==============  # //
// # Copyright � 2007-2008 Dilovan. All Rights Reserved # //
// #----------------------------------------------------# //
// #----------------------------------------------------# //
// # If you want any support vist down address:-        # //
// # Email: df@duhoktimes.com                           # //
// # Site: http://df.duhoktimes.com/index.php           # //
// ###################################################### //
//////////////////////////////////////////////////////////*/

function submitForm()
{

if (surveyinfo.survey_subject.value.length == 0)
	{
	confirm(necessary_to_insert_survey_subject);
	return;
	}
if (surveyinfo.survey_question.value.length == 0)
	{
	confirm(necessary_to_insert_survey_question);
	return;
	}
if (surveyinfo.survey_days.value.length == 0)
	{
	confirm(necessary_to_insert_survey_days);
	return;
	}

surveyinfo.submit();
}
