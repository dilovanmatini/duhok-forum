<?
/*//////////////////////////////////////////////////////////
// ######################################################///
// # DuhokForum 0.5                                     # //
// ###################################################### //
// #                                                    # //
// #       --  DUHOK FORUM IS FREE SOFTWARE  --         # //
// #                                                    # //
// #   ========= Programming By Dilovan ==============  # //
// # Copyright � 2007-2008 Dilovan. All Rights Reserved # //
// #----------------------------------------------------# //
// #----------------------------------------------------# //
// # If you want any support vist down address:-        # //
// # Email: df@duhoktimes.com                           # //
// # Site: http://df.duhoktimes.com/index.php           # //
// ###################################################### //
//////////////////////////////////////////////////////////*/

?>

<script language="javascript">

var hidecounter = false;
var dir = ("<? echo $lang['global']['dir']; ?>");
var topic_max_size = ("<? echo $topic_max_size; ?>");
var reply_max_size = ("<? echo $reply_max_size; ?>");
var pm_max_size = ("<? echo $pm_max_size; ?>");
var sig_max_size = ("<? echo $sig_max_size; ?>");
var your_max_size = 512000;
var editor_method = ("<? echo $method; ?>");
var fileURL = ("<? echo $forum_url; ?>");
var image_folder = ("<? echo $image_folder; ?>");


if ((editor_method == 'topic') || (editor_method == 'edit')) {
  your_max_size = topic_max_size;
}
if ((editor_method == 'reply') || (editor_method == 'editreply')) {
  your_max_size = reply_max_size;
}

if ((editor_method == 'sendmsg') || (editor_method == 'replymsg')) {
  your_max_size = pm_max_size;
}

if (editor_method == 'sig') {
  your_max_size = sig_max_size;
}

//########### language variable ###################################

var necessary_to_insert_site_name = ("<? echo $lang['register']['necessary_to_insert_site_name']; ?>");
var necessary_to_insert_site_address = ("<? echo $lang['register']['necessary_to_insert_site_address']; ?>");
var necessary_to_insert_user_name = ("<? echo $lang['register']['necessary_to_insert_user_name']; ?>");
var necessary_to_insert_more_three_letter = ("<? echo $lang['register']['necessary_to_insert_more_three_letter']; ?>");
var necessary_to_insert_less_thirty_letter = ("<? echo $lang['register']['necessary_to_insert_less_thirty_letter']; ?>");
var not_allowed_to_use_this_symbol_one = ("<? echo $lang['register']['not_allowed_to_use_this_symbol_one']; ?>");
var not_allowed_to_use_this_symbol_two = ("<? echo $lang['register']['not_allowed_to_use_this_symbol_two']; ?>");
var not_allowed_to_use_this_symbol_three = ("<? echo $lang['register']['not_allowed_to_use_this_symbol_three']; ?>");
var not_allowed_to_use_this_symbol_four = ("<? echo $lang['register']['not_allowed_to_use_this_symbol_four']; ?>");
var not_allowed_to_use_this_symbol_five = ("<? echo $lang['register']['not_allowed_to_use_this_symbol_five']; ?>");
var not_allowed_to_use_this_symbol_six = ("<? echo $lang['register']['not_allowed_to_use_this_symbol_six']; ?>");
var not_allowed_to_use_this_symbol_seven = ("<? echo $lang['register']['not_allowed_to_use_this_symbol_seven']; ?>");
var not_allowed_to_use_just_numbers = ("<? echo $lang['register']['not_allowed_to_use_just_numbers']; ?>");
var necessary_to_insert_password = ("<? echo $lang['register']['necessary_to_insert_password']; ?>");
var necessary_to_insert_more_five_letter_to_password = ("<? echo $lang['register']['necessary_to_insert_more_five_letter_to_password']; ?>");
var necessary_to_insert_less_twenty_four_letter_to_password = ("<? echo $lang['register']['necessary_to_insert_less_twenty_four_letter_to_password']; ?>");
var necessary_to_insert_confirm_password = ("<? echo $lang['register']['necessary_to_insert_confirm_password']; ?>");
var necessary_to_insert_true_confirm_password = ("<? echo $lang['register']['necessary_to_insert_true_confirm_password']; ?>");
var necessary_to_password_reversal_to_user_name = ("<? echo $lang['register']['necessary_to_password_reversal_to_user_name']; ?>");
var necessary_to_insert_email = ("<? echo $lang['register']['necessary_to_insert_email']; ?>");
var necessary_to_insert_true_email = ("<? echo $lang['register']['necessary_to_insert_true_email']; ?>");
var necessary_to_password_reversal_to_email = ("<? echo $lang['register']['necessary_to_password_reversal_to_email']; ?>");
var necessary_to_insert_more_twelve_years = ("<? echo $lang['register']['necessary_to_insert_more_twelve_years']; ?>");
var necessary_to_insert_less_ninety_nine_years = ("<? echo $lang['register']['necessary_to_insert_less_ninety_nine_years']; ?>");

var necessary_to_insert_survey_subject = ("<? echo '��� �� ���� ����� ���������'; ?>");
var necessary_to_insert_survey_question = ("<? echo '��� �� ���� ���� ���������'; ?>");
var necessary_to_insert_survey_days = ("<? echo '��� �� ���� ��� ���� ���������'; ?>");

var ed_fontsel = ("<? echo $lang['editor']['ed_fontsel']; ?>");
var ed_fontsize = ("<? echo $lang['editor']['ed_fontsize']; ?>");
var ed_tip_style = ("<? echo $lang['editor']['ed_tip_style']; ?>");
var ed_tip_para = ("<? echo $lang['editor']['ed_tip_para']; ?>");
var ed_tip_text = ("<? echo $lang['editor']['ed_tip_text']; ?>");
var ed_tip_cut = ("<? echo $lang['editor']['ed_tip_cut']; ?>");
var ed_tip_copy = ("<? echo $lang['editor']['ed_tip_copy']; ?>");
var ed_tip_paste = ("<? echo $lang['editor']['ed_tip_paste']; ?>");
var ed_tip_undo = ("<? echo $lang['editor']['ed_tip_undo']; ?>");
var ed_tip_redo = ("<? echo $lang['editor']['ed_tip_redo']; ?>");
var ed_tip_bold = ("<? echo $lang['editor']['ed_tip_bold']; ?>");
var ed_tip_italic = ("<? echo $lang['editor']['ed_tip_italic']; ?>");
var ed_tip_underline = ("<? echo $lang['editor']['ed_tip_underline']; ?>");
var ed_tip_strike = ("<? echo $lang['editor']['ed_tip_strike']; ?>");
var ed_tip_superscr = ("<? echo $lang['editor']['ed_tip_superscr']; ?>");
var ed_tip_subscr = ("<? echo $lang['editor']['ed_tip_subscr']; ?>");
var ed_tip_symbol = ("<? echo $lang['editor']['ed_tip_symbol']; ?>");
var ed_tip_left = ("<? echo $lang['editor']['ed_tip_left']; ?>");
var ed_tip_center = ("<? echo $lang['editor']['ed_tip_center']; ?>");
var ed_tip_right = ("<? echo $lang['editor']['ed_tip_right']; ?>");
var ed_tip_full = ("<? echo $lang['editor']['ed_tip_full']; ?>");
var ed_tip_numlist = ("<? echo $lang['editor']['ed_tip_numlist']; ?>");
var ed_tip_list = ("<? echo $lang['editor']['ed_tip_list']; ?>");
var ed_tip_indent = ("<? echo $lang['editor']['ed_tip_indent']; ?>");
var ed_tip_outdent = ("<? echo $lang['editor']['ed_tip_outdent']; ?>");
var ed_tip_image = ("<? echo $lang['editor']['ed_tip_image']; ?>");
var ed_tip_color = ("<? echo $lang['editor']['ed_tip_color']; ?>");
var ed_tip_bgcolor = ("<? echo $lang['editor']['ed_tip_bgcolor']; ?>");
var ed_tip_link = ("<? echo $lang['editor']['ed_tip_link']; ?>");
var ed_tip_table = ("<? echo $lang['editor']['ed_tip_table']; ?>");
var ed_tip_absolute = ("<? echo $lang['editor']['ed_tip_absolute']; ?>");
var ed_tip_removeformat = ("<? echo $lang['editor']['ed_tip_removeformat']; ?>");
var ed_tip_asset = ("<? echo $lang['editor']['ed_tip_asset']; ?>");
var ed_tip_horzrule = ("<? echo $lang['editor']['ed_tip_horzrule']; ?>");
var ed_tip_clean = ("<? echo $lang['editor']['ed_tip_clean']; ?>");
var ed_tip_show_border = ("<? echo $lang['editor']['ed_tip_show_border']; ?>");
var ed_tip_select_all = ("<? echo $lang['editor']['ed_tip_select_all']; ?>");
var ed_tip_print = ("<? echo $lang['editor']['ed_tip_print']; ?>");
var ed_tip_zoom = ("<? echo $lang['editor']['ed_tip_zoom']; ?>");
var ed_tip_save = ("<? echo $lang['editor']['ed_tip_save']; ?>");
var ed_tip_page = ("<? echo $lang['editor']['ed_tip_page']; ?>");
var ed_tip_word = ("<? echo $lang['editor']['ed_tip_word']; ?>");

var ed_copy_right = "����� ��\n" +
                    "�� ���� ��� ������ �� ��� ���� ������\n" +
                    "��� �������� �����\n" +
                    "����� ���� ������ ��\n" +
                    "������ ����� ����� ��� ���� ����\n" +
                    "������ ����� ����� ��� ������ ������\n" +
                    "��� �� �����\n" +
                    "�� ����� �����\n" +
                    "DUHOKTIMES\n" +
                    "�� �������\n" +
                    "www.startimes2.com";

var ed_iconlib = ("<? echo $lang['editor']['ed_iconlib']; ?>");
var ed_color_title = ("<? echo $lang['editor']['ed_color_title']; ?>");
var ed_bgcolor_title = ("<? echo $lang['editor']['ed_bgcolor_title']; ?>");
var ed_button_select = ("<? echo $lang['editor']['ed_button_select']; ?>");
var ed_button_cancel = ("<? echo $lang['editor']['ed_button_cancel']; ?>");
var ed_link_border = ("<? echo $lang['editor']['ed_link_border']; ?>");
var ed_link_name = ("<? echo $lang['editor']['ed_link_name']; ?>");
var ed_link_apply = ("<? echo $lang['editor']['ed_link_apply']; ?>");
var ed_link_change = ("<? echo $lang['editor']['ed_link_change']; ?>");
var ed_link_title = ("<? echo $lang['editor']['ed_link_title']; ?>");
var ed_color_number = ("<? echo $lang['editor']['ed_color_number']; ?>");
var ed_confirm_reset = ("<? echo $lang['editor']['ed_confirm_reset']; ?>");
var ed_uncheck_html = ("<? echo $lang['editor']['ed_uncheck_html']; ?>");
var ed_need_title = ("<? echo $lang['editor']['ed_need_title']; ?>");
var ed_need_content = ("<? echo $lang['editor']['ed_need_content']; ?>");
var ed_confirm_submit = ("<? echo $lang['editor']['ed_confirm_submit']; ?>");
var ed_confirm_exit = ("<? echo $lang['editor']['ed_confirm_exit']; ?>");
var ed_too_big = ("<? echo $lang['editor']['ed_too_big']; ?>");
var ed_cur_size = ("<? echo $lang['editor']['ed_cur_size']; ?>");
var ed_max_size = ("<? echo $lang['editor']['ed_max_size']; ?>");

var fonts_name = new Array (
	"<? echo $lang['editor']['ed_font_besit']; ?>",
	"<? echo $lang['editor']['ed_font_arial']; ?>",
	"<? echo $lang['editor']['ed_font_ekhbar']; ?>",
	"<? echo $lang['editor']['ed_font_endels']; ?>",
	"<? echo $lang['editor']['ed_font_theqil']; ?>",
	"<? echo $lang['editor']['ed_font_nisikh']; ?>",
	"<? echo $lang['editor']['ed_font_dewany']; ?>",
	"<? echo $lang['editor']['ed_font_dewany_mozelel']; ?>",
	"<? echo $lang['editor']['ed_font_dewany_mokhetet']; ?>",
	"<? echo $lang['editor']['ed_font_kufi']; ?>",
	"<? echo $lang['editor']['ed_font_kufi_kebir']; ?>",
	"<? echo $lang['editor']['ed_font_modir']; ?>",
	"<? echo $lang['editor']['ed_font_antik']; ?>",
	"<? echo $lang['editor']['ed_font_sinaiy']; ?>",
	"<? echo $lang['editor']['ed_font_thlth']; ?>",
	"Arial",
	"Narrow",
	"Comic",
	"Courier",
	"Tahoma",
	"Times",
	"Verdana",
	"Wingdings"
);

var smiliesTitles = new Array (
	"<? echo $lang['editor']['icons']; ?>",
	"<? echo $lang['editor']['animals']; ?>",
	"<? echo $lang['editor']['faces_one']; ?>",
	"<? echo $lang['editor']['faces_two']; ?>",
	"<? echo $lang['editor']['faces_three']; ?>",
	"<? echo $lang['editor']['faces_four']; ?>",
	"<? echo $lang['editor']['faces_five']; ?>",
	"<? echo $lang['editor']['food']; ?>",
	"<? echo $lang['editor']['objects']; ?>",
	"<? echo $lang['editor']['people_one']; ?>",
	"<? echo $lang['editor']['people_two']; ?>",
	"<? echo $lang['editor']['sports']; ?>",
	"<? echo $lang['editor']['planets']; ?>"
	);

var smiliesPaths = new Array (
	"icon_smile",
	"smilies/animals/",
	"smilies/faces/",
	"smilies/faces/",
	"smilies/faces/",
	"smilies/faces/",
	"smilies/faces/",
	"smilies/food/",
	"smilies/objects/",
	"smilies/people/",
	"smilies/people/",
	"smilies/sports/",
	"smilies/planets/"
	);

var smiliesWidths = new Array (
	3,
	3,
	3,
	3,
	3,
	3,
	3,
	3,
	3,
	3,
	3,
	3,
	3
	);

var smiliesList = new Array (
	0,"",
	0,"_big.gif",
	0,"_cool.gif",
	0,"_blush.gif",
	0,"_tongue.gif",
	0,"_evil.gif",
	0,"_wink.gif",
	0,"_clown.gif",
	0,"_blackeye.gif",
	0,"_8ball.gif",
	0,"_sad.gif",
	0,"_shy.gif",
	0,"_shock.gif",
	0,"_angry.gif",
	0,"_dead.gif",
	0,"_kisses.gif",
	0,"_approve.gif",
	0,"_dissapprove.gif",
	0,"_sleepy.gif",
	0,"_question.gif",
	0,"_rotating.gif",
	0,"_eyebrows.gif",
	0,"_hearteyes.gif",
	0,"_crying.gif",
	0,"_waving.gif",
	0,"_waving2.gif",
	0,"_nono.gif",
	0,"_wailing.gif",
	0,"_joker.gif",

	1,"animals_bear[1].gif",
	1,"animals_cat[1].gif",
	1,"animals_cock[1].gif",
	1,"animals_dog[1].gif",
	1,"animals_fish[1].gif",
	1,"animals_fox[1].gif",
	1,"animals_frog[1].gif",
	1,"animals_giraffe[1].gif",
	1,"animals_gorilla[1].gif",
	1,"animals_hen[1].gif",
	1,"animals_hippo[1].gif",
	1,"animals_horse[1].gif",
	1,"animals_leopard[1].gif",
	1,"animals_monkey[1].gif",
	1,"animals_monster[1].gif",
	1,"animals_mouse[1].gif",
	1,"animals_penguin[1].gif",
	1,"animals_pig[1].gif",
	1,"animals_racoon[1].gif",
	1,"animals_serpent[1].gif",
	1,"animals_tiger[1].gif",
	1,"animals_turtle[1].gif",

	2,"faces_accident[1].gif",
	2,"faces_amazed[1].gif",
	2,"faces_angry[1].gif",
	2,"faces_anxious[1].gif",
	2,"faces_appetizing[1].gif",
	2,"faces_ashamed[1].gif",
	2,"faces_astonished[1].gif",
	2,"faces_balloon[1].gif",
	2,"faces_bandage[1].gif",
	2,"faces_bitter[1].gif",
	2,"faces_black_eye[1].gif",
	2,"faces_blind[1].gif",
	2,"faces_cautious[1].gif",
	2,"faces_chagrined[1].gif",
	2,"faces_cloudy[1].gif",
	2,"faces_confident[1].gif",
	2,"faces_confused[1].gif",
	2,"faces_congratulate[1].gif",
	2,"faces_cool[1].gif",
	2,"faces_cyclop[1].gif",
	2,"faces_dead[1].gif",
	2,"faces_deceived[1].gif",
	2,"faces_deep_trouble[1].gif",
	2,"faces_depressed[1].gif",
	2,"faces_disapointed[1].gif",
	2,"faces_disgusted[1].gif",
	2,"faces_dreaming[1].gif",

	3,"faces_dumb[1].gif",
	3,"faces_ecstatic[1].gif",
	3,"faces_embarassed[1].gif",
	3,"faces_encouraging[1].gif",
	3,"faces_enraged[1].gif",
	3,"faces_evolution[1].gif",
	3,"faces_exhausted[1].gif",
	3,"faces_eyes_shut[1].gif",
	3,"faces_fathers_day[1].gif",
	3,"faces_fight[1].gif",
	3,"faces_flirt[1].gif",
	3,"faces_forbidden[1].gif",
	3,"faces_freezing[1].gif",
	3,"faces_friendly[1].gif",
	3,"faces_frustrated[1].gif",
	3,"faces_glad[1].gif",
	3,"faces_greedy[1].gif",
	3,"faces_guilty[1].gif",
	3,"faces_happy[1].gif",
	3,"faces_happy_(f)[1].gif",
	3,"faces_hilarious[1].gif",
	3,"faces_hopeful[1].gif",
	3,"faces_hurt[1].gif",
	3,"faces_hysterical[1].gif",
	3,"faces_imaginative[1].gif",
	3,"faces_indifferent[1].gif",
	3,"faces_innocent[1].gif",

	4,"faces_jealous[1].gif",
	4,"faces_kiss[1].gif",
	4,"faces_laughing[1].gif",
	4,"faces_liar[1].gif",
	4,"faces_listen_to_music[1].gif",
	4,"faces_lonely[1].gif",
	4,"faces_lovestruck[1].gif",
	4,"faces_love_(F)[1].gif",
	4,"faces_love_(M)[1].gif",
	4,"faces_lucky[1].gif",
	4,"faces_mad[1].gif",
	4,"faces_male[1].gif",
	4,"faces_melting[1].gif",
	4,"faces_mischievous[1].gif",
	4,"faces_mocking[1].gif",
	4,"faces_mothers_day[1].gif",
	4,"faces_mute[1].gif",
	4,"faces_nasty[1].gif",
	4,"faces_near_sighted[1].gif",
	4,"faces_nice[1].gif",
	4,"faces_nocturnal[1].gif",
	4,"faces_obnoxious[1].gif",
	4,"faces_overwhelmed[1].gif",
	4,"faces_peace[1].gif",
	4,"faces_perplex[1].gif",
	4,"faces_playboy[1].gif",
	4,"faces_questioning[1].gif",

	5,"faces_rosey_cheek[1].gif",
	5,"faces_sad[1].gif",
	5,"faces_scar[1].gif",
	5,"faces_scared[1].gif",
	5,"faces_screaming[1].gif",
	5,"faces_septical[1].gif",
	5,"faces_sheming[1].gif",
	5,"faces_shocked[1].gif",
	5,"faces_shy[1].gif",
	5,"faces_siamese_twins[1].gif",
	5,"faces_sick[1].gif",
	5,"faces_singing[1].gif",
	5,"faces_sleep[1].gif",
	5,"faces_slobber[1].gif",
	5,"faces_smart[1].gif",
	5,"faces_smug[1].gif",
	5,"faces_sorry[1].gif",
	5,"faces_strained[1].gif",
	5,"faces_stressed[1].gif",
	5,"faces_suffering[1].gif",
	5,"faces_sunny[1].gif",
	5,"faces_surprised[1].gif",
	5,"faces_suspicious[1].gif",
	5,"faces_sympathising[1].gif",
	5,"faces_tearful[1].gif",
	5,"faces_thinking[1].gif",
	5,"faces_threatening[1].gif",

	6,"faces_tired[1].gif",
	6,"faces_together[1].gif",
	6,"faces_tongue_tied[1].gif",
	6,"faces_uncertain[1].gif",
	6,"faces_unconscious[1].gif",
	6,"faces_unhappy[1].gif",
	6,"faces_upset[1].gif",
	6,"faces_valentines_day[1].gif",
	6,"faces_very_ashamed[1].gif",
	6,"faces_very_sorry[1].gif",
	6,"faces_whimsical[1].gif",
	6,"faces_windy[1].gif",
	6,"faces_wry[1].gif",
	6,"faces_yawning[1].gif",
	6,"faces_yelling[1].gif",

	7,"food_apricot[1].gif",
	7,"food_biscuit[1].gif",
	7,"food_bread[1].gif",
	7,"food_cake[1].gif",
	7,"food_cheese[1].gif",
	7,"food_cherry[1].gif",
	7,"food_chicken[1].gif",
	7,"food_coconut[1].gif",
	7,"food_fried_egg[1].gif",
	7,"food_grapefruit[1].gif",
	7,"food_halloween[1].gif",
	7,"food_hamburger[1].gif",
	7,"food_lemon[1].gif",
	7,"food_lettuce[1].gif",
	7,"food_orange[1].gif",
	7,"food_peach[1].gif",
	7,"food_pear[1].gif",
	7,"food_pineapple[1].gif",
	7,"food_plum[1].gif",
	7,"food_raspberry[1].gif",
	7,"food_slice[1].gif",
	7,"food_soft-boiled_egg[1].gif",
	7,"food_steak[1].gif",
	7,"food_strawberry[1].gif",
	7,"food_tomato[1].gif",

	8,"objects_alarm[1].gif",
	8,"objects_alarm_clock[1].gif",
	8,"objects_birthday[1].gif",
	8,"objects_bomb[1].gif",
	8,"objects_bulb[1].gif",
	8,"objects_button[1].gif",
	8,"objects_cactus[1].gif",
	8,"objects_cd[1].gif",
	8,"objects_crosswords[1].gif",
	8,"objects_green_light[1].gif",
	8,"objects_grenade[1].gif",
	8,"objects_handle[1].gif",
	8,"objects_headlight[1].gif",
	8,"objects_ice-stick[1].gif",
	8,"objects_internet[1].gif",
	8,"objects_key[1].gif",
	8,"objects_medal[1].gif",
	8,"objects_nappy[1].gif",
	8,"objects_phone[1].gif",
	8,"objects_red_light[1].gif",
	8,"objects_rose[1].gif",
	8,"objects_snowing[1].gif",
	8,"objects_stop[1].gif",
	8,"objects_telephone[1].gif",
	8,"objects_tulip[1].gif",
	8,"objects_washing_machine[1].gif",
	8,"objects_water_drop[1].gif",
	8,"objects_wheel[1].gif",


	9,"airline_pilot.gif",
	9,"air_hostess.gif",
	9,"alien.gif",
	9,"artist.gif",
	9,"astronaut.gif",
	9,"baby.gif",
	9,"baker.gif",
	9,"banker.gif",
	9,"bearded.gif",
	9,"bell_boy.gif",
	9,"beret.gif",
	9,"blue_helmet.gif",
	9,"camouflage.gif",
	9,"centurion.gif",
	9,"chambermaid.gif",
	9,"chauffeur.gif",
	9,"chef.gif",
	9,"chinese.gif",
	9,"clown.gif",
	9,"cowboy.gif",
	9,"deep_sea_diver.gif",
	9,"devil.gif",
	9,"diva.gif",
	9,"diving.gif",
	9,"doctor.gif",
	9,"elegant.gif",
	9,"female.gif",
	9,"fighter_pilot.gif",
	9,"fireman.gif",
	9,"gas_mask.gif",
	9,"general.gif",
	9,"graduate.gif",


	10,"hero.gif",
	10,"joker.gif",
	10,"judge.gif",
	10,"king.gif",
	10,"knight.gif",
	10,"mask.gif",
	10,"miner.gif",
	10,"moustached.gif",
	10,"musketeer.gif",
	10,"nun.gif",
	10,"paparazzi.gif",
	10,"party.gif",
	10,"pirate.gif",
	10,"policeman.gif",
	10,"postman.gif",
	10,"prisoner.gif",
	10,"queen.gif",
	10,"raining.gif",
	10,"rebel.gif",
	10,"republican_guard.gif",
	10,"robot.gif",
	10,"savlour.gif",
	10,"sheriff.gif",
	10,"ships_boy.gif",
	10,"soldier.gif",
	10,"superhero.gif",
	10,"surgeon.gif",
	10,"swimming.gif",
	10,"television_reporter.gif",
	10,"thief.gif",
	10,"vampire.gif",
	10,"wig.gif",
	10,"witch.gif",
	10,"workman.gif",
	10,"yankee.gif",


	11,"sports_badminton.gif",
	11,"sports_basketball.gif",
	11,"sports_cap.gif",
	11,"sports_cross-country_skiing.gif",
	11,"sports_dart-flechettes.gif",
	11,"sports_fencing.gif",
	11,"sports_football.gif",
	11,"sports_formula_one.gif",
	11,"sports_handball.gif",
	11,"sports_hockey.gif",
	11,"sports_horse_riding.gif",
	11,"sports_hot-air_balloon.gif",
	11,"sports_olympic_rings.gif",
	11,"sports_ping_pong.gif",
	11,"sports_polo.gif",
	11,"sports_rugby.gif",
	11,"sports_skateboard.gif",
	11,"sports_skiing.gif",
	11,"sports_snooker.gif",
	11,"sports_sports.gif",
	11,"sports_squash.gif",
	11,"sports_surfing.gif",
	11,"sports_tennis.gif",
	11,"sports_volleyball.gif",
	11,"sports_water_polo.gif",


	12,"planets_aquarius[1].gif",
	12,"planets_cancer[1].gif",
	12,"planets_earth[1].gif",
	12,"planets_gemini[1].gif",
	12,"planets_jupiter[1].gif",
	12,"planets_leo[1].gif",
	12,"planets_libra[1].gif",
	12,"planets_mars[1].gif",
	12,"planets_mercury[1].gif",
	12,"planets_moon[1].gif",
	12,"planets_neptune[1].gif",
	12,"planets_petanque[1].gif",
	12,"planets_pisces[1].gif",
	12,"planets_pluto[1].gif",
	12,"planets_saturn[1].gif",
	12,"planets_scorpio[1].gif",
	12,"planets_taurus[1].gif",
	12,"planets_uranus[1].gif",
	12,"planets_venus[1].gif",
	12,"planets_virgo[1].gif"
	);

</script>
