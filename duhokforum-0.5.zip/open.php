<?
/*//////////////////////////////////////////////////////////
// ######################################################///
// # DuhokForum 0.5                                     # //
// ###################################################### //
// #                                                    # //
// #       --  DUHOK FORUM IS FREE SOFTWARE  --         # //
// #                                                    # //
// #   ========= Programming By Dilovan ==============  # //
// # Copyright � 2007-2008 Dilovan. All Rights Reserved # //
// #----------------------------------------------------# //
// #----------------------------------------------------# //
// # If you want any support vist down address:-        # //
// # Email: df@duhoktimes.com                           # //
// # Site: http://df.duhoktimes.com/index.php           # //
// ###################################################### //
//////////////////////////////////////////////////////////*/

$HTTP_REFERER = $_SERVER['HTTP_REFERER'];
$Monitor = chk_monitor($DBMemberID, $c);

$Moderator = chk_moderator($DBMemberID, $f);

if ($type == "c") {
    if ($Mlevel == 4) {
		$query = "UPDATE " . $Prefix . "CATEGORY SET CAT_STATUS = ('1') WHERE CAT_ID = '$c' ";
		mysql_query($query, $connection) or die (mysql_error());

	                echo'<center>
	                <table width="99%" border="1">
	                   <tr class="normal">
	                       <td class="list_center" colSpan="10"><font size="5"><br>'.$lang['open']['the_cat_is_opened'].'</font><br><br>
                           <meta http-equiv="Refresh" content="1; URL='.$HTTP_REFERER.'">
                           <a href="index.php">'.$lang['all']['click_here_to_go_home'].'</a><br><br>
                           <a href="'.$HTTP_REFERER.'">'.$lang['all']['click_here_to_go_normal_page'].'</a><br><br>
	                       </td>
	                   </tr>
	                </table>
	                </center>';
    }
    else {
    redirect();
    }
}
elseif ($type == "f") {
    if ($Mlevel == 4) {
		$query = "UPDATE " . $Prefix . "FORUM SET F_STATUS = ('1') WHERE FORUM_ID = '$f' ";
		mysql_query($query, $connection) or die (mysql_error());

	                echo'<center>
	                <table width="99%" border="1">
	                   <tr class="normal">
	                       <td class="list_center" colSpan="10"><font size="5"><br>'.$lang['open']['the_forum_is_opened'].'</font><br><br>
                           <meta http-equiv="Refresh" content="1; URL='.$HTTP_REFERER.'">
                           <a href="index.php">'.$lang['all']['click_here_to_go_home'].'</a><br><br>
                           <a href="'.$HTTP_REFERER.'">'.$lang['all']['click_here_to_go_normal_page'].'</a><br><br>
	                       </td>
	                   </tr>
	                </table>
	                </center>';
    }
    else {
    redirect();
    }
}
elseif ($type == "m") {
    if ($Mlevel == 4) {
		$query = "UPDATE " . $Prefix . "MEMBERS SET M_STATUS = ('1') WHERE MEMBER_ID = '$m' ";
		mysql_query($query, $connection) or die (mysql_error());

	                echo'<center>
	                <table width="99%" border="1">
	                   <tr class="normal">
	                       <td class="list_center" colSpan="10"><font size="5"><br>'.$lang['open']['the_member_is_opened'].'</font><br><br>
                           <meta http-equiv="Refresh" content="1; URL='.$HTTP_REFERER.'">
                           <a href="index.php?mode=members">'.$lang['all']['click_here_to_go_member_page'].'</a><br><br>
                           <a href="'.$HTTP_REFERER.'">'.$lang['all']['click_here_to_go_normal_page'].'</a><br><br>
	                       </td>
	                   </tr>
	                </table>
	                </center>';
    }
    else {
    redirect();
    }
}
elseif ($type == "t") {
    if ($Mlevel == 4 OR $Monitor == 1 OR $Moderator == 1) {
		$query = "UPDATE " . $Prefix . "TOPICS SET T_STATUS = ('1'), T_OPEN_MAKE = ('$DBUserName'), T_OPEN_DATE = ('$date') WHERE TOPIC_ID = '$t' ";
		mysql_query($query, $connection) or die (mysql_error());

	                echo'<center>
	                <table width="99%" border="1">
	                   <tr class="normal">
	                       <td class="list_center" colSpan="10"><font size="5"><br>'.$lang['open']['the_topic_is_opened'].'</font><br><br>
                           <meta http-equiv="Refresh" content="1; URL='.$HTTP_REFERER.'">
                           <a href="index.php?mode=t&t='.$t.'">'.$lang['all']['click_here_to_go_topic'].'</a><br><br>
                           <a href="index.php?mode=f&f='.$f.'">'.$lang['all']['click_here_to_go_forum'].'</a><br><br>
                           <a href="'.$HTTP_REFERER.'">'.$lang['all']['click_here_to_go_normal_page'].'</a><br><br>
	                       </td>
	                   </tr>
	                </table>
	                </center>';
    }
    else {
    redirect();
    }
}
elseif ($type == "s") {
    if ($Mlevel == 4 OR $Monitor == 1 OR $Moderator == 1) {
		$query = "UPDATE " . $Prefix . "TOPICS SET T_STICKY = ('0') WHERE TOPIC_ID = '$t' ";
		mysql_query($query, $connection) or die (mysql_error());

	                echo'<center>
	                <table width="99%" border="1">
	                   <tr class="normal">
	                       <td class="list_center" colSpan="10"><font size="5"><br>'.$lang['open']['the_topic_is_unsticky'].'</font><br><br>
                           <meta http-equiv="Refresh" content="1; URL='.$HTTP_REFERER.'">
                           <a href="index.php?mode=t&t='.$t.'">'.$lang['all']['click_here_to_go_topic'].'</a><br><br>
                           <a href="index.php?mode=f&f='.$f.'">'.$lang['all']['click_here_to_go_forum'].'</a><br><br>
                           <a href="'.$HTTP_REFERER.'">'.$lang['all']['click_here_to_go_normal_page'].'</a><br><br>
	                       </td>
	                   </tr>
	                </table>
	                </center>';
    }
    else {
    redirect();
    }
}
elseif ($type == "h") {
    if ($Mlevel == 4 OR $Monitor == 1 OR $Moderator == 1) {
		$query = "UPDATE " . $Prefix . "TOPICS SET T_HIDDEN = ('0') WHERE TOPIC_ID = '$t' ";
		mysql_query($query, $connection) or die (mysql_error());

	                echo'<center>
	                <table width="99%" border="1">
	                   <tr class="normal">
	                       <td class="list_center" colSpan="10"><font size="5"><br>'.$lang['open']['the_topic_is_unhide'].'</font><br><br>
                           <meta http-equiv="Refresh" content="1; URL='.$HTTP_REFERER.'">
                           <a href="index.php?mode=t&t='.$t.'">'.$lang['all']['click_here_to_go_topic'].'</a><br><br>
                           <a href="index.php?mode=f&f='.$f.'">'.$lang['all']['click_here_to_go_forum'].'</a><br><br>
                           <a href="'.$HTTP_REFERER.'">'.$lang['all']['click_here_to_go_normal_page'].'</a><br><br>
	                       </td>
	                   </tr>
	                </table>
	                </center>';
    }
    else {
    redirect();
    }
}
elseif ($type == "hr") {
    if ($Mlevel == 4 OR $Monitor == 1 OR $Moderator == 1) {
		$query = "UPDATE " . $Prefix . "REPLY SET R_HIDDEN = '0' WHERE REPLY_ID = '$r' ";
		mysql_query($query, $connection) or die (mysql_error());

	                echo'<center>
	                <table width="99%" border="1">
	                   <tr class="normal">
	                       <td class="list_center" colSpan="10"><font size="5"><br>'.$lang['open']['the_reply_is_unhide'].'</font><br><br>
                           <meta http-equiv="Refresh" content="1; URL='.$HTTP_REFERER.'">
                           <a href="index.php?mode=t&t='.$t.'">'.$lang['all']['click_here_to_go_topic'].'</a><br><br>
                           <a href="index.php?mode=f&f='.$f.'">'.$lang['all']['click_here_to_go_forum'].'</a><br><br>
                           <a href="'.$HTTP_REFERER.'">'.$lang['all']['click_here_to_go_normal_page'].'</a><br><br>
	                       </td>
	                   </tr>
	                </table>
	                </center>';
    }
    else {
    redirect();
    }
}
elseif ($type == "pm") {

 $PM = mysql_query("SELECT * FROM ".$Prefix."PM WHERE PM_ID = '$msg' ") or die (mysql_error());

 if(mysql_num_rows($PM) > 0){

 $rs_PM = mysql_fetch_array($PM);

 $PM_PmID = $rs_PM['PM_ID'];
 $PM_MID = $rs_PM['PM_MID'];
 }
    if ($Mlevel == 4 OR $DBMemberID == $PM_MID) {

        $query = "UPDATE " . $Prefix . "PM SET ";
        $query .= "PM_STATUS = 1 ";
        $query .= "WHERE PM_ID = '$msg' ";

        mysql_query($query, $connection) or die (mysql_error());

	                echo'<center>
	                <table width="99%" border="1">
	                   <tr class="normal">
	                       <td class="list_center" colSpan="10"><font size="5"><br>'.$lang['open']['the_pm_is_moved'].'</font><br><br>
                           <meta http-equiv="Refresh" content="1; URL='.$HTTP_REFERER.'">
                           <a href="'.$HTTP_REFERER.'">'.$lang['all']['click_here_to_go_normal_page'].'</a><br><br>
	                       </td>
	                   </tr>
	                </table>
	                </center>';
    }
    else {
    redirect();
    }
}
else {
redirect();
}

mysql_close();
?>
