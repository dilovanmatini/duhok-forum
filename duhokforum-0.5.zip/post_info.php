<?
/*//////////////////////////////////////////////////////////
// ######################################################///
// # DuhokForum 0.5                                     # //
// ###################################################### //
// #                                                    # //
// #       --  DUHOK FORUM IS FREE SOFTWARE  --         # //
// #                                                    # //
// #   ========= Programming By Dilovan ==============  # //
// # Copyright � 2007-2008 Dilovan. All Rights Reserved # //
// #----------------------------------------------------# //
// #----------------------------------------------------# //
// # If you want any support vist down address:-        # //
// # Email: df@duhoktimes.com                           # //
// # Site: http://df.duhoktimes.com/index.php           # //
// ###################################################### //
//////////////////////////////////////////////////////////*/

$HTTP_REFERER = $_SERVER['HTTP_REFERER'];
$method = $_POST['method'];
$r = $_POST['r'];
$t = $_POST['t'];
$f = $_POST['f'];
$c = $_POST['c'];
$m = $_POST['m'];
$host = $_POST['host'];
$type = $_POST['type'];
$pm_to = $_POST['pm_to'];
$msg = $_POST['msg'];
$refer = $_POST['refer'];
$hidden = $_POST['hidden'];
$lock = $_POST['lock'];
$sticky = $_POST['sticky'];
$subject = HtmlSpecialchars($_POST['subject']);
$message = $_POST['message'];
$ReplyAndLock = $_POST['ReplyAndLock'];
$ReplyAndUnLock = $_POST['ReplyAndUnLock'];
$date = time();

if ($lock == 1) {
    $lock = 0;
} else {
    $lock = 1;
}

if ($sticky == 1) {
    $sticky = 1;
} else {
    $sticky = 0;
}

if ($hidden == 1) {
    $hidden = 1;
} else {
    $hidden = 0;
}

if ($method == "topic" OR $method == "edit") {
    if ($message == "") {
    $error = $lang['post_info']['necessary_to_write_topic'];
    }

    if ($subject == "") {
    $error = $lang['post_info']['necessary_to_write_title_topic'];
    }
}

if ($method == "reply" OR $method == "editreply") {
    if ($message == "") {
    $error = $lang['post_info']['necessary_to_write_reply'];
    }
}

if ($host != $HTTP_HOST) {
    redirect();
}


if ($error != "") {
	                echo'<br><center>
	                <table width="99%" border="1">
	                   <tr class="normal">
	                       <td class="list_center" colSpan="10"><font size="5" color="red"><br>'.$lang['all']['error'].'<br>'.$error.'..</font><br><br>
	                       <a href="JavaScript:history.go(-1)">'.$lang['all']['click_here_to_back'].'</a><br><br>
	                       </td>
	                   </tr>
	                </table>
	                </center><xml>';
}

if ($error == "") {
    if ($method == "topic") {

     $query1 = "INSERT INTO " . $Prefix . "TOPICS (TOPIC_ID, FORUM_ID, CAT_ID, T_SUBJECT, T_MESSAGE, T_DATE, T_AUTHOR, T_STATUS, T_STICKY, T_HIDDEN, T_LAST_POST_DATE) VALUES (NULL, ";
     $query1 .= " '$f', ";
     $query1 .= " '$c', ";
     $query1 .= " '$subject', ";
     $query1 .= " '$message', ";
     $query1 .= " '$date', ";
     $query1 .= " '$DBMemberID', ";
     $query1 .= " '$lock', ";
     $query1 .= " '$sticky', ";
     $query1 .= " '$hidden', ";
     $query1 .= " '$date') ";

     mysql_query($query1, $connection) or die (mysql_error());
                 
     $query2 = "UPDATE " . $Prefix . "FORUM SET ";
     $query2 .= "F_TOPICS = F_TOPICS + 1, ";
     $query2 .= "F_REPLIES = F_REPLIES + 1, ";
     $query2 .= "F_LAST_POST_DATE = '$date', ";
     $query2 .= "F_LAST_POST_AUTHOR = '$DBMemberID' ";
     $query2 .= "WHERE FORUM_ID = '$f' ";

     mysql_query($query2, $connection) or die (mysql_error());
     
     $query4 = "UPDATE " . $Prefix . "MEMBERS SET ";
     $query4 .= "M_POSTS = M_POSTS + 1, ";
     $query4 .= "M_LAST_POST_DATE = '$date' ";
     $query4 .= "WHERE MEMBER_ID = '$DBMemberID' ";

     mysql_query($query4, $connection) or die (mysql_error());

	                echo'<center>
	                <table width="99%" border="1">
	                   <tr class="normal">
	                       <td class="list_center" colSpan="10"><font size="5"><br>'.$lang['post_info']['the_topic_is_added'].'</font><br><br>
	                       <meta http-equiv="Refresh" content="1; URL='.$refer.'">
	                       <a href="index.php?mode=f&f='.$f.'">'.$lang['all']['click_here_to_go_forum'].'</a><br><br>
                           <a href="'.$refer.'">'.$lang['all']['click_here_to_go_normal_page'].'</a><br><br>
	                       </td>
	                   </tr>
	                </table>
	                </center>';
    }
    if ($method == "edit") {

$query1 = "UPDATE " . $Prefix . "TOPICS SET T_SUBJECT = ('$subject'), T_MESSAGE = ('$message'), T_STATUS = ('$lock'), T_STICKY = ('$sticky'), T_HIDDEN = ('$hidden'), T_LASTEDIT_MAKE = ('$DBUserName'), T_LASTEDIT_DATE = ('$date'), T_ENUM = T_ENUM + 1 WHERE TOPIC_ID = '$t' ";

     mysql_query($query1, $connection) or die (mysql_error());

	                echo'<center>
	                <table width="99%" border="1">
	                   <tr class="normal">
	                       <td class="list_center" colSpan="10"><font size="5"><br>'.$lang['post_info']['the_topic_is_update'].'</font><br><br>
	                       <meta http-equiv="Refresh" content="1; URL='.$refer.'">
                           <a href="index.php?mode=t&t='.$t.'">'.$lang['all']['click_here_to_go_topic'].'</a><br><br>
	                       <a href="index.php?mode=f&f='.$f.'">'.$lang['all']['click_here_to_go_forum'].'</a><br><br>
                           <a href="'.$refer.'">'.$lang['all']['click_here_to_go_normal_page'].'</a><br><br>
	                       </td>
	                   </tr>
	                </table>
	                </center>';
    }
    if ($method == "reply") {

	$member_replies_today = member_replies_today($DBMemberID, $f);
	$f_total_replies = forums("TOTAL_REPLIES", $f);
	if ($Mlevel == 1 AND $member_replies_today >= $f_total_replies OR $Mlevel == 2 AND $Moderator_all == 0 AND $member_replies_today >= $f_total_replies) {
				go_to("index.php?mode=msg&err=14&f=".$f);
	}
	else{

     $query1 = "INSERT INTO " . $Prefix . "REPLY (REPLY_ID, TOPIC_ID, FORUM_ID, CAT_ID, R_MESSAGE, R_DATE, R_AUTHOR) VALUES (NULL, ";
     $query1 .= " '$t', ";
     $query1 .= " '$f', ";
     $query1 .= " '$c', ";
     $query1 .= " '$message', ";
     $query1 .= " '$date', ";
     $query1 .= " '$DBMemberID') ";

     mysql_query($query1, $connection) or die (mysql_error());

     $query2 = "UPDATE " . $Prefix . "FORUM SET ";
     $query2 .= "F_REPLIES = F_REPLIES + 1, ";
     $query2 .= "F_LAST_POST_DATE = '$date', ";
     $query2 .= "F_LAST_POST_AUTHOR = '$DBMemberID' ";
     $query2 .= "WHERE FORUM_ID = '$f' ";

     mysql_query($query2, $connection) or die (mysql_error());
     
     $query3 = "UPDATE " . $Prefix . "TOPICS SET ";
     if ($ReplyAndLock != "") {
     $query3 .= "T_STATUS = '0', ";
     }
     if ($ReplyAndUnLock != "") {
     $query3 .= "T_STATUS = '1', ";
     }
     $query3 .= "T_REPLIES = T_REPLIES + 1, ";
     $query3 .= "T_LAST_POST_DATE = '$date', ";
     $query3 .= "T_LAST_POST_AUTHOR = '$DBMemberID' ";
     $query3 .= "WHERE TOPIC_ID = '$t' ";

     mysql_query($query3, $connection) or die (mysql_error());
     
     $query4 = "UPDATE " . $Prefix . "MEMBERS SET ";
     $query4 .= "M_POSTS = M_POSTS + 1, ";
     $query4 .= "M_LAST_POST_DATE = '$date' ";
     $query4 .= "WHERE MEMBER_ID = '$DBMemberID' ";

     mysql_query($query4, $connection) or die (mysql_error());
     
	                echo'<center>
	                <table width="99%" border="1">
	                   <tr class="normal">
	                       <td class="list_center" colSpan="10"><font size="5"><br>'.$lang['post_info']['the_reply_is_added'].'</font><br><br>';
	                    if ($type == "q_reply") {
                           $go_to_normal_page = '<meta http-equiv="Refresh" content="1; URL='.$HTTP_REFERER.'">';
                           $go_to_normal_page .= '<a href="'.$HTTP_REFERER.'">'.$lang['all']['click_here_to_go_normal_page'].'</a><br><br>';
	                    }
						if ($type == "") {
                           $go_to_normal_page = '<meta http-equiv="Refresh" content="1; URL='.$refer.'">';
                           $go_to_normal_page .= '<a href="'.$refer.'">'.$lang['all']['click_here_to_go_normal_page'].'</a><br><br>';
						}   
	                       echo'
                           <a href="index.php?mode=t&t='.$t.'">'.$lang['all']['click_here_to_go_topic'].'</a><br><br>
	                       <a href="index.php?mode=f&f='.$f.'">'.$lang['all']['click_here_to_go_forum'].'</a><br><br>
                           '.$go_to_normal_page.'
	                       </td>
	                   </tr>
	                </table>
	                </center>';
    }
	}
    if ($method == "editreply") {

     $query1 = "UPDATE " . $Prefix . "REPLY SET R_MESSAGE = ('$message'), R_LASTEDIT_MAKE = ('$DBUserName'), R_LASTEDIT_DATE = ('$date'), R_ENUM = R_ENUM + 1 WHERE REPLY_ID = '$r' ";

     mysql_query($query1, $connection) or die (mysql_error());

	                echo'<center>
	                <table width="99%" border="1">
	                   <tr class="normal">
	                       <td class="list_center" colSpan="10"><font size="5"><br>'.$lang['post_info']['the_reply_is_update'].'</font><br><br>
	                       <meta http-equiv="Refresh" content="1; URL='.$refer.'">
                           <a href="index.php?mode=t&t='.$t.'">'.$lang['all']['click_here_to_go_topic'].'</a><br><br>
	                       <a href="index.php?mode=f&f='.$f.'">'.$lang['all']['click_here_to_go_forum'].'</a><br><br>
                           <a href="'.$refer.'">'.$lang['all']['click_here_to_go_normal_page'].'</a><br><br>
	                       </td>
	                   </tr>
	                </table>
	                </center>';
    }
    if ($method == "sig") {

     $query1 = "UPDATE ".$Prefix."MEMBERS SET ";
     $query1 .= "M_SIG = '$message' ";
     $query1 .= "WHERE MEMBER_ID = '$DBMemberID' ";

     mysql_query($query1, $connection) or die (mysql_error());

	                echo'<center>
	                <table width="99%" border="1">
	                   <tr class="normal">
	                       <td class="list_center" colSpan="10"><font size="5"><br>'.$lang['post_info']['the_sig_is_update'].'</font><br><br>
	                       <meta http-equiv="Refresh" content="1; URL=index.php?mode=profile&type=details">
                           <a href="index.php?mode=profile&id='.$DBMemberID.'">'.$lang['all']['click_here_to_go_yours_details'].'</a><br><br>
	                       <a href="index.php?mode=profile&type=details">'.$lang['all']['click_here_to_go_normal_page'].'</a><br><br>
	                       </td>
	                   </tr>
	                </table>
	                </center>';
    }
    
    if ($method == "replymsg") {

     if ($m != "") {
       $DBMemberID = $m;
     }

     $query1 = "INSERT INTO ".$Prefix."PM (PM_ID, PM_MID, PM_TO, PM_FROM, PM_OUT, PM_REPLY, PM_SUBJECT, PM_MESSAGE, PM_DATE) VALUES (NULL, ";
     $query1 .= " '$DBMemberID', ";
     $query1 .= " '$pm_to', ";
     $query1 .= " '$DBMemberID', ";
     $query1 .= " '1', ";
    if ($msg != "") {
     $query1 .= " '1', ";
    }
    else {
     $query1 .= " '0', ";
    }
     $query1 .= " '$subject', ";
     $query1 .= " '$message', ";
     $query1 .= " '$date') ";
     
     mysql_query($query1, $connection) or die (mysql_error());
     
     $query2 = "INSERT INTO ".$Prefix."PM (PM_ID, PM_MID, PM_TO, PM_FROM, PM_REPLY, PM_SUBJECT, PM_MESSAGE, PM_DATE) VALUES (NULL, ";
     $query2 .= " '$pm_to', ";
     $query2 .= " '$pm_to', ";
     $query2 .= " '$DBMemberID', ";
     $query2 .= " '1', ";
     $query2 .= " '$subject', ";
     $query2 .= " '$message', ";
     $query2 .= " '$date') ";

     mysql_query($query2, $connection) or die (mysql_error());
     
    if ($msg != "") {
     $query3 = "UPDATE ".$Prefix."PM SET ";
     $query3 .= "PM_REPLY = '2' ";
     $query3 .= "WHERE PM_ID = '$msg' ";

     mysql_query($query3, $connection) or die (mysql_error());
    }
	                echo'<center>
	                <table width="99%" border="1">
	                   <tr class="normal">
	                       <td class="list_center" colSpan="10"><font size="5"><br>'.$lang['post_info']['the_pm_is_replied'].'</font><br><br>';
	                    if ($type == "q_reply") {
                           $go_to_normal_page = '<meta http-equiv="Refresh" content="1; URL='.$HTTP_REFERER.'">';
                           $go_to_normal_page .= '<a href="'.$HTTP_REFERER.'">'.$lang['all']['click_here_to_go_normal_page'].'</a><br><br>';
	                    }
						if ($type == "") {
                           $go_to_normal_page = '<meta http-equiv="Refresh" content="1; URL='.$refer.'">';
                           $go_to_normal_page .= '<a href="'.$refer.'">'.$lang['all']['click_here_to_go_normal_page'].'</a><br><br>';
						}   
	                       echo'
                           '.$go_to_normal_page.'
	                       </td>
	                   </tr>
	                </table>
	                </center>';
    }
    if ($method == "sendmsg") {

     $query1 = "INSERT INTO ".$Prefix."PM (PM_ID, PM_MID, PM_TO, PM_FROM, PM_OUT, PM_SUBJECT, PM_MESSAGE, PM_DATE) VALUES (NULL, ";
     $query1 .= " '$DBMemberID', ";
     $query1 .= " '$pm_to', ";
     $query1 .= " '$DBMemberID', ";
     $query1 .= " '1', ";
     $query1 .= " '$subject', ";
     $query1 .= " '$message', ";
     $query1 .= " '$date') ";

     mysql_query($query1, $connection) or die (mysql_error());

     $query2 = "INSERT INTO ".$Prefix."PM (PM_ID, PM_MID, PM_TO, PM_FROM, PM_SUBJECT, PM_MESSAGE, PM_DATE) VALUES (NULL, ";
     $query2 .= " '$pm_to', ";
     $query2 .= " '$pm_to', ";
     $query2 .= " '$DBMemberID', ";
     $query2 .= " '$subject', ";
     $query2 .= " '$message', ";
     $query2 .= " '$date') ";

     mysql_query($query2, $connection) or die (mysql_error());
     
	                echo'<center>
	                <table width="99%" border="1">
	                   <tr class="normal">
	                       <td class="list_center" colSpan="10"><font size="5"><br>'.$lang['post_info']['the_pm_is_send'].'</font><br><br>
	                       <meta http-equiv="Refresh" content="1; URL='.$refer.'">
	                       <a href="'.$refer.'">'.$lang['all']['click_here_to_go_normal_page'].'</a><br><br>
	                       </td>
	                   </tr>
	                </table>
	                </center>';
    }
}

    if ($method == "survey") {

$query2 = "UPDATE " . $Prefix . "TOPICS SET T_SURVEY = ('0'), T_SURVEYID = ('0') WHERE TOPIC_ID = '$t' ";

     mysql_query($query2, $connection) or die (mysql_error());

	                echo'<center>
	                <table width="99%" border="1">
	                   <tr class="normal">
	                       <td class="list_center" colSpan="10"><font size="5"><br>�� ��� ��������� �� ������� �����..</font><br><br>
	                       <meta http-equiv="Refresh" content="1; URL='.$refer.'">
                           <a href="index.php?mode=t&t='.$t.'">'.$lang['all']['click_here_to_go_topic'].'</a><br><br>
	                       <a href="index.php?mode=f&f='.$f.'">'.$lang['all']['click_here_to_go_forum'].'</a><br><br>
                           <a href="'.$refer.'">'.$lang['all']['click_here_to_go_normal_page'].'</a><br><br>
	                       </td>
	                   </tr>
	                </table>
	                </center>';
    }

?>
