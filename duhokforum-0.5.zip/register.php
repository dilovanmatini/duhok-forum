<?
/*//////////////////////////////////////////////////////////
// ######################################################///
// # DuhokForum 0.5                                     # //
// ###################################################### //
// #                                                    # //
// #       --  DUHOK FORUM IS FREE SOFTWARE  --         # //
// #                                                    # //
// #   ========= Programming By Dilovan ==============  # //
// # Copyright � 2007-2008 Dilovan. All Rights Reserved # //
// #----------------------------------------------------# //
// #----------------------------------------------------# //
// # If you want any support vist down address:-        # //
// # Email: df@duhoktimes.com                           # //
// # Site: http://df.duhoktimes.com/index.php           # //
// ###################################################### //
//////////////////////////////////////////////////////////*/

$HTTP_HOST = $_SERVER['HTTP_HOST'];

if ($r == "") {


echo'

<script language="javascript" src="./javascript/register.js"></script>

<center>
<table cellSpacing="0" cellPadding="0" width="99%" border="0" id="table1">
	<tr>
		<td><center><font color="red" size="+2">'.$lang['register']['register_new_member'].'</font><br>&nbsp;<form name="userinfo" method="post" action="index.php?mode=register&r=insert">
            <input type="hidden" value="'.$HTTP_HOST.'" name="host">
            <input type="hidden" value="1" name="forum_title">
            <input type="hidden" value="1" name="site_address">
            <table cellSpacing="1" cellPadding="4" bgColor="gray" border="0" id="table2">
				<tr class="fixed">
					<td class="optionheader_selected" id="row_user_name"><nobr>'.$lang['register']['user_name'].' </nobr></td>
					<td class="list" colSpan="3"><input class="insidetitle" style="WIDTH: 300px" name="user_name"></td>
				</tr>
				<tr class="fixed">
					<td><font color="red" size="-1">'.$lang['register']['rules_write_user_name_one'].'<br>&nbsp;</font></td>
					<td><font color="red" size="-1">'.$lang['register']['rules_write_user_name_tow'].'<br>&nbsp;</font></td>
				</tr>
				<tr class="fixed">
					<td class="optionheader_selected" id="row_user_password1"><nobr>'.$lang['register']['the_password'].' </nobr></td>
					<td class="list" colSpan="3"><input class="insidetitle" style="WIDTH: 300px" type="password" name="user_password1"></td>
				</tr>
				<tr class="fixed">
					<td class="optionheader_selected" id="row_user_password2"><nobr>'.$lang['register']['the_confirm_password'].' </nobr></td>
					<td class="list" colSpan="3"><input class="insidetitle" style="WIDTH: 300px" type="password" name="user_password2"></td>
				</tr>
				<tr class="fixed">
					<td><font color="red" size="-1">'.$lang['register']['rules_write_password_one'].'<br>&nbsp;</font></td>
					<td><font color="red" size="-1">'.$lang['register']['rules_write_password_tow'].'<br>&nbsp;</font></td>
				</tr>
    			<tr class="fixed">
					<td class="optionheader_selected" id="row_user_email"><nobr>'.$lang['register']['the_email'].' </nobr></td>
					<td class="list" colSpan="3"><input class="insidetitle" dir="ltr" style="WIDTH: 300px" name="user_email"></td>
				</tr>
				<tr class="fixed">
					<td><font color="red" size="-1">'.$lang['register']['rules_write_email_one'].'<br>&nbsp;</font></td>
					<td><font color="red" size="-1">'.$lang['register']['rules_write_email_tow'].'<br>&nbsp;</font></td>
				</tr>
				<tr class="fixed">
					<td class="optionheader" id="row_user_city"><nobr>'.$lang['register']['the_city'].'</nobr></td>
					<td class="list" colSpan="3"><input class="insidetitle" style="WIDTH: 150px" name="user_city"></td>
				</tr>
				<tr class="fixed">
					<td class="optionheader" id="row_user_state"><nobr>'.$lang['register']['the_state'].'</nobr></td>
					<td class="list" colSpan="3"><input class="insidetitle" style="WIDTH: 150px" name="user_state"></td>
				</tr>
				<tr class="fixed">
					<td class="optionheader" id="row_user_country"><nobr>'.$lang['register']['the_country'].'</nobr></td>
					<td class="list" colSpan="3">
					<select class="insidetitle" style="WIDTH: 200px" name="user_country" type="text">';
                    include("country.php");
                    echo'
					</select>
                    </td>
				</tr>
				<tr class="fixed">
					<td class="optionheader" id="row_user_occupation"><nobr>'.$lang['register']['the_occupation'].' </nobr></td>
					<td class="list" colSpan="3"><input class="insidetitle" style="WIDTH: 150px" name="user_occupation"></td>
				</tr>
				<tr class="fixed">
					<td class="optionheader" id="row_user_age"><nobr>'.$lang['register']['the_age'].'</nobr></td>
					<td class="list" colSpan="3"><input class="insidetitle" style="WIDTH: 150px" name="user_age"></td>
				</tr>
				<tr class="fixed">
					<td class="optionheader" id="row_user_sex"><nobr>'.$lang['register']['the_sex'].'</nobr></td>
					<td class="list" colSpan="3">&nbsp;&nbsp;&nbsp;<input class="small" type="radio" value="1" name="user_sex">'.$lang['register']['male'].'&nbsp;&nbsp;&nbsp;<input class="small" type="radio" value="2" name="user_sex">'.$lang['register']['famale'].'</td>
				</tr>
				<tr class="fixed">
					<td class="list_center" colSpan="5"><input onclick="submitForm()" type="button" value="'.$lang['register']['send_data'].'"></td>
				</tr>
			</table>
		</form>
		</center></td>
	</tr>
</table>
</center>
';
}
if ($r == "insert") {

$Name = $_POST["user_name"];
$Email = $_POST["user_email"];
$Password = $_POST["user_password1"];
$City = $_POST["user_city"];
$State = $_POST["user_state"];
$Country = $_POST["user_country"];
$Occupation = $_POST["user_occupation"];
$Age = $_POST["user_age"];
$Sex = $_POST["user_sex"];
$IP = $_SERVER["REMOTE_ADDR"];
$date = time();

 $query = "SELECT * FROM " . $Prefix . "MEMBERS WHERE M_NAME = '" . $Name . "' ";
 $result = mysql_query($query, $connection) or die (mysql_error());

 if(mysql_num_rows($result) > 0){
 $rs=mysql_fetch_array($result);

 $UserName = $rs['M_NAME'];
 }
 
 $query1 = "SELECT * FROM " . $Prefix . "MEMBERS WHERE M_EMAIL = '" . $Email . "' ";
 $result1 = mysql_query($query1, $connection) or die (mysql_error());

 if(mysql_num_rows($result1) > 0){
 $rs1=mysql_fetch_array($result1);

 $MemberEmail = $rs1['M_EMAIL'];
 }
 
 $query2 = "SELECT * FROM " . $Prefix . "NAMEFILTER WHERE N_NAME = '" . $Name . "' ";
 $result2 = mysql_query($query2, $connection) or die (mysql_error());

 if(mysql_num_rows($result2) > 0){
 $rs2=mysql_fetch_array($result2);

 $MemberFilterName = $rs2['N_NAME'];
 }
 
if ($Name == $UserName) {
   $error = $lang['register']['this_name_was_used'];
}
if ($MemberEmail == $Email) {
   $error = $lang['register']['this_email_was_used'];
}
if ($Name == $MemberFilterName) {
   $error = $lang['register']['this_name_was_bad'];
}

$host = $_POST["host"];

if ($HTTP_HOST != $host) {
   $error = $lang['register']['not_allowed_to_use_this_away'];
}
 
if ($error != "") {
	                echo'<br><center>
	                <table width="99%" border="1">
	                   <tr class="normal">
	                       <td class="list_center" colSpan="10"><font size="5" color="red"><br>'.$lang['all']['error'].'<br>'.$error.'..</font><br><br>
	                       <a href="JavaScript:history.go(-1)">'.$lang['all']['click_here_to_back'].'</a><br><br>
	                       </td>
	                   </tr>
	                </table>
	                </center><xml>';
}

if ($error == "") {

$Password = MD5($Password);

 $query = "INSERT INTO " . $Prefix . "MEMBERS (MEMBER_ID, M_NAME, M_PASSWORD, M_EMAIL, M_CITY, M_STATE, M_IP, M_COUNTRY, M_OCCUPATION, M_AGE, M_SEX, M_DATE, M_LAST_POST_DATE, M_LAST_HERE_DATE) VALUES (NULL, '$Name', '$Password', '$Email', '$City', '$State', '$IP', '$Country', '$Occupation', '$Age', '$Sex', '$date', '$date', '$date')";
 mysql_query($query, $connection) or die (mysql_error());
 
 

	                echo'<center>
	                <table width="99%" border="1">
	                   <tr class="normal">
	                       <td class="list_center" colSpan="10"><font size="5"><br>'.$lang['register']['the_member_was_registered'].'</font><br><br>
	                       <meta http-equiv="Refresh" content="1; URL=index.php">
	                       <a href="index.php">'.$lang['all']['click_here_to_go_home'].'</a><br><br>
	                       </td>
	                   </tr>
	                </table>
	                </center>';

}
 
}

mysql_close();
?>

