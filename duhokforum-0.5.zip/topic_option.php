<?
/*//////////////////////////////////////////////////////////
// ######################################################///
// # DuhokForum 0.5                                     # //
// ###################################################### //
// #                                                    # //
// #       --  DUHOK FORUM IS FREE SOFTWARE  --         # //
// #                                                    # //
// #   ========= Programming By Dilovan ==============  # //
// # Copyright � 2007-2008 Dilovan. All Rights Reserved # //
// #----------------------------------------------------# //
// #----------------------------------------------------# //
// # If you want any support vist down address:-        # //
// # Email: df@duhoktimes.com                           # //
// # Site: http://df.duhoktimes.com/index.php           # //
// ###################################################### //
//////////////////////////////////////////////////////////*/

$Monitor = chk_monitor($DBMemberID, cat_id($f));
$Moderator = chk_moderator($DBMemberID, $f);

if ($Mlevel == 4 OR $Monitor == 1 OR $Moderator == 1 OR $DBMemberID > 0) {

if ($type == "") {

$resultTopO = mysql_query("SELECT * FROM ".$Prefix."TOPICS WHERE TOPIC_ID = '$t' ")
or die (mysql_error());

if(mysql_num_rows($resultTopO) > 0){
$rsTopO = mysql_fetch_array($resultTopO);

$TOP_TopicID = $rsTopO['TOPIC_ID'];
$TOP_ForumID = $rsTopO['FORUM_ID'];
$TOP_CatID = $rsTopO['CAT_ID'];
$TOP_TopicSubject = $rsTopO['T_SUBJECT'];
$TOP_TopicSticky = $rsTopO['T_STICKY'];
$TOP_TopicHidden = $rsTopO['T_HIDDEN'];
$TOP_HiddenForum = $rsTopO['T_HIDE_FORUM'];
$TOP_TopicStatus = $rsTopO['T_STATUS'];
$TOP_TopicTop = $rsTopO['T_TOP'];
$TOP_TopicFlag = $rsTopO['T_ARCHIVE_FLAG'];
$TOP_TopicLink = $rsTopO['T_LINKFORUM'];
}

$queryF = "SELECT * FROM " . $Prefix . "FORUM WHERE FORUM_ID = '$TOP_ForumID' ";
$resultF = mysql_query($queryF, $connection) or die (mysql_error());

if(mysql_num_rows($resultF) > 0){
$rsF=mysql_fetch_array($resultF);

$F_CatID = $rsF['CAT_ID'];
$F_ForumID = $rsF['FORUM_ID'];
$F_ForumSubject = $rsF['F_SUBJECT'];
}

echo'
<div align="center">
<form method="POST" action="index.php?mode=option&type=edit">
<input type="hidden" name="TopicID" value="'.$t.'">
<input type="hidden" name="ForumID" value="'.$F_ForumID.'">
	<table cellSpacing="1" cellPadding="5" bgColor="gray" border="0">
		<tr class="fixed">
			<td class="optionheader" colspan="1"><nobr>'.$lang['editor']['topic_address'].'</nobr></td>
			<td colspan="4" class="list"><input type="text" size="50" name="TopicSubject" value="'.$TOP_TopicSubject.'">&nbsp;&nbsp;</td>
		</tr>					
		<tr class=""fixed"">
			<td class="optionheader" colspan="1">'.$lang['all']['forum'].'</td>
			<td colspan="5" class="userdetails_data"><nobr><font color="red">&nbsp;&nbsp;'.$F_ForumSubject.'</font></nobr></td>
		</tr>
		<tr class="fixed">
			<td class="optionheader"><nobr>'.$lang['forum']['sticky_topic'].':</nobr></td>
				<td class="list"><nobr><input type="radio" class="radio" name="TopicSticky" value="0" '.check_radio($TOP_TopicSticky, "0").'>'.$lang['forum']['unstiky'].'</nobr></td>
				<td class="list"><nobr><input type="radio" class="radio" name="TopicSticky" value="1" '.check_radio($TOP_TopicSticky, "1").'>'.$lang['forum']['stiky'].'</nobr></td>
			<td class="list"><nobr></nobr></td>
		</tr>
		<tr class="fixed">
			<td class="optionheader"><nobr>'.$lang['forum']['lock_topic'].':</nobr></td>
				<td class="list"><nobr><input type="radio" class="radio" name="TopicStatus" value="1" '.check_radio($TOP_TopicStatus, "1").'>'.$lang['forum']['topic_unlock'].'</nobr></td>
				<td class="list"><nobr><input type="radio" class="radio" name="TopicStatus" value="0" '.check_radio($TOP_TopicStatus, "0").'>'.$lang['forum']['topic_lock'].'</nobr></td>
			<td class="list"><nobr></nobr></td>
		</tr>
		<tr class="fixed">
			<td class="optionheader"><nobr>'.$lang['forum']['hide_topic'].':</nobr></td>
				<td class="list"><nobr><input type="radio" class="radio" name="TopicHidden" value="0" '.check_radio($TOP_TopicHidden, "0").'>'.$lang['forum']['topic_unhide'].'</nobr></td>
				<td class="list"><nobr><input type="radio" class="radio" name="TopicHidden" value="1" '.check_radio($TOP_TopicHidden, "1").'>'.$lang['forum']['topic_hide'].'</nobr></td>
			<td class="list"><nobr></nobr></td>
		</tr>
		<tr class="fixed">
			<td class="optionheader"><nobr>'.$lang['forum']['topic_link'].':</nobr></td>
				<td class="list"><nobr><input type="radio" class="radio" name="TopicLinkForum" value="0" '.check_radio($TOP_TopicLink, "0").'>'.$lang['forum']['topic_unshow'].'</nobr></td>
				<td class="list"><nobr><input type="radio" class="radio" name="TopicLinkForum" value="1" '.check_radio($TOP_TopicLink, "1").'>'.$lang['forum']['topic_normal_link'].'</nobr></td>
				<td class="list"><nobr><input type="radio" class="radio" name="TopicLinkForum" value="2" '.check_radio($TOP_TopicLink, "2").'>'.$lang['forum']['topic_principal_link'].'</nobr></td>
		</tr>
		<tr class="fixed">
			<td class="optionheader"><nobr>'.$lang['forum']['topic_top'].':</nobr></td>
				<td class="list"><nobr><input type="radio" class="radio" name="TopicTop" value="0" '.check_radio($TOP_TopicTop, "0").'>'.$lang['forum']['topic_untop'].'</nobr></td>
				<td class="list"><nobr><input type="radio" class="radio" name="TopicTop" value="1" '.check_radio($TOP_TopicTop, "1").'>'.$lang['forum']['topic_top_forum'].'</nobr></td>
				<td class="list"><nobr><input type="radio" class="radio" name="TopicTop" value="2" '.check_radio($TOP_TopicTop, "2").'>'.$lang['forum']['topic_top_all_forum'].'</nobr></td>
		</tr>
		<tr class="fixed">
			<td class="optionheader"><nobr>'.$lang['forum']['topic_archive'].':</nobr></td>
				<td class="list"><nobr><input type="radio" class="radio" name="TopicArchive" value="0" '.check_radio($TOP_TopicFlag, "0").'>'.$lang['forum']['topic_archive'].'</nobr></td>
				<td class="list"><nobr><input type="radio" class="radio" name="TopicArchive" value="1" '.check_radio($TOP_TopicFlag, "1").'>'.$lang['forum']['topic_unarchive'].'</nobr></td>
			<td class="list"><nobr></nobr></td>
		</tr>
		<tr class="fixed">
			<td class="list_center" colspan="5"><input type="submit" name="Submit" value="'.$lang['profile']['insert_info'].'">&nbsp;&nbsp;<input type="reset" name="reset" value="'.$lang['profile']['reset_info'].'"></td>
		</tr>
	</table>
</form>
</div>';
}

if ($type == "edit") {

$f = $_POST["ForumID"];
$t = $_POST["TopicID"];
$TopicSubject = HtmlSpecialchars($_POST["TopicSubject"]);
$TopicSticky = $_POST["TopicSticky"];
$TopicHidden = $_POST["TopicHidden"];
$TopicStatus = $_POST["TopicStatus"];
$TopicLinkForum = $_POST["TopicLinkForum"];
$TopicTop = $_POST["TopicTop"];
$TopicArchive = $_POST["TopicArchive"];

if ($TopicSubject == "") {
    $error = $lang['post_info']['necessary_to_write_title_topic'];
}

if ($error != "") {
	                echo'<br><center>
	                <table width="99%" border="1">
	                   <tr class="normal">
	                       <td class="list_center" colSpan="10"><font size="5" color="red"><br>'.$lang['all']['error'].'<br>'.$error.'..</font><br><br>
	                       <a href="JavaScript:history.go(-1)">'.$lang['all']['click_here_to_back'].'</a><br><br>
	                       </td>
	                   </tr>
	                </table>
	                </center>';
}

if ($error == "") {

$queryTop = "UPDATE " . $Prefix . "TOPICS SET T_SUBJECT = ('$TopicSubject'), T_STICKY = ('$TopicSticky'), T_HIDDEN = ('$TopicHidden'), T_STATUS = ('$TopicStatus'), T_TOP = ('$TopicTop'), T_ARCHIVE_FLAG = ('$TopicArchive'), T_LINKFORUM = ('$TopicLinkForum') WHERE TOPIC_ID = '$t' ";

mysql_query($queryTop, $connection) or die (mysql_error());
        
                    echo'
	                <center>
	                <table width="99%" border="1">
	                   <tr class="normal">
	                       <td class="list_center" colSpan="10"><font size="5"><br>'.$lang['all']['info_was_edited'].'</font><br><br>
                           <meta http-equiv="Refresh" content="2; URL=index.php?mode=f&f='.$f.'">
                           <a href="index.php?mode=option&t='.$t.'">'.$lang['all']['click_here_to_go_normal_page'].'</a><br><br>
	                       </td>
	                   </tr>
	                </table>
	                </center>';
}
}

}
?>