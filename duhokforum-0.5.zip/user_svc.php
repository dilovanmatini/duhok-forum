<?php
/*//////////////////////////////////////////////////////////
// ######################################################///
// # DuhokForum 0.5                                     # //
// ###################################################### //
// #                                                    # //
// #       --  DUHOK FORUM IS FREE SOFTWARE  --         # //
// #                                                    # //
// #   ========= Programming By Dilovan ==============  # //
// # Copyright � 2007-2008 Dilovan. All Rights Reserved # //
// #----------------------------------------------------# //
// #----------------------------------------------------# //
// # If you want any support vist down address:-        # //
// # Email: df@duhoktimes.com                           # //
// # Site: http://df.duhoktimes.com/index.php           # //
// ###################################################### //
//////////////////////////////////////////////////////////*/

if ($Mlevel > 1) {

if ($method != "delete") {

echo'
<center>
<table cellSpacing="0" cellPadding="0" width="99%" border="0">
  <tr>
    <td>
    <table class="optionsbar" cellSpacing="2" width="100%" border="0">
      <tr>
        <td class="optionsbar_title" Align="center" width="95%">����� ������ �������</td>';
        go_to_forum();
      echo'
      </tr>
    </table>
    </td>
  </tr>
</table>
</center><br>';
}

if ($method == "svc") {


if ($svc == "") {

echo'
<center>
<table width="30%" cellSpacing="1" cellPadding="4">
  <tr>
    <td class="optionsbar_menus" colSpan="9"><font color="black" size="+1">����� ����� </font><br><font color="red" size="2">'.member_name($id).'</font></td>
  </tr>
  <tr>
    <td class="stats_h"><nobr>�����</nobr></td>
  </tr>
  <tr>
    <td class="stats_g"><nobr><a href="index.php?mode=user_svc&method=svc&svc=titles&id='.$id.'">����� ����� </a><font color="red">( '.member_title_count($id).' )</font></nobr></td>
  </tr>
</table>
</center>';
}



if ($svc == "titles") {



echo'
<center>
<table cellSpacing="1" cellPadding="5">
  <tr>
    <td class="optionsbar_menus" colSpan="11"><font color="black" size="+1">����� ����� </font><br><font color="red" size="2">'.member_name($id).'</font></td>
  </tr>
  <tr>
    <td class="stats_h"><nobr>�����</nobr></td>
    <td class="stats_h"><nobr>����� �����</nobr></td>
    <td class="stats_h"><nobr>���� ��<br>����<br>���������</nobr></td>
    <td class="stats_h"><nobr>�����</nobr></td>
    <td class="stats_h"><nobr>�������</nobr></td>
    <td class="stats_h"><nobr>�� ���<br>��� �����</nobr></td>
    <td class="stats_h"><nobr>�����<br>�������</nobr></td>
    <td class="stats_h" colspan="3"><nobr>������</nobr></td>
  </tr>';

  $FTitles = mysql_query("SELECT * FROM ".$Prefix."TITLES WHERE T_MEMBERID = '$id' ORDER BY TITLE_ID ASC ") or die (mysql_error());
  $FT_num = mysql_num_rows($FTitles);
  if ($FT_num <= 0) {
  echo'
  <tr>
    <td class="stats_p" align="middle" colSpan="11"><font color="black" size="3"><br>�� ���� ��� ��� ���� �����<br><br></font></td>
  </tr>';
  }
  else {
  $i=0;
  while ($i < $FT_num) {

        $T_TitleID = mysql_result($FTitles, $i, "TITLE_ID");
        $T_ForumID = mysql_result($FTitles, $i, "T_FORUMID");
        $T_Status = mysql_result($FTitles, $i, "T_STATUS");
        $T_Added = mysql_result($FTitles, $i, "T_MAKE");
        $T_Color = mysql_result($FTitles, $i, "T_COLOR");
        $T_Subject = mysql_result($FTitles, $i, "T_SUBJECT");
        $T_Date = mysql_result($FTitles, $i, "T_DATE");
        
        if ($T_Status == 0) {
          $status = '��';
        }
        if ($T_Status == 1) {
          $status = '���';
        }

  echo'
  <tr>
    <td class="stats_h" align="middle"><font color="white" size="-1">'.$T_TitleID.'</font></td>
    <td class="stats_p" align="middle"><font color="black" size="-1">'.$T_Subject.'</font></td>
    <td class="stats_h" align="middle"><font color="yellow" size="-1">'.$status.'</font></td>
    <td class="stats_p" align="middle"><font size="-1">'.title_color($T_Color).'</font></td>
    <td class="stats_g" align="middle"><font color="white" size="-1">'.forum_name($T_ForumID).'</font></td>
    <td class="stats_p" align="middle"><font color="black" size="-1">'.link_profile(member_name($T_Added), $T_Added).'</font></td>
    <td class="stats_h" align="middle"><font color="white" size="-1">'.normal_date($T_Date).'</font></td>';

if ($Mlevel == 4 OR chk_monitor($DBMemberID, cat_id($T_ForumID)) == 1 OR chk_moderator($DBMemberID,$T_ForumID) == 1) {
echo'<td class="stats_p" align="middle"><font color="black" size="-1"><a href="index.php?mode=user_svc&method=delete&svc=titles&t='.$T_TitleID.'&id='.$id.'&f='.$T_ForumID.'&c='.cat_id($T_ForumID).'">'.icons($icon_trash, "��� �����", "").'</a></font></td>';
}
else {
echo'<td class="stats_p" align="middle"><font color="black" size="-1">-</font></td>';
}
  
  echo'
  </tr>';
  
  $i++;
  }
  }

echo'
</table>
<center>';

}

}



if ($method == "delete") {
if ($Mlevel == 4 OR chk_monitor($DBMemberID,$c) == 1 OR chk_moderator($DBMemberID,$f) == 1) {

if ($svc == "titles") {


		$query = "DELETE FROM " . $Prefix . "TITLES WHERE TITLE_ID = '$t' ";
		mysql_query($query, $connection) or die (mysql_error());


	                echo'<br><center>
	                <table width="99%" border="1">
	                   <tr class="normal">
	                       <td class="list_center" colSpan="10"><font size="5"><br>�� ��� ����� �����..</font><br><br>
	                       <meta http-equiv="Refresh" content="2; URL=index.php?mode=user_svc&method=svc&svc=titles&id='.$id.'&f='.$f.'&c='.$c.'">
	                       <a href="index.php?mode=svc">-- ���� ��� ������ ��� ������ ����� --</a><br><br>
                           <a href="index.php?mode=svc&method=svc&svc=titles&f='.$f.$cat_id.'">-- ���� ��� ������ ��� ������ ������� --</a><br><br>
	                       </td>
	                   </tr>
	                </table>
	                </center>';


}


}}

/*///////////////////////////////////////////////////////////////////////////////////////
//#####################################################################################//
//################################## MEDALS BY MR TAZI ################################//
//#####################################################################################//
///////////////////////////////////////////////////////////////////////////////////////*/

if ($method == "svc") {


if ($svc == "") {

echo'
<center>
<table width="30%" dir="rtl" cellSpacing="1" cellPadding="4">

  <tr>
    <td class="stats_p"><nobr><a href="index.php?mode=user_svc&method=svc&svc=medals&id='.$id.'">����� ����� </a><font color="red">( '.member_medal_count($id).' )</font></nobr></td>
  </tr>
</table>
</center>';
}



if ($svc == "medals") {



echo'
<center>
<table dir="rtl" cellSpacing="1" cellPadding="5">
  <tr>
    <td class="optionsbar_menus" colSpan="11"><font color="black" size="+1">����� ����� </font><br><font color="red" size="2">'.member_name($id).'</font></td>
  </tr>
  <tr>
    <td class="stats_h"><nobr>�����</nobr></td>
    <td class="stats_h"><nobr>��� ������</nobr></td>
    <td class="stats_h"><nobr>���� ������</nobr></td>
    <td class="stats_h"><nobr>�������</nobr></td>
    <td class="stats_h"><nobr>�� ����<br>��� ������</nobr></td>
    <td class="stats_h"><nobr>�����<br>�������</nobr></td>
    <td class="stats_h" colspan="3"><nobr>������</nobr></td>
  </tr>';

  $FMedal = mysql_query("SELECT * FROM ".$Prefix."MEDALS WHERE M_MEMBERID = '$id' ORDER BY MEDAL_ID ASC ") or die (mysql_error());
  $FM_num = mysql_num_rows($FMedal);
  if ($FM_num <= 0) {
  echo'
  <tr>
    <td class="stats_p" align="middle" colSpan="11"><font color="black" size="3"><br>�� ���� �� ���� ���� �����<br><br></font></td>
  </tr>';
  }
  else {
  $im=0;
  while ($im < $FM_num) {

        $M_MedalID = mysql_result($FMedal, $im, "MEDAL_ID");
        $M_ForumID = mysql_result($FMedal, $im, "M_FORUMID");
        $M_Status = mysql_result($FMedal, $im, "M_STATUS");
        $M_Added = mysql_result($FMedal, $im, "M_MAKE");
        $M_Points = mysql_result($FMedal, $im, "M_MPOINTS");
        $M_Subject = mysql_result($FMedal, $im, "M_SUBJECT");
        $M_Date = mysql_result($FMedal, $im, "M_DATE");

  echo'
  <tr>
    <td class="stats_h" align="middle"><font color="white" size="-1">'.$M_MedalID.'</font></td>
    <td class="stats_p" align="middle"><font color="black" size="-1">'.$M_Subject.'</font></td>
    <td class="stats_h" align="middle"><font color="yellow" size="-1">'.$M_Points.'</font></td>
    <td class="stats_g" align="middle"><font color="white" size="-1">'.forum_name($M_ForumID).'</font></td>
    <td class="stats_p" align="middle"><font color="black" size="-1">'.link_profile(member_name($M_Added), $M_Added).'</font></td>
    <td class="stats_h" align="middle"><font color="white" size="-1">'.normal_date($M_Date).'</font></td>';

if ($Mlevel == 4 OR chk_monitor($DBMemberID, cat_id($M_ForumID)) == 1 OR chk_moderator($DBMemberID,$M_ForumID) == 1) {
echo'<td class="stats_p" align="middle"><font color="black" size="-1"><a href="index.php?mode=user_svc&method=delete&svc=medals&m='.$M_MedalID.'&id='.$id.'&f='.$M_ForumID.'&c='.cat_id($M_ForumID).'">'.icons($icon_trash, "��� ������", "").'</a></font></td>';
}
else {
echo'<td class="stats_p" align="middle"><font color="black" size="-1">-</font></td>';
}
  
  echo'
  </tr>';
  
  $im++;
  }
  }

echo'
</table>
<center>';

}

}



if ($method == "delete") {
if ($Mlevel == 4 OR chk_monitor($DBMemberID,$c) == 1 OR chk_moderator($DBMemberID,$f) == 1) {

if ($svc == "medals") {


		$query = "DELETE FROM " . $Prefix . "MEDALS WHERE MEDAL_ID = '$m' ";
		mysql_query($query, $connection) or die (mysql_error());


	                echo'<br><center>
	                <table width="99%" border="1">
	                   <tr class="normal">
	                       <td class="list_center" colSpan="10"><font size="5"><br>�� ��� ������ �����..</font><br><br>
	                       <meta http-equiv="Refresh" content="2; URL=index.php?mode=user_svc&method=svc&svc=medals&id='.$id.'&f='.$f.'&c='.$c.'">
	                       <a href="index.php?mode=svc">-- ���� ��� ������ ��� ������ ����� --</a><br><br>
                           <a href="index.php?mode=svc&method=svc&svc=medals&f='.$f.$cat_id.'">-- ���� ��� ������ ��� ������ ������� --</a><br><br>
	                       </td>
	                   </tr>
	                </table>
	                </center>';


}


}}

/*///////////////////////////////////////////////////////////////////////////////////////
//#####################################################################################//
//################################## MEDALS BY MR TAZI ################################//
//#####################################################################################//
///////////////////////////////////////////////////////////////////////////////////////*/

}
?>
