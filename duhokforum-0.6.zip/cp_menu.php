<?
/*//////////////////////////////////////////////////////////
// ######################################################///
// # DuhokForum 0.6                                     # //
// ###################################################### //
// #                                                    # //
// #       --  DUHOK FORUM IS FREE SOFTWARE  --         # //
// #                                                    # //
// #   ========= Programming By Dilovan ==============  # //
// # Copyright � 2007-2008 Dilovan. All Rights Reserved # //
// #----------------------------------------------------# //
// #----------------------------------------------------# //
// # If you want any support vist down address:-        # //
// # Email: df@duhoktimes.com                           # //
// # Site: http://df.duhoktimes.com/index.php           # //
// ###################################################### //
//////////////////////////////////////////////////////////*/

include("check.php");

?>
<html dir="rtl">
<head>
<title></title>
<meta http-equiv="Content-Type" content="text/html; charset=windows-1256">
<meta content="DUHOK FORUM 1.0: Copyright (C) 2007-2008 Dilovan." name="copyright">
<link href="<? print $admin_folder; ?>/cp_styles/cp_style_green.css" type="text/css" rel="stylesheet">
<script type="text/javascript">
	function set_cp_title()
	{
		parent.document.title = ("DUHOK FORUM - "+parent.document.title);
	}
</script>
</head>
<body bgcolor="#ddffdd" onload="set_cp_title();" leftMargin="0" topMargin="0" marginheight="0" marginwidth="0">


<table background="<? print $admin_folder; ?>/cp_styles/bg_green.jpg" cellspacing="0" cellpadding="0" width="100%" border="0">
  <tr>
    <td height="80" valign="top"><img title="���� ������ ������" alt="" hspace=0 src="<? print $admin_folder; ?>/images/cp_logo.gif" vspace=0 border=0></td>
  </tr>
  <tr>
    <td valign="top" align="middle" height="50"><font face="tahoma" color="black" size="2">DUHOK FORUM <? print $forum_version; ?><br><font style="FONT-WEIGHT: normal; FONT-SIZE: 11px">Programming By Dilovan</font></font></td>
  </tr>
</table>

<table cellspacing="0" cellpadding="0" width="100%" border="0">
  <tr>
    <td>
    <div class="menu">
    <script src="<? print $admin_folder; ?>/javascript.js" type="text/javascript"></script>
    
    <script type="text/javascript">
    	function open_close_group(group, doOpen)
	{
		var curdiv = fetch_object("group_" + group);
		var curbtn = fetch_object("button_" + group);

		if (doOpen)
		{
			curdiv.style.display = "";
			curbtn.src = "<? print $admin_folder; ?>/images/cp_collapse.gif";
			curbtn.title = "����� �������";
		}
		else
		{
			curdiv.style.display = "none";
			curbtn.src = "<? print $admin_folder; ?>/images/cp_expand.gif";
			curbtn.title = "��� �������";
		}

	}
    </script>
    
      <a name="GroupDuhokForum_0"></a>
      <table class="navtitle" ondblclick="toggle_group('DuhokForum_0'); return false;" cellSpacing="0" cellPadding="0" width="100%" border="0">
        <tr>
          <td><font color="#ffffff"><strong>������� �������</strong></font></td>
          <td align="left">
    	  <a oncontextmenu="toggle_group('DuhokForum_0'); save_group_prefs('DuhokForum_0'); return false" onclick="toggle_group('DuhokForum_0'); return false;" href="index.php?id=DuhokForum_0#GroupDuhokForum_0" target="_self">
	      <img id="button_DuhokForum_0" title="��� �������" alt="" src="<? print $admin_folder; ?>/images/cp_expand.gif" border="0"></a>
	      </td>
        </tr>
      </table>
      <div class="navgroup" id="group_DuhokForum_0" style="DISPLAY: none">
        <div class="navlink-normal" onmouseover="this.className='navlink-hover';" onclick="nav_goto('cp_home.php?mode=option');" onmouseout="this.className='navlink-normal'">
        <a class="menu" href="javascript:nav_goto('cp_home.php?mode=option');">������� ��������</a>
        </div>
        <div class="navlink-normal" onmouseover="this.className='navlink-hover';" onclick="nav_goto('cp_home.php?mode=option&method=other');" onmouseout="this.className='navlink-normal'">
        <a class="menu" href="javascript:nav_goto('cp_home.php?mode=option&method=other');">������� ����</a>
        </div>
        <div class="navlink-normal" onmouseover="this.className='navlink-hover';" onclick="nav_goto('cp_home.php?mode=option&method=editor');" onmouseout="this.className='navlink-normal'">
        <a class="menu" href="javascript:nav_goto('cp_home.php?mode=option&method=editor');">������� ������</a>
        </div>
        <div class="navlink-normal" onmouseover="this.className='navlink-hover';" onclick="nav_goto('cp_home.php?mode=option&method=files');" onmouseout="this.className='navlink-normal'">
        <a class="menu" href="javascript:nav_goto('cp_home.php?mode=option&method=files');">������� �������</a>
        </div>
      </div>

      <a name="GroupDuhokForum_1"></a>
      <table class="navtitle" ondblclick="toggle_group('DuhokForum_1'); return false;" cellSpacing="0" cellPadding="0" width="100%" border="0">
        <tr>
          <td><font color="#ffffff"><strong>������� ������</strong></font></td>
          <td align="left">
    	  <a oncontextmenu="toggle_group('DuhokForum_1'); save_group_prefs('DuhokForum_1'); return false" onclick="toggle_group('DuhokForum_1'); return false;" href="index.php?id=DuhokForum_1#GroupDuhokForum_1" target="_self">
	      <img id="button_DuhokForum_1" title="��� �������" alt="" src="<? print $admin_folder; ?>/images/cp_expand.gif" border="0"></a>
	      </td>
        </tr>
      </table>
      <div class="navgroup" id="group_DuhokForum_1" style="DISPLAY: none">
        <div class="navlink-normal" onmouseover="this.className='navlink-hover';" onclick="nav_goto('cp_home.php?mode=style');" onmouseout="this.className='navlink-normal'">
        <a class="menu" href="javascript:nav_goto('cp_home.php?mode=style');">������ �����</a>
        </div>
        <div class="navlink-normal" onmouseover="this.className='navlink-hover';" onclick="nav_goto('cp_home.php?mode=lang');" onmouseout="this.className='navlink-normal'">
        <a class="menu" href="javascript:nav_goto('cp_home.php?mode=lang');">������ ���</a>
        </div>
      </div>
      
      <a name="GroupDuhokForum_4"></a>
      <table class="navtitle" ondblclick="toggle_group('DuhokForum_4'); return false;" cellSpacing="0" cellPadding="0" width="100%" border="0">
        <tr>
          <td><font color="#ffffff"><strong>������ ���������</strong></font></td>
          <td align="left">
    	  <a oncontextmenu="toggle_group('DuhokForum_4'); save_group_prefs('DuhokForum_4'); return false" onclick="toggle_group('DuhokForum_4'); return false;" href="index.php?id=DuhokForum_4#GroupDuhokForum_4" target="_self">
	      <img id="button_DuhokForum_4" title="��� �������" alt="" src="<? print $admin_folder; ?>/images/cp_expand.gif" border="0"></a>
	      </td>
        </tr>
      </table>
      <div class="navgroup" id="group_DuhokForum_4" style="DISPLAY: none">
        <div class="navlink-normal" onmouseover="this.className='navlink-hover';" onclick="nav_goto('cp_home.php?mode=permission&method=mon');" onmouseout="this.className='navlink-normal'">
        <a class="menu" href="javascript:nav_goto('cp_home.php?mode=permission&method=mon');">�������</a>
        </div>
        <div class="navlink-normal" onmouseover="this.className='navlink-hover';" onclick="nav_goto('cp_home.php?mode=permission&method=mod');" onmouseout="this.className='navlink-normal'">
        <a class="menu" href="javascript:nav_goto('cp_home.php?mode=permission&method=mod');">������</a>
        </div>
        <div class="navlink-normal" onmouseover="this.className='navlink-hover';" onclick="nav_goto('cp_home.php?mode=permission&method=mem');" onmouseout="this.className='navlink-normal'">
        <a class="menu" href="javascript:nav_goto('cp_home.php?mode=permission&method=mem');">�������</a>
        </div>
        <div class="navlink-normal" onmouseover="this.className='navlink-hover';" onclick="nav_goto('cp_home.php?mode=permission&method=bad');" onmouseout="this.className='navlink-normal'">
        <a class="menu" href="javascript:nav_goto('cp_home.php?mode=permission&method=bad');">���������</a>
        </div>
      </div>

      <a name="GroupDuhokForum_2"></a>
      <table class="navtitle" ondblclick="toggle_group('DuhokForum_2'); return false;" cellSpacing="0" cellPadding="0" width="100%" border="0">
        <tr>
          <td><font color="#ffffff"><strong>����� ��������</strong></font></td>
          <td align="left">
    	  <a oncontextmenu="toggle_group('DuhokForum_2'); save_group_prefs('DuhokForum_2'); return false" onclick="toggle_group('DuhokForum_2'); return false;" href="index.php?id=DuhokForum_2#GroupDuhokForum_2" target="_self">
	      <img id="button_DuhokForum_2" title="��� �������" alt="" src="<? print $admin_folder; ?>/images/cp_expand.gif" border="0"></a>
	      </td>
        </tr>
      </table>
      <div class="navgroup" id="group_DuhokForum_2" style="DISPLAY: none">
        <div class="navlink-normal" onmouseover="this.className='navlink-hover';" onclick="nav_goto('cp_home.php?mode=ranks&type=stars');" onmouseout="this.className='navlink-normal'">
        <a class="menu" href="javascript:nav_goto('cp_home.php?mode=ranks&type=stars');">����� �������</a>
        </div>
        <div class="navlink-normal" onmouseover="this.className='navlink-hover';" onclick="nav_goto('cp_home.php?mode=ranks&type=colors');" onmouseout="this.className='navlink-normal'">
        <a class="menu" href="javascript:nav_goto('cp_home.php?mode=ranks&type=colors');">����� ����</a>
        </div>
      </div>
      
      <a name="GroupDuhokForum_3"></a>
      <table class="navtitle" ondblclick="toggle_group('DuhokForum_3'); return false;" cellSpacing="0" cellPadding="0" width="100%" border="0">
        <tr>
          <td><font color="#ffffff"><strong>�������</strong></font></td>
          <td align="left">
    	  <a oncontextmenu="toggle_group('DuhokForum_3'); save_group_prefs('DuhokForum_3'); return false" onclick="toggle_group('DuhokForum_3'); return false;" href="index.php?id=DuhokForum_3#GroupDuhokForum_3" target="_self">
	      <img id="button_DuhokForum_3" title="��� �������" alt="" src="<? print $admin_folder; ?>/images/cp_expand.gif" border="0"></a>
	      </td>
        </tr>
      </table>
      <div class="navgroup" id="group_DuhokForum_3" style="DISPLAY: none">
        <div class="navlink-normal" onmouseover="this.className='navlink-hover';" onclick="nav_goto('cp_home.php?mode=phpinfo');" onmouseout="this.className='navlink-normal'">
        <a class="menu" href="javascript:nav_goto('cp_home.php?mode=phpinfo');">������� PHP</a>
        </div>
      </div>
	        
    </div>
    </td>
  </tr>
</table>
</body>
</html>
