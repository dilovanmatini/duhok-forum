<?
/*//////////////////////////////////////////////////////////
// ######################################################///
// # DuhokForum 0.6                                     # //
// ###################################################### //
// #                                                    # //
// #       --  DUHOK FORUM IS FREE SOFTWARE  --         # //
// #                                                    # //
// #   ========= Programming By Dilovan ==============  # //
// # Copyright � 2007-2008 Dilovan. All Rights Reserved # //
// #----------------------------------------------------# //
// #----------------------------------------------------# //
// # If you want any support vist down address:-        # //
// # Email: df@duhoktimes.com                           # //
// # Site: http://df.duhoktimes.com/index.php           # //
// ###################################################### //
//////////////////////////////////////////////////////////*/

if ($f == "") {
 redirect();
}

$forum_hide = forums("HIDE", $f);
$check_forum_login = check_forum_login($f);
if ($forum_hide == 1){
	if ($check_forum_login == 0){
		redirect();
	}
}

require_once("./include/forum_function.php");

//################## paging ####################################################
echo' 
<script language="JavaScript" type="text/javascript">
	function goto_pg(){
		var pg = pg_form.pg_num.value;
		var f_id = pg_form.pg_f_id.value;
		window.location = "index.php?mode=f&f="+f_id+"&pg="+pg;
	}
</script>';

if (!isset($pg) OR empty($pg)){
	$pg = 1;
}
$pg_limit = (($pg * $max_page) - $max_page);
$pg_sql = mysql_result(mysql_query("SELECT COUNT(TOPIC_ID) FROM ".$Prefix."TOPICS WHERE FORUM_ID = '$f'"),0);
$pg_col = ceil($pg_sql / $max_page);
function paging() {
	global $f, $lang, $pg_col, $pg;
	echo '
	<form name="pg_form">
	<input type="hidden" name="pg_f_id" value="'.$f.'">
	<td class="optionsbar_menus"><b>'.$lang['forum']['page'].'&nbsp;:</b>
		<select class="forumSelect" name="pg_num" size="1" onchange="goto_pg();">';
        for($i = 1; $i <= $pg_col; $i++) {
			echo '<option value="'.$i.'" '.check_select($pg, $i).'>'.$i.'&nbsp;'.$lang['forum']['from'].'&nbsp;'.$pg_col.'</option>';
        }
		echo '
		</select>
	</td>
	</form>';
}
//################## paging ####################################################

$cat_id = forums("CAT_ID", $f);
$f_subject = forums("SUBJECT", $f);
$f_logo = forums("LOGO", $f);

$allowed = allowed($f, 2);

echo'
<center>
<table cellSpacing="0" cellPadding="0" width="99%" border="0">
	<tr>
		<td>
		<table cellSpacing="2" width="100%" border="0">
			<tr>
				<td><a class="menu" href="index.php?mode=finfo&f='.$f.'">'.icons($f_logo, "������� �� �������").'</a></td>
				<td class="main" vAlign="center" width="100%"><a class="menu" href="index.php?mode=f&f='.$f.'"><font color="red" size="+1">'.$f_subject.'</font></a><font size="-1">'.forum_mods($f).'</font></td>
				<td class="optionsbar_menus"><nobr><a href="index.php?mode=editor&method=topic&f='.$f.'&c='.$cat_id.'">'.icons($folder_new).'<br>'.$lang['forum']['new_topic'].'</a></nobr></td>
				<td class="optionsbar_menus"><nobr><a href="index.php?mode=editor&method=sendmsg&m='.abs2($f).'">'.$lang['forum']['send_message_to_forum'].'</a></nobr></td>';
			if ($allowed == 1){
				echo'
				<td class="optionsbar_menus"><nobr><a href="index.php?mode=pm&mail=in&m='.abs2($f).'&c='.$cat_id.'">'.forum_new_mail($f).$lang['forum']['forum_mail'].'</a></nobr></td>';
			}
			if (allowed($f, 2) == 1){
				echo'
				<td class="optionsbar_menus"><nobr><a href="index.php?mode=mf&f='.$f.'">�����<br>�������</a></nobr></td>';
			}
				order_by();
				refresh_time();
				if ($pg_sql > 0){
					paging();
				}
				go_to_forum();
			echo'
			</tr>
		</table>';
		$fl_sql = mysql_query("SELECT * FROM ".$Prefix."TOPICS WHERE T_LINKFORUM > '0' AND FORUM_ID = '$f' ") or die (mysql_error()); // category mysql
		$fl_num = mysql_num_rows($fl_sql);
		if ($fl_num > 0) {
			echo'
			<table>
				<tr>';
				$fl_i = 0;
				while ($fl_i < $fl_num) {
					$fl_topic_id = mysql_result($fl_sql, $fl_i, "TOPIC_ID");
					$fl_t_subject = topics("SUBJECT", $fl_topic_id);
					$fl_t_link = topics("LINKFORUM", $fl_topic_id);
					
					if ($fl_t_link == 1){
						$td_class = "extras2";
					}
					if ($fl_t_link == 2){
						$td_class = "extras";
					}
					echo'<td class="'.$td_class.'"><nobr><a href="index.php?mode=t&t='.$fl_topic_id.'">'.$fl_t_subject.'</a></nobr></td>';
						
				++$fl_i;
				}
				echo'
				</tr>
			</table>';
		}

		echo'
		<table class="grid" cellSpacing="0" cellPadding="0" width="100%" align="center" border="0">
			<tr>
				<td>
				<table cellSpacing="1" cellPadding="2" width="100%" border="0">
					<tr>
						<td class="cat" width="55%"  colSpan="2">'.$lang['forum']['topics'].'</td>
						<td class="cat" width="12%">'.$lang['forum']['author'].'</td>
						<td class="cat" width="8%">'.$lang['forum']['posts'].'</td>
						<td class="cat" width="8%">'.$lang['forum']['reads'].'</td>
						<td class="cat" width="12%">'.$lang['forum']['last_post'].'</td>';
					if ($Mlevel > 0){	
						echo'
						<td class="cat" width="4%">'.$lang['forum']['options'].'</td>';
					}	
					echo'
					</tr>';

				if ($order_by == "post"){
					$order_by_date = "T_LAST_POST_DATE DESC, T_DATE DESC";
				}
				else if ($order_by == "topic"){
					$order_by_date = "T_DATE DESC, T_LAST_POST_DATE DESC";
				}
				else{
					$order_by_date = "T_LAST_POST_DATE DESC, T_DATE DESC";
				}					
					
				$topics = mysql_query("SELECT * FROM ".$Prefix."TOPICS WHERE CAT_ID = '$cat_id' AND FORUM_ID = '$f' ORDER BY T_STICKY DESC, ".$order_by_date." LIMIT $pg_limit, $max_page") or die (mysql_error());
				$t_num = mysql_num_rows($topics);
				if ($t_num <= 0) {
					echo'
					<tr>
						<td class="f1" vAlign="center" align="middle" colspan="20"><br><br>'.$lang['forum']['not_topics'].'<br><br><br></td>
					</tr>';
				}
				
				$t_i = 0;
				while ($t_i < $t_num) {
					$topic_id = mysql_result($topics, $t_i, "TOPIC_ID");
					$t_hidden = topics("HIDDEN", $topic_id);
					$t_sticky = topics("STICKY", $topic_id);
					$t_author = topics("AUTHOR", $topic_id);
					
					if ($t_hidden == 1){
						$tr_class = "deleted";
					}
					else{
						if ($t_sticky == 1) {
							$tr_class = "fixed";
						}
						else{
							$tr_class = "normal";
						}
					}
					
					if (($t_hidden == 0) OR ($t_hidden == 1 AND $allowed == 1) OR ($t_hidden == 1 AND $t_author == $DBMemberID)){
						forum_func($topic_id);
					}
				++$t_i;	
				}	
				echo'
				</table>
				</td>
			</tr>
		</table>
		</td>
	</tr>
</table>
</center>';

?>
