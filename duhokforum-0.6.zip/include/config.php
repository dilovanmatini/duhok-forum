<?php
/*//////////////////////////////////////////////////////////
// ######################################################///
// # DuhokForum 0.6                                     # //
// ###################################################### //
// #                                                    # //
// #       --  DUHOK FORUM IS FREE SOFTWARE  --         # //
// #                                                    # //
// #   ========= Programming By Dilovan ==============  # //
// # Copyright � 2007-2008 Dilovan. All Rights Reserved # //
// #----------------------------------------------------# //
// #----------------------------------------------------# //
// # If you want any support vist down address:-        # //
// # Email: df@duhoktimes.com                           # //
// # Site: http://df.duhoktimes.com/index.php           # //
// ###################################################### //
//////////////////////////////////////////////////////////*/

require("connect.php");

$forum_title = open_mysql("FORUM_TITLE");
$site_name = open_mysql("SITE_ADDRESS");
$copy_right = open_mysql("COPY_RIGHT");
$image_folder = open_mysql("IMAGE_FOLDER");
$max_page = open_mysql("PAGE_NUMBER");
$admin_folder = open_mysql("ADMIN_FOLDER");
$admin_email = open_mysql("ADMIN_EMAIL");
$forum_version = open_mysql("FORUM_VERSION");
$author_script = open_mysql("AUTHOR_SCRIPT");
$total_pm_message = open_mysql("TOTAL_PM_MSG");
$mod_add_titles = open_mysql("MOD_ADD_TITLES");
$mod_add_medals = open_mysql("MOD_ADD_MEDALS");
$topic_max_size = open_mysql("TOPIC_MAX_SIZE");
$reply_max_size = open_mysql("REPLY_MAX_SIZE");
$pm_max_size = open_mysql("PM_MAX_SIZE");
$sig_max_size = open_mysql("SIG_MAX_SIZE");
$default_language = open_mysql("DEFAULT_LANGUAGE");
$default_style = open_mysql("DEFAULT_STYLE");
$forum_url = open_mysql("FORUM_URL");

$show_admin_info = open_mysql("SHOW_ADMIN_INFO");
$change_name_max = open_mysql("CHANGE_NAME_MAX");
$changename_dayslimit = open_mysql("CHANGENAME_DAYSLIMIT");
$show_moderators = open_mysql("SHOW_MODERATORS");
$Files_Max_Size = open_mysql("FILES_MAX_SIZE");
$Files_Max_Allowed = open_mysql("FILES_MAX_ALLOWED");
$help_forum = open_mysql("HELP_FORUM");
$show_alexa_traffic = open_mysql("SHOW_ALEXA_TRAFFIC");
$register_waitting = open_mysql("REGISTER_WAITTING");
$show_medals_in_posts = open_mysql("SHOW_MEDALS_IN_POSTS");

$Title = array(
	open_mysql("TITLE_0"),
	open_mysql("TITLE_1"),
	open_mysql("TITLE_2"),
	open_mysql("TITLE_3"),
	open_mysql("TITLE_4"),
	open_mysql("TITLE_5"),
	open_mysql("TITLE_6"),
	open_mysql("TITLE_7"),
	open_mysql("TITLE_8"),
	open_mysql("TITLE_9"),
	open_mysql("TITLE_10"),
	open_mysql("TITLE_11"),
	open_mysql("TITLE_12"),
	open_mysql("TITLE_13")
);

$StarsNomber = array(
	open_mysql("STARS_NUMBER_0"),
	open_mysql("STARS_NUMBER_1"),
	open_mysql("STARS_NUMBER_2"),
	open_mysql("STARS_NUMBER_3"),
	open_mysql("STARS_NUMBER_4"),
	open_mysql("STARS_NUMBER_5"),
	open_mysql("STARS_NUMBER_6"),
	open_mysql("STARS_NUMBER_7"),
	open_mysql("STARS_NUMBER_8"),
	open_mysql("STARS_NUMBER_9"),
	open_mysql("STARS_NUMBER_10")
);

$StarsColor=array(
	open_mysql("MLV_STARS_COLOR_0"),
	open_mysql("MLV_STARS_COLOR_1"),
	open_mysql("MLV_STARS_COLOR_2"),
	open_mysql("MLV_STARS_COLOR_3"),
	open_mysql("MLV_STARS_COLOR_4")
);

//####### editor  ##############

$editor_full_html = open_mysql("EDITOR_FULL_HTML");
$editor_width = open_mysql("EDITOR_WIDTH");
$editor_height = open_mysql("EDITOR_HEIGHT");

$EditorIcon=array(
	open_mysql("EDITOR_ICON_SAVE"),
	open_mysql("EDITOR_ICON_PRINT"),
	open_mysql("EDITOR_ICON_ZOOM"),
	open_mysql("EDITOR_ICON_STYLE"),
	open_mysql("EDITOR_ICON_PARAGRAPH"),
	open_mysql("EDITOR_ICON_FONT_NAME"),
	open_mysql("EDITOR_ICON_SIZE"),
	open_mysql("EDITOR_ICON_TEXT"),
	open_mysql("EDITOR_ICON_SELECT_ALL"),
	open_mysql("EDITOR_ICON_CUT"),
	open_mysql("EDITOR_ICON_COPY"),
	open_mysql("EDITOR_ICON_PASTE"),
	open_mysql("EDITOR_ICON_UNDO"),
	open_mysql("EDITOR_ICON_REDO"),
	open_mysql("EDITOR_ICON_BOLD"),
	open_mysql("EDITOR_ICON_ITALIC"),
	open_mysql("EDITOR_ICON_UNDER_LINE"),
	open_mysql("EDITOR_ICON_STRIKE"),
	open_mysql("EDITOR_ICON_SUPER_SCRIPT"),
	open_mysql("EDITOR_ICON_SUB_SCRIPT"),
	open_mysql("EDITOR_ICON_SYMBOL"),
	open_mysql("EDITOR_ICON_LEFT"),
	open_mysql("EDITOR_ICON_CENTER"),
	open_mysql("EDITOR_ICON_RIGHT"),
	open_mysql("EDITOR_ICON_FULL"),
	open_mysql("EDITOR_ICON_NUBERING"),
	open_mysql("EDITOR_ICON_BULLETS"),
	open_mysql("EDITOR_ICON_INDENT"),
	open_mysql("EDITOR_ICON_OUTDENT"),
	open_mysql("EDITOR_ICON_IMAGE"),
	open_mysql("EDITOR_ICON_COLOR"),
	open_mysql("EDITOR_ICON_BGCOLOR"),
	open_mysql("EDITOR_ICON_EX_LINK"),
	open_mysql("EDITOR_ICON_IN_LINK"),
	open_mysql("EDITOR_ICON_ASSET"),
	open_mysql("EDITOR_ICON_TABLE"),
	open_mysql("EDITOR_ICON_SHOW_BORDER"),
	open_mysql("EDITOR_ICON_ABSOLUTE"),
	open_mysql("EDITOR_ICON_CLEAN"),
	open_mysql("EDITOR_ICON_LINE"),
	open_mysql("EDITOR_ICON_PROPERTIES"),
	open_mysql("EDITOR_ICON_WORD")
);

//####### editor  ##############

?>
