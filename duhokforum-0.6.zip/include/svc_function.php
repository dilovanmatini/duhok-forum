<?php
/*//////////////////////////////////////////////////////////
// ######################################################///
// # DuhokForum 0.6                                     # //
// ###################################################### //
// #                                                    # //
// #       --  DUHOK FORUM IS FREE SOFTWARE  --         # //
// #                                                    # //
// #   ========= Programming By Dilovan ==============  # //
// # Copyright � 2007-2008 Dilovan. All Rights Reserved # //
// #----------------------------------------------------# //
// #----------------------------------------------------# //
// # If you want any support vist down address:-        # //
// # Email: df@duhoktimes.com                           # //
// # Site: http://df.duhoktimes.com/index.php           # //
// ###################################################### //
//////////////////////////////////////////////////////////*/

function chk_global_medals_get(){
	if (app == ""){
		$app = "ok";
	}
	else{
		$app = app;
	}
	if (scope == ""){
		$scope = "mod";
	}
	else{
		$scope = scope;
	}
	if ($scope == "mod"){
		$scope_sql = " AND FORUM_ID IN (".chk_allowed_forums_all_id().")";
	}
	if ($scope == "own"){
		$scope_sql = " AND ADDED = '".m_id."'";
	}
	if ($scope == "all"){
		$scope_sql = "";
	}
	if ($app == "design"){
		$sql = "WHERE STATUS = '2' AND CLOSE = '0'".$scope_sql;
	}
	if ($app == "wait"){
		$sql = "WHERE STATUS = '0' AND CLOSE = '0'".$scope_sql;
	}
	if ($app == "ok"){
		$sql = "WHERE STATUS = '1' AND CLOSE = '0'".$scope_sql;
	}
	if ($app == "closed"){
		$sql = "WHERE CLOSE = '1'".$scope_sql;
	}
return($sql);
}

function chk_global_titles_get(){
	if (app == ""){
		$app = "ok";
	}
	else{
		$app = app;
	}
	if (scope == ""){
		$scope = "mod";
	}
	else{
		$scope = scope;
	}
	if ($scope == "mod"){
		$scope_sql = "AND FORUM_ID IN (".chk_allowed_forums_all_id().")";
	}
	if ($scope == "own"){
		$scope_sql = "AND ADDED = '".m_id."'";
	}
	if ($scope == "all"){
		$scope_sql = "";
	}
	if ($app == "design"){
		$sql = "WHERE STATUS = '2' AND CLOSE = '0' ".$scope_sql;
	}
	if ($app == "wait"){
		$sql = "WHERE STATUS = '0' AND CLOSE = '0' ".$scope_sql;
	}
	if ($app == "ok"){
		$sql = "WHERE STATUS = '1' AND CLOSE = '0' ".$scope_sql;
	}
	if ($app == "closed"){
		$sql = "WHERE CLOSE = '1' ".$scope_sql;
	}
	if ($app == "all"){
		$sql = "WHERE TITLE_ID > '0' ".$scope_sql;
	}
return($sql);
}

function chk_medals_get(){
	$app = app;
	$scope = scope;
	$days = days;
	$m = m;
	$id = id;
	if (empty($scope)){
		$scope = "mod";
	}
	else{
		$scope = $scope;
	}
	if (empty($app)){
		$app = "ok";
	}
	else{
		$app = $app;
	}
	if (empty($days)){
		$days = 30;
	}
	else{
		$days = $days;
	}

	if ($id > 0){
		$id_sql = "AND GM_ID = '$id'";
	}
	if ($m > 0){
		$m_sql = "AND MEMBER_ID = '$m'";
	}

	if ($scope == "mod"){
		$scope_sql = "AND FORUM_ID IN (".chk_allowed_forums_all_id().")";
	}
	if ($scope == "own"){
		$scope_sql = "AND ADDED = '".m_id."'";
	}
	if ($scope == "all"){
		$scope_sql = "";
	}

	if ($days == 30){
		$days_sql = "AND DATE > '".before_days(30)."'";
	}
	if ($days == 60){
		$days_sql = "AND DATE > '".before_days(60)."'";
	}
	if ($days == 180){
		$days_sql = "AND DATE > '".before_days(180)."'";
	}
	if ($days == 365){
		$days_sql = "AND DATE > '".before_days(365)."'";
	}
	if ($days == "all"){
		$days_sql = "";
	}

	if ($app == "wait"){
		$sql = "WHERE STATUS = '0' ".$scope_sql." ".$days_sql;
	}
	if ($app == "ok"){
		$sql = "WHERE STATUS = '1' ".$scope_sql." ".$days_sql;
	}
	if ($app == "ref"){
		$sql = "WHERE STATUS = '2' ".$scope_sql." ".$days_sql;
	}
	if ($app == "all"){
		if (!empty($scope_sql) OR !empty($days_sql)){
			$sql = "WHERE MEDAL_ID > '0' ".$scope_sql." ".$days_sql." ".$id_sql." ".$m_sql;
		}
		else{
			if (!empty($id) OR !empty($m)){
				$sql = "WHERE MEDAL_ID > '0' ".$id_sql." ".$m_sql;
			}
			else{
				$sql = "";
			}
		}
	}

return($sql);
}

function chk_surveys_get(){
	$app = app;
	if (empty($app)){
		$app = "running";
	}
	else{
		$app = $app;
	}

	if ($app == "running"){
		$sql = "WHERE STATUS = '1' AND END > '".time()."' AND FORUM_ID IN (".chk_allowed_forums_all_id().") ";
	}
	if ($app == "ended"){
		$sql = "WHERE STATUS = '1' AND END < '".time()."' AND FORUM_ID IN (".chk_allowed_forums_all_id().") ";
	}
	if ($app == "closed"){
		$sql = "WHERE STATUS = '0' AND FORUM_ID IN (".chk_allowed_forums_all_id().") ";
	}
	if ($app == "all"){
		$sql = "WHERE FORUM_ID IN (".chk_allowed_forums_all_id().") ";
	}
return($sql);
}

function forum_medal_count($f){
	$sql = mysql_query("SELECT count(*) FROM ".prefix."GLOBAL_MEDALS WHERE FORUM_ID = '$f' AND STATUS = '1' AND CLOSE = '0' ") or die(mysql_error());
	$count = mysql_result($sql, 0, "count(*)");
return($count);
}

function forum_title_count($f){
	$sql = mysql_query("SELECT count(*) FROM ".prefix."GLOBAL_TITLES WHERE FORUM_ID = '$f' AND STATUS = '1' AND CLOSE = '0' ") or die(mysql_error());
	$count = mysql_result($sql, 0, "count(*)");
return($count);
}

function chk_add_titles($t, $m){
	$sql = mysql_query("SELECT * FROM ".prefix."TITLES WHERE GT_ID = '$t' AND MEMBER_ID = '$m' AND STATUS = '1' ") or die(mysql_error());
	if (mysql_num_rows($sql) > 0){
		$chk = 1;
	}
	else{
		$chk = 0;
	}
return($chk);
}

function chk_member_last_medal($m){
	$sql = mysql_query("SELECT * FROM ".prefix."MEDALS WHERE MEMBER_ID = '$m' AND STATUS = '1' ORDER BY DATE DESC ") or die(mysql_error());
	if (mysql_num_rows($sql) > 0){
		$rs = mysql_fetch_array($sql);
		$chk = $rs['MEDAL_ID'];
	}
	else{
		$chk = 0;
	}
return($chk);
}

function svc_show_global_medals($id){
	global $icon_trash, $icon_folder_archive, $icon_question;
	$f = gm("FORUM_ID", $id);
	$subject = gm("SUBJECT", $id);
	$url = gm("URL", $id);
	$days = gm("DAYS", $id);
	$status = gm("STATUS", $id);
	$close = gm("CLOSE", $id);
	$points = gm("POINTS", $id);
	$added = gm("ADDED", $id);
	$date = gm("DATE", $id);

	if ($status == 1){
		$mon_app = "<font color=\"cyan\">���</font>";
	}
	else{
		$mon_app = "<font color=\"yellow\">��</font>";
	}

	if (allowed($f, 2) == 1){
		$medals_icon = '<a href="index.php?mode=svc&method=edit&svc=medals&m='.$id.'">'.icons($icon_folder_archive, "����� ������", " hspace=\"3\"").'</a>';
		$medals_icon .= '<a href="index.php?mode=svc&svc=medals&app=all&scope=all&days=all&id='.$id.'">'.icons($icon_question, "������� ������", " hspace=\"3\"").'</a>';
	}
	else{
		$medals_icon = "-";
	}

	if (allowed($f, 1) == 1 AND $status != 1){
		$app_box = '<input class="small" type="checkbox" name="m_app[]" value="'.$id.'">';
	}
	else{
		$app_box = " - ";
	}

		echo'
		<tr>';
		if (mlv > 2){
			echo'
			<td class="stats_p" align="center"><nobr>'.$app_box.'</nobr></td>';
		}
			echo'
			<td class="stats_h"><nobr>'.$id.'</nobr></td>
			<td class="stats_p"><font size="-1" color="red">'.$subject.'</font></td>
			<td class="stats_p"><a target="plaquepreview" href="'.$url.'">'.icons($url, "", " height=\"33\" width=\"33\"").'</a></td>
			<td class="stats_h"><font color="#aaaaff">'.$points.'</font></td>
			<td class="stats_h"><font color="yellow">'.$mon_app.'</font></td>
			<td class="stats_p"><font color="red">'.forums("SUBJECT", $f).'</font></td>
			<td class="stats_h"><font color="#aaaaff">'.$days.'</font></td>
			<td class="stats_g"><nobr><a href="index.php?mode=profile&id='.$added.'"><font color="#ffffff">'.members("NAME", $added).'</font></a></nobr></td>
			<td class="stats_p" align="middle"><nobr>'.$medals_icon.'</nobr></td>
		</tr>';
}

function svc_award_global_medals($id){
	global $m;
	$f = gm("FORUM_ID", $id);
	$subject = gm("SUBJECT", $id);
	$url = gm("URL", $id);
	$days = gm("DAYS", $id);
	$status = gm("STATUS", $id);
	$close = gm("CLOSE", $id);
	$points = gm("POINTS", $id);
	$added = gm("ADDED", $id);
	$date = gm("DATE", $id);

		echo'
		<tr>
			<td class="stats_h"><nobr>'.$id.'</nobr></td>
			<td class="stats_p"><font size="-1">'.$subject.'</font></td>
			<td class="stats_p"><a target="plaquepreview" href="'.$url.'">'.icons($url, "", "height=\"33\" width=\"33\"").'</a></td>
			<td class="stats_h"><font color="#aaaaff">'.$points.'</font></td>
			<td class="stats_p"><font color="red">'.forums("SUBJECT", $f).'</font></td>
			<td class="stats_h"><font color="#aaaaff">'.$days.'</font></td>
			<td class="stats_g"><a href="index.php?mode=profile&id='.$added.'"><font color="#ffffff">'.members("NAME", $added).'</font></a></td>
			<td class="stats_p" align="middle"><nobr><a href="index.php?mode=svc&method=in&svc=medals&f='.$f.'&m='.$m.'&id='.$id.'">- ����� ������ -</a></nobr></td>
		</tr>';
}

function svc_show_medals($id){
	global $icon_folder_archive, $icon_question, $icon_camera, $app, $scope, $days;
	$f = medals("FORUM_ID", $id);
	$author = medals("MEMBER_ID", $id);
	$gm = medals("GM_ID", $id);
	$subject = gm("SUBJECT", $gm);
	$url = medals("URL", $id);
	$m_days = medals("DAYS", $id);
	$status = medals("STATUS", $id);
	$points = medals("POINTS", $id);
	$added = medals("ADDED", $id);
	$date = medals("DATE", $id);

	if ($status == 1){
		$mon_app = "<font color=\"cyan\">���</font>";
	}
	else{
		$mon_app = "<font color=\"yellow\">��</font>";
	}

	if (allowed($f, 2) == 1){
		$medals_icon = '<a href="index.php?mode=svc&svc=medals&app=all&scope=all&days=all&id='.$gm.'">'.icons($icon_question, "������� ������", " hspace=\"3\"").'</a>';
	}
	else{
		$medals_icon = "-";
	}

	if (allowed($f, 1) == 1 AND $status != 1){
		$app_box = '<input class="small" type="checkbox" name="m_app[]" value="'.$id.'">';
	}
	else{
		$app_box = " - ";
	}

	if (members("LEVEL", $author) == 1){
		$author_link = '<a href="index.php?mode=profile&id='.$author.'"><font color="#ffffff">'.members("NAME", $author).'</font></a>';
	}
	else{
		$author_link = link_profile(members("NAME", $author), $author);
	}
		echo'
		<tr>';
		if (mlv > 2){
			echo'
			<td class="stats_p" align="center"><nobr>'.$app_box.'</nobr></td>';
		}
			echo'
			<td class="stats_g"><nobr>'.$author_link.'</nobr></td>
			<td class="stats_p"><font color="red">'.normal_date($date).'</font></td>
			<td class="stats_p" align="middle"><font color="black">'.days_added($m_days, $date).'</font></td>
			<td class="stats_g"><font size="-1">'.$subject.'</font></td>
			<td class="stats_p"><a target="plaquepreview" href="'.$url.'">'.icons($icon_camera).'</a></td>
			<td class="stats_h">'.$points.'</td>';
		if ($app == "all"){
			echo'
			<td class="stats_h">'.$mon_app.'</td>';
		}
			echo'
			<td class="stats_p"><font color="red">'.forums("SUBJECT", $f).'</font></td>
			<td class="stats_g"><nobr><a href="index.php?mode=profile&id='.$added.'"><font color="#ffffff">'.members("NAME", $added).'</font></a></nobr></td>
			<td class="stats_p" align="middle"><nobr>'.$medals_icon.'</nobr></td>
		</tr>';
}

function svc_show_global_titles($t){
	global $icon_folder_archive, $icon_question;
	$f = gt("FORUM_ID", $t);
	$subject = gt("SUBJECT", $t);
	$status = gt("STATUS", $t);
	$close = gt("CLOSE", $t);
	$forum = gt("FORUM", $t);
	$added = gt("ADDED", $t);

	if ($forum == 1){
		$mon_app = "<font color=\"cyan\">���</font>";
	}
	else{
		$mon_app = "<font color=\"yellow\">��</font>";
	}

	if (allowed($f, 2) == 1){
		$medals_icon = '<a href="index.php?mode=svc&method=edit&svc=titles&t='.$t.'">'.icons($icon_folder_archive, "����� �����", " hspace=\"3\"").'</a>';
		$medals_icon .= '<a href="index.php?mode=svc&method=award&svc=titles&type=used&id='.$t.'">'.icons($icon_question, "������� �����", " hspace=\"3\"").'</a>';
	}
	else{
		$medals_icon = "-";
	}

	if (allowed($f, 1) == 1 AND $status != 1){
		$app_box = '<input class="small" type="checkbox" name="t_app[]" value="'.$t.'">';
	}
	else{
		$app_box = " - ";
	}

		echo'
		<tr>';
		if (mlv > 2){
			echo'
			<td class="stats_p" align="center"><nobr>'.$app_box.'</nobr></td>';
		}
			echo'
			<td class="stats_h"><nobr>'.$t.'</nobr></td>
			<td class="stats_p"><font size="-1" color="red">'.$subject.'</font></td>
			<td class="stats_h">'.$mon_app.'</td>
			<td class="stats_p"><font color="red">'.forums("SUBJECT", $f).'</font></td>
			<td class="stats_g"><nobr><a href="index.php?mode=profile&id='.$added.'"><font color="#ffffff">'.members("NAME", $added).'</font></a></nobr></td>
			<td class="stats_p" align="center"><nobr>'.$medals_icon.'</nobr></td>
		</tr>';
}

function svc_award_global_titles($id){
	global $m;
	$f = gt("FORUM_ID", $id);
	$subject = gt("SUBJECT", $id);
	$forum = gt("FORUM", $id);

	if ($forum == 1){
		$mon_app = "<font color=\"cyan\">���</font>";
	}
	else{
		$mon_app = "<font color=\"yellow\">��</font>";
	}

		echo'
		<tr>
			<td class="stats_h"><nobr>'.$id.'</nobr></td>
			<td class="stats_p"><font size="-1" color="red">'.$subject.'</font></td>
			<td class="stats_h">'.$mon_app.'</td>
			<td class="stats_p"><font color="red">'.forums("SUBJECT", $f).'</font></td>
			<td class="stats_p" align="middle"><nobr><a href="index.php?mode=svc&method=in&svc=titles&f='.$f.'&m='.$m.'&id='.$id.'">- ����� ����� -</a></nobr></td>
		</tr>';
}

function svc_show_titles($t){
	global $icon_trash, $icon_question;
	$gt_id = titles("GT_ID", $t);
	$member_id = titles("MEMBER_ID", $t);
	$subject = gt("SUBJECT", $gt_id);
	$f = gt("FORUM_ID", $gt_id);
	$forum = gt("FORUM", $gt_id);

	if ($status == 1){
		$mon_app = "<font color=\"cyan\">���</font>";
	}
	else{
		$mon_app = "<font color=\"yellow\">��</font>";
	}

	if (allowed($f, 2) == 1){
		$titles_icon = '<a href="index.php?mode=svc&method=award&svc=titles&type=history&m='.$member_id.'&t='.$gt_id.'">'.icons($icon_question, "����� ������� ����� ���� �����", " hspace=\"3\"").'</a>';
		$titles_icon .= '<a href="index.php?mode=svc&method=trash&svc=titles&t='.$t.'">'.icons($icon_trash, "����� ����� �� �����", " hspace=\"3\"").'</a>';
	}
	else{
		$titles_icon = "-";
	}
			echo'
			<tr>
				<td class="stats_h"><nobr>'.$t.'</nobr></td>
				<td class="stats_p"><font size="-1" color="red">'.$subject.'</font></td>
				<td class="stats_h">'.$mon_app.'</td>
				<td class="stats_p"><font color="red">'.forums("SUBJECT", $f).'</font></td>
				<td class="stats_p" align="center">'.$titles_icon.'</td>
			</tr>';
}

function svc_survey_value($v){
	$count = 0;
	for ($x = 0;$x < count($v); ++$x){
		if ($v[$x] != ""){
			$count = $count + 1;
		}
	}
return($count);
}

function svc_chk_survey_id($f, $subject, $question){
	$sql = mysql_query("SELECT * FROM ".prefix."SURVEYS WHERE FORUM_ID = '$f' AND SUBJECT = '$subject' AND QUESTION = '$question' ") or die(mysql_error());
	$rs = mysql_fetch_array($sql);
	$id = $rs['SURVEY_ID'];
return($id);
}

function svc_show_surveys($s){
	global $icon_folder_archive;
	$f = surveys("FORUM_ID", $s);
	$subject = surveys("SUBJECT", $s);
	$status = surveys("STATUS", $s);
	$secret = surveys("SECRET", $s);
	$days = surveys("DAYS", $s);
	$min_days = surveys("MIN_DAYS", $s);
	$min_posts = surveys("MIN_POSTS", $s);
	$added = surveys("ADDED", $id);
	$start = surveys("START", $s);
	$end = surveys("END", $s);
	if ($secret == 0){
		$secret_txt = '<font color="white">��� ���</font>';
	}
	if ($secret == 1){
		$secret_txt = '<font color="yellow">���</font>';
	}
			echo'
			<tr>
				<td class="stats_h"><nobr>'.$s.'</nobr></td>
				<td class="stats_g"><nobr>'.$subject.'</nobr></td>
				<td class="stats_p"><font color="red">'.forums("SUBJECT", $f).'</font></td>
				<td class="stats_g"><nobr>'.normal_date($start).'</nobr></td>
				<td class="stats_g"><nobr>'.normal_date($end).'</nobr></td>
				<td class="stats_h"><font color="white">'.$secret_txt.'</font></td>
				<td class="stats_h"><font color="#aaaaff">'.$min_posts.'</font></td>
				<td class="stats_h"><font color="#aaaaff">'.$min_days.'</font></td>
				<td class="stats_p" align="center"><nobr><a href="">'.icons($icon_folder_archive).'</a></nobr></td>
			</tr>';
}

function chk_add_member_to_topic($t, $m){
	$sql = mysql_query("SELECT * FROM ".prefix."TOPIC_MEMBERS WHERE TOPIC_ID = '$t' AND MEMBER_ID = '$m' ") or die(mysql_error());
	if (mysql_num_rows($sql) > 0){
		$chk = 1;
	}
	else{
		$chk = 0;
	}
return($chk);
}
?>
