<?
/*//////////////////////////////////////////////////////////
// ######################################################///
// # DuhokForum 0.6                                     # //
// ###################################################### //
// #                                                    # //
// #       --  DUHOK FORUM IS FREE SOFTWARE  --         # //
// #                                                    # //
// #   ========= Programming By Dilovan ==============  # //
// # Copyright � 2007-2008 Dilovan. All Rights Reserved # //
// #----------------------------------------------------# //
// #----------------------------------------------------# //
// # If you want any support vist down address:-        # //
// # Email: df@duhoktimes.com                           # //
// # Site: http://df.duhoktimes.com/index.php           # //
// ###################################################### //
//////////////////////////////////////////////////////////*/

if(empty($pg)){
	$pag = 1;
}
else{
	$pag = $pg;
}
if ($type == "lock"){
	if ($Mlevel > 1){
		$open_sql = "WHERE M_STATUS = '0'";
	}
	else{
		$open_sql = "WHERE M_STATUS = '1'";
	}
}
else{
	$open_sql = "WHERE M_STATUS = '1'";
}
$start = (($pag * $max_page) - $max_page);
$pg_sql = mysql_query("SELECT COUNT(*) FROM ".$Prefix."MEMBERS ".$open_sql." ") or die (mysql_error());
$total_res = mysql_result($pg_sql, 0, "COUNT(*)");
$total_col = ceil($total_res / $max_page);

?>
<script language="JavaScript" type="text/javascript">
	function paging(obj){
		var pg = obj.options[obj.selectedIndex].value;
		window.location = "index.php?mode=members&pg="+pg;
	}
</script>
<?

function paging($total_col, $pag) {
	global $lang;
	echo '
	<form name="members">
	<td class="optionsbar_menus"><b>'.$lang['members']['page'].' :</b>
	<select name="pg" size="1" onchange="paging(this);">';
	for($i = 1; $i <= $total_col; $i++) {
		if(($pag) == $i) {
			echo'
			<option selected value="'.$i.'">'.$i.' '.$lang['members']['from'].' '.$total_col.'</option>';
		}
		else {
			echo'
			<option value="'.$i.'">'.$i.' '.$lang['members']['from'].' '.$total_col.'</option>';
		}
	}
	echo '
	</select>
	</td>
	</form>';
}
	echo'
	<center>
	<table class="optionsbar" cellSpacing="2" width="99%" border="0" id="table11">
		<tr>
			<td class="optionsbar_title" Align="middle" vAlign="center" width="100%">'.$lang['members']['members_page'].'</td>';
		if ($total_res > 0){
			paging($total_col, $pag);
		}
			go_to_forum();
		echo'
		</tr>
	</table><br>
	<table class="grid" cellSpacing="1" cellPadding="2" width="99%" border="0">
		<tr>
			<td class="cat">'.$lang['members']['numbers'].'</td>
			<td class="cat">'.$lang['members']['members'].'</td>
			<td class="cat">'.$lang['members']['country'].'</td>
			<td class="cat">'.$lang['members']['posts'].'</td>
			<td class="cat">'.$lang['members']['last_post'].'</td>
			<td class="cat">'.$lang['members']['last_visit'].'</td>
			<td class="cat">'.$lang['members']['rejister_date'].'</td>';
		if ($Mlevel == 4) {
			echo'
			<td class="cat">'.$lang['members']['options'].'</td>';
		}
		echo'
		</tr>';
	$sql = mysql_query("SELECT * FROM ".$Prefix."MEMBERS ".$open_sql." ORDER BY M_POSTS DESC LIMIT $start, $max_page") or die (mysql_error());
	$num = mysql_num_rows($sql);
	$i = 0;
	while ($i < $num) {
		$MMember_ID = mysql_result($sql, $i, "MEMBER_ID");
		$MMemberStatus = mysql_result($sql, $i, "M_STATUS");
		$MMemberName = mysql_result($sql, $i, "M_NAME");
		$MMemberCountry = mysql_result($sql, $i, "M_COUNTRY");
		$MMemberPosts = mysql_result($sql, $i, "M_POSTS");
		$MMemberLastPostDate = mysql_result($sql, $i, "M_LAST_POST_DATE");
		$MMemberLastHereDate = mysql_result($sql, $i, "M_LAST_HERE_DATE");
		$MMemberDate = mysql_result($sql, $i, "M_DATE");
		$MMemberBrowse = mysql_result($sql, $i, "M_BROWSE");
		if ($i % 2){
			$bg_color="fixed";
		}
		else{
			$bg_color="normal";
		}
		
			echo'
			<tr class="'.$bg_color.'">
			<td class="list_date" vAlign="center">'.$MMember_ID.'</td>
			<td class="list_names"><nobr><a href="index.php?mode=profile&id='.$MMember_ID.'">'.$MMemberName.'</a></nobr><br>'.member_title($MMember_ID).'</td>
			<td class="list_small">'.$MMemberCountry.'</td>
			<td class="list_small">'.$MMemberPosts.'<br>'.member_stars($MMember_ID).'</td>
			<td class="list_date">'.members_time($MMemberLastPostDate).'</td>
			<td class="list_small">';
		if ($Mlevel > 1){
			echo members_time($MMemberLastHereDate);
		}
		else{
			if ($MMemberBrowse == 1){
				echo members_time($MMemberLastHereDate);
			}
			else{
				echo '-';
			}
		}
			echo'
			</td>
			<td class="list_date">'.members_time($MMemberDate).'</td>';

		if ($Mlevel == 4) {
			echo'
			<td class="list_date">';
			if ($MMemberStatus == 1 && $MMember_ID != 1 && $MMember_ID != $DBMemberID) {
				echo'
				<a href="index.php?mode=lock&type=m&m='.$MMember_ID.'"  onclick="return confirm(\''.$lang['members']['you_are_sure_to_lock_this_member'].'\');">'.icons($icon_lock, $lang['members']['lock_member'], "hspace=\"2\"").'</a>';
			}
			if ($MMemberStatus == 0 && $MMember_ID != 1 && $MMember_ID != $DBMemberID) {
				echo'
				<a href="index.php?mode=open&type=m&m='.$MMember_ID.'"  onclick="return confirm(\''.$lang['members']['you_are_sure_to_open_this_member'].'\');">'.icons($icon_unlock, $lang['members']['open_member'], "hspace=\"2\"").'</a>';
			}
			$edit_member = '<a href="index.php?mode=profile&type=edit_user&id='.$MMember_ID.'">'.icons($icon_edit, $lang['members']['edit_member'], "hspace=\"2\"").'</a>';
			if ($MMember_ID == 1) {
				if ($DBMemberID == 1) {
					echo $edit_member;
				}
			}
			else {
				echo $edit_member;
			}
			if ($MMember_ID != 1 && $MMember_ID != $DBMemberID) {
				echo'
				<a href="index.php?mode=delete&type=m&m='.$MMember_ID.'"  onclick="return confirm(\''.$lang['members']['you_are_sure_to_delete_this_member'].'\');">'.icons($icon_trash, $lang['members']['delete_member'], "hspace=\"2\"").'</a>';
			}
			echo'
			</td>';
		}
		echo'
		</tr>';
		$count = $counr + 1;
	++$i;
	}
	if ($count == 0) {
		if ($type == "lock"){
			if ($Mlevel > 1){
				$non_text = "�� ���� �� ����� ������ �� �������";
			}
			else{
				$non_text = "�� ����� ������ ������ ��������";
			}
		}
		else{
			$non_text = "�� ���� �� ��� ���� ���������";
		}
		echo'
		<tr class="normal">
			<td class="list_center" vAlign="center" colspan="10"><br>'.$non_text.'<br><br></td>
		</tr>';
	}
	echo '
	</table>
	</center>';
?>
