<?
/*//////////////////////////////////////////////////////////
// ######################################################///
// # DuhokForum 0.6                                     # //
// ###################################################### //
// #                                                    # //
// #       --  DUHOK FORUM IS FREE SOFTWARE  --         # //
// #                                                    # //
// #   ========= Programming By Dilovan ==============  # //
// # Copyright � 2007-2008 Dilovan. All Rights Reserved # //
// #----------------------------------------------------# //
// #----------------------------------------------------# //
// # If you want any support vist down address:-        # //
// # Email: df@duhoktimes.com                           # //
// # Site: http://df.duhoktimes.com/index.php           # //
// ###################################################### //
//////////////////////////////////////////////////////////*/

$ip2long = ip2long($HTTP_SERVER_VARS[REMOTE_ADDR]);
$date = time();
$out_date = time() - 60*10;
$member_browse = members("BROWSE", $DBMemberID);

if (empty($f)){
	if (empty($t)) {
		$f = 0;	
	}
	else{
		$f = topics("FORUM_ID", $t);
	}
}

$if_online = mysql_query("SELECT * FROM ".$Prefix."ONLINE WHERE O_IP = '$ip2long' ") or die (mysql_error());
if(mysql_num_rows($if_online) <= 0){

	$in_online = "INSERT INTO ".$Prefix."ONLINE (ONLINE_ID, O_MEMBER_ID, O_FORUM_ID, O_MEMBER_LEVEL, O_MEMBER_BROWSE, O_IP, O_MODE, O_DATE, O_LAST_DATE) VALUES (NULL, ";
	$in_online .= " '$DBMemberID', ";
	$in_online .= " '$f', ";
	$in_online .= " '$Mlevel', ";
	$in_online .= " '$member_browse', ";
	$in_online .= " '$ip2long', ";
	$in_online .= " '$mode', ";
	$in_online .= " '$date', ";
	$in_online .= " '$date') ";
	mysql_query($in_online, $connection) or die (mysql_error());
}

$up_online = "UPDATE ".$Prefix."ONLINE SET ";
$up_online .= "O_MEMBER_ID = '$DBMemberID', ";
$up_online .= "O_FORUM_ID = '$f', ";
$up_online .= "O_MEMBER_LEVEL = '$Mlevel', ";
$up_online .= "O_MEMBER_BROWSE = '$member_browse', ";
$up_online .= "O_MODE = '$mode', ";
$up_online .= "O_LAST_DATE = '$date' ";
$up_online .= "WHERE O_IP = '$ip2long' ";
mysql_query($up_online, $connection) or die (mysql_error());

mysql_query("DELETE FROM ".$Prefix."ONLINE WHERE O_LAST_DATE < '$out_date' ") or die (mysql_error());

?>
