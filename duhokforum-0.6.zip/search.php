<?php
/*//////////////////////////////////////////////////////////
// ######################################################///
// # DuhokForum 0.6                                     # //
// ###################################################### //
// #                                                    # //
// #       --  DUHOK FORUM IS FREE SOFTWARE  --         # //
// #                                                    # //
// #   ========= Programming By Dilovan ==============  # //
// # Copyright � 2007-2008 Dilovan. All Rights Reserved # //
// #----------------------------------------------------# //
// #----------------------------------------------------# //
// # If you want any support vist down address:-        # //
// # Email: df@duhoktimes.com                           # //
// # Site: http://df.duhoktimes.com/index.php           # //
// ###################################################### //
//////////////////////////////////////////////////////////*/

function search_func(){
	global $lang, $Prefix;

	echo'<br><br>
	<center>
	<table cellSpacing="0" cellPadding="0" width="99%" border="0">
		<tr>
			<td>
			<center>
			<form method="post" action="index.php?mode=search&method=find">
			<table cellSpacing="1" cellPadding="4" bgColor="gray" border="0">
				<tr class="fixed">
					<td class="cat" colspan="4"><nobr>�����</nobr></td>
				</tr>
				<tr class="fixed">
					<td class="cat"><nobr>���� �� ������ ���</nobr></td>
					<td class="list" colspan="3"><input type="text" size="50" name="search"></td>
				</tr>
				<tr class="fixed">
					<td class="cat"><nobr>���� �����</nobr></td>
					<td class="list"><input class="small" type="radio" name="type" value="subject" CHECKED>&nbsp;����� �������&nbsp;</td>
					<td class="list" colspan="2"><input class="small" type="radio" name="type" value="message">&nbsp;����� �������&nbsp;&nbsp;
				</tr>
				<tr class="fixed">
					<td class="cat"><nobr>����� ��</nobr></td>
					<td class="list"><input class="small" type="radio" name="ch_f" value="0" CHECKED>&nbsp;���� �������&nbsp;</td>
					<td class="list" colspan="2"><input class="small" type="radio" name="ch_f" value="1">&nbsp;��� �����&nbsp;&nbsp;
					<select name="forum_id">
						<option value="">&nbsp;&nbsp;-- ���� ������� --</option>';
				$cats = mysql_query("SELECT * FROM ".$Prefix."CATEGORY ORDER BY CAT_ORDER ASC ") or die (mysql_error());
				$num = mysql_num_rows($cats);
				$i = 0;
				while($i < $num){
					$c = mysql_result($cats, $i, "CAT_ID");
					$forums = mysql_query("SELECT * FROM ".$Prefix."FORUM WHERE CAT_ID = '$c' ORDER BY F_ORDER ASC ") or die (mysql_error());
					$f_num = mysql_num_rows($forums);
					$f_i = 0;
					while($f_i < $f_num){
						$f = mysql_result($forums, $f_i, "FORUM_ID");
						$subject = forums("SUBJECT", $f);
						$hide = forums("HIDE", $f);
						if ($hide == 0 OR check_forum_login($f) == 1){
							echo'<option value="'.$f.'">'.$subject.'</option>';
						}
					++$f_i;
					}
				++$i;
				}		
					echo'
					</select>
					</td>
				</tr>
				<tr class="fixed">
					<td class="list_center" colspan="4">
						<input type="submit" value="����">&nbsp;&nbsp;<input type="reset" value="����� �������">
					</td>
				</tr>
			</table>
			</form>
			</td>
		</tr>
	</table>
	</center>';
}

function search_head(){
	global $lang, $img, $search;
			echo'
			<table cellSpacing="2" width="100%" border="0">
				<tr>
					<td>'.icons($search).'</td>
					<td width="100%" vAlign="center"><a href="index.php?mode=active"><font size="3" color="red"><b>&nbsp;&nbsp;�����</b></font></a></td>';
					refresh_time();
					go_to_forum();
				echo'
				</tr>
			</table>';
}

function search_topics($t){
	global $Mlevel, $DBMemberID, $lang, $icon_reply_topic, $folder_new_locked, $folder_new, $folder_new_hot, $folder;
	
$f = topics("FORUM_ID", $t);
$status = topics("STATUS", $t);
$subject = topics("SUBJECT", $t);
$author = topics("AUTHOR", $t);
$author_name = members("NAME", $author);
$replies = topics("REPLIES", $t);
$views = topics("COUNTS", $t);
$lp_date = topics("LAST_POST_DATE", $t);
$date = topics("DATE", $t);
$lp_author = topics("LAST_POST_AUTHOR", $t);
$lp_author_name = members("NAME", $lp_author);
$hide = topics("HIDE", $t);
$f_subject = forums("SUBJECT", $f);
$allowed = allowed($forum_id, 2);

						echo'
						<tr class="normal">
							<td class="list_small"><a href="index.php?mode=f&f='.$f.'"><b>'.$f_subject.'</b></a></td>
							<td class="list_center"><nobr><a href="index.php?mode=f&f='.$f.'">';
							if ($status == 0 AND $replies < 20) {
								echo icons($folder_new_locked, $lang['forum']['topic_is_locked']);
							}
							elseif ($status == 0 AND $replies >= 20) {
								echo icons($folder_new_locked, $lang['forum']['topic_is_hot_and_locked']);
							}
							elseif ($status == 1 AND $replies < 20) {
								echo icons($folder_new);
							}
							elseif ($status == 1 AND $replies >= 20) {
								echo icons($folder_new_hot, $lang['forum']['topic_is_hot']);
							}
							else {
								echo icons($folder);
							}					
							echo'
							</a></nobr></td>
							<td class="list">
							<table cellPadding="0" cellsapcing="0">
								<tr>
									<td><a href="index.php?mode=t&t='.$t.'"><b>'.$subject.'</b></a>&nbsp;'; echo topic_paging($t); echo'</td>
								</tr>
							</table>
							</td>
							<td class="list_small2" noWrap><font  color="green">'.normal_time($date).'</font><br><b>'.link_profile($author_name, $author).'</b></td>
							<td class="list_small2">'.$replies.'</td>
							<td class="list_small2">'.$views.'</td>
							<td class="list_small2" noWrap><font color="red">';
						if ($replies > 0){
							echo normal_time($lp_date).'</font><br><b>'.link_profile($lp_author_name, $lp_author).'<b>';
						}
							echo'
							</td>';
						if ($Mlevel > 0){
							echo'
							<td class="list_small2">';
							if ($allowed == 1 OR $status == 1){
								echo'<a href="index.php?mode=editor&method=reply&t='.$t.'">'.icons($icon_reply_topic, $lang['forum']['reply_to_this_topic'], "hspace=\"2\"").'</a>';
							}
							echo'
							</td>';
						}	
						echo'
						</tr>';
}

function search_body(){
	global $Mlevel, $DBMemberID, $lang, $HTTP_POST_VARS, $Prefix;
			echo'
			<table class="grid" cellSpacing="0" cellPadding="0" width="100%" align="center" border="0">
				<tr>
					<td>
					<table cellSpacing="1" cellPadding="2" width="100%" border="0">
						<tr>
							<td class="cat" width="15%">�������</td>
							<td class="cat">&nbsp;</td>
							<td class="cat" width="45%">��������</td>
							<td class="cat" width="15%">'.$lang['forum']['author'].'</td>
							<td class="cat">'.$lang['forum']['posts'].'</td>
							<td class="cat">'.$lang['forum']['reads'].'</td>
							<td class="cat" width="15%">'.$lang['forum']['last_post'].'</td>
							<td class="cat" width="1%">'.$lang['forum']['options'].'</td>
						</tr>';
			$search = $HTTP_POST_VARS[search];
			if ($search != ""){
				$ch_f = $HTTP_POST_VARS[ch_f];
				$forum_id = $HTTP_POST_VARS[forum_id];
				$type = $HTTP_POST_VARS[type];
				if ($ch_f == 1 AND $forum_id > 0){
					$open_sql = "AND FORUM_ID = '$forum_id' ";
				}
				if ($type == "subject"){
					$search_in = "SUBJECT";
				}
				if ($type == "message"){
					$search_in = "MESSAGE";
				}
				$topics = mysql_query("SELECT * FROM ".$Prefix."TOPICS WHERE T_".$search_in." LIKE '%$search%' ".$open_sql." LIMIT 50") or die (mysql_error());
				$num = mysql_num_rows($topics);
				if ($num <= 0) {
						echo'
						<tr>
							<td class="f1" vAlign="center" align="middle" colspan="20"><br><br>�� ��� ������ ��� �� ����� ����� ���� ���� ����<br><br><br></td>
						</tr>';
				}
				else{
					$i = 0;
					while ($i < $num) {
						$t = mysql_result($topics, $i, "TOPIC_ID");
						$t_hide = topics("HIDE", $t);
						$t_author = topics("AUTHOR", $t);
						$f = topics("FORUM_ID", $t);
						$f_hide = forums("HIDE", $f);
						$check_forum_login = check_forum_login($f);
						if (($f_hide == 0 AND $t_hide == 0) OR ($f_hide == 1 AND $t_hide == 0 AND $check_forum_login == 1) OR ($f_hide == 0 AND $t_hide == 1 AND allowed($f, 2) == 1) OR ($f_hide == 0 AND $t_hide == 1 AND $DBMemberID == $t_author) OR ($f_hide == 1 AND $t_hide == 1 AND $DBMemberID == $t_author AND $check_forum_login == 1) OR ($f_hide == 1 AND $t_hide == 1 AND allowed($f, 2) == 1 AND $check_forum_login == 1)){
							search_topics($t);
						}
					++$i;
					}
				}
					echo'
					</table>
					</td>
				</tr>';
			}
			else{
						echo'
						<tr>
							<td class="f1" vAlign="center" align="middle" colspan="20"><br><br>��� �� ���� �� �� ����� ����<br><br><br></td>
						</tr>';
			}
			echo'
			</table>';
}

function search_find(){
	global $lang;
	echo'
	<center>
	<table cellSpacing="0" cellPadding="0" width="99%" border="0">
		<tr>
			<td>';
			search_head();
			search_body();
			echo'
			</td>
		</tr>
	</table>
	</center>';
}
if ($Mlevel > 0){
	if ($method == ""){
		search_func();
	}
	if ($method == "find"){
		search_find();
	}
}
else{
	go_to("index.php");
}
?>
