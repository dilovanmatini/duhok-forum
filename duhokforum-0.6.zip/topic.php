<?
/*//////////////////////////////////////////////////////////
// ######################################################///
// # DuhokForum 0.6                                     # //
// ###################################################### //
// #                                                    # //
// #       --  DUHOK FORUM IS FREE SOFTWARE  --         # //
// #                                                    # //
// #   ========= Programming By Dilovan ==============  # //
// # Copyright � 2007-2008 Dilovan. All Rights Reserved # //
// #----------------------------------------------------# //
// #----------------------------------------------------# //
// # If you want any support vist down address:-        # //
// # Email: df@duhoktimes.com                           # //
// # Site: http://df.duhoktimes.com/index.php           # //
// ###################################################### //
//////////////////////////////////////////////////////////*/

function topic_show_medals($id){
	global $show_medals_in_posts;
	$m = members("MEDAL", $id);
	$gm_id = medals("GM_ID", $m);
	$subject = gm("SUBJECT", $gm_id);
	$url = medals("URL", $m);
	$days = medals("DAYS", $m);
	$date = medals("DATE", $m);
	$add_days = $days*60*60*24;
	$add_days = $add_days + $date;
	
	if ($show_medals_in_posts == 2 AND $add_days > time()){
		$show_medal = '<table border="0" cellSpacing="1"><tr><td><img src="'.$url.'" border="0" height="100" width="100"></td></tr></table>';
	}
	else if ($show_medals_in_posts == 1 AND $add_days > time()){
		$show_medal = '
		<table cellSpacing="4" cellPadding="3" width="100" border="0">
			<tr>
				<td bgColor="gray" align="middle"><font color="yellow" size="-2">��� ���� �����:</font><br><font color="white" size="-2">'.$subject.'</font></td>
			</tr>
		</table>';
	}
	else{
		$show_medal = '';
	}
return($show_medal);
}

function topic_show_titles($m, $f){
	$member_title = members("TITLE", $m);
	$sql = mysql_query("SELECT * FROM ".prefix."TITLES WHERE MEMBER_ID = '$m' AND STATUS = '1' ") or die(mysql_error());
	$num = mysql_num_rows($sql);
	$x= 0;
	while($x < $num){
		$t = mysql_result($sql, $x, "TITLE_ID");
		$gt = titles("GT_ID", $t);
		$f_id = gt("FORUM_ID", $gt);
		$forum = gt("FORUM", $gt);
		$subject = gt("SUBJECT", $gt);
		if ($forum == 0 AND $f_id == $f){
			$show_title .= $subject.'<br>';
		}
		if ($forum == 1){
			$show_title .= '<font color="blue">'.$subject.'</font><br>';
		}
	++$x;
	}
	if (!empty($member_title)){
		$member_title = $member_title.'<br>';
	}
	else{
		$member_title = '';
	}
	if (!empty($show_title)){
		$show_title = '<font size="-1"><small>'.$member_title.$show_title.'</small></font>';
	}
	else{
		$show_title = '';
	}
return($show_title);
}

function show_sig(){
	global $show_sig, $HTTP_SERVER_VARS;
	echo'
	<form method="post" action="'.$HTTP_SERVER_VARS[REQUEST_URI].'">
	<td class="optionsbar_menus" vAlign="top"><nobr>��������<br>
		<select style="WIDTH: 70px" name="show_sig" onchange="submit();">
			<option value="hide" '.check_select($show_sig, "hide").'>������</option>
			<option value="show" '.check_select($show_sig, "show").'>�����</option>
		</select></nobr>
	</td>
	</form>';
}

function topic_head($t){
	global $icon_print, $icon_reply_topic, $lang, $folder_new, $icon_subscribe, $max_page, $reply_num_page, $Mlevel;
	$c = topics("CAT_ID", $t);
	$f = topics("FORUM_ID", $t);
	$f_subject = forums("SUBJECT", $f);
	$f_logo = forums("LOGO", $f);
	echo'
	<table cellSpacing="2" width="100%" border="0">
		<tr>
			<td><a class="menu" href="index.php?mode=f&f='.$f.'">'.icons($f_logo).'</a></td>
			<td class="main" vAlign="center" width="100%"><a class="menu" href="index.php?mode=f&f='.$f.'"><font color="red" size="+1">'.$f_subject.'</font></a></td>';
		if ($Mlevel > 0) {
			echo'
			<td class="optionsbar_menus" vAlign="top"><nobr><a href="index.php?mode=p&t='.$t.'&f='.$f.'&c='.$c.'"">'.icons($icon_print, $lang['topics']['reply_to_this_topic']).'<br>�����</a></nobr></td>
			<td class="optionsbar_menus" vAlign="top"><nobr><a href="index.php?mode=editor&method=reply&t='.$t.'&f='.$f.'&c='.$c.'">'.icons($icon_reply_topic, $lang['topics']['reply_to_this_topic']).'<br>'.$lang['topics']['add_reply'].'</a></nobr></td>
			<td class="optionsbar_menus" vAlign="top"><nobr><a href="index.php?mode=editor&method=topic&f='.$f.'&c='.$c.'">'.icons($folder_new, $lang['topics']['add_new_topic']).'<br>'.$lang['topics']['new_topic'].'</a></nobr></td>
			<td class="optionsbar_menus" vAlign="top"><nobr><a href="index.php?mode=topicmonitor&t='.$t.'&f='.$f.'&c='.$c.'">'.icons($icon_subscribe, $lang['topics']['add_monitor'], "").'<br>'.$lang['topics']['monitor'].'</a></nobr></td>';
		}
			show_sig();
			reply_num_page();
			echo multi_page("REPLY WHERE TOPIC_ID = '$t'", $reply_num_page);
			go_to_forum();
		echo'
		</tr>
	</table>';
}

function topic_title($t){
	global $lang, $folder, $folder_locked;
	$status = topics("STATUS", $t);
	$subject = topics("SUBJECT", $t);
		echo'
		<table class="optionsbar" cellSpacing="2" width="100%" border="0">
			<tr>
				<td vAlign="center">&nbsp;';
				if ($status == 1) {
				    echo icons($folder, $lang['topics']['topic_is_opened']);
				}
				if ($status == 0) {
				    echo icons($folder_locked, $lang['topics']['topic_is_locked']);
				}
				echo'
				</td>
				<td class="optionsbar_title" vAlign="center" align="middle" width="100%">&nbsp;'.$subject.'</td>
			</tr>
		</table>';
}

function topic_quick_reply($t){
	global $lang, $icon_reply_topic, $http_host;
	$status = topics("STATUS", $t);
	$f = topics("FORUM_ID", $t);
	$c = topics("CAT_ID", $t);
		echo'
		<script language="javascript">
			function submitQuickReplyForm() {
				var x = quickreply.message.value;
				while ((x.substring(0,1) == \' \') || (x.substring(0,1) == \'\r\') || (x.substring(0,1) == \'\n\') || (x.substring(0,1) == \'\t\'))
					x = x.substring(1);
					quickreply.message.value = x;
				if (quickreply.message.value.length < 3) return;
					quickreply.submit();
			}
		</script>
		<tr>
			<form name="quickreply" method="post" action="index.php?mode=post_info">
			<td vAlign="top" align="middle" bgColor="white"><br>'.icons($icon_reply_topic).'<br><br><font color="red">'.$lang['topics']['add_quick_reply'].'</font></td>
			<td vAlign="top" align="middle" width="100%" bgColor="white" colSpan="3">
			<textarea style="FONT-SIZE: 25px; WIDTH: 100%; COLOR: #006600; FONT-FAMILY: comic sans ms; HEIGHT: 150px; TEXT-ALIGN: center" name="message" rows="1" cols="20"></textarea>
			<input name="method" type="hidden" value="reply">
			<input name="t" type="hidden" value="'.$t.'">
			<input name="f" type="hidden" value="'.$f.'">
			<input name="c" type="hidden" value="'.$c.'">
			<input name="host" type="hidden" value="'.$http_host.'">
			<input name="type" type="hidden" value="q_reply">
			<input onclick="submitQuickReplyForm()" type="button" value="'.$lang['topics']['add_reply_to_this_topic'].'">';
		if (allowed($f, 2) == 1) {
			if ($status == 1) {
				echo'&nbsp;&nbsp;<input name="ReplyAndLock" type="submit" value="'.$lang['topics']['add_reply_and_lock_topic'].'">';
			}
		}
		if (allowed($f, 2) == 1) {
			if ($status == 0) {
				echo'&nbsp;&nbsp;<input name="ReplyAndUnLock" type="submit" value="'.$lang['topics']['add_reply_and_open_topic'].'">';
			}
		}
			echo'
			</td>
		</form>
		</tr>';
}

function topic_first($t){
	global
		$show_admin_info, $lang, $icon_blank, $Mlevel, $icon_online, $icon_private_message,
		$icon_profile, $show_sig, $DBMemberID, $icon_edit, $icon_poll, $icon_who_poll,
		$icon_trash_poll, $folder_delete, $folder_unlocked, $folder_locked, $icon_unhidden,
		$icon_hidden, $icon_group
	;
	$message = topics("MESSAGE", $t);
	$date = topics("DATE", $t);
	$status = topics("STATUS", $t);
	$hidden = topics("HIDDEN", $t);
	$last_edit_date = topics("LASTEDIT_DATE", $t);
	$last_edit_make = topics("LASTEDIT_MAKE", $t);
	$lock_date = topics("LOCK_DATE", $t);
	$lock_make = topics("LOCK_MAKE", $t);
	$open_date = topics("OPEN_DATE", $t);
	$open_make = topics("OPEN_MAK", $t);
	$edit_num = topics("ENUM", $t);
	$servey_id = topics("SURVEYID", $t);
	
	$c = topics("CAT_ID", $t);
	$f = topics("FORUM_ID", $t);
	$m = topics("AUTHOR", $t);
	$level = members("LEVEL", $m);
	$m_status = members("STATUS", $m);
	$posts = members("POSTS", $m);
	$photo_url = members("PHOTO_URL", $m);
	$country = members("COUNTRY", $m);
	$m_date = members("DATE", $m);
	$sig = members("SIG", $m);
	$points = member_all_points($m);
	$stars = member_stars($m);
	$online = member_is_online($m);
	$browse = members("BROWSE", $m);
	
	if ($hidden == 1){
		$td_class = "deleted";
	}
	if ($hidden == 0){
		$td_class = "first";
	}
		echo'
		<tr>
			<td width="12%" vAlign="top" class="'.$td_class.'">';
			if ($level == 4 AND $show_admin_info == 1){
				echo admin_link($m);
			}
			else{
				echo member_normal_link($m).'<br>';
				if ($m_status == 0) {
					echo'
					<font size="1"><nobr>'.$lang['topics']['member_is_locked'].'</nobr></font>';
				}
				else {
					echo'
					<font size="-1"><nobr><small>'.$lang['topics']['posts'].'&nbsp;'.$posts.'</small></nobr></font><br>';
					if ($points > 0 AND $level == 1) {
						echo'
						<font color="red" size="-1"><nobr><small>'.$lang['topics']['points'].'&nbsp;'.$points.'</small></nobr></font><br>';
					}
					if ($stars != "") {
						echo'<font size="-1"><nobr><small>'.$stars.'</small></nobr></font><br>';
					}
					if (topic_show_titles($m, $f) != ""){
						echo topic_show_titles($m, $f);
					}
					else{
						echo '<font size="-1"><small>'.member_title($m).'</small></font><br>';
					}
					if (topic_show_medals($m) != ""){
						echo topic_show_medals($m);
					}
					if ($photo_url != "") {
						echo'<img onerror="this.src=\''.$icon_blank.'\';this.width=0;" src="'.$photo_url.'" width="100"><br>';
					}
					if ($country != "") {
						echo'<font size="-1"><nobr><small>'.$country.'</small></nobr><br>';
					}
					echo'
					<font size="-1"><nobr><small>'.$lang['topics']['number_days_of_register'].'&nbsp;'.member_total_days($m_date).'</small></nobr><br>';
					echo'
					<font size="-1"><nobr><small>'.$lang['topics']['member_middle_posts'].'&nbsp;'.member_middle_posts($posts, $m_date).'</small></nobr><br>';
					if ($online == 1 AND $browse == 1 OR $online == 1 AND $Mlevel > 1){
						echo'
						<table border="0">
							<tr>
								<td class="optionsbar_menus2">'.icons($icon_online).'<br><font size="1">'.$lang['profile']['status_online'].'</font></td>
							</tr>
						</table>';
					}
				}
			}
			echo'
			</td>
			<td vAlign="top" width="100%" class="'.$td_class.'" colSpan="3">
			<table cellSpacing="0" cellPadding="0" width="100%">
				<tr>
					<td class="posticon" bgColor="red">
					<table cellSpacing="2" width="100%">
						<tr>
							<td class="posticon"><nobr>'.normal_time($date).'</nobr></td>
							<td class="posticon"><nobr><a href="index.php?mode=profile&id='.$m.'">'.icons($icon_profile, $lang['topics']['member_info']).'</a></nobr></td>';
				if ($Mlevel > 0) {
							echo'
							<td class="posticon"><nobr><a href="index.php?mode=editor&method=sendmsg&m='.$m.'">'.icons($icon_private_message, $lang['topics']['send_message_to_this_member']).'</a></nobr></td>';
						if (allowed($f, 2) == 1 OR $status == 1 AND $DBMemberID == $m) {
							echo'
							<td class="posticon"><nobr><a href="index.php?mode=editor&method=edit&t='.$t.'&f='.$f.'&c='.$c.'">'.icons($icon_edit, $lang['topics']['edit_topic']).'</a></nobr></td>';
						}
					if (allowed($f, 2) == 1) {
						/*
						if ($servey_id == 0) {
							echo'
							<td class="posticon"><nobr><a href="index.php?mode=svc&method=svc&svc=add_survey&t='.$t.'&f='.$f.'&c='.$c.'" >'.icons($icon_poll, "��� ������� �������").'</a></nobr></td>';
						}
						if ($servey_id > 0) {
							echo'
							<td class="posticon"><nobr><a href="index.php?mode=svc&method=svc&svc=who_poll&s='.$servey_id.'&t='.$t.'&f='.$f.'&c='.$c.'" >'.icons($icon_who_poll, "�� ��� ��������").'</a></nobr></td>';
							echo'
							<td class="posticon"><nobr><a href="index.php?mode=svc&method=svc&svc=remove_survey&t='.$t.'&f='.$f.'&c='.$c.'" >'.icons($icon_trash_poll, "��� ������� �� �������").'</a></nobr></td>';
						}
						*/
						if ($status == 1) {
							echo'
							<td class="posticon"><nobr><a href="index.php?mode=lock&type=t&t='.$t.'&f='.$f.'&c='.$c.'" onclick="return confirm(\''.$lang['topics']['you_are_sure_to_lock_this_topic'].'\');">'.icons($folder_locked, $lang['topics']['lock_topic']).'</a></nobr></td>';
						}
						if ($status == 0) {
							echo'
							<td class="posticon"><nobr><a href="index.php?mode=open&type=t&t='.$t.'&f='.$f.'&c='.$c.'" onclick="return confirm(\''.$lang['topics']['you_are_sure_to_open_this_topic'].'\');">'.icons($folder_unlocked, $lang['topics']['open_topic']).'</a></nobr></td>';
						}
						if (allowed($f, 1) == 1) {
							echo'
							<td class="posticon"><nobr><a href="index.php?mode=delete&type=t&t='.$t.'&f='.$f.'&c='.$c.'" onclick="return confirm(\''.$lang['topics']['you_are_sure_to_delete_this_topic'].'\');">'.icons($folder_delete, $lang['topics']['delete_topic']).'</a></nobr></td>';
						}
							echo'
							<td class="posticon"><nobr><a href="index.php?mode=svc&svc=prv&t='.$t.'">'.icons($icon_group, '����� ������� �������� ����� ��� ������� ������', "").'</a></nobr></td>';
						if ($hidden == 1){
							echo'
							<td class="posticon"><nobr><a href="index.php?mode=open&type=h&t='.$t.'&f='.$f.'&c='.$c.'" onclick="return confirm(\''.$lang['topics']['you_are_sure_to_show_this_topic'].'\');">'.icons($icon_unhidden, $lang['topics']['show_topic']).'</a></nobr></td>';
						}
						if ($hidden == 0){
							echo'
							<td class="posticon"><nobr><a href="index.php?mode=lock&type=h&t='.$t.'&f='.$f.'&c='.$c.'" onclick="return confirm(\''.$lang['topics']['you_are_sure_to_hide_this_topic'].'\');">'.icons($icon_hidden, $lang['topics']['hide_topic']).'</a></nobr></td>';
						}
					}
				}
							echo'
							<td class="posticon" width="90%">&nbsp;</td>
						</tr>
					</table>
					</td>
				</tr>
			</table>';
		if ($hidden == 1){
			echo'
			<table cellSpacing="1" cellPadding="4" width="100%" border="0">
				<tr>
					<td vAlign="top" width="100%" bgColor="#aadddd" colSpan="3">
					<table class="optionsbar" width="100%">
						<tr>
							<td class="optionsbar_menus">'.$lang['topics']['hide_reply_info'].'</td>
						</tr>
					</table>
					</td>
				</tr>
			</table>';
		}
			echo'
			<table style="TABLE-LAYOUT: fixed">
				<tr>
					<td>';
					echo text_replace($message);
					if ($show_sig == "show" AND !empty($sig)){
						echo'<br><br>
						<FIELDSET style="width: 100%; text-align: center">
							<legend>&nbsp;<font color="black">'.$lang['topics']['the_signature'].'</font></legend>
							'.text_replace($sig).'
						</FIELDSET>
						';
					}
					echo'
					</td>
				</tr>';
			/*
			if ($servey_id > 0) {
				echo'
				<tr>
					<td align="left" valign="bottom">';
					require_once("survey_vote.php");
					echo'
					</td>
				</tr>';
			}
			*/
		if ($Mlevel > 0) {
			if ($last_edit_make != "" OR $lock_make != "" OR $open_make != "") {
				echo'
				<tr>
					<td align="left" valign="bottom">
					<table dir="rtl" cellSpacing="1" cellPadding="0" bgColor="red">
						<tr>
							<td class="editedby">';
						if ($lock_make != "") {
							echo normal_time_last($lock_date).'&nbsp;:&nbsp;<font color="black">'.$lang['open']['the_topic_is_locked_by'].'&nbsp;'.$open_make.'</font><br>';
						}
						if ($status == 1) {
							if ($open_make != "") {
								echo normal_time_last($open_date).'&nbsp;:&nbsp;<font color="black">'.$lang['open']['the_topic_is_re_opened_by'].'&nbsp;'.$open_make.'</font><br>';
							}
						}
						if ($last_edit_make != "") {
							echo normal_time_last($last_edit_date).'&nbsp;:&nbsp;<font color="black">'.$lang['last_edit']['text_last_edit_by'].'&nbsp;'.$last_edit_make.'</font><br>';
							if ($edit_num > 1) {
								echo'<font color="gray">'.$lang['last_edit']['number_edit_text'].':&nbsp;'.$edit_num.'';
							}
						}
							echo'
							</td>
						</tr>
					</table>
					</td>
				</tr>';
			}
		}	
			echo'
			</table>
			</td>
		</tr>';
}

function topic_replies($r, $td_class, $m_get, $r_get){
	global
		$show_admin_info, $lang, $icon_blank, $Mlevel, $icon_online, $icon_private_message,
		$icon_profile, $show_sig, $DBMemberID, $icon_edit, $icon_unhidden, $icon_hidden, $icon_group,
		$x, $icon_delete_reply, $icon_single, $icon_group
	;
	$message = replies("MESSAGE", $r);
	$date = replies("DATE", $r);
	$hidden = replies("HIDDEN", $r);
	$le_date = replies("LE_DATE", $r);
	$le_make = replies("LE_MAKE", $r);
	$edit_num = replies("EDIT_NUM", $r);
	
	$c = replies("CAT_ID", $r);
	$f = replies("FORUM_ID", $r);
	$t = replies("TOPIC_ID", $r);
	$m = replies("AUTHOR", $r);
	$level = members("LEVEL", $m);
	$status = members("STATUS", $m);
	$posts = members("POSTS", $m);
	$photo_url = members("PHOTO_URL", $m);
	$country = members("COUNTRY", $m);
	$m_date = members("DATE", $m);
	$sig = members("SIG", $m);
	$points = member_all_points($m);
	$stars = member_stars($m);
	$online = member_is_online($m);
	$browse = members("BROWSE", $m);
	if ($m_get > 0){
		echo'
		<tr>
			<td align="center" bgcolor="red" colspan="5"><font color="white">'.$lang['topics']['show_sigle_member_reply'].' <a href="index.php?mode=t&t='.$t.'"><font color="yellow">'.$lang['topics']['click_here'].'</font></a></font></td>
		</tr>';
	}
	if ($r_get > 0){
		$open_sql = "AND REPLY_ID = '$r'";
		echo'
		<tr>
			<td align="center" bgcolor="red" colspan="5"><font color="white">'.$lang['topics']['show_sigle_reply'].' <a href="index.php?mode=t&t='.$t.'"><font color="yellow">'.$lang['topics']['click_here'].'</font></a></font></td>
		</tr>';
	}
		echo'
		<tr>
			<td width="12%" vAlign="top" class="'.$td_class.'">';
			if ($level == 4 AND $show_admin_info == 1){
				echo admin_link($m);
			}
			else{
				echo member_normal_link($m).'<br>';
				if ($status == 0) {
					echo'
					<font size="1"><nobr>'.$lang['topics']['member_is_locked'].'</nobr></font>';
				}
				else {
					echo'
					<font size="-1"><nobr><small>'.$lang['topics']['posts'].'&nbsp;'.$posts.'</small></nobr></font><br>';
					if ($points > 0 AND $level == 1) {
						echo'
						<font color="red" size="-1"><nobr><small>'.$lang['topics']['points'].'&nbsp;'.$points.'</small></nobr></font><br>';
					}
					if ($stars != "") {
						echo'<font size="-1"><nobr><small>'.$stars.'</small></nobr></font><br>';
					}
					if (topic_show_titles($m, $f) != ""){
						echo topic_show_titles($m, $f);
					}
					else{
						echo '<font size="-1"><small>'.member_title($m).'</small></font><br>';
					}
					if (topic_show_medals($m) != ""){
						echo topic_show_medals($m);
					}
					if ($photo_url != "") {
						echo'<img onerror="this.src=\''.$icon_blank.'\';this.width=0;" src="'.$photo_url.'" width="100"><br>';
					}
					if ($country != "") {
						echo'<font size="-1"><nobr><small>'.$country.'</small></nobr><br>';
					}
					echo'
					<font size="-1"><nobr><small>'.$lang['topics']['number_days_of_register'].'&nbsp;'.member_total_days($m_date).'</small></nobr><br>';
					echo'
					<font size="-1"><nobr><small>'.$lang['topics']['member_middle_posts'].'&nbsp;'.member_middle_posts($posts, $m_date).'</small></nobr><br>';
					if ($online == 1 AND $browse == 1 OR $online == 1 AND $Mlevel > 1){
						echo'
						<table border="0">
							<tr>
								<td class="optionsbar_menus2">'.icons($icon_online).'<br><font size="1">'.$lang['profile']['status_online'].'</font></td>
							</tr>
						</table>';
					}
				}
			}
			echo'
			</td>
			<td vAlign="top" width="100%" class="'.$td_class.'" colSpan="3">
			<table cellSpacing="0" cellPadding="0" width="100%">
				<tr>
					<td class="posticon" bgColor="red">
					<table cellSpacing="2" width="100%">
						<tr>
							<td class="posticon"><nobr>'.normal_time($date).'</nobr></td>
							<td class="posticon"><nobr><a href="index.php?mode=profile&id='.$m.'">'.icons($icon_profile, $lang['topics']['member_info']).'</a></nobr></td>';
				if ($Mlevel > 0) {
							echo'
							<td class="posticon"><nobr><a href="index.php?mode=editor&method=sendmsg&m='.$m.'">'.icons($icon_private_message, $lang['topics']['send_message_to_this_member']).'</a></nobr></td>';
						if (allowed($f, 2) == 1 OR $DBMemberID == $m) {
							echo'
							<td class="posticon"><nobr><a href="index.php?mode=editor&method=editreply&r='.$r.'&t='.$t.'&f='.$f.'&c='.$c.'">'.icons($icon_edit, $lang['topics']['edit_reply']).'</a></nobr></td>';
						}
					if (allowed($f, 2) == 1) {
						if (allowed($f, 1) == 1 OR $DBMemberID == $m) {
							echo'
							<td class="posticon"><nobr><a href="index.php?mode=delete&type=r&r='.$r.'&t='.$t.'&f='.$f.'&c='.$c.'" onclick="return confirm(\''.$lang['topics']['you_are_sure_to_delete_this_reply'].'\');">'.icons($icon_delete_reply, $lang['topics']['delete_reply']).'</a></nobr></td>';
						}
						if ($hidden == 1){
							echo'
							<td class="posticon"><nobr><a href="index.php?mode=open&type=hr&r='.$r.'&t='.$t.'&f='.$f.'&c='.$c.'" onclick="return confirm(\''.$lang['topics']['you_are_sure_to_show_this_reply'].'\');">'.icons($icon_unhidden, $lang['topics']['show_reply']).'</a></nobr></td>';
						}
						if ($hidden == 0){
							echo'
							<td class="posticon"><nobr><a href="index.php?mode=lock&type=h&t='.$t.'&f='.$f.'&c='.$c.'" onclick="return confirm(\''.$lang['topics']['you_are_sure_to_hide_this_topic'].'\');">'.icons($icon_hidden, $lang['topics']['hide_topic']).'</a></nobr></td>';
						}
					}
						if ($Mlevel > 0) {
							echo'
							<td class="posticon"><nobr><a href="index.php?mode=t&t='.$t.'&r='.$r.'">'.icons($icon_single, $lang['topics']['just_this_reply']).'</a></nobr></td>
							<td class="posticon"><nobr><a href="index.php?mode=t&t='.$t.'&m='.$m.'">'.icons($icon_group, $lang['topics']['reply_this_member']).'</a></nobr></td>';
						}
				}
							echo'
							<td class="posticon" width="90%">&nbsp;</td>
						</tr>
					</table>
					</td>
				</tr>
			</table>';
		if ($hidden == 1){
			echo'
			<table cellSpacing="1" cellPadding="4" width="100%" border="0">
				<tr>
					<td vAlign="top" width="100%" bgColor="#aadddd" colSpan="3">
					<table class="optionsbar" width="100%">
						<tr>
							<td class="optionsbar_menus">'.$lang['topics']['hide_reply_info'].'</td>
						</tr>
					</table>
					</td>
				</tr>
			</table>';
		}
			echo'
			<table style="TABLE-LAYOUT: fixed">
				<tr>
					<td>';
					echo text_replace($message);
					if ($show_sig == "show" AND !empty($sig)){
						echo'<br><br>
						<FIELDSET style="width: 100%; text-align: center">
							<legend>&nbsp;<font color="black">'.$lang['topics']['the_signature'].'</font></legend>
							'.text_replace($sig).'
						</FIELDSET>
						';
					}
					echo'
					</td>
				</tr>';
		if ($Mlevel > 0) {
			if ($le_make != "") {
				echo'
				<tr>
					<td align="left" valign="bottom">
					<table dir="rtl" cellSpacing="1" cellPadding="0" bgColor="red">
						<tr>
							<td class="editedby">';
						if ($le_make != "") {
							echo normal_time_last($le_date).'&nbsp;:&nbsp;<font color="black">'.$lang['last_edit']['text_last_edit_by'].'&nbsp;'.$le_make.'</font><br>';
							if ($edit_num > 1) {
								echo'<font color="gray">'.$lang['last_edit']['number_edit_text'].':&nbsp;'.$edit_num.'';
							}
						}
							echo'
							</td>
						</tr>
					</table>
					</td>
				</tr>';
			}
		}	
			echo'
			</table>
			</td>
		</tr>';
}

function topic_func($t){
	global $lang, $Mlevel, $reply_num_page, $r, $m;
	$f = topics("FORUM_ID", $t);
	$status = topics("STATUS", $t);
	echo'
	<center>
	<table cellSpacing="0" cellPadding="0" width="99%" border="0">
		<tr>
			<td>';
			topic_head($t);
			topic_title($t);
			echo'
			<table class="grid" cellSpacing="0" cellPadding="0" width="100%" align="center" border="0">
				<tr>
					<td>
					<table cellSpacing="1" cellPadding="4" width="100%" border="0">';
					if (empty($r)){
						topic_first($t);
					}
					if ($r > 0){
						$open_sql = "AND REPLY_ID = '$r'";
					}
					if ($m > 0){
						$open_sql = "AND R_AUTHOR = '$m'";
					}
					$sql = mysql_query("SELECT * FROM ".prefix."REPLY WHERE TOPIC_ID = '$t' ".$open_sql." ORDER BY R_DATE ASC LIMIT ".pg_limit($reply_num_page).", $reply_num_page") or die (mysql_error());
					$num = mysql_num_rows($sql);
					$x = 0;
					while ($x < $num) {
						$r_id = mysql_result($sql, $x, "REPLY_ID");
						$hidden = replies("HIDDEN", $r_id);
						if ($hidden == 1){
							$td_class = "deleted";
						}
						if ($hidden == 0){
							if ($x % 2){
								$td_class = "fixed";
							}
							else{
								$td_class = "normal";
							}
						}
						if (chk_load_reply($r_id) == 1){
							topic_replies($r_id, $td_class, $m, $r);
						}
					++$x;
					}
					if (allowed($f, 2) == 1 OR $status == 1 AND $Mlevel > 0) {
						topic_quick_reply($t);
					}
					echo'	
					</table>
					</td>
				</tr>
			</table>';
			topic_title($t);
			topic_head($t);
			echo'
			</td>
		</tr>
	</table>
	</center>';
}
if (chk_load_topic($t) == 1){
	mysql_query("UPDATE ".prefix."TOPICS SET T_COUNTS = T_COUNTS + 1 WHERE TOPIC_ID = '$t' ") or die (mysql_error());
	topic_func($t);
}
else{
	go_to("index.php?mode=msg&err=t");
}
?>
