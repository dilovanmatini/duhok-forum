<?
/*//////////////////////////////////////////////////////////
// ######################################################///
// # DuhokForum 0.7                                     # //
// ###################################################### //
// #                                                    # //
// #       --  DUHOK FORUM IS FREE SOFTWARE  --         # //
// #                                                    # //
// #   ========= Programming By Dilovan ==============  # //
// # Copyright � 2007-2008 Dilovan. All Rights Reserved # //
// #----------------------------------------------------# //
// #----------------------------------------------------# //
// # If you want any support vist down address:-        # //
// # Email: df@duhoktimes.com                           # //
// # Site: http://df.duhoktimes.com/index.php           # //
// ###################################################### //
//////////////////////////////////////////////////////////*/

include("check.php");
?>
<html dir="rtl">
<head>
<title></title>
<meta http-equiv="Content-Type" content="text/html; charset=windows-1256">
<meta content="DUHOK FORUM 1.0: Copyright (C) 2007-2008 Dilovan." name="copyright">
<link href="<? print $admin_folder; ?>/cp_styles/cp_style_green.css" type="text/css" rel="stylesheet">
</head>
<body bgcolor="#659867" leftMargin="0" topMargin="0" marginheight="0" marginwidth="0">
<br>
<?
switch ($mode) {
     case "":
          include ("./admin/body.php");
     break;
     case "option":
          include ("./admin/option.php");
     break;
     case "ranks":
          include ("./admin/ranks.php");
     break;
     case "permission":
          include ("./admin/permission.php");
     break;
     case "lang":
          include ("./admin/lang.php");
     break;
     case "style":
          include ("./admin/style.php");
     break;
     case "phpinfo":
          print '<table width="100%" border="0" cellpadding="0" cellspacing="0" dir="ltr"><tr><td dir="ltr">';
          phpinfo();
          print '</td></tr></table>';
     break;
}
?>
</body>
</html>
