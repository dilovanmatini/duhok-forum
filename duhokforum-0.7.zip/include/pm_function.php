<?php
/*//////////////////////////////////////////////////////////
// ######################################################///
// # DuhokForum 0.7                                     # //
// ###################################################### //
// #                                                    # //
// #       --  DUHOK FORUM IS FREE SOFTWARE  --         # //
// #                                                    # //
// #   ========= Programming By Dilovan ==============  # //
// # Copyright � 2007-2008 Dilovan. All Rights Reserved # //
// #----------------------------------------------------# //
// #----------------------------------------------------# //
// # If you want any support vist down address:-        # //
// # Email: df@duhoktimes.com                           # //
// # Site: http://df.duhoktimes.com/index.php           # //
// ###################################################### //
//////////////////////////////////////////////////////////*/

function class_dis($this, $mail){
 if ($this == $mail) {
   $color = 'extras2';
 }
 else {
   $color = 'extras';
 }
 return($color);
}



?>
