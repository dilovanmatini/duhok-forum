<?
/*//////////////////////////////////////////////////////////
// ######################################################///
// # DuhokForum 0.7                                     # //
// ###################################################### //
// #                                                    # //
// #       --  DUHOK FORUM IS FREE SOFTWARE  --         # //
// #                                                    # //
// #   ========= Programming By Dilovan ==============  # //
// # Copyright � 2007-2008 Dilovan. All Rights Reserved # //
// #----------------------------------------------------# //
// #----------------------------------------------------# //
// # If you want any support vist down address:-        # //
// # Email: df@duhoktimes.com                           # //
// # Site: http://df.duhoktimes.com/index.php           # //
// ###################################################### //
//////////////////////////////////////////////////////////*/

require_once("./include/members_function.php");

//############################################## PAGING ##############################################
if(empty($pg)){
	$pag = 1;
}
else{
	$pag = $pg;
}
if ($type == "lock"){
	if ($Mlevel > 1){
		$open_sql = "WHERE M_STATUS = '0'";
	}
	else{
		$open_sql = "WHERE M_STATUS = '1'";
	}
}
else{
	$open_sql = "WHERE M_STATUS = '1'";
}
$start = (($pag * $max_page) - $max_page);
$pg_sql = mysql_query("SELECT COUNT(*) FROM ".$Prefix."MEMBERS ".$open_sql." ") or die (mysql_error());
$total_res = mysql_result($pg_sql, 0, "COUNT(*)");
$total_col = ceil($total_res / $max_page);

?>
<script language="JavaScript" type="text/javascript">
	function paging(obj){
		var pg = obj.options[obj.selectedIndex].value;
		window.location = "index.php?mode=members&pg="+pg;
	}
</script>
<?

function paging($total_col, $pag) {
	global $lang;
	echo '
	<form name="members">
	<td class="optionsbar_menus"><b>'.$lang['members']['page'].' :</b><br>
	<select name="pg" size="1" onchange="paging(this);">';
	for($i = 1; $i <= $total_col; $i++) {
		if(($pag) == $i) {
			echo'
			<option selected value="'.$i.'">'.$i.' '.$lang['members']['from'].' '.$total_col.'</option>';
		}
		else {
			echo'
			<option value="'.$i.'">'.$i.' '.$lang['members']['from'].' '.$total_col.'</option>';
		}
	}
	echo '
	</select>
	</td>
	</form>';
}
//############################################## PAGING ##############################################

if ($order_option == "online") {
          $text = "������� �� ��������� �����";
}
else if ($order_option == "points") {
          $text = "����� �����<br><font color='black' size='1'>����� ������� ��� ���� ������</font>";
}
else if ($order_option == "mods") {
          $text = "����� ��������";
}
else {
          $text = "����� �������";
}

echo'
<center>
<table cellSpacing="2" cellPadding="1" width="99%" border="0">
	<tr>
		<td class="optionsbar_menus" width="38%"><font color="red" size="+1">'.$text.'</font></td>
		<form method="post" action="index.php?mode=members&type=true">
		<td class="optionsbar_menus">���� �� ���:<br>
			<input style="width: 100px" name="search_member">
			&nbsp;<input class="submit" type="submit" value="����">
		</td>
		</form>';

		order_option();
		members_order();
  
paging($total_col, $pag);
go_to_forum();
echo'
	</tr>
</table>';

if ($type == "true") {
	$open_sql = "WHERE M_NAME LIKE '%$search_member%' AND M_STATUS = '1' ";
	$no_member = "�� ���� �� ��� ���� ���� �����";
	member_func();
}
else if ($type == "lock") {
	if ($Mlevel > 1){
		$open_sql = "WHERE M_STATUS = '0'";
	}
	else{
		$open_sql = "WHERE M_STATUS = '1'";
	}
	$no_member = "�� ���� �� ������ ������";
	member_func();
}
else if ($order_option == "" OR $order_option == "online") {

	$sql = "SELECT * FROM " . $Prefix . "ONLINE ";
	$rsql = mysql_query($sql, $connection) or die (mysql_error());
	$online = mysql_num_rows($rsql);
	$on_i=0;
	while ($on_i < $online) {
	$Member_ID = mysql_result($rsql, $on_i, "O_MEMBER_ID");
	$where = "WHERE MEMBER_ID =' $Member_ID' AND M_STATUS = '1' AND M_BROWSE = '1'";
	echo'
	<center><br>
	<table cellSpacing="1" cellPadding="2" border="1" width="65%">';
	if (mlv == 4) {
		echo'
		<tr>
			<td class="cat" colspan="5">�����</td>
		</tr>
		<tr>';
		mods_online(4);
		echo'
		</tr>

		<tr>
			<td class="cat" colspan="5">�������</td>
		</tr>
		<tr>';
		mods_online(3);
		echo'
		</tr>';
	}
		echo'
		<tr>
			<td class="cat" colspan="5">������</td>
		</tr>
		<tr>';
		mods_online(2);
		echo'
		</tr>

		<tr>
			<td class="cat" colspan="5">�����</td>
		</tr>
		<tr>';
		mods_online(1);
		echo'
		</tr>
	</table>
	</center>';
	++$on_i;
	}

}
else if ($order_option == "points") {

echo'
<table cellSpacing="1" cellPadding="2">
	<tr>
		<td align="center"><img onerror="this.src=\''.$icon_blank.'\';" src="'.$winner_ribbon.'" border="0"></td>
	</tr>
</table>
<table cellSpacing="1" cellPadding="2" border="1" width="410">';
	mods_list();
echo'
</table>';

}

else if ($order_option == "posts") {

	$open_sql = "WHERE M_STATUS = '1' ORDER BY M_POSTS ".$desc_asc." ";
	member_func();

}

else if ($order_option == "name") {

	$open_sql = "WHERE M_STATUS = '1' ORDER BY M_NAME ".$desc_asc." ";
	member_func();

}

else if ($order_option == "country") {

	$open_sql = "WHERE M_STATUS = '1' ORDER BY M_COUNTRY ".$desc_asc." ";
	member_func();

}

else if ($order_option == "lastpost") {

	$open_sql = "WHERE M_STATUS = '1' ORDER BY M_LAST_POST_DATE ".$desc_asc." ";
	member_func();

}

else if ($order_option == "lastvisit") {

	$open_sql = "WHERE M_STATUS = '1' ORDER BY M_LAST_HERE_DATE ".$desc_asc." ";
	member_func();

}

else if ($order_option == "register") {

	$open_sql = "WHERE M_STATUS = '1' ORDER BY M_DATE ".$desc_asc." ";
	member_func();

}

else if ($order_option == "mods") {

	$open_sql = "WHERE M_STATUS = '1' AND M_LEVEL = '2' ORDER BY M_NAME ".$desc_asc." ";
	member_func();

}

echo'
</table>
</center>';

?>
