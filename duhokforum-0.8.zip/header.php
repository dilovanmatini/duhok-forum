<?php
/*//////////////////////////////////////////////////////////
// ######################################################///
// # DuhokForum 0.8                                     # //
// ###################################################### //
// #                                                    # //
// #       --  DUHOK FORUM IS FREE SOFTWARE  --         # //
// #                                                    # //
// #   ========= Programming By Dilovan ==============  # //
// # Copyright � 2007-2008 Dilovan. All Rights Reserved # //
// #----------------------------------------------------# //
// #----------------------------------------------------# //
// # If you want any support vist down address:-        # //
// # Email: df@duhoktimes.com                           # //
// # Site: http://df.duhoktimes.com/index.php           # //
// ###################################################### //
//////////////////////////////////////////////////////////*/
ob_start( 'ob_gzhandler' );
session_start();
	$user_name = trim($HTTP_POST_VARS["user_name"]);
	$user_pass = trim($HTTP_POST_VARS["user_pass"]);
	if (method == "login"){
		$HTTP_SESSION_VARS['DFName'] = $user_name;
		$HTTP_SESSION_VARS['DFPass'] = $user_pass;
	}
	if (method == "logout"){
		$HTTP_SESSION_VARS['DFName'] = '';
		$HTTP_SESSION_VARS['DFPass'] = '';
		head('index.php');
	}
	$load_user_name = $HTTP_SESSION_VARS['DFName'];
	$load_user_pass = $HTTP_SESSION_VARS['DFPass'];
	$load_md5_user_pass = MD5($load_user_pass);
	$sql = mysql_query("SELECT * FROM ".prefix."MEMBERS WHERE M_NAME = '$load_user_name' AND M_PASSWORD = '$load_md5_user_pass' AND M_STATUS = '1' ") or die (mysql_error());
	if(mysql_num_rows($sql) > 0){
		$rs = mysql_fetch_array($sql);
		$DBMemberID = $rs['MEMBER_ID'];
		$DBUserName = $rs['M_NAME'];
		$DBPassword = $rs['M_PASSWORD'];
		$Mlevel = $rs['M_LEVEL'];
		$DBMemberPosts = $rs['M_POSTS'];
		$DBMemberDate = $rs['M_DATE'];
		define(m_id, $DBMemberID);
		define(m_name, $DBUserName);
		define(mlv, $Mlevel);
		chk_update_login_members();
	}
	else {
		$DBMemberID = 0;
		$DBUserName = 0;
		$DBPassword = 0;
		$Mlevel = 0;
		$DBMemberPosts = 0;
		$DBMemberDate = 0;
		define(m_id, $DBMemberID);
		define(m_name, $DBUserName);
		define(mlv, $Mlevel);
	}
	if (method == "login"){
		if (mlv > 0){
			head("index.php");
		}
	}
require_once("session.php");
require_once("language/arabic.php");
require_once("online.php");
$coda = codding($forum_title, $site_name, $copy_right);

if (mode == "editor"){
	$html_dir = '';
	$body_content = ' onload="load_content()" style="font:10pt verdana,arial,sans-serif" scroll="no"';
} else {
	$html_dir = ' dir="'.$lang['global']['dir'].'"';
	$body_content = '';
}

echo'<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.0 Transitional//EN">
<html'.$html_dir.'>
	<head>
		<title>'.$forum_title.'</title>
		<meta http-equiv=Content-Type content="'.$lang['global']['charset'].'">
		<meta http-equiv="Content-Language" content="'.$lang['global']['lang_code'].'">
		<meta content="DUHOK FORUM 1.6: Copyright (C) 2007-2008 Dilovan." name="copyright">
		<meta http-equiv="Page-Enter" content="blendTrans(Duration=0)">
		<meta http-equiv="Page-Exit" content="blendTrans(Duration=0)">
		<link rel="stylesheet" href="styles/style_'.$choose_style.'.css">
		<script language="javascript" src="javascript/javascript.js"></script>
		<script language="javascript" src="language/'.$choose_language.'.js"></script>
		<script language="javascript">
			var dir = "'.$lang['global']['dir'].'";
			var topic_max_size = "'.$topic_max_size.'";
			var reply_max_size = "'.$reply_max_size.'";
			var pm_max_size = "'.$pm_max_size.'";
			var sig_max_size = "'.$sig_max_size.'";
			var editor_method = "'.method.'";
			var fileURL = "'.$forum_url.'";
			var image_folder = "'.$image_folder.'";
		</script>
	</head>
<body leftmargin="0" topmargin="0" marginheight="0" marginwidth="0"'.$body_content.'>';

if (mode != "editor" AND mode != "p"){
	echo'
	<table class="topholder" cellSpacing="0" cellPadding="0" width="100%">
		<tr>
			<td>
			<table class="menubar" cellSpacing="1" cellPadding="0" width="100%">
				<tr>
					<td width="100%"><a href="index.php">'.icons($logo, $forum_title).'</td>';
			if (mlv > 0){
					echo'
					<td class="optionsbar_menus2" vAlign="top"><nobr><a href="index.php">'.icons($Home).'<br>'.$lang['header']['home'].'</a></nobr></td>';
					echo'
					<td class="optionsbar_menus2" vAlign="top"><nobr><a href="index.php?mode=posts&m=0">'.icons($yourposts).'<br>'.$lang['header']['your_posts'].'</a></nobr></td>';
                    echo'
					<td class="optionsbar_menus2" vAlign="top"><nobr><a href="index.php?mode=topics&m=0">'.icons($yourtopics).'<br>'.$lang['header']['your_topics'].'</a></nobr></td>';
					echo'
					<td class="optionsbar_menus2" vAlign="top"><nobr><a href="index.php?mode=members">'.icons($members).'<br>'.$lang['header']['members'].'</a></nobr></td>';
					echo'
					<td class="optionsbar_menus2" vAlign="top"><nobr><a href="index.php?mode=active&active=monitored">'.icons($monitor).'<br>'.$lang['header']['monitors'].'</a></nobr></td>';
					echo'
					<td class="optionsbar_menus2" vAlign="top"><nobr><a href="index.php?mode=pm&mail=in">'.icons($messages).'<br>'.$lang['header']['messages'].'</a></nobr></td>';
					echo'
					<td class="optionsbar_menus2" vAlign="top"><nobr><a href="index.php?mode=active">'.icons($actives).'<br>'.$lang['header']['active_topics'].'</a></nobr></td>';
					echo'
					<td class="optionsbar_menus2" vAlign="top"><nobr><a href="index.php?mode=search">'.icons($search).'<br>'.$lang['header']['search'].'</a></nobr></td>';
					echo'
					<td class="optionsbar_menus2" vAlign="top"><nobr><a href="index.php?mode=f&f='.$help_forum.'">'.icons($help).'<br>'.$lang['header']['help'].'</a></nobr></td>';
					echo'
					<td class="optionsbar_menus2" vAlign="top"><nobr><a href="index.php?mode=profile&type=details">'.icons($details).'<br>'.$lang['header']['your_details'].'</a></nobr></td>';
				if (mlv == 4){
					echo'
					<td class="optionsbar_menus2" vAlign="top"><nobr><a href="login.php">'.icons($admin).'<br>'.$lang['header']['administration'].'</a></nobr></td>';
				}
					echo'
					<td class="optionsbar_menus2" vAlign="top"><nobr><a href="index.php?method=logout" onclick="return confirm(\''.$lang['header']['you_are_sure_to_logout'].'\');">'.icons($exit).'<br>'.$lang['header']['exit'].'</a></nobr></td>';
			}
			else {
					echo'
					<td class="optionsbar_menus2" vAlign="top"><nobr><a href="index.php">'.icons($Home).'<br>'.$lang['header']['home'].'</a></nobr></td>';
					echo'
					<td class="optionsbar_menus2" vAlign="top"><nobr><a href="index.php?mode=members">'.icons($members).'<br>'.$lang['header']['members'].'</a></nobr></td>';
					echo'
					<td class="optionsbar_menus2" vAlign="top"><nobr><a href="index.php?mode=active">'.icons($actives).'<br>'.$lang['header']['active_topics'].'</a></nobr></td>';
					echo'
					<td class="optionsbar_menus2" vAlign="top"><nobr><a href="index.php?mode=f&f='.$help_forum.'">'.icons($help).'<br>'.$lang['header']['help'].'</a></nobr></td>';
					echo'
					<td class="optionsbar_menus2" vAlign="top"><nobr><a href="index.php?mode=policy">'.icons($details).'<br>'.$lang['header']['register'].'</a></nobr></td>';
			}
				echo'
				</tr>
			</table>
			</td>
		</tr>
		<tr>
			<td>';
		if (mlv > 0){
			echo'
			<table class="userbar" cellSpacing="0" cellPadding="0" width="100%" border="0">
				<tr>
					<td vAlign="center">
					<table cellSpacing="0" cellPadding="0">
						<tr>
							<td class="user" align="left"><nobr><a href="index.php?mode=profile&type=details">'.$lang['header']['name'].'</a></nobr></td>
							<td class="user"><nobr><a href="index.php?mode=profile&type=details">&nbsp;<font color="red">'.m_name.'</font></a></nobr></td>
						</tr>
						<tr>
							<td class="user" align="left"><nobr><a href="index.php?mode=profile&id='.m_id.'">'.$lang['header']['posts'].'</a></nobr></td>
							<td class="user"><nobr><a href="index.php?mode=profile&id='.m_id.'">&nbsp;<font color="red">'.members("POSTS", m_id).'</font></a></nobr></td>
						</tr>';
					if (members_new_pm(m_id) > 0){
						echo'
						<tr>
							<td class="user" align="left"><nobr><a href="index.php?mode=pm&mail=new">'.$lang['header']['new_pm'].'</a></nobr></td>
							<td class="user"><nobr><a href="index.php?mode=pm&mail=new">&nbsp;<font color="red">'.members_new_pm(m_id).'</font></a></nobr></td>
						</tr>';
					}
					if (num_user_wait() > 0 AND mlv == 4){
						echo'
						<tr>
							<td class="user" align="left"><nobr><a href="index.php?mode=admin_svc&type=approve">����� ��������:</a></nobr></td>
							<td class="user"><nobr><a href="index.php?mode=admin_svc&type=approve">&nbsp;<font color="red">'.num_user_wait().'</font></a></nobr></td>
						</tr>';
					}
					echo'
					</table>
					</td>
					<td width="10%"></td>
					<td vAlign="center">';
				if(mode == "f"){
					echo'
					<table class="chatusers">
						<tr>
							<td class="forumusers" vAlign="top">
								<a href="index.php?mode=finfo&f='.$f.'">�� ��� ������� �����:</a><br>
								<a class="tiny" href="index.php?mode=finfo&f='.$f.'"><font color="red">��� �������:</font>'.forum_online_num($f).'</a>
							</td>
						</tr>
					</table>';
				}
					echo'
					</td>
					<td align="left" width="30%">
					<table border="0" cellPadding="1" cellSpacing="2">';
					if (mlv > 1){
						echo'
						<tr>';
						if (mlv == 4){
							echo'
							<td class="optionsbar_menus" rowspan="2"><nobr><a href="index.php?mode=admin_svc">�����<br>������</a></nobr></td>';
						}
							echo'
							<td class="optionsbar_menus"><nobr><a href="index.php?mode=mods">������</a></nobr></td>
							<td class="optionsbar_menus"><nobr><a href="index.php?mode=svc&method=svc&svc=mon&sel=1&show=cur">����� ����</a></nobr></td>
						</tr>
						<tr>
							<td class="optionsbar_menus"><nobr><a href="index.php?mode=files">'.$lang['header']['files'].'</a></nobr></td>
							<td class="optionsbar_menus"><nobr><a href="index.php?mode=svc&svc=medals">'.$lang['header']['services'].'</a></nobr></td>
						</tr>';
					}
					echo'
					</table>
					</td>
				</tr>
			</table>';
		}
		else{
			echo'
			<table class="grid" height="100%" cellSpacing="0" cellPadding="0" border="0">
			<form method="post" action="index.php?method=login">
				<tr>
					<td class="cat" align="middle" colSpan="4">'.$lang['header']['members_login'].'</td>
				</tr>
				<tr>
					<td class="f2ts" align="left"><font color="red"><b>'.$lang['header']['name'].'</b></font></td>
					<td class="f2ts"><input type="text" class="small" style="WIDTH: 100px" name="user_name"></td>
					<td class="f2ts" align="left"><font color="red"><nobr><b>'.$lang['header']['password'].'</b></nobr></font></td>
					<td class="f2ts"><input type="password" class="small" style="WIDTH: 100px" name="user_pass"></td>
				</tr>
				<tr>
					<td colspan="3" class="f2ts" align="right">
					<select name="SavePassword">
						<option value="true">'.$lang['header']['save_pass_and_user_name'].'</option>
						<option value="false">'.$lang['header']['temporarily_login'].'</option>
					</select>
					<td class="f2ts" vAlign="top" align="left"><input class="small" src="'.$login.'" type="image" border="0" value="'.$lang['header']['login'].'"></td>
				</tr>
				<tr>
					<td colspan="3" class="f2ts" align="right"><a class="menu" href="index.php?mode=forget_pass">'.$lang['header']['forget_password'].'</a></td>
					<td class="f2ts" align="right"></td>
				</tr>
			</form>
			</table>';
		}
			echo'
			<br></td>
		</tr>
	</table>';
}

if (method == "login"){
	if (mlv == 0){
		login_error_msg(chk_login_name($load_user_name, $load_user_pass));
	}
}
?>
