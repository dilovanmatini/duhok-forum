<?php
/*//////////////////////////////////////////////////////////
// ######################################################///
// # DuhokForum 0.8                                     # //
// ###################################################### //
// #                                                    # //
// #       --  DUHOK FORUM IS FREE SOFTWARE  --         # //
// #                                                    # //
// #   ========= Programming By Dilovan ==============  # //
// # Copyright � 2007-2008 Dilovan. All Rights Reserved # //
// #----------------------------------------------------# //
// #----------------------------------------------------# //
// # If you want any support vist down address:-        # //
// # Email: df@duhoktimes.com                           # //
// # Site: http://df.duhoktimes.com/index.php           # //
// ###################################################### //
//////////////////////////////////////////////////////////*/

require_once("./include/home_function.php");
$time = mktime(gmdate("H"), gmdate("i"), gmdate("s"));
$time = gmt_time($time);
define(time, $time);

	echo'
	<center>
	<table class="mainheader" cellSpacing="0" cellPadding="0" width="99%" border="0">
		<tr>
			<td width="99%">&nbsp;</td>
			<td vAlign="center"><font size="3" color="red">'.time.'</font></td>
			<td>&nbsp;</td>

			<form method="post" action="index.php?tz=1">
			<td vAlign="center">
			<select class="timezoneSelect" style="WIDTH: 70px" name="timezone" onchange="submit();">';
			home_timezone();
			echo'
			</select>
			</td>
			</form>
			<td>&nbsp;</td>
			<td>&nbsp;</td>
			<td>&nbsp;</td>';
/*
			<form method="post" action="index.php?ch=lang">
			<td vAlign="center">
			<select class="styleSelect" name="lan_name" onchange="submit();">';

        $ch_lang = mysql_query("SELECT * FROM ".$Prefix."LANGUAGE ") or die (mysql_error());
        $lang_num = mysql_num_rows($ch_lang);
    
        if ($lang_num > 0) {

            $lang_i = 0;
            while ($lang_i < $lang_num) {

                $lang_id = mysql_result($ch_lang, $lang_i, "L_ID");
                $lang_file_name = mysql_result($ch_lang, $lang_i, "L_FILE_NAME");
                $lang_name = mysql_result($ch_lang, $lang_i, "L_NAME");
            
                echo'<option value="'.$lang_file_name.'" '.check_select($choose_language, $lang_file_name).'>'.$lang_name.'</option>';
            
            ++$lang_i;
            }
        }
        else {
            echo'<option value="">'.$lang['home']['choose_language'].'</option>';
        }
            echo'
            </select>
            </td>
            </form>
*/
	echo'
            <form method="post" action="index.php?ch=style">
            <td vAlign="center">
            <select class="styleSelect" name="style_name" onchange="submit();">';

        $ch_style = mysql_query("SELECT * FROM ".$Prefix."STYLE ") or die (mysql_error());
        $style_num = mysql_num_rows($ch_style);

        if ($style_num > 0) {

            $style_i = 0;
            while ($style_i < $style_num) {

                $style_id = mysql_result($ch_style, $style_i, "S_ID");
                $style_file_name = mysql_result($ch_style, $style_i, "S_FILE_NAME");
                $style_name = mysql_result($ch_style, $style_i, "S_NAME");

                echo'<option value="'.$style_file_name.'" '.check_select($choose_style, $style_file_name).'>'.$style_name.'</option>';

            ++$style_i;
            }
        }
        else {
            echo'<option value="">'.$lang['home']['choose_style'].'</option>';
        }
            echo'
            </select>
            </td>
            </form>
	</tr>
	<tr>';
		home_online();
	echo'
	</tr>
</table>
</center>
';

	if ($Mlevel == 4){
		home_add();
	}
	
	echo'
	<center>
	<table cellSpacing="0" cellPadding="0" width="99%" border="0">
		<tr>
			<td>
			<table class="grid" cellSpacing="1" cellPadding="1" width="100%" border="0">';
			$cat = mysql_query("SELECT * FROM ".$Prefix."CATEGORY ORDER BY CAT_ORDER ASC") or die (mysql_error()); // category mysql
			$c_num = mysql_num_rows($cat);
			if ($c_num <= 0) {
				echo'
				<tr>
					<td class="f1" vAlign="center" align="middle"><br><br>'.$lang['home']['no_cat'].'<br><br><br></td>
				</tr>';
			}
			else{
				$c_i = 0;
				while ($c_i < $c_num) { //category while start
					$cat_id = mysql_result($cat, $c_i, "CAT_ID");
					$cat_name = mysql_result($cat, $c_i, "CAT_NAME");
					$cat_status = mysql_result($cat, $c_i, "CAT_STATUS");
					$cat_monitor = mysql_result($cat, $c_i, "CAT_MONITOR");
					$cat_hide = cat("HIDE", $cat_id);
					$check_cat_login = check_cat_login($cat_id);
					
					if ($cat_hide == 0 OR $cat_hide == 1 AND $check_cat_login == 1) {
					
					echo'
					<tr>
						<td class="cat" width="30%"><nobr>'.$cat_name.'</nobr></td>
						<td class="cat"><nobr>'.$lang['home']['topics'].'</nobr></td>
						<td class="cat"><nobr>'.$lang['home']['posts'].'</nobr></td>
						<td class="cat"><nobr>'.icons($icon_group).'</nobr></td>
						<td class="cat"><nobr>'.$lang['home']['last_post'].'</nobr></td>
						<td class="cat"><nobr>'.$lang['home']['monitors'].'</nobr></td>
						<td class="cat" width="30%"><nobr>'.$lang['home']['moderators'].'</nobr></td>';
						if ($Mlevel == 4) {
							echo'
							<td class="cat" vAlign="middle" align="middle"><nobr>
								<a href="index.php?mode=add_cat_forum&method=add&type=f&c='.$cat_id.'">'.icons($folder_new, $lang['home']['add_new_forum'], "hspace=\"3\"").'</a>
								<a href="index.php?mode=add_cat_forum&method=edit&type=c&c='.$cat_id.'">'.icons($folder_new_edit, $lang['home']['edit_cat'], "hspace=\"3\"").'</a>';
							if ($cat_status == 1) {
								echo'
								<a href="index.php?mode=lock&type=c&c='.$cat_id.'"  onclick="return confirm(\''.$lang['home']['you_are_sure_to_lock_this_cat'].'\');">'.icons($folder_new_locked, $lang['home']['lock_cat'], "hspace=\"3\"").'</a>';
							}
							if ($cat_status == 0) {
								echo'
								<a href="index.php?mode=open&type=c&c='.$cat_id.'"  onclick="return confirm(\''.$lang['home']['you_are_sure_to_open_this_cat'].'\');">'.icons($folder_new_unlocked, $lang['home']['open_cat'], "hspace=\"3\"").'</a>';
							}
							echo'<a href="index.php?mode=delete&type=c&c='.$cat_id.'"  onclick="return confirm(\''.$lang['home']['you_are_sure_to_delete_this_cat'].'\');">'.icons($folder_new_delete, $lang['home']['delete_cat'], "hspace=\"3\"").'</a>
							</nobr></td>';
						}
					echo'
					</tr>';
					$forums = mysql_query("SELECT * FROM ".$Prefix."FORUM WHERE CAT_ID = '$cat_id' ORDER BY F_ORDER ASC") or die (mysql_error()); // forum mysql
					$f_num = mysql_num_rows($forums);
					if ($f_num <= 0) {
						echo'
						<tr>
							<td class="f1" vAlign="center" align="middle" colspan="20"><br><br>'.$lang['home']['no_forums'].'<br><br><br></td>
						</tr>';
					}
					else{
						$f_i = 0;
						while ($f_i < $f_num) { // forum while start
							$forum_id = mysql_result($forums, $f_i, "FORUM_ID");
							$f_hide = forums("HIDE", $forum_id);
							$check_forum_login = check_forum_login($forum_id);
							
							if ($f_hide == 0 OR $f_hide == 1 AND $check_forum_login == 1){
								home($forum_id);
							}
							
						++$f_i; // forum while end
						}
					}
					}
				++$c_i; // category while end
				}
			}
			echo'
			</table>
			</td>
		</tr>
	</table>
	</center>';

include("other_cat_info.php");
print $coda;
mysql_close();
?>

