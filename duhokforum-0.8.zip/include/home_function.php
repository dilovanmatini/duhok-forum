<?php
/*//////////////////////////////////////////////////////////
// ######################################################///
// # DuhokForum 0.8                                     # //
// ###################################################### //
// #                                                    # //
// #       --  DUHOK FORUM IS FREE SOFTWARE  --         # //
// #                                                    # //
// #   ========= Programming By Dilovan ==============  # //
// # Copyright � 2007-2008 Dilovan. All Rights Reserved # //
// #----------------------------------------------------# //
// #----------------------------------------------------# //
// # If you want any support vist down address:-        # //
// # Email: df@duhoktimes.com                           # //
// # Site: http://df.duhoktimes.com/index.php           # //
// ###################################################### //
//////////////////////////////////////////////////////////*/

function home_timezone(){
	global $load_timezone;
		echo'
			<option value="-12" '.check_select($load_timezone, "-12").'>GMT -12</option>
			<option value="-11" '.check_select($load_timezone, "-11").'>GMT -11</option>
			<option value="-10" '.check_select($load_timezone, "-10").'>GMT -10</option>
			<option value="-9" '.check_select($load_timezone, "-9").'>GMT -9</option>
			<option value="-8" '.check_select($load_timezone, "-8").'>GMT -8</option>
			<option value="-7" '.check_select($load_timezone, "-7").'>GMT -7</option>
			<option value="-6" '.check_select($load_timezone, "-6").'>GMT -6</option>
			<option value="-5" '.check_select($load_timezone, "-5").'>GMT -5</option>
			<option value="-4" '.check_select($load_timezone, "-4").'>GMT -4</option>
			<option value="-3" '.check_select($load_timezone, "-3").'>GMT -3</option>
			<option value="-2" '.check_select($load_timezone, "-2").'>GMT -2</option>
			<option value="-1" '.check_select($load_timezone, "-1").'>GMT -1</option>
			<option value="0" '.check_select($load_timezone, "0").'>GMT</option>
			<option value="1" '.check_select($load_timezone, "1").'>GMT +1</option>
			<option value="2" '.check_select($load_timezone, "2").'>GMT +2</option>
			<option value="3" '.check_select($load_timezone, "3").'>GMT +3</option>
			<option value="4" '.check_select($load_timezone, "4").'>GMT +4</option>
			<option value="5" '.check_select($load_timezone, "5").'>GMT +5</option>
			<option value="6" '.check_select($load_timezone, "6").'>GMT +6</option>
			<option value="7" '.check_select($load_timezone, "7").'>GMT +7</option>
			<option value="8" '.check_select($load_timezone, "8").'>GMT +8</option>
			<option value="9" '.check_select($load_timezone, "9").'>GMT +9</option>
			<option value="10" '.check_select($load_timezone, "10").'>GMT +10</option>
			<option value="11" '.check_select($load_timezone, "11").'>GMT +11</option>
			<option value="12" '.check_select($load_timezone, "12").'>GMT +12</option>';
}

function home_online(){
	global $Prefix, $lang, $Mlevel;
	$visitors_sql = mysql_query("SELECT * FROM ".$Prefix."ONLINE WHERE O_MEMBER_LEVEL = '0' ") or die (mysql_error());
	$visitors_online = mysql_num_rows($visitors_sql);
	
	$members_sql = mysql_query("SELECT * FROM ".$Prefix."ONLINE WHERE O_MEMBER_LEVEL = '1' ") or die (mysql_error());
	$members_online = mysql_num_rows($members_sql);
	
	$moderators_sql = mysql_query("SELECT * FROM ".$Prefix."ONLINE WHERE O_MEMBER_LEVEL = '2' ") or die (mysql_error());
	$moderators_online = mysql_num_rows($moderators_sql);

	$monitors_sql = mysql_query("SELECT * FROM ".$Prefix."ONLINE WHERE O_MEMBER_LEVEL = '3' ") or die (mysql_error());
	$monitors_online = mysql_num_rows($monitors_sql);
			echo'
			<td vAlign="center"><nobr><font color="red">'.$lang['home']['online_now'].'</font>&nbsp;&nbsp;&nbsp;';
				echo $lang['home']['members'].'<font class="online">'.$members_online.'</font>&nbsp;&nbsp;&nbsp;';
				echo $lang['home']['the_moderator'].'<font class="online">'.$moderators_online.'</font>&nbsp;&nbsp;&nbsp;';
			if ($Mlevel > 2){	
				echo $lang['home']['the_monitor'].'<font class="online">'.$monitors_online.'</font>&nbsp;&nbsp;&nbsp;';
			}	
				echo $lang['home']['visitor'].'<font class="online">'.$visitors_online.'</font>';
			echo'
			<nobr></td>';
}

function home_add(){
	global $lang, $folder_new, $folder_new_order, $folder_other_cat;
	echo'
	<center>
	<table cellSpacing="0" cellPadding="0" width="99%" border="0">
		<tr>
			<td>
			<table class="grid" cellSpacing="1" cellPadding="0" width="100%" border="0">
				<tr>
					<td class="cat" align="middle">
						<a href="index.php?mode=add_cat_forum&method=add&type=c">'.icons($folder_new, $lang['home']['add_new_cat'], "hspace=\"3\"").'</a>
						<a href="index.php?mode=order">'.icons($folder_new_order, $lang['home']['order_cat_and_forum'], "hspace=\"3\"").'</a>
						<a href="index.php?mode=other_cat_add&method=cat">'.icons($folder_other_cat, $lang['other_cat_forum']['add_cat'], "hspace=\"3\"").'</a>
					</td>
				</tr>
			</table>
			</td>
		</tr>
	</table>
	</center>';
}

function home_forum_mods($id){
	global $Prefix;
	$sql = mysql_query("SELECT * FROM ".$Prefix."MODERATOR WHERE FORUM_ID = '$id' ") or die(mysql_error());
	$num = mysql_num_rows($sql);
	$forum_mods = '<table class="mods" cellspacing="0" cellpadding="0"><tr>';
 	$j = 0;
	$i = 0;
	while ($i < $num){
		$member_id = mysql_result($sql, $i, "MEMBER_ID");
		if ($j == 3){
			$forum_mods .= '</tr></table><table class="mods" cellspacing="0" cellpadding="0"><tr>';
			$j = 0;
		}
		$forum_mods .= '<td><nobr>&nbsp;';
		if ($j){
			$forum_mods .= ' + ';
		}
		$forum_mods .= normal_profile(members("NAME", $member_id), $member_id).'</td>';
	$i++;
	$j++;
	}
	$forum_mods .= '</tr></table>';
return($forum_mods);
}

function home($f){
	global 
	$lang, $Mlevel, $image_folder, $folder_locked, 
	$folder, $show_moderators, $folder_edit, $folder_unlocked,
	$folder_delete, $cat_monitor;
	
	$f_cat_id = forums("CAT_ID", $f);
	$f_subject = forums("SUBJECT", $f);
	$f_status = forums("STATUS", $f);
	$f_desc = forums("DESCRIPTION", $f);
	$f_topics = forums("TOPICS", $f);
	$f_replies = forums("REPLIES", $f);
	$f_last_post_date = forums("LAST_POST_DATE", $f);
	$f_last_post_author = forums("LAST_POST_AUTHOR", $f);
	$f_logo = forums("LOGO", $f);
	$author_name = members("NAME", $f_last_post_author);
							
							echo'
							<tr>
								<td class="f1">
								<table width="100%">
									<tr>
										<td class="logo" align="middle" width="55">'.icons($f_logo).'</td>
										<td class="f1"><a href="index.php?mode=f&f='.$f.'">'.$f_subject.'</a><br><font size="1">'.$f_desc.'</font></td>
									</tr>
								</table>
								</td>
								<td class="f2ts" vAlign="center" align="middle">
								<table width="100%">
									<tr>
										<td>';
										if ($f_status == 0) {
											echo icons($folder_locked, $lang['home']['forum_locked'], "");
										}
										else {
											echo icons($folder, $lang['home']['forum_opened'], "");
										}
										echo'
										</td>
										<td class="f2ts" vAlign="center" align="middle">'.$f_topics.'</td>
									</tr>
								</table>
							</td>
							<td class="f2ts">'.$f_replies.'</td>
							<td class="f2ts" width="25">'.forum_online_num($f).'</td>
							<td class="f2ts">';
							if ($author_name != "") {
								if ($f_replies != 0) {
									echo'
									<nobr><font color="red">'.normal_time($f_last_post_date).'</font><br>'.link_profile($author_name, $f_last_post_author);
								}
							}
							echo'
							</td>
							<td class="f1" align="center">
							<table class="mods" cellSpacing="0" cellPadding="0">
								<tr>
									<td><nobr>'.normal_profile(members("NAME", $cat_monitor), $cat_monitor).'</nobr></td>
								</tr>
							</table>
							</td>
							<td class="f1">';
							if ($show_moderators == 1) {
								echo home_forum_mods($f); // forum moderator
							}
							else{
								echo '&nbsp;';
							}
							echo'
							</td>';
							if ($Mlevel == 4) {
								echo'
								<td class="f2ts"><nobr>
									<a href="index.php?mode=editor&method=topic&f='.$f.'&c='.$f_cat_id.'">'.icons($folder, $lang['home']['add_new_topic'], "hspace=\"3\"").'</a>
									<a href="index.php?mode=add_cat_forum&method=edit&type=f&f='.$f.'">'.icons($folder_edit, $lang['home']['edit_forum'], "hspace=\"3\"").'</a>';
								if ($f_status == 1) {
									echo'
									<a href="index.php?mode=lock&type=f&f='.$f.'&c='.$f_cat_id.'" onclick="return confirm(\''.$lang['home']['you_are_sure_to_lock_this_forum'].'\');">'.icons($folder_locked, $lang['home']['lock_forum'], "hspace=\"3\"").'</a>';
								}
								if ($f_status == 0) {
									echo'<a href="index.php?mode=open&type=f&f='.$f.'&c='.$f_cat_id.'" onclick="return confirm(\''.$lang['home']['you_are_sure_to_open_this_forum'].'\');">'.icons($folder_unlocked, $lang['home']['open_forum'], "hspace=\"3\"").'</a>';
								}
									echo'
									<a href="index.php?mode=delete&type=f&f='.$f.'&c='.$f_cat_id.'" onclick="return confirm(\''.$lang['home']['you_are_sure_to_delete_this_forum'].'\');">'.icons($folder_delete, $lang['home']['delete_forum'], "hspace=\"3\"").'</a>
								</nobr></td>';
								}
							echo'
							</tr>';             
}

?>
