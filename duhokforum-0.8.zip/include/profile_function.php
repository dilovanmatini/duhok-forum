<?php
/*//////////////////////////////////////////////////////////
// ######################################################///
// # DuhokForum 0.8                                     # //
// ###################################################### //
// #                                                    # //
// #       --  DUHOK FORUM IS FREE SOFTWARE  --         # //
// #                                                    # //
// #   ========= Programming By Dilovan ==============  # //
// # Copyright � 2007-2008 Dilovan. All Rights Reserved # //
// #----------------------------------------------------# //
// #----------------------------------------------------# //
// # If you want any support vist down address:-        # //
// # Email: df@duhoktimes.com                           # //
// # Site: http://df.duhoktimes.com/index.php           # //
// ###################################################### //
//////////////////////////////////////////////////////////*/

function profile_member_title($m){
	global $Prefix;
	$sql = mysql_query("SELECT * FROM ".$Prefix."TITLES WHERE MEMBER_ID = '$m' AND STATUS = '1' ORDER BY DATE ASC ") or die (mysql_error());
	$num = mysql_num_rows($sql);
	$x = 0;
	while ($x < $num){
		$t = mysql_result($sql, $x, "TITLE_ID");
		$gt_id = titles("GT_ID", $t);
		$f = gt("FORUM_ID", $gt_id);
		$subject = gt("SUBJECT", $gt_id);
		if ($x > 0){
			$titles .= '<br>';
		}
		$titles .= $subject.' - <font color="red">'.forums("SUBJECT", $f).'</font>';
	++$x;
	}
return($titles);
}

function profile_moderator_title($m){
	global $Prefix, $lang;
	$sql = mysql_query("SELECT * FROM ".$Prefix."MODERATOR WHERE MEMBER_ID = '$m' ORDER BY MOD_ID ASC ") or die (mysql_error());
	$num = mysql_num_rows($sql);
	$x = 0;
	while ($x < $num) {
		$f = mysql_result($sql, $x, "FORUM_ID");
		if ($x > 0){
			$forums .= '<font color="red"> + </font>';
		}
		$forums .= '<a href="index.php?mode=f&f='.$f.'">'.forums("SUBJECT", $f).'</a>';
	++$x;
	}
	$titles = '<font color="red">'.$lang['function']['moderator_title'].'&nbsp;</font>'.$forums.'<br>'.member_title($m).'<br>'.profile_member_title($m);
return($titles);
}

function profile_monitor_title($m){
	global $Prefix, $lang;
	$sql = mysql_query("SELECT * FROM ".$Prefix."CATEGORY WHERE CAT_MONITOR = '$m' ORDER BY CAT_ID ASC ") or die (mysql_error());
	$num = mysql_num_rows($sql);
	$x = 0;
	while ($x < $num) {
		$c_name = mysql_result($sql, $x, "CAT_NAME");
		if ($x > 0){
			$cats .= '<font color="red"> + </font>';
		}
		$cats .= $c_name;
	++$x;
	}
	$titles = '<font color="red">'.$lang['function']['monitor_title'].'&nbsp;</font>'.$cats.'<br>'.member_title($m).'<br>'.profile_member_title($m);
return($titles);
}

?>
