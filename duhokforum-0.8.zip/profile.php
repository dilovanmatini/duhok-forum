<?php
/*//////////////////////////////////////////////////////////
// ######################################################///
// # DuhokForum 0.8                                     # //
// ###################################################### //
// #                                                    # //
// #       --  DUHOK FORUM IS FREE SOFTWARE  --         # //
// #                                                    # //
// #   ========= Programming By Dilovan ==============  # //
// # Copyright � 2007-2008 Dilovan. All Rights Reserved # //
// #----------------------------------------------------# //
// #----------------------------------------------------# //
// # If you want any support vist down address:-        # //
// # Email: df@duhoktimes.com                           # //
// # Site: http://df.duhoktimes.com/index.php           # //
// ###################################################### //
//////////////////////////////////////////////////////////*/

require_once("./include/profile_function.php");

if (members("STATUS", $id) == 1 OR $Mlevel > 1 AND members("NAME", $id) != "" OR $type != "") {

if ($id != "") {

$ppMemberID = $id;

if ($DBMemberID > 0) {

 $query = "SELECT * FROM " . $Prefix . "MEMBERS WHERE MEMBER_ID = '" .$ppMemberID."' ";
 $result = mysql_query($query, $connection) or die (mysql_error());

 if(mysql_num_rows($result) > 0){
 $rs=mysql_fetch_array($result);

 $ProMemberID = $rs['MEMBER_ID'];
 $ProMemberStatus = $rs['M_STATUS'];
 $ProMemberName = $rs['M_NAME'];
 $ProMemberEmail = $rs['M_EMAIL'];
 $ProMemberLevel = $rs['M_LEVEL'];
 $ProMemberCountry = $rs['M_COUNTRY'];
 $ProMemberCity = $rs['M_CITY'];
 $ProMemberPosts = $rs['M_POSTS'];
 $ProMemberState = $rs['M_STATE'];
 $ProMemberOccupation = $rs['M_OCCUPATION'];
 $ProMemberAge = $rs['M_AGE'];
 $ProMemberSex = $rs['M_SEX'];
 $ProMemberDate = $rs['M_DATE'];
 $ProMemberLastPostDate = $rs['M_LAST_POST_DATE'];
 $ProMemberLastHereDate = $rs['M_LAST_HERE_DATE'];
 $ProMemberPhotoURL = $rs['M_PHOTO_URL'];
 $ProMemberMarStatus = $rs['M_MARSTATUS'];
 $ProMemberBio = $rs['M_BIO'];
 $ProMemberTitle = $rs['M_TITLE'];
 $ProMemberOldMod = $rs['M_OLD_MOD'];
 $ProMemberSig = $rs['M_SIG'];
 $ProMemberPmHide = $rs['M_PMHIDE'];
 $ProMemberLogin = $rs['M_LOGIN'];
 $ProMemberBrowse = $rs['M_BROWSE'];
 $ProMemberHidePhoto = $rs['M_HIDE_PHOTO'];
 $ProMemberHideSig = $rs['M_HIDE_SIG'];
 }

 $queryCH = "SELECT * FROM " . $Prefix . "CHANGENAME_PENDING WHERE MEMBERID = '" .$ppMemberID."'";
 $resultCH = mysql_query($queryCH, $connection) or die (mysql_error());

 if(mysql_num_rows($resultCH) > 0){
 $rsCH=mysql_fetch_array($resultCH);

 $CHMemberID = $rsCH['MEMBERID'];
 }

if ($type == "") {
echo '
<center>
<table cellSpacing="0" cellPadding="0" width="99%" border="0">
	<tr>
		<td>
		<table class="optionsbar" cellSpacing="2" width="100%" border="0">
			<tr>
				<td vAlign="center"></td>
				<td class="optionsbar_title" vAlign="center" width="100%"><img hspace="7" border="0" src="'.$icon_profile.'">'.$lang['profile']['member_info'].' '.$ProMemberName.'</td>';
if ($Mlevel > 0 AND $ppMemberID != $DBMemberID) {
				echo'
				<td class="optionsbar_menus"><a href="index.php?mode=pm&mail=m&m='.$ppMemberID.'"><nobr>'.$lang['profile']['your_pm_with_this_member'].'</nobr></a></td>';
}
				echo'
				<td class="optionsbar_menus"><a href="index.php?mode=posts&m='.$ppMemberID.'"><nobr>'.$lang['profile']['posts_member'].'</nobr></a></td>';
                echo'
				<td class="optionsbar_menus"><a href="index.php?mode=topics&m='.$ppMemberID.'"><nobr>'.$lang['profile']['topics_member'].'</nobr></a></td>';
if ($Mlevel > 1) {
				echo'
				<td>&nbsp;</td>
				<td class="optionsbar_menus"><nobr><a href="index.php?mode=svc&method=award&svc=medals&m='.$ppMemberID.'">��� �����<br>����� ����</a></nobr></td>
				<td class="optionsbar_menus"><nobr><a href="index.php?mode=svc&method=award&svc=titles&m='.$ppMemberID.'">��� ���<br>�����</a></nobr></td>
				<td>&nbsp;</td>
				<td class="optionsbar_menus"><nobr><a href="index.php?mode=svc&svc=medals&app=all&scope=all&days=all&m='.$ppMemberID.'">������<br>����� �����</a></nobr></td>
				<td class="optionsbar_menus"><nobr><a href="index.php?mode=svc&svc=titles&m='.$ppMemberID.'">�����<br>�����</a></nobr></td>
				<td class="optionsbar_menus"><nobr><a href="index.php?mode=requestmon&aid='.$ppMemberID.'">�����<br>�������</a></nobr></td>';
}
if ($Mlevel == 4) {
				echo'
				<td>&nbsp;</td>
				<td class="optionsbar_menus"><a href="index.php?mode=profile&type=edit_user&id='.$ppMemberID.'"><nobr>'.$lang['profile']['edit_member'].'</nobr></a></td>';
			if ($ProMemberStatus == 1){
				echo'
				<td class="optionsbar_menus"><a href="index.php?mode=lock&type=m&m='.$ppMemberID.'"><nobr>���<br>�������</nobr></a></td>';
			}
			if ($ProMemberStatus == 0){
				echo'
				<td class="optionsbar_menus"><a href="index.php?mode=open&type=m&m='.$ppMemberID.'"><nobr>���<br>�������</nobr></a></td>';
			}
}
            go_to_forum();
            echo'
            </tr>
		</table>
		</td>
	</tr>
</table>
</center>
<center>
<table cellSpacing="0" cellPadding="0" width="99%" border="0">
	<tr>
		<td>
		<table cellSpacing="1" cellPadding="0" width="888" align="center" border="0">
			<tr>
				<td vAlign="top" width="307">
				<table cellSpacing="2" cellPadding="3" width="100%" border="0">
					<tr>
						<td class="userdetails_header" align="middle" colSpan="2"><b><font size="3">'.$lang['profile']['single_photo'].'</font></b></td>
					</tr>
     
					<tr>
						<td class="userdetails_data" vAlign="top" noWrap align="middle" colSpan="2">';
				if ($ProMemberPhotoURL != "" AND ($ProMemberHidePhoto == 0 OR $Mlevel > 1)) {
      						echo'<a href="'.$ProMemberPhotoURL.'">
      						<img onerror="this.src=\''.$icon_photo_none.'\';" alt="'.$ProMemberName.'" src="'.$ProMemberPhotoURL.'" border="0" width="120"></a>';
				}
				else {
						echo'<a href="'.$icon_photo_none.'">
						<img alt="'.$ProMemberName.'" src="'.$icon_photo_none.'" border="0"></a>';
				}
						echo'<br><b><font size="3">'.$lang['profile']['click_here_to_zoom_in_this_photo'].'</font></b>';
						echo'</td>
					</tr>';
					echo'<tr>
						<td class="userdetails_header" align="middle" colSpan="2"><b><font size="3">'.$lang['profile']['way_to_call_me'].'</font></b></td>
					</tr>';
if ($ProMemberPmHide == 1) {

	if ($ppMemberID == 1) {
                    echo'
					<tr>
						<td class="userdetails_title" vAlign="top" noWrap align="left"><b><font size="3">'.$lang['profile']['private_message'].'</font></b></td>
						<td class="userdetails_data" width="100%"><font size="3"><a href="index.php?mode=sendpm&msg=1&m=1">'.$lang['profile']['send_pm_to_this_member'].'</a></font></td>
					</tr>';
	}
	else {
                    echo'
					<tr>
						<td class="userdetails_title" vAlign="top" noWrap align="left"><b><font size="3">'.$lang['profile']['private_message'].'</font></b></td>
						<td class="userdetails_data" width="100%"><font size="3"><a href="index.php?mode=editor&method=sendmsg&m='.$ppMemberID.'">'.$lang['profile']['send_pm_to_this_member'].'</a></font></td>
					</tr>';
	}
}
else {
    if ($Mlevel > 1) {
                    echo'
					<tr>
						<td class="userdetails_title" vAlign="top" noWrap align="left"><b><font size="3">'.$lang['profile']['private_message'].'</font></b></td>
						<td class="userdetails_data" width="100%"><font size="3"><a href="index.php?mode=editor&method=sendmsg&m='.$ppMemberID.'">'.$lang['profile']['send_pm_to_this_member'].'</a></font></td>
					</tr>';
    }
}
if ($Mlevel > 1) {
                    echo'
					<tr>
						<td class="userdetails_title" vAlign="top" noWrap align="left"><b><font size="3">'.$lang['profile']['the_email'].'</font></b></td>
						<td class="userdetails_data" width="100%"><b><font size="3"><a href="mailto:'.$ProMemberEmail.'">'.$lang['profile']['send_email_to_this_member'].'</a></font></b></td>
					</tr>';
}

					echo'
					<tr>
						<td class="userdetails_header" align="middle" colSpan="2"><b><font size="3">'.$lang['profile']['statistics'].'</font></b></td>
					</tr>';
				if ($ProMemberStatus == 0){
					echo'
					<tr>
						<td class="userdetails_title" vAlign="top" noWrap align="left"><b><font size="3">��� �������:</font></b></td>
						<td class="userdetails_data" width="100%"><font size="3" color="red">������� ������</font></td>
					</tr>';
				}
				if (member_all_points($ppMemberID) > 0){
					echo'
					<tr>
						<td class="userdetails_title" vAlign="top" noWrap align="left"><b><font size="3">���� ������:</font></b></td>
						<td class="userdetails_data" width="100%"><font size="3">'.member_all_points($ppMemberID).'</font></td>
					</tr>';
				}
					echo'
					<tr>
						<td class="userdetails_title" vAlign="top" noWrap align="left"><b><font size="3">'.$lang['profile']['number_posts'].'</font></b></td>
						<td class="userdetails_data" width="100%"><font size="3">'.$ProMemberPosts.'</font></td>
					</tr>
                  
					<tr>
						<td class="userdetails_title" vAlign="top" noWrap align="left"><b><font size="3">'.$lang['profile']['rejister_date'].'</font></b></td>
						<td class="userdetails_data" width="100%"><font size="3">'.normal_time($ProMemberDate).'</font></td>
					</tr>';
			if ($ProMemberLastPostDate != "") {
                if ($ppMemberID == 1) {
                    echo'';
                }
				else {
                    echo'
					<tr>
						<td class="userdetails_title" vAlign="top" noWrap align="left"><b><font size="3">'.$lang['profile']['last_post'].'</font></b></td>
						<td class="userdetails_data" width="100%"><font size="3">'.normal_time($ProMemberLastPostDate).'</font></td>
					</tr>';
                }
			}
			if ($Mlevel > 1) {
				if (!empty($ProMemberLastHereDate)){
                    echo'
					<tr>
						<td class="userdetails_title" vAlign="top" noWrap align="left"><b><font size="3">'.$lang['profile']['last_visit'].'</font></b></td>
						<td class="userdetails_data" width="100%"><font size="3">'.normal_time($ProMemberLastHereDate).'</font></td>
					</tr>';
				}
			}
			else{
				if (!empty($ProMemberLastHereDate) AND $ProMemberBrowse == 1){
                    echo'
					<tr>
						<td class="userdetails_title" vAlign="top" noWrap align="left"><b><font size="3">'.$lang['profile']['last_visit'].'</font></b></td>
						<td class="userdetails_data" width="100%"><font size="3">'.normal_time($ProMemberLastHereDate).'</font></td>
					</tr>';
				}
			}
			$member_is_online = member_is_online($ppMemberID);
			if ($Mlevel > 1) {
				if ($member_is_online == 1){
                    echo'
					<tr>
						<td class="userdetails_title" vAlign="top" noWrap align="left"><b><font size="3">'.$lang['profile']['status'].'</font></b></td>
						<td class="userdetails_data" width="100%">
						<table border="0">
							<tr>
								<td class="optionsbar_menus2">'.icons($icon_online).'<br><font size="1">'.$lang['profile']['status_online'].'</font></td>
							</tr>
						</table>
						</td>
					</tr>';
				}
			}
			else{
				if ($member_is_online == 1 AND $ProMemberBrowse == 1){
                    echo'
					<tr>
						<td class="userdetails_title" vAlign="top" noWrap align="left"><b><font size="3">'.$lang['profile']['status'].'</font></b></td>
						<td class="userdetails_data" width="100%">
						<table border="0">
							<tr>
								<td class="optionsbar_menus2" align="center"><img src="'.$icon_online.'" hspace="0" border="0"><br><font size="1">'.$lang['profile']['status_online'].'</font></td>
							</tr>
						</table>
						</td>
					</tr>';
				}
			}
//------------------------------------------ CHANGES NAMES BY MR TAZI / H -------------------------------------------

if ($CHMemberID != "") {
					echo'<tr>
						<td class="userdetails_header" align="middle" colSpan="2"><b><font size="3">'.$lang['profile']['member_last_name'].'</font></b></td>
					</tr>';
 $query = "SELECT * FROM " . $Prefix . "CHANGENAME_PENDING WHERE MEMBERID = '" .$ppMemberID."' AND UNDERDEMANDE = '0' ";
 $query .= " ORDER BY CH_DATE DESC";
 $result = mysql_query($query, $connection) or die (mysql_error());

 $num = mysql_num_rows($result);
	
 $i=0;
 while ($i < $num) {

    $CH_NameID = mysql_result($result, $i, "CHNAME_ID");
    $CH_OriginalName = mysql_result($result, $i, "LAST_NAME");
    $CH_Date = mysql_result($result, $i, "CH_DATE");

                    echo'
                    			<tr>
						<td class="userdetails_title" vAlign="top" noWrap align="center"><b><font size="3">'.normal_date($CH_Date).':</font></b></td>
						<td class="userdetails_data" width="100%"><font size="3">'.$CH_OriginalName.'</font></td>
					</tr>';
    ++$i;
 }
}

//------------------------------------------ CHANGES NAMES BY MR TAZI / F -------------------------------------------

                echo'		</table>
				</td>
				<td vAlign="top" width="33">&nbsp;</td>
				<td vAlign="top">
				<table cellSpacing="2" cellPadding="3" width="560" border="0" valign="top">
					<tr>
						<td class="userdetails_header" align="middle" colSpan="2"><b><font size="3">'.$lang['profile']['total_details'].'</font></b></td>
					</tr>';
if ($Mlevel > 1) {
                    echo'
                    <tr>
						<td class="userdetails_title" vAlign="top" noWrap align="left"><b><font size="3">'.$lang['profile']['member_id'].'</font></b></td>
						<td class="userdetails_data" width="100%"><font size="3">'.$ProMemberID.'</font></td>
					</tr>';
}
if ($ProMemberLevel == 1 AND profile_member_title($ppMemberID) != "" OR $ProMemberOldMod > 0) {
                    echo'
                    <tr>
						<td class="userdetails_title" vAlign="top" noWrap align="left"><b><font size="3">'.$lang['profile']['the_title'].'</font></b></td>
						<td class="userdetails_data" width="100%"><font size="3">'.old_mod($ppMemberID, "3", "").''.profile_member_title($ppMemberID).'</font></td>
					</tr>';
}
if ($ProMemberLevel == 2 AND profile_moderator_title($ppMemberID) != "") {
                    echo'
                    <tr>
						<td class="userdetails_title" vAlign="top" noWrap align="left"><b><font size="3">'.$lang['profile']['the_title'].'</font></b></td>
						<td class="userdetails_data" width="100%"><font size="3">'.profile_moderator_title($ppMemberID).'</font></td>
					</tr>';
}
if ($ProMemberLevel == 3 AND profile_monitor_title($ppMemberID) != "") {
                    echo'
                    <tr>
						<td class="userdetails_title" vAlign="top" noWrap align="left"><b><font size="3">'.$lang['profile']['the_title'].'</font></b></td>
						<td class="userdetails_data" width="100%"><font size="3">'.profile_monitor_title($ppMemberID).'</font></td>
					</tr>';
}
if ($ProMemberLevel == 4 AND member_title($ppMemberID) != "") {
                    echo'
                    <tr>
						<td class="userdetails_title" vAlign="top" noWrap align="left"><b><font size="3">'.$lang['profile']['the_title'].'</font></b></td>
						<td class="userdetails_data" width="100%"><font size="3">'.member_title($ppMemberID).'</font></td>
					</tr>';
}


if ($ProMemberCity != "" || $ProMemberState != "" || $ProMemberCountry != "") {

    if ($ProMemberCity != "") {
        $ProMemberCity = $ProMemberCity."<br>";
    }
    if ($ProMemberState != "") {
        $ProMemberState = $ProMemberState."<br>";
    }
                    echo'
                    <tr>
						<td class="userdetails_title" vAlign="top" noWrap align="left"><b><font size="3">'.$lang['profile']['address'].'</font></b></td>
						<td class="userdetails_data" width="100%"><font size="3">'.$ProMemberCity.$ProMemberState.$ProMemberCountry.'</font></td>
					</tr>';
}
if ($ProMemberAge != "") {
                    echo'
					<tr>
						<td class="userdetails_title" vAlign="top" noWrap align="left"><b><font size="3">'.$lang['profile']['the_age'].'</font></b></td>
						<td class="userdetails_data" width="100%"><font size="3">'.$ProMemberAge.'</font></td>
					</tr>';
}
if ($ProMemberMarStatus != "") {
                    echo'
					<tr>
						<td class="userdetails_title" vAlign="top" noWrap align="left"><b><font size="3">'.$lang['profile']['the_sociability_status'].'</font></b></td>
						<td class="userdetails_data" width="100%"><font size="3">'.$ProMemberMarStatus.'</font></td>
					</tr>';
}
if ($ProMemberSex != "" && $ProMemberSex != 0) {
    if ($ProMemberSex == "1") {
        $MemberSex = $lang['profile']['male'];
    }
    if ($ProMemberSex == "2") {
        $MemberSex = $lang['profile']['female'];
    }
                    echo'
					<tr>
						<td class="userdetails_title" vAlign="top" noWrap align="left"><b><font size="3">'.$lang['profile']['the_sex'].'</font></b></td>
						<td class="userdetails_data" width="100%"><font size="3">'.$MemberSex.'</font></td>
					</tr>';
}
if ($ProMemberOccupation != "") {
                    echo'
					<tr>
						<td class="userdetails_title" vAlign="top" noWrap align="left"><b><font size="3">'.$lang['profile']['the_occupation'].'</font></b></td>
						<td class="userdetails_data" width="100%"><font size="3">'.$ProMemberOccupation.'</font></td>
					</tr>';
}
//###########################  medals ##############################
	if ($app == "all"){
		$sql_open_all = '';
	}
	else{
		$sql_open_all = 'LIMIT 9';
	}
	$sql = mysql_query("SELECT * FROM ".$Prefix."MEDALS WHERE MEMBER_ID = '$ppMemberID' AND STATUS = '1' ORDER BY DATE DESC ".$sql_open_all." ") or die(mysql_error());
	$num = mysql_num_rows($sql);
	if ($num > 0){
		echo'
		<tr>
			<td class="userdetails_header" align="middle" colSpan="2"><b><font size="3">����� ������ �������� �����</font></b></td>
		</tr>
		<tr>
			<td class="userdetails_data" width="100%" colspan="2">
			<table border="0" width="100%" cellpadding="6">
				<tr>';
		$count = 0;
		$x = 0;
		while($x < $num){
			$m = mysql_result($sql, $x, "MEDAL_ID");
			$gm_id = medals("GM_ID", $m);
			$url = medals("URL", $m);
			$f = medals("FORUM_ID", $m);
			$subject = gm("SUBJECT", $gm_id);
			$date = medals("DATE", $m);
					echo'
					<td align="center">'.icons($url).'<br><font color="red" size="-2">'.forums("SUBJECT", $f).'<br></font><font color="black" size="-2">'.$subject.'<br><font color="orange" size="-2">'.normal_date($date).'</font></font></td>';
			$three_medals = $three_medals + 1;
			if ($three_medals == 3){
				echo'
				</tr>
				<tr>';
				$three_medals = 0;
			}
			$count += 1;
		++$x;
		}
				echo'
				</tr>
			</table>';
		if ($count > 8 AND $app != "all"){
			echo'
			<br><div align="center"><font size="1"><a class="menu" href="index.php?mode=profile&id='.$ppMemberID.'&app=all">-- ���� ����� ���� ���� ����� -- ���� ��� ��������� ������� --</a></font></div>';
		}
		if ($count > 8 AND $app == "all"){
			echo'
			<br><div align="center"><font size="1"><a class="menu" href="index.php?mode=profile&id='.$ppMemberID.'">-- ���� ��� ������ ��� ����� ��������� --</a></font></div>';
		}
			echo'
			</td>
		</tr>';
	}
//###########################  medals ##############################
if ($ProMemberBio != "") {
                    echo'
					<tr>
						<td class="userdetails_header" align="middle" colSpan="2"><b><font size="3">'.$lang['profile']['additional_info'].'</font></b></td>
					</tr>
					<tr>
						<td class="userdetails_title" vAlign="top" noWrap align="left"><b><font size="3">'.$lang['profile']['the_biography'].'</font></b></td>
						<td class="userdetails_data" width="100%"><font size="3">'.$ProMemberBio.'</font></td>
					</tr>';
}
                echo'
				</table>
				</td>
			</tr>
            <tr>
                <td>&nbsp;</td>
            </tr>';
   
if ($ProMemberSig != "" AND ($ProMemberHideSig == 0 OR $Mlevel > 1)) {
            echo'<tr>
				<td vAlign="top" width="99%" colSpan="3">
				<table cellSpacing="2" cellPadding="3" width="100%" border="0">
					<tr>
						<td class="userdetails_header" align="middle"><b><font size="3">'.$lang['profile']['the_signature'].'</font></b></td>
					</tr>
					<tr>
						<td class="userdetails_data" width="100%"><font size="3">'.text_replace($ProMemberSig).'</font></td>
					</tr>
                </table>
                </td>
            </tr>
            <tr>
                <td>&nbsp;</td>
            </tr>';
}
            echo'
		</table>
		</td>
	</tr>
</table>
</center>
';

}
}
else {
	                echo'<br><center>
	                <table width="99%" border="1">
	                   <tr class="normal">
	                       <td class="list_center" colSpan="10"><font size="5" color="red"><br>'.$lang['profile']['you_must_login_to_view'].'</font><br><br>
	                       <a href="JavaScript:history.go(-1)">'.$lang['profile']['click_here_to_back'].'</a><br><br>
	                       </td>
	                   </tr>
	                </table>
	                </center><xml>';
                 

    }
}

if ($type == "details") {

echo'<br><br>
<center>
<table cellSpacing="1" cellPadding="4" bgColor="gray" border="0" id="table1">
	<tr class="fixed">
		<td class="list"><img src="'.$details.'"></td>
		<td class="optionheader">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<font color="yellow" size="+2">'.$lang['profile']['your_options_and_details'].'</font>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<br>'.$lang['profile']['please_choose_one'].'</td>
	</tr>
	<tr class="fixed">
		<td class="list" colSpan="2">
		<a href="index.php?mode=profile&type=edit_pass">'.$lang['profile']['edit_your_password_and_email'].'</a></td>
	</tr>
	<tr class="fixed">
		<td class="list" colSpan="2">
		<a href="index.php?mode=profile&type=edit_details">'.$lang['profile']['edit_your_details_and_options'].'</a></td>
	</tr>
	<tr class="fixed">
		<td class="list" colSpan="2">
		<a href="index.php?mode=editor&method=sig">'.$lang['profile']['edit_your_signature'].'</a></td>
	</tr>
	<tr class="fixed">
		<td class="list" colSpan="2">
		<a href="index.php?mode=profile&type=medals">'.$lang['profile']['your_medals_info'].'</a></td>
	</tr>
	<tr class="fixed">
		<td class="list" colSpan="2">
		<a href="index.php?mode=hide_topics">'.$lang['profile']['private'].'</a></td>
	</tr>
	<tr class="fixed">
		<td class="list" colSpan="2">
		<a href="index.php?mode=changename">'.$lang['profile']['change_username'].'</a></td>
	</tr>
	</table>
</center>';
}

if ($type == "edit_details") {

    if ($DBMemberID > 0) {

 $query = "SELECT * FROM " . $Prefix . "MEMBERS WHERE MEMBER_ID = ".$DBMemberID." ";
 $result = mysql_query($query, $connection) or die (mysql_error());

 if(mysql_num_rows($result) > 0){
 $rs=mysql_fetch_array($result);

 $ProMemberID = $rs['MEMBER_ID'];
 $ProMemberName = $rs['M_NAME'];
 $ProMemberCountry = $rs['M_COUNTRY'];
 $ProMemberCity = $rs['M_CITY'];
 $ProMemberPosts = $rs['M_POSTS'];
 $ProMemberState = $rs['M_STATE'];
 $ProMemberOccupation = $rs['M_OCCUPATION'];
 $ProMemberAge = $rs['M_AGE'];
 $ProMemberSex = $rs['M_SEX'];
 $ProMemberDate = $rs['M_DATE'];
 $ProMemberLastPostDate = $rs['M_LASTPOSTDATE'];
 $ProMemberPhotoURL = $rs['M_PHOTO_URL'];
 $ProMemberMarStatus = $rs['M_MARSTATUS'];
 $ProMemberReceiveEmail = $rs['M_RECEIVE_EMAIL'];
 $ProMemberBio = $rs['M_BIO'];
 $ProMemberTitle = $rs['M_TITLE'];
 $ProMemberPmHide = $rs['M_PMHIDE'];
 $ProMemberBrowse = $rs['M_BROWSE'];
 }

echo'
<script>
 function submitdetails()
{

if (detailsinfo.user_age.value.length == 1)
	{
	confirm("'.$lang['profile']['ecessary_to_insert_more_twelve_years'].'");
	return;
	}

if (detailsinfo.user_age.value.length > 2)
	{
	confirm("'.$lang['profile']['necessary_to_insert_less_ninety_nine_years'].'");
	return;
	}


detailsinfo.submit();
}
</script>';

echo'<center>
<table cellSpacing="0" cellPadding="0" width="99%" border="0">
	<tr>
		<td><center><font color="red" size="+2">'.$lang['profile']['edit_your_details'].'</font><br>'.$lang['profile']['please_update_your_details'].'<br>&nbsp;
            <form name="detailsinfo" method="post" action="index.php?mode=profile&type=insert_details">
			<table cellSpacing="1" cellPadding="4" bgColor="gray" border="0">
				<tr class="fixed">
					<td class="optionheader" id="row_user_city"><nobr>'.$lang['profile']['the_city'].'</nobr></td>
					<td class="list"><input class="insidetitle" style="WIDTH: 200px" value="'.$ProMemberCity.'" name="user_city"></td>
					<td class="optionheader" id="row_user_state"><nobr>'.$lang['profile']['the_state'].'</nobr></td>
					<td class="list"><input class="insidetitle" style="WIDTH: 200px" value="'.$ProMemberState.'" name="user_state"></td>
				</tr>
				<tr class="fixed">
					<td class="optionheader" id="row_user_country">'.$lang['profile']['the_country'].' </td>
					<td>
					<select class="insidetitle" style="WIDTH: 200px" name="user_country" type="text">';
                    $selected = $ProMemberCountry;
                    include("country.php");
					echo'</select></td>
					<td class="optionheader" id="row_user_occupation"><nobr>'.$lang['profile']['the_occupation'].'</nobr></td>
					<td class="list"><input class="insidetitle" style="WIDTH: 200px" value="'.$ProMemberOccupation.'" name="user_occupation"></td>
				</tr>
				<tr class="fixed">
					<td class="optionheader" id="row_user_marstatus"><nobr>'.$lang['profile']['the_sociability_status'].' </nobr></td>
					<td class="list"><input class="insidetitle" style="WIDTH: 200px" value="'.$ProMemberMarStatus.'" name="user_marstatus"></td>
					<td class="optionheader" id="row_user_age"><nobr>'.$lang['profile']['the_age'].'</nobr></td>
					<td class="list"><input class="insidetitle" style="WIDTH: 200px" value="'.$ProMemberAge.'" name="user_age"></td>
				</tr>

				<tr class="fixed">
					<td class="optionheader" id="row_user_gender">'.$lang['profile']['the_sex'].' </td>
					<td class="list" colSpan="3">
					<input class="small" type="radio" value="0" name="user_gender" '.check_radio($ProMemberSex, "0").'>'.$lang['profile']['no_selected'].'&nbsp;&nbsp;&nbsp;
					<input class="small" type="radio" value="1" name="user_gender" '.check_radio($ProMemberSex, "1").'>'.$lang['profile']['male'].'&nbsp;&nbsp;&nbsp;
					<input class="small" type="radio" value="2" name="user_gender" '.check_radio($ProMemberSex, "2").'>'.$lang['profile']['female'].'
					</td>
				</tr>
    
				<tr class="fixed">
					<td class="optionheader" id="row_user_hideemail">'.$lang['profile']['the_email'].' </td>
					<td class="list"><input class="small" type="radio" value="0" name="user_hideemail" '.check_radio($ProMemberReceiveEmail, "0").'>'.$lang['profile']['the_member_not_allowed_to_send_email'].'</td>
					<td class="list" colSpan="2"><input class="small" type="radio" value="1" name="user_hideemail" '.check_radio($ProMemberReceiveEmail, "1").'>'.$lang['profile']['the_member_allowed_to_send_email'].'</td>
				</tr>
				<tr class="fixed">
					<td class="optionheader" id="row_user_allowmsgs">'.$lang['profile']['private_message'].' </td>
					<td class="list"><input class="small" type="radio" value="0" name="user_pmhide" '.check_radio($ProMemberPmHide, "0").'>'.$lang['profile']['the_member_not_allowed_to_send_pm'].'</td>
					<td class="list" colSpan="2"><input class="small" type="radio" value="1" name="user_pmhide" '.check_radio($ProMemberPmHide, "1").'>'.$lang['profile']['the_member_allowed_to_send_pm'].'</td>
				</tr>
				<tr class="fixed">
					<td class="optionheader" id="row_user_hideactivity">'.$lang['profile']['your_browse'].' </td>
					<td class="list"><input class="small" type="radio" value="1" name="user_hideactivity" '.check_radio($ProMemberBrowse, "1").'>'.$lang['profile']['your_browse_show'].'</td>
					<td class="list" colSpan="2"><input class="small" type="radio" value="0" name="user_hideactivity" '.check_radio($ProMemberBrowse, "0").'>'.$lang['profile']['your_browse_hide'].'</td>
				</tr>';

            if ($Mlevel > 1) {
                echo'
				<tr class="fixed">
					<td class="optionheader" id="row_user_photo_url"><nobr>'.$lang['profile']['your_title'].' </nobr></td>
					<td class="list" align="right" colSpan="3"><input class="insidetitle" style="WIDTH: 100%" value="'.$ProMemberTitle.'" name="user_title"></td>
				</tr>';
            }
                echo'
				<tr class="fixed">
					<td class="optionheader" id="row_user_photo_url"><nobr>'.$lang['profile']['your_single_photo'].' </nobr></td>
					<td class="list" dir="ltr" align="right" colSpan="3"><input class="insidetitle" style="WIDTH: 100%" value="'.$ProMemberPhotoURL.'" name="user_photo_url"></td>
				</tr>
				<tr class="fixed">
					<td class="optionheader" id="row_user_bio">'.$lang['profile']['your_biography'].' </td>
					<td class="list" colSpan="3"><textarea class="insidetitle" style="WIDTH: 100%; HEIGHT: 70px" name="user_bio" type="text" rows="1" cols="20">'.$ProMemberBio.'</textarea></td>
				</tr>
				<tr class="fixed">
					<td class="list_center" colSpan="5"><input onclick="submitdetails()" type="button" value="'.$lang['profile']['insert_info'].'">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<input type="reset" value="'.$lang['profile']['reset_info'].'"></td>
				</tr>
			</table>
			</form>
		</center></td>
	</tr>
</table>
</center>';

    }
    else {
    redirect();
    }

}



if ($type == "insert_details") {

    if ($DBMemberID > 0) {


$user_country = HtmlSpecialchars($_POST["user_country"]);
$user_city = HtmlSpecialchars($_POST["user_city"]);
$user_state = HtmlSpecialchars($_POST["user_state"]);
$user_age = HtmlSpecialchars($_POST["user_age"]);
$user_gender = HtmlSpecialchars($_POST["user_gender"]);
$user_photo_url = HtmlSpecialchars($_POST["user_photo_url"]);
$user_marstatus = HtmlSpecialchars($_POST["user_marstatus"]);
$user_hideemail = HtmlSpecialchars($_POST["user_hideemail"]);
$user_bio = HtmlSpecialchars($_POST["user_bio"]);
$user_occupation = HtmlSpecialchars($_POST["user_occupation"]);
$user_title = $_POST["user_title"];
$user_pmhide = HtmlSpecialchars($_POST["user_pmhide"]);
$user_browse = HtmlSpecialchars($_POST["user_hideactivity"]);



if ($error == "") {
		$query = "UPDATE " . $Prefix . "MEMBERS SET ";
        $query .= "M_COUNTRY = ('$user_country'), ";
        $query .= "M_CITY = ('$user_city'), ";
        $query .= "M_STATE = ('$user_state'), ";
        $query .= "M_AGE = ('$user_age'), ";
        $query .= "M_SEX = ('$user_gender'), ";
        $query .= "M_PHOTO_URL = ('$user_photo_url'), ";
        $query .= "M_MARSTATUS = ('$user_marstatus'), ";
        $query .= "M_RECEIVE_EMAIL = ('$user_hideemail'), ";
        $query .= "M_BIO = ('$user_bio'), ";
        $query .= "M_OCCUPATION = ('$user_occupation'), ";
        $query .= "M_PMHIDE = ('$user_pmhide'), ";
        $query .= "M_BROWSE = ('$user_browse'), ";
        $query .= "M_TITLE = ('$user_title') ";
        $query .= "WHERE MEMBER_ID = ".$DBMemberID." ";
		mysql_query($query, $connection) or die (mysql_error());
  
                    echo'
	                <center>
	                <table width="99%" border="1">
	                   <tr class="normal">
	                       <td class="list_center" colSpan="10"><font size="5"><br>'.$lang['profile']['your_details_has_edited'].'</font><br><br>
                           <meta http-equiv="Refresh" content="2; URL=index.php?mode=profile&type=details">
                           <a href="index.php?mode=profile&type=details">'.$lang['profile']['click_here_to_go_normal_page'].'</a><br>
	                       <br></td>
	                   </tr>
	                </table>
	                </center>';
}


    }
    else {
    redirect();
    }

}

if ($type == "edit_pass") {

    if ($DBMemberID > 0) {

 $query = "SELECT * FROM " . $Prefix . "MEMBERS WHERE MEMBER_ID = ".$DBMemberID." ";
 $result = mysql_query($query, $connection) or die (mysql_error());

 if(mysql_num_rows($result) > 0){
 $rs=mysql_fetch_array($result);

 $ProMemberID = $rs['MEMBER_ID'];
 $ProMemberName = $rs['M_NAME'];
 $ProMemberEmail = $rs['M_EMAIL'];
 $ProMemberPassword = $rs['M_PASSWORD'];

 }


echo'
<script>

 function submitpass()
{


if (passinfo.user_password0.value.length != 0)
{

if (passinfo.user_password1.value.length == 0)
    {
	confirm("'.$lang['register_js']['necessary_to_insert_password'].'");
	return;
    }

if (passinfo.user_password1.value.length != 0)
{
    if (passinfo.user_password1.value.length < 6)
	{
	confirm("'.$lang['register_js']['necessary_to_insert_more_five_letter_to_password'].'");
	return;
	}
}

if (passinfo.user_password1.value.length > 24)
	{
	confirm("'.$lang['register_js']['necessary_to_insert_less_twenty_four_letter_to_password'].'");
	return;
	}

if (passinfo.user_password1.value.length != 0)
{
    if (passinfo.user_password2.value.length < 6)
	{
	confirm("'.$lang['register_js']['necessary_to_insert_confirm_password'].'");
	return;
	}
}

if (passinfo.user_password1.value  != passinfo.user_password2.value)
	{
	confirm("'.$lang['register_js']['necessary_to_insert_true_confirm_password'].'");
	return;
	}

if (passinfo.user_password1.value  == passinfo.user_name.value)
	{
	confirm("'.$lang['register_js']['necessary_to_password_reversal_to_user_name'].'");
	return;
	}

if (passinfo.user_password1.value.toLowerCase()  == passinfo.user_name.value.toLowerCase())
	{
	confirm("'.$lang['register_js']['necessary_to_password_reversal_to_user_name'].'");
	return;
	}

if (passinfo.user_password1.value.toLowerCase()  == passinfo.user_email.value.toLowerCase())
	{
	confirm("'.$lang['register_js']['necessary_to_password_reversal_to_email'].'");
	return;
	}
}

if (passinfo.user_email.value.length == 0)
	{
	confirm("'.$lang['register_js']['necessary_to_insert_email'].'");
	return;
	}

if (!/^[a-zA-Z0-9._-]+@([a-zA-Z0-9.-]+\.)+[a-zA-Z0-9.-]{2,4}$/.test(passinfo.user_email.value))
	{
	confirm("'.$lang['register_js']['necessary_to_insert_true_email'].'");
	return;
	}

passinfo.submit();
}
</script>';


echo'
<center>
<table cellSpacing="0" cellPadding="0" width="99%" border="0">
	<tr>
		<td><center><font color="red" size="+2">'.$lang['profile']['edit_your_details'].'</font><br>'.$lang['profile']['please_update_your_details'].'<br>&nbsp;
            <form name="passinfo" method="post" action="index.php?mode=profile&type=insert_pass">
            <input value="'.$ProMemberName.'" type="hidden" name="user_name">
            <input value="'.$ProMemberPassword.'" type="hidden" name="user_password">
			<table cellSpacing="1" cellPadding="4" bgColor="gray" border="0">
				<tr class="fixed">
					<td class="optionheader" id="row_user_password0"><nobr>'.$lang['profile']['your_password_to_use_now'].' </nobr></td>
					<td class="list" dir="ltr" align="right" colSpan="3"><input class="insidetitle" style="WIDTH: 100%" type="password" name="user_password0"></td>
				</tr>
				<tr class="fixed">
					<td class="optionheader" id="row_user_email"><nobr>'.$lang['profile']['the_email'].' </nobr></td>
					<td class="list" dir="ltr" align="right" colSpan="3"><input class="insidetitle" style="WIDTH: 100%" value="'.$ProMemberEmail.'" name="user_email"></td>
				</tr>
				<tr class="fixed">
					<td class="optionheader" id="row_user_password1"><nobr>'.$lang['profile']['the_new_password'].' </nobr></td>
					<td class="list"><input class="insidetitle" style="WIDTH: 200px" type="password" name="user_password1"></td>
					<td class="optionheader" id="row_user_password2"><nobr>'.$lang['profile']['the_confirm_new_password'].' </nobr></td>
					<td class="list"><input class="insidetitle" style="WIDTH: 200px" type="password" name="user_password2"></td>
				</tr>
				<tr class="fixed">
					<td class="list_center" colSpan="5"><input onclick="submitpass()" type="button" value="'.$lang['profile']['insert_info'].'">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<input type="reset" value="'.$lang['profile']['reset_info'].'"></td>
				</tr>
			</table>
		</form>
		</center></td>
	</tr>
</table>
</center>';

    }
    else {
    redirect();
    }

}


if ($type == "insert_pass") {

    if ($DBMemberID > 0) {


$user_password = HtmlSpecialchars($_POST["user_password"]);
$user_password0 = HtmlSpecialchars($_POST["user_password0"]);
$user_password1 = HtmlSpecialchars($_POST["user_password1"]);
$user_password2 = HtmlSpecialchars($_POST["user_password2"]);
$user_email = HtmlSpecialchars($_POST["user_email"]);


$md_password0 = MD5($user_password0);

if ($user_password0 != "") {
    if ($user_password != $md_password0) {
        $error = $lang['profile']['the_password_not_identical_to_the_confirm_password'];
    }
}

if ($error != "") {
	                echo'<br><center>
	                <table width="99%" border="1">
	                   <tr class="normal">
	                       <td class="list_center" colSpan="10"><font size="5" color="red"><br>���<br>'.$error.'..</font><br><br>
	                       <a href="JavaScript:history.go(-1)">'.$lang['profile']['click_here_to_back'].'</a><br><br>
	                       </td>
	                   </tr>
	                </table>
	                </center>';
}


if ($error == "") {
		$query = "UPDATE " . $Prefix . "MEMBERS SET ";
  
    if ($user_password0 != "") {
        $user_password1 = MD5($user_password1);
        $query .= "M_PASSWORD = ('$user_password1'), ";
    }
        
        $query .= "M_EMAIL = ('$user_email') ";
        $query .= "WHERE MEMBER_ID = ".$DBMemberID." ";
        mysql_query($query, $connection) or die (mysql_error());

                    echo'
	                <center>
	                <table width="99%" border="1">
	                   <tr class="normal">
	                       <td class="list_center" colSpan="10"><font size="5"><br>'.$lang['profile']['your_details_has_edited'].'</font><br><br>
                           <meta http-equiv="Refresh" content="2; URL=index.php?mode=profile&type=details">
                           <a href="index.php?mode=profile&type=details">'.$lang['profile']['click_here_to_go_normal_page'].'</a><br>
                           <a href="index.php">'.$lang['profile']['click_here_to_go_home'].'</a><br><br>
	                       </td>
	                   </tr>
	                </table>
	                </center>';
}


    }
    else {
    redirect();
    }

}


if ($type == "edit_user") {
 if ($Mlevel == 4) {

 $query = "SELECT * FROM " . $Prefix . "MEMBERS WHERE MEMBER_ID = '" .$ppMemberID."' ";
 $result = mysql_query($query, $connection) or die (mysql_error());

 if(mysql_num_rows($result) > 0){
 $rs=mysql_fetch_array($result);

 $ProMemberID = $rs['MEMBER_ID'];
 $ProMemberName = $rs['M_NAME'];
 $ProMemberLevel = $rs['M_LEVEL'];
 $ProMemberEmail = $rs['M_EMAIL'];
 $ProMemberReceiveEmail = $rs['M_RECEIVE_EMAIL'];
 $ProMemberIP = $rs['M_IP'];
 $ProMemberLastIP = $rs['M_LAST_IP'];
 $ProMemberCountry = $rs['M_COUNTRY'];
 $ProMemberCity = $rs['M_CITY'];
 $ProMemberPosts = $rs['M_POSTS'];
 $ProMemberState = $rs['M_STATE'];
 $ProMemberOccupation = $rs['M_OCCUPATION'];
 $ProMemberAge = $rs['M_AGE'];
 $ProMemberSex = $rs['M_SEX'];
 $ProMemberPhotoURL = $rs['M_PHOTO_URL'];
 $ProMemberMarStatus = $rs['M_MARSTATUS'];
 $ProMemberBio = $rs['M_BIO'];
 $ProMemberTitle = $rs['M_TITLE'];
 $ProMemberOldMod = $rs['M_OLD_MOD'];
 $ProMemberLastApp = $rs['M_LAST_APP'];
 $ProMemberSig = $rs['M_SIG'];
 $ProMemberPmHide = $rs['M_PMHIDE'];
 }

echo '
<center>
<table cellSpacing="0" cellPadding="0" width="99%" border="0">
	<tr>
		<td>
		<table class="optionsbar" cellSpacing="2" width="100%" border="0">
			<tr>
				<td vAlign="center"></td>
				<td class="optionsbar_title" vAlign="center" width="100%">'.$lang['profile']['edit_member_details'].' '.$ProMemberName.'</td>';
            go_to_forum();
            echo'
            </tr>
		</table>
		</td>
	</tr>
</table>
</center>
<br>';


echo'
<center>
<table class="grid" border="0" cellspacing="1" cellpadding="4" width="60%">
<form method="post" action="index.php?mode=profile&type=edit_user_add">
<input type="hidden" name="user_id" value="'.$ppMemberID.'">
<input type="hidden" name="user_old_level" value="'.$ProMemberLevel.'">
<input type="hidden" name="user_old_mod" value="'.$ProMemberOldMod.'">

	<tr class="fixed">
		<td class="cat"><nobr>'.$lang['profile']['member_name'].'</nobr></td>
		<td class="userdetails_data"><input type="text" name="user_name" size="40" value="'.$ProMemberName.'"></td>
	</tr>
	<tr class="fixed">
		<td class="cat"><nobr>'.$lang['profile']['member_password'].'</nobr></td>
		<td class="userdetails_data"><input type="password" name="user_password" size="40"></td>
	</tr>
 	<tr class="fixed">
		<td class="cat"><nobr>'.$lang['profile']['the_email'].'</nobr></td>
		<td class="userdetails_data"><input type="text" dir="ltr" name="user_email" size="40" value="'.$ProMemberEmail.'"></td>
	</tr>';
if ($ppMemberID > 1) {
echo'	<tr class="fixed">
		<td class="cat"><nobr>'.$lang['profile']['the_rank'].'</nobr></td>
		<td class="userdetails_data">
        <input class="radio" type="radio" value="1" name="user_level" '.check_radio($ProMemberLevel, "1").'>'.$lang['profile']['member'].'&nbsp;&nbsp;&nbsp;&nbsp;
        <input class="radio" type="radio" value="2" name="user_level" '.check_radio($ProMemberLevel, "2").'>'.$lang['profile']['moderator'].'&nbsp;&nbsp;&nbsp;&nbsp;
        <input class="radio" type="radio" value="3" name="user_level" '.check_radio($ProMemberLevel, "3").'>'.$lang['profile']['monitor'].'&nbsp;&nbsp;&nbsp;&nbsp;
        <input class="radio" type="radio" value="4" name="user_level" '.check_radio($ProMemberLevel, "4").'>'.$lang['profile']['admin'].'
        </td>
	</tr>';
}
echo'	<tr class="fixed">
		<td class="cat"><nobr>'.$lang['profile']['the_sex'].'</nobr></td>
		<td class="userdetails_data">
        <input class="radio" type="radio" value="0" name="user_sex" '.check_radio($ProMemberSex, "0").'>'.$lang['profile']['no_selected'].'&nbsp;&nbsp;&nbsp;&nbsp;
        <input class="radio" type="radio" value="1" name="user_sex" '.check_radio($ProMemberSex, "1").'>'.$lang['profile']['male'].'&nbsp;&nbsp;&nbsp;&nbsp;
        <input class="radio" type="radio" value="2" name="user_sex" '.check_radio($ProMemberSex, "2").'>'.$lang['profile']['female'].'
        </td>
	</tr>
 	<tr class="fixed">
		<td class="cat"><nobr>'.$lang['profile']['private_message'].'</nobr></td>
		<td class="userdetails_data">
        <input class="radio" type="radio" value="1" name="user_pmhide" '.check_radio($ProMemberPmHide, "1").'>'.$lang['profile']['the_member_allowed_to_send_pm'].'&nbsp;&nbsp;&nbsp;&nbsp;<br>
        <input class="radio" type="radio" value="0" name="user_pmhide" '.check_radio($ProMemberPmHide, "0").'>'.$lang['profile']['the_member_not_allowed_to_send_pm'].'
        </td>
	</tr>
 	<tr class="fixed">
		<td class="cat"><nobr>'.$lang['profile']['the_email'].'</nobr></td>
		<td class="userdetails_data">
        <input class="radio" type="radio" value="1" name="user_receive_email" '.check_radio($ProMemberReceiveEmail, "1").'>'.$lang['profile']['the_member_allowed_to_send_email'].'&nbsp;&nbsp;&nbsp;&nbsp;<br>
        <input class="radio" type="radio" value="0" name="user_receive_email" '.check_radio($ProMemberReceiveEmail, "0").'>'.$lang['profile']['the_member_not_allowed_to_send_email'].'
        </td>
	</tr>
 	<tr class="fixed">
		<td class="cat"><nobr>'.$lang['profile']['ip_address'].'</nobr></td>
		<td class="userdetails_data">'.$ProMemberIP.'</td>
	</tr>
 	<tr class="fixed">
		<td class="cat"><nobr>'.$lang['profile']['last_ip_address'].'</nobr></td>
		<td class="userdetails_data">'.$ProMemberLastIP.'</td>
	</tr>
 	<tr class="fixed">
		<td class="cat"><nobr>'.$lang['profile']['number_posts'].'</nobr></td>
		<td class="userdetails_data"><input type="text" name="user_posts" size="10" value="'.$ProMemberPosts.'"></td>
	</tr>
 	<tr class="fixed">
		<td class="cat"><nobr>'.$lang['profile']['the_age'].'</nobr></td>
		<td class="userdetails_data"><input type="text" name="user_age" size="10" value="'.$ProMemberAge.'"></td>
	</tr>
  	<tr class="fixed">
		<td class="cat"><nobr>'.$lang['profile']['the_country'].'</nobr></td>
		<td class="userdetails_data">
		<select class="insidetitle" style="WIDTH: 200px" name="user_country" type="text">';
        $selected = $ProMemberCountry;
        include("country.php");
		echo'</select>
        </td>
    </tr>
 	<tr class="fixed">
		<td class="cat"><nobr>'.$lang['profile']['the_title'].'</nobr></td>
		<td class="userdetails_data"><input type="text" name="user_title" size="40" value="'.$ProMemberTitle.'"></td>
	</tr>
 	<tr class="fixed">
		<td class="cat"><nobr>'.$lang['profile']['url_in_singe_photo'].'</nobr></td>
		<td class="userdetails_data"><input type="text" dir="ltr" name="user_photo_url" size="40" value="'.$ProMemberPhotoURL.'"></td>
	</tr>
 	<tr class="fixed">
		<td class="cat"><nobr>'.$lang['profile']['the_city'].'</nobr></td>
		<td class="userdetails_data"><input type="text" name="user_city" size="40" value="'.$ProMemberCity.'"></td>
	</tr>
 	<tr class="fixed">
		<td class="cat"><nobr>'.$lang['profile']['the_state'].'</nobr></td>
		<td class="userdetails_data"><input type="text" name="user_state" size="40" value="'.$ProMemberState.'"></td>
	</tr>
 	<tr class="fixed">
		<td class="cat"><nobr>'.$lang['profile']['the_sociability_status'].'</nobr></td>
		<td class="userdetails_data"><input type="text" name="user_mar_status" size="40" value="'.$ProMemberMarStatus.'"></td>
	</tr>
 	<tr class="fixed">
		<td class="cat"><nobr>'.$lang['profile']['the_occupation'].'</nobr></td>
		<td class="userdetails_data"><input type="text" name="user_occupation" size="40" value="'.$ProMemberOccupation.'"></td>
	</tr>
 	<tr class="fixed">
		<td class="cat"><nobr>'.$lang['profile']['the_biography'].'</nobr></td>
		<td class="userdetails_data"><textarea cols="50" rows="5" name="user_bio">'.$ProMemberBio.'</textarea></td>
	</tr>
 	<tr class="fixed">
		<td class="cat"><nobr>'.$lang['profile']['the_signature'].'</nobr></td>
		<td class="userdetails_data"><textarea cols="50" rows="5" name="user_sig">'.$ProMemberSig.'</textarea></td>
	</tr>
 	<tr class="fixed">
		<td align="middle" colspan="2"><input type="submit" value="'.$lang['profile']['insert_info'].'">&nbsp;&nbsp;&nbsp;<input type="reset" value="'.$lang['profile']['reset_info'].'"></td>
	</tr>
</form>
</table>
</center>';
 }
 else {
 redirect();
 }
}

if ($type == "edit_user_add") {

 if ($Mlevel == 4) {

$ppMemberID = HtmlSpecialchars($_POST["user_id"]);
$user_name = HtmlSpecialchars($_POST["user_name"]);
if ($_POST["user_password"] != "") {
$user_password = md5($_POST["user_password"]);
}
$user_email = HtmlSpecialchars($_POST["user_email"]);
if ($ppMemberID > 1) {
$user_level = HtmlSpecialchars($_POST["user_level"]);
}
$ProMemberLevel = $_POST["user_old_level"];
$ProMemberOldMod = $_POST["user_old_mod"];
$user_sex = HtmlSpecialchars($_POST["user_sex"]);
$user_receive_email = HtmlSpecialchars($_POST["user_receive_email"]);
$user_posts = HtmlSpecialchars($_POST["user_posts"]);
$user_age = HtmlSpecialchars($_POST["user_age"]);
$user_photo_url = HtmlSpecialchars($_POST["user_photo_url"]);
$user_country = HtmlSpecialchars($_POST["user_country"]);
$user_state = HtmlSpecialchars($_POST["user_state"]);
$user_sity = HtmlSpecialchars($_POST["user_sity"]);
$user_mar_status = HtmlSpecialchars($_POST["user_mar_status"]);
$user_occupation = HtmlSpecialchars($_POST["user_occupation"]);
$user_bio = HtmlSpecialchars($_POST["user_bio"]);
$user_title = HtmlSpecialchars($_POST["user_title"]);
$user_sig = $_POST["user_sig"];
$user_pmhide = $_POST["user_pmhide"];

if ($ProMemberLevel == 3 AND $user_level == 1) {
$user_old_mod = 2;
}

if ($ProMemberLevel == 2 AND $user_level == 1) {
$user_old_mod = 1;
}

if ($user_level == 2 OR $user_level == 3 AND $ProMemberOldMod == 1 OR $ProMemberOldMod == 2) {
$user_old_mod = 0;
}

if ($user_name == "") {
    $error = $lang['register_js']['necessary_to_insert_user_name'];
}
if ($user_email == "") {
    $error = $lang['register_js']['necessary_to_insert_email'];
}

if ($error != "") {
	                echo'<br><center>
	                <table width="99%" border="1">
	                   <tr class="normal">
	                       <td class="list_center" colSpan="10"><font size="5" color="red"><br>���<br>'.$error.'..</font><br><br>
	                       <a href="JavaScript:history.go(-1)">'.$lang['profile']['click_here_to_back'].'</a><br><br>
	                       </td>
	                   </tr>
	                </table>
	                </center>';
}

if ($error == "") {
		$query = "UPDATE " . $Prefix . "MEMBERS SET ";
        $query .= "M_NAME = '$user_name', ";
        if ($user_password != "") {
        $query .= "M_PASSWORD = '$user_password', ";
        }
        $query .= "M_EMAIL = '$user_email', ";
if ($ppMemberID > 1) {
        $query .= "M_LEVEL = '$user_level', ";
}
        $query .= "M_SEX = '$user_sex', ";
        $query .= "M_RECEIVE_EMAIL = '$user_receive_email', ";
        $query .= "M_POSTS = '$user_posts', ";
        $query .= "M_AGE = '$user_age', ";
        $query .= "M_PHOTO_URL = '$user_photo_url', ";
        $query .= "M_COUNTRY = '$user_country', ";
        $query .= "M_STATE = '$user_state', ";
        $query .= "M_CITY = '$user_city', ";
        $query .= "M_MARSTATUS = '$user_mar_status', ";
        $query .= "M_OCCUPATION = '$user_occupation', ";
        $query .= "M_SIG = '$user_sig', ";
        $query .= "M_BIO = '$user_bio', ";
        $query .= "M_PMHIDE = '$user_pmhide', ";
        if ($user_level == 1) {
        $query .= "M_TITLE = '', ";
        }
        else {
        $query .= "M_TITLE = '$user_title', ";
        }
        $query .= "M_OLD_MOD = '$user_old_mod' ";
        $query .= "WHERE MEMBER_ID = '$ppMemberID' ";
        
        mysql_query($query, $connection) or die (mysql_error());
        
                    echo'
	                <center>
	                <table width="99%" border="1">
	                   <tr class="normal">
	                       <td class="list_center" colSpan="10"><font size="5"><br>'.$lang['profile']['your_details_has_edited'].'</font><br><br>
                           <meta http-equiv="Refresh" content="2; URL=index.php?mode=profile&id='.$ppMemberID.'">
                           <a href="index.php?mode=profile&id='.$ppMemberID.'">'.$lang['profile']['click_here_to_go_normal_page'].'</a><br><br>
	                       </td>
	                   </tr>
	                </table>
	                </center>';
}


    }
    else {
    redirect();
    }

}

}	// (members("STATUS", $id) == 1 OR $Mlevel > 1 OR members("NAME", $id) != "")
else {
echo'
<center>
<table width="99%" border="1">
	<tr class="normal">
		<td class="list_center" colspan="10">
		<br><br><font size="+2">����� ������� ��� �����.</font>
		<br><br>�� ���� ���� ��� ����� ���� ����:<br><br>
		<table>
			<tr>
				<td>* ��� ����� ������� ��� ����. </td>
			</tr>
			<tr>
				<td>* ����� �� ��� ����� ������ ����. </td>
			</tr>
			<tr>
				<td>* ����� �� �� ����� ������� �������. </td>
			</tr>
			<tr>
				<td>* ����� �� �� ������ �� ���������. </td>
			</tr>
		</table>
		<br></td>
	</tr>
</table>
</center>';
}

if ($type == "medals"){
	if ($Mlevel > 0){
		echo'
		<script language="javascript">
			function choose_medal(id){
				document.m_info.mem_id.value = id;
				document.m_info.submit();
			}
			function remove_medal(){
				document.m_info.mem_id.value = "remove";
				document.m_info.submit();
			}
		</script>
		<form name="m_info" method="post" action="index.php?mode=profile&type=medals">
		<input type="hidden" name="mem_id">
		</form>
		<center>
		<table cellSpacing="2" width="100%" border="0">
			<tr>
				<td class="optionsbar_menus" width="99%">&nbsp;<nobr><font color="red" size="+1">����� �������</font></nobr></td>';
				echo multi_page("MEDALS WHERE MEMBER_ID = '$DBMemberID' AND STATUS = '1' ", $max_page);
				go_to_forum();
			echo'
			</tr>
		</table><br>';
		$mem_id = $HTTP_POST_VARS[mem_id];
		if (!empty($mem_id)){
			if ($mem_id == "remove"){
				mysql_query("UPDATE ".$Prefix."MEMBERS SET M_MEDAL = '0' WHERE MEMBER_ID = '$DBMemberID' ") or die (mysql_error());
				echo'<p align="center"><font size="+1" color="red">�� ����� ����� ������ �����.</font></p>';
			}
			else{
				mysql_query("UPDATE ".$Prefix."MEMBERS SET M_MEDAL = '$mem_id' WHERE MEMBER_ID = '$DBMemberID' ") or die (mysql_error());
				echo'<p align="center"><font size="+1" color="red">�� ����� ����� ������ �����.</font></p>';
			}
		}
		echo'
		<table cellSpacing="1" cellPadding="2">
			<tr>
				<td class="optionsbar_menus" colSpan="10"><font color="red" size="+1">����� ������ �������� ��</font></td>
			</tr>
			<tr>
				<td class="stats_h"><nobr>�������</nobr></td>
				<td class="stats_h"><nobr>���� ���</nobr></td>
				<td class="stats_h"><nobr>������ �������</nobr></td>
				<td class="stats_h">������<br>������</td>
				<td class="stats_h"><nobr>�������</nobr></td>';
			if (mlv > 1){
				echo'
				<td class="stats_h"><nobr>��� ������</nobr></td>';
			}
				echo'
				<td class="stats_h"><nobr>������</nobr></td>
			</tr>';
		$sql = mysql_query("SELECT * FROM ".prefix."MEDALS WHERE MEMBER_ID = '$DBMemberID' AND STATUS = '1' ORDER BY DATE DESC LIMIT ".pg_limit($max_page).", $max_page") or die (mysql_error());
		$num = mysql_num_rows($sql);
		$x = 0;
		while ($x < $num){
			$m = mysql_result($sql, $x, "MEDAL_ID");
			$gm_id = medals("GM_ID", $m);
			$subject = gm("SUBJECT", $gm_id);
			$date = medals("DATE", $m);
			$days = medals("DAYS", $m);
			$url = medals("URL", $m);
			$f = medals("FORUM_ID", $m);
			$added = medals("ADDED", $m);
			$add_days = $days*60*60*24;
			$add_days = $add_days + $date;
			echo'
			<tr>
				<td class="stats_p" align="middle"><font color="red">'.normal_date($date).'</font></td>
				<td class="stats_p" align="middle"><font color="black">'.days_added($days, $date).'</font></td>
				<td class="stats_g"><font size="-1">'.$subject.'</font></td>
				<td class="stats_p" align="middle"><a target="plaquepreview" href="'.$url.'">'.icons($icon_camera).'</a></td>
				<td class="stats_p"><font color="red">'.forums("SUBJECT", $f).'</font></td>';
			if ($Mlevel > 1){
				echo'
				<td class="stats_g"><nobr><a href="index.php?mode=profile&id='.$added.'"><font color="#ffffff">'.members("NAME", $added).'</font></a></nobr></td>';
			}
				echo'
				<td class="stats_h" align="middle">';
				if ($add_days > time()){
					echo'
					<a href="javascript:choose_medal('.$m.')">'.icons($icon_profile, "������ ��� ������ ������ ������", " hspace=\"3\"").'</a>';
				}
				echo'
				</td>
			</tr>';
			$count = $count + 1;
		++$x;
		}
		if ($count == 0){
			echo'
			<tr>
				<td class="stats_h" colSpan="10" align="center"><br><font size="3">��� �� ���� �� ����</font><br><br></td>
			</tr>';
		}
		else{
			echo'
			<tr>
				<td class="optionsbar_menus" colSpan="10"><font size="3"><a href="javascript:remove_medal()">- ���� ��� ������ ����� ������ �� ����� ��� ���� �� �������� - </a></font></td>
			</tr>';
		}
		echo'
		</table>
		</center><br>';
	}
	else {
		redirect();
	}
}
?>
