<?php
/*//////////////////////////////////////////////////////////
// ######################################################///
// # DuhokForum 0.8                                     # //
// ###################################################### //
// #                                                    # //
// #       --  DUHOK FORUM IS FREE SOFTWARE  --         # //
// #                                                    # //
// #   ========= Programming By Dilovan ==============  # //
// # Copyright � 2007-2008 Dilovan. All Rights Reserved # //
// #----------------------------------------------------# //
// #----------------------------------------------------# //
// # If you want any support vist down address:-        # //
// # Email: df@duhoktimes.com                           # //
// # Site: http://df.duhoktimes.com/index.php           # //
// ###################################################### //
//////////////////////////////////////////////////////////*/

//##################  save active type ####################################
if ($active == "private"){
	$active_type = "prv";
	$post_active_type = $HTTP_POST_VARS["active_type"];
	if (!empty($post_active_type)){
	$HTTP_SESSION_VARS['DF_active_type'] = $post_active_type;
	head($HTTP_SERVER_VARS[REQUEST_URI]);
	}
	$load_active_type = $HTTP_SESSION_VARS['DF_active_type'];
	if (!empty($load_active_type)){
	$active_type = $load_active_type;
	}
}
else if ($active == "monitored"){
	$active_type = "mon";
	$post_active_type = $HTTP_POST_VARS["active_type"];
	if (!empty($post_active_type)){
	$HTTP_SESSION_VARS['DF_active_type'] = $post_active_type;
	head($HTTP_SERVER_VARS[REQUEST_URI]);
	}
	$load_active_type = $HTTP_SESSION_VARS['DF_active_type'];
	if (!empty($load_active_type)){
	$active_type = $load_active_type;
	}
}
else if ($active == ""){
	$active_type = "active";
	$post_active_type = $HTTP_POST_VARS["active_type"];
	if (!empty($post_active_type)){
	$HTTP_SESSION_VARS['DF_active_type'] = $post_active_type;
	head($HTTP_SERVER_VARS[REQUEST_URI]);
	}
	$load_active_type = $HTTP_SESSION_VARS['DF_active_type'];
	if (!empty($load_active_type)){
	$active_type = $load_active_type;
	}
else {
	$active_type = $active_type;
     }
}
//##################  save active type ####################################

//##################  save refresh time ###################################
$refresh_time = 0;
$post_refresh_time = $HTTP_POST_VARS["refresh_time"];
if (!empty($post_refresh_time)){
	$HTTP_SESSION_VARS['DF_refresh_time'] = $post_refresh_time;
	head($HTTP_SERVER_VARS[REQUEST_URI]);
}
$load_refresh_time = $HTTP_SESSION_VARS['DF_refresh_time'];
if (!empty($load_refresh_time)){
	$refresh_time = $load_refresh_time;
}
else {
	$refresh_time = $refresh_time;
}
//##################  save refresh time ###################################

//##################  save order by #######################################
$order_by = "post";
$post_order_by = $HTTP_POST_VARS["order_by"];
if (!empty($post_order_by)){
	$HTTP_SESSION_VARS['DF_order_by'] = $post_order_by;
	head($HTTP_SERVER_VARS[REQUEST_URI]);
}
$load_order_by = $HTTP_SESSION_VARS['DF_order_by'];
if (!empty($load_order_by)){
	$order_by = $load_order_by;
}
else {
	$order_by = $order_by;
}
//##################  save order by #######################################

//##################  save reply num page #################################
$reply_num_page = 30;
$post_reply_num_page = $HTTP_POST_VARS["reply_num_page"];
if (!empty($post_reply_num_page)){
	$HTTP_SESSION_VARS['DF_reply_num_page'] = $post_reply_num_page;
	head($HTTP_SERVER_VARS[REQUEST_URI]);
}
$load_reply_num_page = $HTTP_SESSION_VARS['DF_reply_num_page'];
if (!empty($load_reply_num_page)){
	$reply_num_page = $load_reply_num_page;
}
else {
	$reply_num_page = $reply_num_page;
}
//##################  save reply num page #################################

//################## save sig #############################################
$show_sig = "hide";
$post_show_sig = $HTTP_POST_VARS[show_sig];
if (!empty($post_show_sig)){
	$HTTP_SESSION_VARS['DF_show_sig'] = $post_show_sig;
	head($HTTP_SERVER_VARS[REQUEST_URI]);
}
$load_show_sig = $HTTP_SESSION_VARS['DF_show_sig'];
if (!empty($load_show_sig)){
	$show_sig = $load_show_sig;
}
else {
	$show_sig = $show_sig;
}
//################## save sig #############################################

//################## save style ###########################################
if (!empty($ch) && $ch == "style"){
 $style_name = $HTTP_POST_VARS["style_name"];
 $_SESSION['DF_choose_style'] = $style_name;
 head('index.php');
}
$load_choose_style = $_SESSION['DF_choose_style'];

if (!empty($load_choose_style)){
$choose_style = $load_choose_style;
}
else {
$choose_style = $default_style;
}
//################## save style ###########################################

//##################  save lang ###########################################
if (!empty($ch) && $ch == "lang"){
 $lan_name = $HTTP_POST_VARS["lan_name"];
 $_SESSION['DF_choose_language'] = $lan_name;
 head('index.php');
}
$load_choose_language = $_SESSION['DF_choose_language'];

if (!empty($load_choose_language)){
$choose_language = $load_choose_language;
}
else {
$choose_language = $default_language;
}

//##################  save lang ###########################################

//##################  save order option ###################################
$order_option = "online";
$post_order_option = $HTTP_POST_VARS["order_option"];
if (!empty($post_order_option)){
	$HTTP_SESSION_VARS['DF_order_option'] = $post_order_option;
	head($HTTP_SERVER_VARS[REQUEST_URI]);
}
$load_order_option = $HTTP_SESSION_VARS['DF_order_option'];
if (!empty($load_order_option)){
	$order_option = $load_order_option;
}
else {
	$order_option = $order_option;
}
//##################  save order option ###################################

//##################  save desc asc #######################################
$desc_asc = "desc";
$post_desc_asc = $HTTP_POST_VARS["desc_asc"];
if (!empty($post_desc_asc)){
	$HTTP_SESSION_VARS['DF_desc_asc'] = $post_desc_asc;
	head($HTTP_SERVER_VARS[REQUEST_URI]);
}
$load_desc_asc = $HTTP_SESSION_VARS['DF_desc_asc'];
if (!empty($load_desc_asc)){
	$desc_asc = $load_desc_asc;
}
else {
	$desc_asc = $desc_asc;
}
//##################  save desc asc #######################################

//##################  save timezone #######################################
$timezone = $HTTP_POST_VARS["timezone"];
if ($tz != "") {
	$HTTP_SESSION_VARS['DF_timezone'] = $timezone;
	head("index.php");
}
$load_timezone =$HTTP_SESSION_VARS['DF_timezone'];
if ($load_timezone == "") {
	$load_timezone = $site_timezone;
}

$chk_timezone = $load_timezone * 3600;
//##################  save timezone #######################################

?>