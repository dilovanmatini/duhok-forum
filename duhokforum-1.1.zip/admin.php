<?
/*//////////////////////////////////////////////////////////
// ######################################################///
// # DuhokForum 1.1                                     # //
// ###################################################### //
// #                                                    # //
// #       --  DUHOK FORUM IS FREE SOFTWARE  --         # //
// #                                                    # //
// #   ========= Programming By Dilovan ==============  # //
// # Copyright � 2007-2009 Dilovan. All Rights Reserved # //
// #----------------------------------------------------# //
// #----------------------------------------------------# //
// # If you want any support vist down address:-        # //
// # Email: df@duhoktimes.com                           # //
// # Site: http://df.duhoktimes.com/index.php           # //
// ###################################################### //
//////////////////////////////////////////////////////////*/

include("check.php");
?>
<html dir="rtl">
<head>
<TITLE>���� ������ ������</TITLE>
<META http-equiv=Content-Type content="text/html; charset=windows-1256">
<META content="DUHOK FORUM 1.0: Copyright (C) 2007-2008 Dilovan." name=copyright>
<META http-equiv="Page-Enter" content="blendTrans(Duration=0)">
<META http-equiv="Page-Exit" content="blendTrans(Duration=0)">
<SCRIPT type=text/javascript>
	if (self.parent.frames.length != 0)
	{
		self.parent.location.replace(document.location.href);
	}
</SCRIPT>
</head>
<FRAMESET border=0 frameSpacing=0 frameBorder=0 cols=*,195>
<FRAMESET border=0 frameSpacing=0 rows=30,* frameBorder=0>
<FRAME border=no name=head marginWidth=10 marginHeight=0 src="cp_header.php" frameBorder=0 noResize scrolling=no>
<FRAME border=no name=main marginWidth=10 marginHeight=10 src="cp_home.php" frameBorder=0 scrolling=yes></FRAMESET>
<FRAME border=no name=nav marginWidth=0 marginHeight=0 src="cp_menu.php" frameBorder=0 scrolling=yes></FRAMESET>
</HTML>

