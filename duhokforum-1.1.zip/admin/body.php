<?
/*//////////////////////////////////////////////////////////
// ######################################################///
// # DuhokForum 1.1                                     # //
// ###################################################### //
// #                                                    # //
// #       --  DUHOK FORUM IS FREE SOFTWARE  --         # //
// #                                                    # //
// #   ========= Programming By Dilovan ==============  # //
// # Copyright � 2007-2009 Dilovan. All Rights Reserved # //
// #----------------------------------------------------# //
// #----------------------------------------------------# //
// # If you want any support vist down address:-        # //
// # Email: df@duhoktimes.com                           # //
// # Site: http://df.duhoktimes.com/index.php           # //
// ###################################################### //
//////////////////////////////////////////////////////////*/

echo'
<center>
<table class="grid" border="0" cellspacing="1" cellpadding="4" width="80%">
	<tr class="fixed">
		<td class="cat"><nobr>������ ��������</nobr></td>
	</tr>
	<tr class="fixed">
		<td align="middle">
        <br>
        <font color="black">
        ---------------------------------------------------------------------------------
        <br>
        ����� ��� �� ���� ������� DUHOK FORUM '.$forum_version.'
        <br>
        �� ����� ������ (<font color="#cc0033">������</font>)
        <br>
        ---------------------------------------------------------------------------------
        <br><br>
        ��� ������� �� ��� �� ���
        <br>
        ���� ��� ������
        <br>
        <br>
        -- <a href="http://df.duhoktimes.com/index.php"><font color="#cc0033">df.duhoktimes.com</font></a> --
        <br>
        <br>
        �� ���� �����  ������ ������
        <br>
        -- <a href="mailto:df@duhoktimes.com"><font color="#cc0033">df@duhoktimes.com</font></a> --
        <br>
        </font>
        ---------------------------------------------------------------------------------
        <br>
        <font face="Tahoma" color="black" style="FONT-SIZE: 11px">Copyright � Dilovan 2007 - 2008. All rights reserved</font>
        <br>
        <br>
        </td>
	</tr>
</table>
</center>';


?>

