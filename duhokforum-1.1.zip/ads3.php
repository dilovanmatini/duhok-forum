<?
/*//////////////////////////////////////////////////////////
// ######################################################///
// # DuhokForum 1.1                                     # //
// ###################################################### //
// #                                                    # //
// #       --  DUHOK FORUM IS FREE SOFTWARE  --         # //
// #                                                    # //
// #   ========= Programming By Dilovan ==============  # //
// # Copyright � 2007-2009 Dilovan. All Rights Reserved # //
// #----------------------------------------------------# //
// #----------------------------------------------------# //
// # If you want any support vist down address:-        # //
// # Email: df@duhoktimes.com                           # //
// # Site: http://df.duhoktimes.com/index.php           # //
// ###################################################### //
//////////////////////////////////////////////////////////*/

if($pub == 1){
echo'
</p>
<p align="'.$pub6.'"><a target="_blank" href="http://'.$pub1.'">
<img alt="'.$pub2.'" src="'.$pub3.'" border="0" width="'.$pub4.'" height="'.$pub5.'"></a></p>
<p align="center">';
}

?>
