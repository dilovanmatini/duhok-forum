<?
/*//////////////////////////////////////////////////////////
// ######################################################///
// # DuhokForum 1.1                                     # //
// ###################################################### //
// #                                                    # //
// #       --  DUHOK FORUM IS FREE SOFTWARE  --         # //
// #                                                    # //
// #   ========= Programming By Dilovan ==============  # //
// # Copyright � 2007-2009 Dilovan. All Rights Reserved # //
// #----------------------------------------------------# //
// #----------------------------------------------------# //
// # If you want any support vist down address:-        # //
// # Email: df@duhoktimes.com                           # //
// # Site: http://df.duhoktimes.com/index.php           # //
// ###################################################### //
//////////////////////////////////////////////////////////*/

if($pubs == 1){
echo'
</p>
<p align="'.$pubs6.'"><a target="_blank" href="http://'.$pubs1.'">
<img alt="'.$pubs2.'" src="'.$pubs3.'" border="0" width="'.$pubs4.'" height="'.$pubs5.'"></a></p>
<p align="center">';
}

?>
