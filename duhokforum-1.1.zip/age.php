<?
/*//////////////////////////////////////////////////////////
// ######################################################///
// # DuhokForum 1.1                                     # //
// ###################################################### //
// #                                                    # //
// #       --  DUHOK FORUM IS FREE SOFTWARE  --         # //
// #                                                    # //
// #   ========= Programming By Dilovan ==============  # //
// # Copyright � 2007-2009 Dilovan. All Rights Reserved # //
// #----------------------------------------------------# //
// #----------------------------------------------------# //
// # If you want any support vist down address:-        # //
// # Email: df@duhoktimes.com                           # //
// # Site: http://df.duhoktimes.com/index.php           # //
// ###################################################### //
//////////////////////////////////////////////////////////*/

                    echo'
                    <option value="" '.check_select($selected, "").'>��� ����</option>
					<option value="12" '.check_select($selected, "12").'>12</option>
					<option value="13" '.check_select($selected, "13").'>13</option>
					<option value="14" '.check_select($selected, "14").'>14</option>
					<option value="15" '.check_select($selected, "15").'>15</option>
					<option value="16" '.check_select($selected, "16").'>16</option>
					<option value="17" '.check_select($selected, "17").'>17</option>
					<option value="18" '.check_select($selected, "18").'>18</option>
					<option value="19" '.check_select($selected, "19").'>19</option>
					<option value="20" '.check_select($selected, "20").'>20</option>
					<option value="21" '.check_select($selected, "21").'>21</option>
					<option value="22" '.check_select($selected, "22").'>22</option>
					<option value="23" '.check_select($selected, "23").'>23</option>
					<option value="24" '.check_select($selected, "24").'>24</option>
					<option value="25" '.check_select($selected, "25").'>25</option>
					<option value="26" '.check_select($selected, "26").'>26</option>
					<option value="27" '.check_select($selected, "27").'>27</option>
					<option value="28" '.check_select($selected, "28").'>28</option>
					<option value="29" '.check_select($selected, "29").'>29</option>
					<option value="30" '.check_select($selected, "30").'>30</option>
					<option value="31" '.check_select($selected, "31").'>31</option>
					<option value="32" '.check_select($selected, "32").'>32</option>
					<option value="33" '.check_select($selected, "33").'>33</option>
					<option value="34" '.check_select($selected, "34").'>34</option>
					<option value="35" '.check_select($selected, "35").'>35</option>
					<option value="36" '.check_select($selected, "36").'>36</option>
					<option value="37" '.check_select($selected, "37").'>37</option>
					<option value="38" '.check_select($selected, "38").'>38</option>
					<option value="39" '.check_select($selected, "39").'>39</option>
					<option value="40" '.check_select($selected, "40").'>40</option>
					<option value="41" '.check_select($selected, "41").'>41</option>
					<option value="42" '.check_select($selected, "42").'>42</option>
					<option value="43" '.check_select($selected, "43").'>43</option>
					<option value="44" '.check_select($selected, "44").'>44</option>
					<option value="45" '.check_select($selected, "45").'>45</option>
					<option value="46" '.check_select($selected, "46").'>46</option>
					<option value="47" '.check_select($selected, "47").'>47</option>
					<option value="48" '.check_select($selected, "48").'>48</option>
					<option value="49" '.check_select($selected, "49").'>49</option>
					<option value="50" '.check_select($selected, "50").'>50</option>	
					<option value="51" '.check_select($selected, "51").'>51</option>
					<option value="52" '.check_select($selected, "52").'>52</option>
					<option value="53" '.check_select($selected, "53").'>53</option>
					<option value="54" '.check_select($selected, "54").'>54</option>
					<option value="55" '.check_select($selected, "55").'>55</option>
					<option value="56" '.check_select($selected, "56").'>56</option>
					<option value="57" '.check_select($selected, "57").'>57</option>
					<option value="58" '.check_select($selected, "58").'>58</option>
					<option value="59" '.check_select($selected, "59").'>59</option>
					<option value="60" '.check_select($selected, "60").'>60</option>
					<option value="61" '.check_select($selected, "61").'>61</option>
					<option value="62" '.check_select($selected, "62").'>62</option>
					<option value="63" '.check_select($selected, "63").'>63</option>
					<option value="64" '.check_select($selected, "64").'>64</option>
					<option value="65" '.check_select($selected, "65").'>65</option>
					<option value="66" '.check_select($selected, "66").'>66</option>
					<option value="67" '.check_select($selected, "67").'>67</option>
					<option value="68" '.check_select($selected, "68").'>68</option>
					<option value="69" '.check_select($selected, "69").'>69</option>
					<option value="70" '.check_select($selected, "70").'>70</option>
					<option value="71" '.check_select($selected, "71").'>71</option>
					<option value="72" '.check_select($selected, "72").'>72</option>
					<option value="73" '.check_select($selected, "73").'>73</option>
					<option value="74" '.check_select($selected, "74").'>74</option>
					<option value="75" '.check_select($selected, "75").'>75</option>
					<option value="76" '.check_select($selected, "76").'>76</option>
					<option value="77" '.check_select($selected, "77").'>77</option>
					<option value="78" '.check_select($selected, "78").'>78</option>
					<option value="79" '.check_select($selected, "79").'>79</option>
					<option value="80" '.check_select($selected, "80").'>80</option>
					<option value="81" '.check_select($selected, "81").'>81</option>
					<option value="82" '.check_select($selected, "82").'>82</option>
					<option value="83" '.check_select($selected, "83").'>83</option>
					<option value="84" '.check_select($selected, "84").'>84</option>
					<option value="85" '.check_select($selected, "85").'>85</option>
					<option value="86" '.check_select($selected, "86").'>86</option>
					<option value="87" '.check_select($selected, "87").'>87</option>
					<option value="88" '.check_select($selected, "88").'>88</option>
					<option value="89" '.check_select($selected, "89").'>89</option>
					<option value="90" '.check_select($selected, "90").'>90</option>
					<option value="91" '.check_select($selected, "91").'>91</option>
					<option value="92" '.check_select($selected, "92").'>92</option>
					<option value="93" '.check_select($selected, "93").'>93</option>
					<option value="94" '.check_select($selected, "94").'>94</option>
					<option value="95" '.check_select($selected, "95").'>95</option>
					<option value="96" '.check_select($selected, "96").'>96</option>
					<option value="97" '.check_select($selected, "97").'>97</option>
					<option value="98" '.check_select($selected, "98").'>98</option>
					<option value="99" '.check_select($selected, "99").'>99</option>

					';
?>
