<?
/*//////////////////////////////////////////////////////////
// ######################################################///
// # DuhokForum 1.1                                     # //
// ###################################################### //
// #                                                    # //
// #       --  DUHOK FORUM IS FREE SOFTWARE  --         # //
// #                                                    # //
// #   ========= Programming By Dilovan ==============  # //
// # Copyright � 2007-2009 Dilovan. All Rights Reserved # //
// #----------------------------------------------------# //
// #----------------------------------------------------# //
// # If you want any support vist down address:-        # //
// # Email: df@duhoktimes.com                           # //
// # Site: http://df.duhoktimes.com/index.php           # //
// ###################################################### //
//////////////////////////////////////////////////////////*/

$http_host = $HTTP_SERVER_VARS[HTTP_HOST];
$referer = $HTTP_SERVER_VARS[HTTP_REFERER];
$mode = trim($HTTP_GET_VARS[mode]);
$step = trim($HTTP_GET_VARS[step]);
$type = trim($HTTP_GET_VARS[type]);
$method = trim($HTTP_GET_VARS[method]);
$mail = trim($HTTP_GET_VARS[mail]);
$msg = trim($HTTP_GET_VARS[msg]);
$svc = trim($HTTP_GET_VARS[svc]);
$sel = trim($HTTP_GET_VARS[sel]);
$show = trim($HTTP_GET_VARS[show]);
$app = trim($HTTP_GET_VARS[app]);
$days = trim($HTTP_GET_VARS[days]);
$scope = trim($HTTP_GET_VARS[scope]);
$sg = trim($HTTP_GET_VARS[sg]);
$ch = trim($HTTP_GET_VARS[ch]);
$tz = trim($HTTP_GET_VARS[tz]);
$c = trim($HTTP_GET_VARS[c]);
$f = trim($HTTP_GET_VARS[f]);
$t = trim($HTTP_GET_VARS[t]);
$r = trim($HTTP_GET_VARS[r]);
$m = trim($HTTP_GET_VARS[m]);
$err = trim($HTTP_GET_VARS[err]);
$id = trim($HTTP_GET_VARS[id]);
$pm = trim($HTTP_GET_VARS[pm]);
$n = trim($HTTP_GET_VARS[n]);
$pg = trim($HTTP_GET_VARS[pg]);
$active = trim($HTTP_GET_VARS[active]);
$aid = trim($HTTP_GET_VARS[aid]);
$mod_option = trim($HTTP_GET_VARS[mod_option]);
$quote = trim($HTTP_GET_VARS[quote]);
$author = trim($HTTP_GET_VARS[author]);
$tdate = trim($HTTP_GET_VARS[tdate]);
$rdate = trim($HTTP_GET_VARS[rdate]);
$src = trim($HTTP_GET_VARS[src]);
$pm_from = trim($HTTP_GET_VARS[from]);
$auth = trim($HTTP_GET_VARS[auth]);
$vote = trim($HTTP_GET_VARS[vote]);

define(http_host, trim($HTTP_SERVER_VARS[HTTP_HOST]));
define(referer, trim($HTTP_SERVER_VARS[HTTP_REFERER]));
define(mode, trim($HTTP_GET_VARS[mode]));
define(step, trim($HTTP_GET_VARS[step]));
define(type, trim($HTTP_GET_VARS[type]));
define(method, trim($HTTP_GET_VARS[method]));
define(mail, trim($HTTP_GET_VARS[mail]));
define(msg, trim($HTTP_GET_VARS[msg]));
define(svc, trim($HTTP_GET_VARS[svc]));
define(app, trim($HTTP_GET_VARS[app]));
define(days, trim($HTTP_GET_VARS[days]));
define(scope, trim($HTTP_GET_VARS[scope]));
define(c, trim($HTTP_GET_VARS[c]));
define(f, trim($HTTP_GET_VARS[f]));
define(t, trim($HTTP_GET_VARS[t]));
define(r, trim($HTTP_GET_VARS[r]));
define(m, trim($HTTP_GET_VARS[m]));
define(err, trim($HTTP_GET_VARS[err]));
define(id, trim($HTTP_GET_VARS[id]));
define(n, trim($HTTP_GET_VARS[n]));
define(pg, trim($HTTP_GET_VARS[pg]));

?>