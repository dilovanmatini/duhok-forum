<?
/*//////////////////////////////////////////////////////////
// ######################################################///
// # DuhokForum 1.1                                     # //
// ###################################################### //
// #                                                    # //
// #       --  DUHOK FORUM IS FREE SOFTWARE  --         # //
// #                                                    # //
// #   ========= Programming By Dilovan ==============  # //
// # Copyright � 2007-2009 Dilovan. All Rights Reserved # //
// #----------------------------------------------------# //
// #----------------------------------------------------# //
// # If you want any support vist down address:-        # //
// # Email: df@duhoktimes.com                           # //
// # Site: http://df.duhoktimes.com/index.php           # //
// ###################################################### //
//////////////////////////////////////////////////////////*/

$HTTP_REFERER = $_SERVER['HTTP_REFERER'];

$Monitor = chk_monitor($DBMemberID, $c);
$date = time();

if ($type == "c") {
    if ($Mlevel == 4) {
		$query = "DELETE FROM " . $Prefix . "CATEGORY WHERE CAT_ID = '$c' ";
		mysql_query($query, $connection) or die (mysql_error());
  
	                echo'<center>
	                <table width="99%" border="1">
	                   <tr class="normal">
	                       <td class="list_center" colSpan="10"><font size="5"><br>'.$lang['delete']['the_cat_is_deleted'].'</font><br><br>
                           <meta http-equiv="Refresh" content="1; URL=index.php">
                           <a href="index.php">'.$lang['all']['click_here_to_go_home'].'</a><br><br>
	                       </td>
	                   </tr>
	                </table>
	                </center>';
    }
    else {
    redirect();
    }
}
elseif ($type == "f") {
    if ($Mlevel == 4) {
		$query = "DELETE FROM " . $Prefix . "FORUM WHERE FORUM_ID = '$f' ";
		mysql_query($query, $connection) or die (mysql_error());

	                echo'<center>
	                <table width="99%" border="1">
	                   <tr class="normal">
	                       <td class="list_center" colSpan="10"><font size="5"><br>'.$lang['delete']['the_forum_is_deleted'].'</font><br><br>
                           <meta http-equiv="Refresh" content="1; URL=index.php">
                           <a href="index.php">'.$lang['all']['click_here_to_go_home'].'</a><br><br>
	                       </td>
	                   </tr>
	                </table>
	                </center>';
    }
    else {
    redirect();
    }
}
elseif ($type == "m") {
    if ($Mlevel == 4) {
if(members("LEVEL", $m) == 4){
redirect();
exit();
}
if (members("THE_ID", $m) == 1 ) {
	                echo'<br><center>
	                <table width="99%" border="1">
	                   <tr class="normal">
	                       <td class="list_center" colSpan="10"><font size="5" color="red"><br>
'.$lang[lock][member_is_admin].'
</font><br><br>
	                       <a href="JavaScript:history.go(-1)">'.$lang['profile']['click_here_to_back'].'</a><br><br>
	                       </td>
	                   </tr>
	                </table>
	                </center><xml>';
exit();
}

		$query = "DELETE FROM " . $Prefix . "MEMBERS WHERE MEMBER_ID = '$m' ";
		mysql_query($query, $connection) or die (mysql_error());

	                echo'<center>
	                <table width="99%" border="1">
	                   <tr class="normal">
	                       <td class="list_center" colSpan="10"><font size="5"><br>'.$lang['delete']['the_member_is_deleted'].'</font><br><br>
                           <meta http-equiv="Refresh" content="1; URL='.$HTTP_REFERER.'">
                           <a href="index.php?mode=members">'.$lang['all']['click_here_to_go_member_page'].'</a><br><br>
                           <a href="'.$HTTP_REFERER.'">'.$lang['all']['click_here_to_go_normal_page'].'</a><br><br>
	                       </td>
	                   </tr>
	                </table>
	                </center>';
    }
    else {
    redirect();
    }
}
elseif ($type == "del_mod") {
    if ($Mlevel == 4) {
		$query = "DELETE FROM " . $Prefix . "MODERATOR WHERE MOD_ID = '$m' ";
		mysql_query($query, $connection) or die (mysql_error());
  
	                echo'<center>
	                <table width="99%" border="1">
	                   <tr class="normal">
	                       <td class="list_center" colSpan="10"><font size="5"><br>'.$lang['delete']['the_mod_is_deleted'].'</font><br><br>
                           <meta http-equiv="Refresh" content="1; URL='.$HTTP_REFERER.'">
                           <a href="index.php?mode=add_cat_forum&method=edit&type=f&f='.$f.'">'.$lang['all']['click_here_to_go_moderator_list'].'</a><br><br>
                           <a href="'.$HTTP_REFERER.'">'.$lang['all']['click_here_to_go_normal_page'].'</a><br><br>
	                       </td>
	                   </tr>
	                </table>
	                </center>';
    }
    else {
    redirect();
    }
}
elseif ($type == "del_mem") {
    if ($Mlevel == 4) {
		mysql_query("DELETE FROM ".$Prefix."HIDE_FORUM WHERE HF_ID = '$m' ") or die (mysql_error());
	                echo'<center>
	                <table width="99%" border="1">
	                   <tr class="normal">
	                       <td class="list_center" colSpan="10"><font size="5"><br>�� ��� ����� �� ������� �����</font><br><br>
                           <meta http-equiv="Refresh" content="1; URL='.$HTTP_REFERER.'">
                           <a href="index.php?mode=add_cat_forum&method=edit&type=f&f='.$f.'">-- ���� ��� ������ ��� ����� ����� ������� --</a><br><br>
                           <a href="'.$HTTP_REFERER.'">'.$lang['all']['click_here_to_go_normal_page'].'</a><br><br>
	                       </td>
	                   </tr>
	                </table>
	                </center>';
    }
    else {
		redirect();
    }
}
elseif ($type == "t") {
    if (allowed($f, 2) == 1) {
	if (allowed($f, 1) == 1) {
		$query = "DELETE FROM " . $Prefix . "TOPICS WHERE TOPIC_ID = '$t' ";
	}
	else {
		$query = "UPDATE " . $Prefix . "TOPICS SET T_STATUS = '2', T_DELETED_BY = '$DBMemberID', T_DELETED_DATE = '$date' WHERE TOPIC_ID = '$t' ";
	}
		mysql_query($query, $connection) or die (mysql_error());
  
	$query2 = "UPDATE ".$Prefix."FORUM SET ";
	$query2 .= "F_TOPICS = F_TOPICS - 1, ";
	$query2 .= "F_REPLIES = F_REPLIES - 1 ";
	$query2 .= "WHERE FORUM_ID = '$f.' ";
	mysql_query($query2, $connection) or die (mysql_error());

	                echo'<center>
	                <table width="99%" border="1">
	                   <tr class="normal">
	                       <td class="list_center" colSpan="10"><font size="5"><br>'.$lang['delete']['the_topic_is_deleted'].'</font><br><br>
                           <meta http-equiv="Refresh" content="1; URL=index.php?mode=f&f='.$f.'">
                           <a href="index.php?mode=f&f='.$f.'">'.$lang['all']['click_here_to_go_forum'].'</a><br><br>
                           <a href="index.php">'.$lang['all']['click_here_to_go_home'].'</a><br><br>
	                       </td>
	                   </tr>
	                </table>
	                </center>';
    }
    else {
    redirect();
    }
}
elseif ($type == "monitored") {
    if ($Mlevel > 0) {
		$query = "DELETE FROM " . $Prefix . "FAVOURITE_TOPICS WHERE F_TOPICID = '$t' AND F_MEMBERID = '$DBMemberID' ";
		mysql_query($query, $connection) or die (mysql_error());

	                echo'<center>
	                <table width="99%" border="1">
	                   <tr class="normal">
	                       <td class="list_center" colSpan="10"><font color="red" size="5"><br>�� ����� ������� �� ����� ������� �������.</font><br><br>
                           <a href="index.php?mode=active&active=monitored">-- ���� ��� ������ ��� ������ ������� --</a><br><br>
	                       </td>
	                   </tr>
	                </table>
	                </center>';
    }
    else {
    redirect();
    }
}
elseif ($type == "r") {
	$author = replies("AUTHOR", $r);
	$hidden = replies("HIDDEN", $r);
    if (allowed($f, 2) == 1 OR $hidden != 1 AND $DBMemberID == $author) {
	if (allowed($f, 1) == 1) {
		$query = "DELETE FROM " . $Prefix . "REPLY WHERE REPLY_ID = '$r' ";
	}
	else {
		$query = "UPDATE " . $Prefix . "REPLY SET R_STATUS = '2', R_DELETED_BY = '$DBMemberID', R_DELETED_DATE = '$date' WHERE REPLY_ID = '$r' ";
	}
		mysql_query($query, $connection) or die (mysql_error());

	$query2 = "UPDATE " . $Prefix . "FORUM SET ";
	$query2 .= "F_REPLIES = F_REPLIES - 1 ";
	$query2 .= "WHERE FORUM_ID = '$f' ";     
	mysql_query($query2, $connection) or die (mysql_error());
     
	$query3 = "UPDATE " . $Prefix . "TOPICS SET ";
	$query3 .= "T_REPLIES = T_REPLIES - 1 ";
	$query3 .= "WHERE TOPIC_ID = '$t' ";
	mysql_query($query3, $connection) or die (mysql_error());

	$query4 = "UPDATE " . $Prefix . "MEMBERS SET ";
	$query4 .= "M_POSTS = M_POSTS - 1 ";
	$query4 .= "WHERE MEMBER_ID = '$DBMemberID' ";
	mysql_query($query4, $connection) or die (mysql_error());

	                echo'<center>
	                <table width="99%" border="1">
	                   <tr class="normal">
	                       <td class="list_center" colSpan="10"><font size="5"><br>'.$lang['delete']['the_reply_is_deleted'].'</font><br><br>
                           <meta http-equiv="Refresh" content="1; URL='.$HTTP_REFERER.'">
                           <a href="index.php?mode=t&t='.$t.'">'.$lang['all']['click_here_to_go_topic'].'</a><br><br>
                           <a href="index.php?mode=f&f='.$f.'">'.$lang['all']['click_here_to_go_forum'].'</a><br><br>
                           <a href="'.$HTTP_REFERER.'">'.$lang['all']['click_here_to_go_normal_page'].'</a><br><br>
	                       </td>
	                   </tr>
	                </table>
	                </center>';
    }
    else {
    redirect();
    }
}
elseif ($type == "pm") {

 $remove = $_POST['remove'];
 
 $delete = $_POST['delete'];
 
 $PM = mysql_query("SELECT * FROM ".$Prefix."PM WHERE PM_ID = '$msg' ") or die (mysql_error());

 if(mysql_num_rows($PM) > 0){

 $rs_PM = mysql_fetch_array($PM);

 $PM_PmID = $rs_PM['PM_ID'];
 $PM_MID = $rs_PM['PM_MID'];
 }
    if ($$DBMemberID == $PM_MID ) {
        if ($method == "") {

        $query = "UPDATE " . $Prefix . "PM SET ";
        $query .= "PM_STATUS = 0 ";
        $query .= "WHERE PM_ID = '$msg' ";

        mysql_query($query, $connection) or die (mysql_error());

	                echo'<center>
	                <table width="99%" border="1">
	                   <tr class="normal">
	                       <td class="list_center" colSpan="10"><font size="5"><br>'.$lang['delete']['the_pm_is_moved'].'</font><br><br>
                           <meta http-equiv="Refresh" content="1; URL='.$HTTP_REFERER.'">
                           <a href="'.$HTTP_REFERER.'">'.$lang['all']['click_here_to_go_normal_page'].'</a><br><br>
	                       </td>
	                   </tr>
	                </table>
	                </center>';
        }
        if ($method == "remove") {
             if ($remove == "") {
	                echo'<br><center>
	                <table width="99%" border="1">
	                   <tr class="normal">
	                       <td class="list_center" colSpan="10"><font size="5" color="red"><br>'.$lang['all']['error'].'<br>'.$lang['delete']['you_are_non_selected_any_pm'].'</font><br><br>
	                       <a href="JavaScript:history.go(-1)">'.$lang['all']['click_here_to_back'].'</a><br><br>
	                       </td>
	                   </tr>
	                </table>
	                </center>';
            }
            else {

            $i_pm = 0;
            while($i_pm  < count($remove)) {

                mysql_query("UPDATE ".$Prefix."PM SET PM_STATUS = '0' WHERE PM_ID = ".$remove[$i_pm]." ") or die (mysql_error());
                $i_pm++;

            }

	                echo'<center>
	                <table width="99%" border="1">
	                   <tr class="normal">
	                       <td class="list_center" colSpan="10"><font size="5"><br>'.$lang['delete']['the_pm_is_moved'].'</font><br><br>
                           <meta http-equiv="Refresh" content="1; URL='.$HTTP_REFERER.'">
                           <a href="'.$HTTP_REFERER.'">'.$lang['all']['click_here_to_go_normal_page'].'</a><br><br>
	                       </td>
	                   </tr>
	                </table>
	                </center>';
            }
        }
        if ($method == "delete") {
             if ($delete == "") {
	                echo'<br><center>
	                <table width="99%" border="1">
	                   <tr class="normal">
	                       <td class="list_center" colSpan="10"><font size="5" color="red"><br>'.$lang['all']['error'].'<br>'.$lang['delete']['you_are_non_selected_any_pm'].'</font><br><br>
	                       <a href="JavaScript:history.go(-1)">'.$lang['all']['click_here_to_back'].'</a><br><br>
	                       </td>
	                   </tr>
	                </table>
	                </center>';
            }
            else {

            $i_pm = 0;
            while($i_pm  < count($delete)) {

                mysql_query("DELETE FROM ".$Prefix."PM WHERE PM_ID = ".$delete[$i_pm]." ") or die (mysql_error());
                $i_pm++;

            }

	                echo'<center>
	                <table width="99%" border="1">
	                   <tr class="normal">
	                       <td class="list_center" colSpan="10"><font size="5"><br>'.$lang['delete']['the_pm_is_normal_deleted'].'</font><br><br>
                           <meta http-equiv="Refresh" content="1; URL='.$HTTP_REFERER.'">
                           <a href="'.$HTTP_REFERER.'">'.$lang['all']['click_here_to_go_normal_page'].'</a><br><br>
	                       </td>
	                   </tr>
	                </table>
	                </center>';
            }
        }
    }
    else{
    redirect();
    }
}
else {
redirect();
}


mysql_close();
?>
