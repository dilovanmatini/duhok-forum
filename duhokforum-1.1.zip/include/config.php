<?php
/*//////////////////////////////////////////////////////////
// ######################################################///
// # DuhokForum 1.1                                     # //
// ###################################################### //
// #                                                    # //
// #       --  DUHOK FORUM IS FREE SOFTWARE  --         # //
// #                                                    # //
// #   ========= Programming By Dilovan ==============  # //
// # Copyright � 2007-2009 Dilovan. All Rights Reserved # //
// #----------------------------------------------------# //
// #----------------------------------------------------# //
// # If you want any support vist down address:-        # //
// # Email: df@duhoktimes.com                           # //
// # Site: http://df.duhoktimes.com/index.php           # //
// ###################################################### //
//////////////////////////////////////////////////////////*/

if (eregi("config.php","$HTTP_SERVER_VARS[PHP_SELF]")) {
	header("HTTP/1.0 404 Not Found");
exit();
}
require("connect.php");


$forum_title = open_mysql("FORUM_TITLE");
$forum_title2 = open_mysql("FORUM_TITLE2");
$Site_ID = 1;
/*
$forum_title = open_mysql("FORUM_TITLE2");
$Site_ID = 2;
*/
$site_name = open_mysql("SITE_ADDRESS");
$copy_right = open_mysql("COPY_RIGHT");
$image_folder = open_mysql("IMAGE_FOLDER");
$max_page = open_mysql("PAGE_NUMBER");
$admin_folder = open_mysql("ADMIN_FOLDER");
$admin_email = open_mysql("ADMIN_EMAIL");
$forum_version = open_mysql("FORUM_VERSION");
$author_script = open_mysql("AUTHOR_SCRIPT");
$total_pm_message = open_mysql("TOTAL_PM_MSG");
$total_post_close_topic = open_mysql("TOTAL_POST_CLOSE_TOPIC");
$mod_add_titles = open_mysql("MOD_ADD_TITLES");
$mod_add_medals = open_mysql("MOD_ADD_MEDALS");
$topic_max_size = open_mysql("TOPIC_MAX_SIZE");
$reply_max_size = open_mysql("REPLY_MAX_SIZE");
$pm_max_size = open_mysql("PM_MAX_SIZE");
$sig_max_size = open_mysql("SIG_MAX_SIZE");
$default_language = open_mysql("DEFAULT_LANGUAGE");
$default_style = open_mysql("DEFAULT_STYLE");
$forum_url = open_mysql("FORUM_URL");
$forum_status = open_mysql("FORUM_STATUS");
$seo = open_mysql("FORUM_SEO");
$Meta = open_mysql("FORUM_META");
$KeyWords = open_mysql("FORUM_KEY");
$BanWords = open_mysql("FORUM_BANWORDS");
$show_admin_info = open_mysql("SHOW_ADMIN_INFO");
$change_name_max = open_mysql("CHANGE_NAME_MAX");
$changename_dayslimit = open_mysql("CHANGENAME_DAYSLIMIT");
$show_moderators = open_mysql("SHOW_MODERATORS");
$Files_Max_Size = open_mysql("FILES_MAX_SIZE");
$Files_Max_Allowed = open_mysql("FILES_MAX_ALLOWED");
$help_forum = open_mysql("HELP_FORUM");
$show_alexa_traffic = open_mysql("SHOW_ALEXA_TRAFFIC");
$register_waitting = open_mysql("REGISTER_WAITTING");
$show_medals_in_posts = open_mysql("SHOW_MEDALS_IN_POSTS");
$new_member_min_posts = open_mysql("NEW_MEMBER_MIN_POSTS");
$new_member_min_posts_pm = open_mysql("NEW_MEMBER_MIN_POSTS_PM");
$site_timezone = open_mysql("SITE_TIMEZONE");
$show_admin_topics = open_mysql("SHOW_ADMIN_TOPICS");
$max_search = open_mysql("MAX_SEARCH");


$max_list_cat_members = open_mysql("MAX_LIST_CAT_MEMBERS");
$max_list_m_members = open_mysql("MAX_LIST_M_MEMBERS");
$max_list_cat_moderators = open_mysql("MAX_LIST_CAT_MODERATORS");
$max_list_m_moderators = open_mysql("MAX_LIST_M_MODERATORS");

$color_0 = open_mysql("COLOR_0");
$color_1 = open_mysql("COLOR_1");
$color_2 = open_mysql("COLOR_2");
$color_3 = open_mysql("COLOR_3");
$color_4 = open_mysql("COLOR_4");

// ############# Permession ###########

$CAN_SHOW_PM = open_mysql("CAN_SHOW_PM");
$CAN_CLOSE_M = open_mysql("CAN_CLOSE_M");
$CAN_OPEN_M = open_mysql("CAN_OPEN_M");

$CAN_SHOW_FORUM = open_mysql("CAN_SHOW_FORUM");
$CAN_SHOW_TOPIC = open_mysql("CAN_SHOW_TOPIC");
$CAN_SHOW_PROFILE = open_mysql("CAN_SHOW_PROFILE");

// ############# FTP ###########

$FTP_ACTIVE = open_mysql("FTP_ACTIVE");
$FTP_SERVER = open_mysql("FTP_SERVER");
$FTP_USER = open_mysql("FTP_USER");
$FTP_PASS = open_mysql("FTP_PASS");

// ############# Titles ###########


$Title = array(
	open_mysql("TITLE_0"),
	open_mysql("TITLE_1"),
	open_mysql("TITLE_2"),
	open_mysql("TITLE_3"),
	open_mysql("TITLE_4"),
	open_mysql("TITLE_5"),
	open_mysql("TITLE_6"),
	open_mysql("TITLE_7"),
	open_mysql("TITLE_8"),
	open_mysql("TITLE_9"),
	open_mysql("TITLE_10"),
	open_mysql("TITLE_11"),
	open_mysql("TITLE_12"),
	open_mysql("TITLE_13")
);

$Title_Female = array(
	open_mysql("TITLE_0_FEMALE"),
	open_mysql("TITLE_1_FEMALE"),
	open_mysql("TITLE_2_FEMALE"),
	open_mysql("TITLE_3_FEMALE"),
	open_mysql("TITLE_4_FEMALE"),
	open_mysql("TITLE_5_FEMALE"),
	open_mysql("TITLE_6_FEMALE"),
	open_mysql("TITLE_7_FEMALE"),
	open_mysql("TITLE_8_FEMALE"),
	open_mysql("TITLE_9_FEMALE"),
	open_mysql("TITLE_10_FEMALE"),
	open_mysql("TITLE_11_FEMALE"),
	open_mysql("TITLE_12_FEMALE"),
	open_mysql("TITLE_13_FEMALE")
);

$StarsNomber = array(
	open_mysql("STARS_NUMBER_0"),
	open_mysql("STARS_NUMBER_1"),
	open_mysql("STARS_NUMBER_2"),
	open_mysql("STARS_NUMBER_3"),
	open_mysql("STARS_NUMBER_4"),
	open_mysql("STARS_NUMBER_5"),
	open_mysql("STARS_NUMBER_6"),
	open_mysql("STARS_NUMBER_7"),
	open_mysql("STARS_NUMBER_8"),
	open_mysql("STARS_NUMBER_9"),
	open_mysql("STARS_NUMBER_10")
);

$StarsColor=array(
	open_mysql("MLV_STARS_COLOR_0"),
	open_mysql("MLV_STARS_COLOR_1"),
	open_mysql("MLV_STARS_COLOR_2"),
	open_mysql("MLV_STARS_COLOR_3"),
	open_mysql("MLV_STARS_COLOR_4")
);

//####### editor  ##############

$editor_full_html = open_mysql("EDITOR_FULL_HTML");
$editor_width = open_mysql("EDITOR_WIDTH");
$editor_height = open_mysql("EDITOR_HEIGHT");

$EditorIcon=array(
	open_mysql("EDITOR_ICON_SAVE"),
	open_mysql("EDITOR_ICON_PRINT"),
	open_mysql("EDITOR_ICON_ZOOM"),
	open_mysql("EDITOR_ICON_STYLE"),
	open_mysql("EDITOR_ICON_PARAGRAPH"),
	open_mysql("EDITOR_ICON_FONT_NAME"),
	open_mysql("EDITOR_ICON_SIZE"),
	open_mysql("EDITOR_ICON_TEXT"),
	open_mysql("EDITOR_ICON_SELECT_ALL"),
	open_mysql("EDITOR_ICON_CUT"),
	open_mysql("EDITOR_ICON_COPY"),
	open_mysql("EDITOR_ICON_PASTE"),
	open_mysql("EDITOR_ICON_UNDO"),
	open_mysql("EDITOR_ICON_REDO"),
	open_mysql("EDITOR_ICON_BOLD"),
	open_mysql("EDITOR_ICON_ITALIC"),
	open_mysql("EDITOR_ICON_UNDER_LINE"),
	open_mysql("EDITOR_ICON_STRIKE"),
	open_mysql("EDITOR_ICON_SUPER_SCRIPT"),
	open_mysql("EDITOR_ICON_SUB_SCRIPT"),
	open_mysql("EDITOR_ICON_SYMBOL"),
	open_mysql("EDITOR_ICON_LEFT"),
	open_mysql("EDITOR_ICON_CENTER"),
	open_mysql("EDITOR_ICON_RIGHT"),
	open_mysql("EDITOR_ICON_FULL"),
	open_mysql("EDITOR_ICON_NUBERING"),
	open_mysql("EDITOR_ICON_BULLETS"),
	open_mysql("EDITOR_ICON_INDENT"),
	open_mysql("EDITOR_ICON_OUTDENT"),
	open_mysql("EDITOR_ICON_IMAGE"),
	open_mysql("EDITOR_ICON_COLOR"),
	open_mysql("EDITOR_ICON_BGCOLOR"),
	open_mysql("EDITOR_ICON_EX_LINK"),
	open_mysql("EDITOR_ICON_IN_LINK"),
	open_mysql("EDITOR_ICON_ASSET"),
	open_mysql("EDITOR_ICON_TABLE"),
	open_mysql("EDITOR_ICON_SHOW_BORDER"),
	open_mysql("EDITOR_ICON_ABSOLUTE"),
	open_mysql("EDITOR_ICON_CLEAN"),
	open_mysql("EDITOR_ICON_LINE"),
	open_mysql("EDITOR_ICON_PROPERTIES"),
	open_mysql("EDITOR_ICON_WORD")
);

//####### editor  ##############

//####### Schat  ##############

$active_schat = open_mysql("ACTIVE_SCHAT");
$visitor_schat = open_mysql("VISITOR_SCHAT");
$num_schat = open_mysql("NUM_SCHAT");
$active_room = open_mysql("ACTIVE_ROOM");
$nbr_max_post_schat = open_mysql("NBR_MAX_POST_SCHAT");
$boss_schat = open_mysql("BOSS_SCHAT");
$schat_url = open_mysql("SCHAT_URL");
$forumid_mon_schat = open_mysql("FORUMID_MON_SCHAT");
$active_schat_smile = open_mysql("ACTIVE_SCHAT_SMILE");




//####### Best  ##############
$best = open_mysql("BEST");
$best_mem = open_mysql("BEST_MEM");
$best_topic = open_mysql("BEST_TOPIC");
$best_mod = open_mysql("BEST_MOD");
$best_frm = open_mysql("BEST_FRM");

$best_t = open_mysql("BEST_T");
$best_mem_t = open_mysql("BEST_MEM_T");
$best_topic_t = open_mysql("BEST_TOPIC_T");
$best_mod_t = open_mysql("BEST_MOD_T");
$best_frm_t = open_mysql("BEST_FRM_T");

//####### ADD  ##############

$logos = open_mysql("logos");
$note = open_mysql("note");

$close = open_mysql("close");


//####### New Member  ##############
$new_member_show_topic = open_mysql("NEW_MEMBER_SHOW_TOPIC");
$new_member_min_search = open_mysql("NEW_MEMBER_MIN_SEARCH");
$new_member_change_name = open_mysql("NEW_MEMBER_CHANGE_NAME");

$editor_topic = open_mysql("editor_topic");
$editor_msg = open_mysql("editor_msg");
$editor_style = open_mysql("editor_style");

//####### ads  ##############
$ad = open_mysql("ad");
$ad1 = open_mysql("ad1");
$ad2 = open_mysql("ad2");
$ad3 = open_mysql("ad3");
$ad4 = open_mysql("ad4");
$ad5 = open_mysql("ad5");
$ad6 = open_mysql("ad6");

$pb = open_mysql("pb");
$pb1 = open_mysql("pb1");
$pb2 = open_mysql("pb2");
$pb3 = open_mysql("pb3");
$pb4 = open_mysql("pb4");
$pb5 = open_mysql("pb5");
$pb6 = open_mysql("pb6");

$pub = open_mysql("pub");
$pub1 = open_mysql("pub1");
$pub2 = open_mysql("pub2");
$pub3 = open_mysql("pub3");
$pub4 = open_mysql("pub4");
$pub5 = open_mysql("pub5");
$pub6 = open_mysql("pub6");

$pubs = open_mysql("pubs");
$pubs1 = open_mysql("pubs1");
$pubs2 = open_mysql("pubs2");
$pubs3 = open_mysql("pubs3");
$pubs4 = open_mysql("pubs4");
$pubs5 = open_mysql("pubs5");
$pubs6 = open_mysql("pubs6");
//####### ads  ##############

$BAR = open_mysql("BAR");
$BAR1 = open_mysql("BAR1");
$BAR2 = open_mysql("BAR2");


$FORUM_MSG = open_mysql("FORUM_MSG");
$FORUM_MSG1 = open_mysql("FORUM_MSG1");
$FORUM_MSG2 = open_mysql("FORUM_MSG2");
$MSG = open_mysql("MSG");

$WHAT_ACTIVE = open_mysql("WHAT_ACTIVE");
$WHAT_TITLE = open_mysql("WHAT_TITLE");
$WHAT_ADMIN_SHOW = open_mysql("WHAT_ADMIN_SHOW");
$WHAT_LIMIT = open_mysql("WHAT_LIMIT");
$WHAT_COLOR = open_mysql("WHAT_COLOR");
$WHAT_FASEL = open_mysql("WHAT_FASEL");
$WHAT_ALL = open_mysql("WHAT_ALL");
$WHAT_DIRECTION = open_mysql("WHAT_DIRECTION");


?>
