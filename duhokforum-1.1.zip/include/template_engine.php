<?
/*//////////////////////////////////////////////////////////
// ######################################################///
// # DuhokForum 1.1                                     # //
// ###################################################### //
// #                                                    # //
// #       --  DUHOK FORUM IS FREE SOFTWARE  --         # //
// #                                                    # //
// #   ========= Programming By Dilovan ==============  # //
// # Copyright � 2007-2009 Dilovan. All Rights Reserved # //
// #----------------------------------------------------# //
// #----------------------------------------------------# //
// # If you want any support vist down address:-        # //
// # Email: df@duhoktimes.com                           # //
// # Site: http://df.duhoktimes.com/index.php           # //
// ###################################################### //
//////////////////////////////////////////////////////////*/

class Template{
var $variable = "";

	function display($code){
                   $code = $this->Get_Tmp($code);
                   echo $code;
                  }

	function G_TMP($code){
                   $code = $this->Get_Tmp($code);
                   return $code;
                  }

	function xml_exists($xml){
                      $xml = "styles/style.xml";
                      if(file_exists($xml )){
                       return true;
                       }else{
                       return false;
                       }
                  }

	function wrong_path($xml){
                      $xml = $xml.".xml";
                      $path = "styles/style".$xml;
                     echo '<b>Warning : </b> Template File '.$xml.' Not Exists in Path '.$path.'';
                     exit();
                  }

	function wrong_tmp($file,$style){
                     echo '<b>Warning : </b> Template Row '.$file.' Not Exists in Style '.$style.' , Wrong Query';
                     exit();
                  }

	function Get_Tmp($file){
                  global $choose_style,$dbhost,$dbuser,$dbpass,$dbname;

                 // Check File XML
                 if(!$this->xml_exists($choose_style)){
                 $this->wrong_path($choose_style);
                  }

                 // if is footer , run connection because some time we use mysql_close(); 
                 if($file == "footer"){
                 $connection = @mysql_connect($dbhost, $dbuser, $dbpass);
                 @mysql_select_db($dbname);
                  }


                $Sql = mysql_query("select *  from ".prefix."TEMPLATES where NAME ='$file'  ") or die(mysql_error());
                $Num = mysql_num_rows($Sql);
                 if ($Num == 0) {
                 $this->wrong_tmp($file,$choose_style);
                 }

                 if ($Num != 0) {
                 $row=mysql_fetch_array($Sql);
                 $tpl_source = $row['SOURCE'];
                 }
 
                  $DesignCode = $this->Code_Html($tpl_source);
	return $DesignCode;
	}
	
	function Code_Html($html){
	extract($GLOBALS);

$DF = stripslashes($html);

                                                    $DF = preg_replace('#{\$(.*)\[(.*)]\[(.*)]}#i','<php> echo $this->variable[\'$1\'][\'$2\'][\'$3\'];</php>',$DF); 

		$DF = eregi_replace("{{","<php> echo ", $DF);
		$DF = eregi_replace("}}","; </php>", $DF);


// if condition
			$DF = $this->if_condition($DF);
			$DF =eregi_replace("\<else>","</code>\";} else {echo \"<code>",$DF);



// loop
			$DF = $this->html_loop($DF);


// while and mysql_fetch

                                                      $DF = $this->sql_com($DF);

// Replace php by code for use in the realy php

		$DF = eregi_replace("\<php>","</code>\";", $DF);
		$DF = eregi_replace("\</php>","echo \"<code>", $DF);

// Config Simple

	                  $DF = "echo \"<code>".$DF."</code>\";";	

// Replace " with \" until I can echo html code with no prblem

		$DF =  $this->Html_Quot($DF);

// Delete code from template 

	                  $DF = str_replace("<code>","",$DF);
		$DF = str_replace("</code>","",$DF);

// Bye Bye

                                    $DF.= "\nreturn true;";

// ShowTime !!!!
                                                                        ob_start();
				$DF = eval($DF);
				$DF = ob_get_contents();
				ob_end_clean();
	
	return $DF;
	}


	
	function if_condition($Html){
                   $Html = preg_replace('/\<if condition\=\"(.*)\">/','</code>"; if($1){ echo "<code>',$Html); 
                   $Html = preg_replace('/\<\/if\>/','</code>";} echo "<code>',$Html);
                   return $Html;
	}

                  function sql_com($Html){
/*
$Html = preg_replace('#<section name="(.*)" fetch="(.*)">(.*)</section>#i','<php>while($2 = mysql_fetch_array($1)){</php>$3<php>}</php>',$Html); 
*/
$Html = preg_replace('#<sql name="(.*)" fetch="(.*)">#','</code>";$i=1; while($2=@mysql_fetch_array($1)){ echo "<code>',$Html); 
$Html = preg_replace('/\<\/sql\>/','</code>"; $i++;} echo "<code>',$Html);
return $Html;
                  }

                  function html_loop($Html){

$Html = preg_replace('#<loop value="(.*)" star="(.*)" end="(.*)">(.*)</loop>#si','<php>for($1 = $2;$i < $3;$1++){</php>$4<php>}</php>',$Html); 
                   return $Html;

                  }

// Add Multipe Array like $lang

               function assign_array($string,$value){
                $this->variable[$string] = $value;
                return true;
               }

              function array_fix($a,$b,$c){
              extract($GLOBALS);
              die($this->variable[$a][$b][$c]);
              return true;
              }

               function assign($string,$value){
               $GLOBALS[$string] = $value;
                return true;
               }

		function Html_Quot($String){
		    $Tablo=split("<code>",$String);
		    $String="";
		    $String.=$Tablo[0];
		    foreach($Tablo as $Cle=>$Valeur){
		        if(eregi("</code>",$Valeur)) {
		            $TabloOne=split("</code>",$Valeur);
		            $TabloOne[0]=eregi_replace('\"','\"',$TabloOne[0]);
		            foreach($TabloOne as $CleOne=>$ValeurOne){
		                if($CleOne==0)
		                $ValeurOne="<code>".$ValeurOne."</code>";
		                $String.=$ValeurOne;
		            }
		        }     
		    }
		    return $String;
		} 

	
}
?>