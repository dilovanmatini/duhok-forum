<?php
/*//////////////////////////////////////////////////////////
// ######################################################///
// # DuhokForum 1.1                                     # //
// ###################################################### //
// #                                                    # //
// #       --  DUHOK FORUM IS FREE SOFTWARE  --         # //
// #                                                    # //
// #   ========= Programming By Dilovan ==============  # //
// # Copyright � 2007-2009 Dilovan. All Rights Reserved # //
// #----------------------------------------------------# //
// #----------------------------------------------------# //
// # If you want any support vist down address:-        # //
// # Email: df@duhoktimes.com                           # //
// # Site: http://df.duhoktimes.com/index.php           # //
// ###################################################### //
//////////////////////////////////////////////////////////*/

if($mlv == 1 AND $DBMemberPosts < $new_member_min_search){
	                echo'<br><center>
	                <table width="99%" border="1">
	                   <tr class="normal">
	                       <td class="list_center" colSpan="10"><font size="5" color="red"><br>
	                       
'.$lang[sorry][noo].'
'.$lang[sorry][search].'
'.$lang[sorry][will].'
	                       </font><br><br>
	                       <a href="JavaScript:history.go(-1)">'.$lang['profile']['click_here_to_back'].'</a><br><br>
	                       </td>
	                   </tr>
	                </table>
	                </center><xml>';
exit();
}
if (members("SEARCH", $DBMemberID) == 1  ) {
	                echo'<br><center>
	                <table width="99%" border="1">
	                   <tr class="normal">
	                       <td class="list_center" colSpan="10"><font size="5" color="red"><br>
'.$lang[permission][sorry].'
'.$lang[permission][search].'<br>
'.$lang[permission][contact].'
</font><br><br>
	                       <a href="JavaScript:history.go(-1)">'.$lang['profile']['click_here_to_back'].'</a><br><br>
	                       </td>
	                   </tr>
	                </table>
	                </center><xml>';
exit();
}



function search_count($m,$h){
$Hour = time() - ($h * 3600);
$Sql = mysql_query("SELECT * FROM ".prefix."SEARCH WHERE MEMBER_ID  = '$m' AND DATE >= $Hour");
$Num = mysql_num_rows($Sql);
return $Num;
}



function search_func(){
	global $lang, $Prefix,$icon_group,$max_search;
$search_count = search_count(m_id,24);

if(mlv < 2){
	echo'<br><br>
	<center>
	<table cellSpacing="0" cellPadding="0" width="99%" border="0">
		<tr>
			<td>
			<center>
			<form method="post" action="index.php?mode=search&method=find">
			<table cellSpacing="1" cellPadding="4" bgColor="gray" border="0">
				<tr class="fixed">
					<td class="cat" colspan="4"><nobr>�����</nobr></td>
				</tr>
				<tr class="fixed">
					<td class="cat"><nobr>���� �� ������ ���</nobr></td>
					<td class="list" colspan="3"><input type="text" size="50" name="search"></td>
				</tr>
				<tr class="fixed">
					<td class="cat"><nobr>���� �����</nobr></td>
					<td class="list"><input class="small" type="radio" name="type" value="subject" CHECKED>&nbsp;����� �������&nbsp;</td>
					<td class="list" colspan="2"><input class="small" type="radio" name="type" value="message">&nbsp;����� �������&nbsp;&nbsp;
				</tr>
				<tr class="fixed">
					<td class="cat"><nobr>����� ��</nobr></td>
					<td class="list"><input class="small" type="radio" name="ch_f" value="0" CHECKED>&nbsp;���� �������&nbsp;</td>
					<td class="list" colspan="2"><input class="small" type="radio" name="ch_f" value="1">&nbsp;��� �����&nbsp;&nbsp;
					<select name="forum_id">
						<option value="">&nbsp;&nbsp;-- ���� ������� --</option>';
				$cats = mysql_query("SELECT * FROM ".$Prefix."CATEGORY ORDER BY CAT_ORDER ASC ") or die (mysql_error());
				$num = mysql_num_rows($cats);
				$i = 0;
				while($i < $num){
					$c = mysql_result($cats, $i, "CAT_ID");
					$forums = mysql_query("SELECT * FROM ".$Prefix."FORUM WHERE CAT_ID = '$c' ORDER BY F_ORDER ASC ") or die (mysql_error());
					$f_num = mysql_num_rows($forums);
					$f_i = 0;
					while($f_i < $f_num){
						$f = mysql_result($forums, $f_i, "FORUM_ID");
						$subject = forums("SUBJECT", $f);
						$hide = forums("HIDE", $f);
						if ($hide == 0 OR check_forum_login($f) == 1){
							echo'<option value="'.$f.'">'.$subject.'</option>';
						}
					++$f_i;
					}
				++$i;
				}		
					echo'
					</select>
					</td>
				</tr>
				<tr class="fixed">
					<td class="list_center" colspan="4">
						<input type="submit" value="����">&nbsp;&nbsp;<input type="reset" value="����� �������">
					</td>
				</tr>
			</table>
			</form>
			</td>
		</tr>
	</table>
	</center>';
}

                 if(mlv > 1){


		echo '
<form name="search" method="post" action="index.php?mode=search&method=find"><center>
		<table cellSpacing="0" cellPadding="0" width="99%" border="0">
			<tr>
				<td>
				<table cellSpacing="2" width="100%" border="0">
					<tr>
						<td class="optionsbar_menus" vAlign="center"><nobr>���� �� :</nobr></td>
						<td class="optionsbar_menus"><input type="text" size="80" name="search"></td>
						<td class="optionsbar_menus"><input type="button" onclick="submit_search('.$search_count.','.$max_search.');" value="����">
</td>
						<td class="optionsbar_menus">���� �� : <br>
<select name="where">
<option value="all">�� �������</option>
<option value="this">������� �������</option>
</select></td>
						<td class="optionsbar_menus">
���� �� : <br>
<select name="type">
<option value="subject_msg">�� ������� �������� �������</option>
<option value="reply">������ ������� ���</option>
</select></td>';
					
					echo'
					</tr>
				</table>
				</td>
			</tr>
		</table>
		</center>';

echo'
		<center>
		<table cellSpacing="0" cellPadding="0" width="99%" border="0">
			<tr>
				<td>
				<table cellSpacing="2" width="100%" border="0">
					<tr>
						<td class="optionsbar_menus" vAlign="center"><nobr>�� ������� <br> ����� :</nobr></td>
						<td class="optionsbar_menus"><input type="text" size="40" name="search_m">'.icons($icon_group,"").'</td>
						<td class="optionsbar_menus"><nobr>����� ���� ����� : </nobr></td>
						<td class="optionsbar_menus">
<select name="month">
<option value="this">-- ����� --</option>
<option value="01">�����</option>
<option value="02">������</option>
<option value="03">����</option>
<option value="04">�����</option>
<option value="05">����</option>
<option value="06">�����</option>
<option value="07">�����</option>
<option value="08">�����</option>
<option value="09">������</option>
<option value="10">������</option>
<option value="11">������</option>
<option value="12">������</option>
</select></td>
						<td class="optionsbar_menus">
<select name="years">
<option value="this">-- ����� --</option>
<option value="2008">2008</option>
</select></td>

<td class="optionsbar_menus" vAlign="center" width="50%">&nbsp;</td>
<td class="optionsbar_menus" vAlign="center"><nobr>��� �������� �� : </nobr><br>
<select name="forum_id">
						<option value="all">&nbsp;&nbsp;-- ���� ��������� --</option>';
				$cats = mysql_query("SELECT * FROM ".$Prefix."CATEGORY ORDER BY CAT_ORDER ASC ") or die (mysql_error());
				$num = mysql_num_rows($cats);
				$i = 0;
				while($i < $num){
					$c = mysql_result($cats, $i, "CAT_ID");
					$forums = mysql_query("SELECT * FROM ".$Prefix."FORUM WHERE CAT_ID = '$c' ORDER BY F_ORDER ASC ") or die (mysql_error());
					$f_num = mysql_num_rows($forums);
					$f_i = 0;
					while($f_i < $f_num){
						$f = mysql_result($forums, $f_i, "FORUM_ID");
						$subject = forums("SUBJECT", $f);
						$hide = forums("HIDE", $f);
						if ($hide == 0 OR check_forum_login($f) == 1){
							echo'<option value="'.$f.'">'.$subject.'</option>';
						}
					++$f_i;
					}
				++$i;
				}		
					echo'
					</select>
</td>
';
					
					echo'
					</tr>
				</table>
				</td>
			</tr>
		</table>
		</center>
		<br></form>';

echo '	                <table width="99%" border="1">
	                   <tr class="normal">
	                       <td class="list_center" colSpan="10">
<br><br>
���� ������� ���� ���� ����� ���� ����� ��� ���� ��� �� ����� .<br><br>
����� ���� ����� �� ������� ��� ���� ���� ����� ����� ����� ���� , ��� ���� ��� ����� . <br><br>
�������� ������� ���� ���� ����� ���� ��� : <br><br>
<font color="red">
������� ��� ���� <br>
����� ����� ����� <br>
����� ����� ����� <br>
����� �� ����� ���� <br>
���� ������ ����� <br><br>
</font>
<font color="black">������ : ������ ����� ���� ��� [?] ������� ������</font><br><br>
<table width="30%" border="1">
<tr>
<td colspan="2" style="background-color:black;text-align:center;color:white">������ ����� ���� ��� ��� �� ��� 24 ����</td>
</tr>
<tr class="normal">
<td>��� ������ ����� :</td>
<td style="color:red">'.$search_count.'</td>
</tr>
<tr class="normal">
<td>���� �������� �� :</td>
<td style="color:red">'.$max_search.'</td>
</tr>
</table><br><br>
	                       </td>
	                   </tr>
	                </table><br><br>';

              }

}

function search_head(){
	global $lang, $img, $search;
			echo'
			<table cellSpacing="2" width="100%" border="0">
				<tr>
					<td>'.icons($search).'</td>
					<td width="100%" vAlign="center"><a href="index.php?mode=active"><font size="3" color="red"><b>&nbsp;&nbsp;�����</b></font></a></td>';
					refresh_time();
					go_to_forum();
				echo'
				</tr>
			</table>';
}

function search_topics($t){
	global $Mlevel, $DBMemberID, $lang, $icon_reply_topic, $folder_new_locked, $folder_new, $folder_new_hot, $folder;
	
$f = topics("FORUM_ID", $t);
$status = topics("STATUS", $t);
$subject = topics("SUBJECT", $t);
$author = topics("AUTHOR", $t);
$author_name = members("NAME", $author);
$replies = topics("REPLIES", $t);
$views = topics("COUNTS", $t);
$lp_date = topics("LAST_POST_DATE", $t);
$date = topics("DATE", $t);
$lp_author = topics("LAST_POST_AUTHOR", $t);
$lp_author_name = members("NAME", $lp_author);
$hide = topics("HIDE", $t);
$f_subject = forums("SUBJECT", $f);
$allowed = allowed($forum_id, 2);

						echo'
						<tr class="normal">
							<td class="list_small"><a href="index.php?mode=f&f='.$f.'"><b>'.$f_subject.'</b></a></td>
							<td class="list_center"><nobr><a href="index.php?mode=f&f='.$f.'">';
							if ($status == 0 AND $replies < 20) {
								echo icons($folder_new_locked, $lang['forum']['topic_is_locked']);
							}
							elseif ($status == 0 AND $replies >= 20) {
								echo icons($folder_new_locked, $lang['forum']['topic_is_hot_and_locked']);
							}
							elseif ($status == 1 AND $replies < 20) {
								echo icons($folder_new);
							}
							elseif ($status == 1 AND $replies >= 20) {
								echo icons($folder_new_hot, $lang['forum']['topic_is_hot']);
							}
							else {
								echo icons($folder);
							}					
							echo'
							</a></nobr></td>
							<td class="list">
							<table cellPadding="0" cellsapcing="0">
								<tr>
									<td><a href="index.php?mode=t&t='.$t.'"><b>'.$subject.'</b></a>&nbsp;'; echo topic_paging($t); echo'</td>
								</tr>
							</table>
							</td>
							<td class="list_small2" noWrap><font  color="green">'.normal_time($date).'</font><br><b>'.link_profile($author_name, $author).'</b></td>
							<td class="list_small2">'.$replies.'</td>
							<td class="list_small2">'.$views.'</td>
							<td class="list_small2" noWrap><font color="red">';
						if ($replies > 0){
							echo normal_time($lp_date).'</font><br><b>'.link_profile($lp_author_name, $lp_author).'<b>';
						}
							echo'
							</td>';
						if ($Mlevel > 0){
							echo'
							<td class="list_small2">';
							if ($allowed == 1 OR $status == 1){
								echo'<a href="index.php?mode=editor&method=reply&t='.$t.'">'.icons($icon_reply_topic, $lang['forum']['reply_to_this_topic'], "hspace=\"2\"").'</a>';
							}
							echo'
							</td>';
						}	
						echo'
						</tr>';
}

function update_search($query,$type,$in_user,$forum,$month,$year){

             if ($type == "subject_msg"){
               $type = 0;
              }else{
               $type = 1;
              }
              $date = time();
              $mlv = mlv;
              $m_id = m_id;
          mysql_query("insert into ".prefix."SEARCH SET QUERY = '$query', DATE = '$date', TYPE = '$type', MEMBER_ID = '$m_id', IN_USER = '$in_user', FORUM = '$forum', M_LEVEL = '$mlv', MONTH = '$month', YEAR = '$year' ") or die(mysql_error());
 
}


function search_body(){
	global $Mlevel, $DBMemberID, $lang, $HTTP_POST_VARS, $Prefix;


			echo'
			<table class="grid" cellSpacing="0" cellPadding="0" width="100%" align="center" border="0">
				<tr>
					<td>
					<table cellSpacing="1" cellPadding="2" width="100%" border="0">
						<tr>
							<td class="cat" width="15%">�������</td>
							<td class="cat">&nbsp;</td>
							<td class="cat" width="45%">��������</td>
							<td class="cat" width="15%">'.$lang['forum']['author'].'</td>
							<td class="cat">'.$lang['forum']['posts'].'</td>
							<td class="cat">'.$lang['forum']['reads'].'</td>
							<td class="cat" width="15%">'.$lang['forum']['last_post'].'</td>
							<td class="cat" width="1%">'.$lang['forum']['options'].'</td>
						</tr>';
			                  $search = $HTTP_POST_VARS[search];
				$ch_f = $HTTP_POST_VARS['ch_f'];
				$forum_id = $HTTP_POST_VARS['forum_id'];
				$type = $HTTP_POST_VARS['type'];
				$search_m = trim($HTTP_POST_VARS['search_m']);
				$month = trim($HTTP_POST_VARS['month']);
				$years = trim($HTTP_POST_VARS['years']);
			if ($search == "" AND $search_m != ""){
                                                       $search = " ";
                                                       }

			if ($search != ""){
				if ($ch_f == 1 AND $forum_id > 0){
					$open_sql = "AND FORUM_ID = '$forum_id' ";
				}
				if ($type == "subject"){
					$search_in = "SUBJECT";
				}
				if ($type == "message"){
					$search_in = "MESSAGE";
				}


                                                                       if(mlv < 2){
				$topics = mysql_query("SELECT * FROM ".$Prefix."TOPICS WHERE T_".$search_in." LIKE '%$search%' ".$open_sql." LIMIT 50") or die (mysql_error());
                                                                      }

                                                          if(mlv > 1){
				if ($forum_id != "all"){
					$open_sql = "AND FORUM_ID = '$forum_id' ";
				}

				if ($search_m != ""){
					$m_sql = mysql_fetch_array(mysql_query("select MEMBER_ID from ".prefix."MEMBERS                                                            WHERE M_NAME = '$search_m' "));

                                                                                          $m_id = $m_sql['MEMBER_ID'];

                                                                       if ($type == "subject_msg"){
					$open_sql .= "AND T_AUTHOR = '$m_id' ";
                                                                       }
                                                                       if ($type == "reply"){
					$open_sql .= "AND R_AUTHOR = '$m_id' ";
                                                                        }
			}

// ######### YEARS ############

                  if($years != "this"){

                         if ($type == "subject_msg"){
                    $open_sql .= "AND YEAR(FROM_UNIXTIME(T_DATE)) = '$years'  ";
                          }
                          if ($type == "reply"){
                      $open_sql .= "AND  YEAR(FROM_UNIXTIME(R_DATE)) = '$years'  ";
                           }
                }

// ######### MONTH ############

                  if($month != "this"){

                        if ($type == "subject_msg"){
                      $open_sql .= "AND MONTH(FROM_UNIXTIME(T_DATE)) = '$month'  ";
                         }
                       if ($type == "reply"){
                    $open_sql .= "AND  MONTH(FROM_UNIXTIME(R_DATE)) = '$month'  ";
                       }

             }

				if ($type == "subject_msg"){
					$search_in = "T_SUBJECT LIKE '%$search%' ".$open_sql." OR T_MESSAGE LIKE '%$search%' ".$open_sql." ";
                                                                                        $topics = mysql_query("SELECT * FROM ".$Prefix."TOPICS WHERE ".$search_in."  LIMIT 50") or die (mysql_error());

				}
				if ($type == "reply"){

$topics = mysql_query("SELECT DISTINCT TOPIC_ID from ".$Prefix."REPLY WHERE R_MESSAGE LIKE '%$search%' ".$open_sql." LIMIT 50") or die (mysql_error());
				}

update_search($search,$type,$m_id,$forum_id,$month,$years);				
}

				$num = mysql_num_rows($topics);
				if ($num <= 0) {
						echo'
						<tr>
							<td class="f1" vAlign="center" align="middle" colspan="20"><br><br>�� ��� ������ ��� �� ����� ����� ���� ���� ����<br><br><br></td>
						</tr>';
				}
				else{
					$i = 0;
					while ($i < $num) {
						$t = mysql_result($topics, $i, "TOPIC_ID");
						$t_hide = topics("HIDE", $t);
						$t_author = topics("AUTHOR", $t);
						$f = topics("FORUM_ID", $t);
						$f_hide = forums("HIDE", $f);
						$check_forum_login = check_forum_login($f);
						if (($f_hide == 0 AND $t_hide == 0) OR ($f_hide == 1 AND $t_hide == 0 AND $check_forum_login == 1) OR ($f_hide == 0 AND $t_hide == 1 AND allowed($f, 2) == 1) OR ($f_hide == 0 AND $t_hide == 1 AND $DBMemberID == $t_author) OR ($f_hide == 1 AND $t_hide == 1 AND $DBMemberID == $t_author AND $check_forum_login == 1) OR ($f_hide == 1 AND $t_hide == 1 AND allowed($f, 2) == 1 AND $check_forum_login == 1)){
							search_topics($t);
						}
					++$i;
					}
				}
					echo'
					</table>
					</td>
				</tr>';
			}
			else{
						echo'
						<tr>
							<td class="f1" vAlign="center" align="middle" colspan="20"><br><br>��� �� ���� �� �� ����� ����<br><br><br></td>
						</tr>';
			}
			echo'
			</table>';
}

function search_find(){
	global $lang;
	echo'
	<center>
	<table cellSpacing="0" cellPadding="0" width="99%" border="0">
		<tr>
			<td>';
			search_head();
			search_body();
			echo'
			</td>
		</tr>
	</table>
	</center>';
}
if ($Mlevel > 0){
	if ($method == ""){
		search_func();
	}
	if ($method == "find"){
		search_find();
	}
}
else{
	go_to("index.php");
}
?>
