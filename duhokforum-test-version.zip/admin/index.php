<?
/*//////////////////////////////////////////////////////////
// ######################################################///
// # DuhokForum Test Version                            # //
// ###################################################### //
// #                                                    # //
// #       --  DUHOK FORUM IS FREE SOFTWARE  --         # //
// #                                                    # //
// #   ========= Programming By Dilovan ==============  # //
// # Copyright � 2007 Dilovan. All Rights Reserved      # //
// #----------------------------------------------------# //
// #----------------------------------------------------# //
// # If you want any support vist down address:-        # //
// # Email: df@duhoktimes.com                           # //
// # Site: http://df.duhoktimes.com/index.php           # //
// ###################################################### //
//////////////////////////////////////////////////////////*/
 
if ($type == "home") {
 if ($Mlevel == 4) {

echo '
<center>
<table dir="rtl" cellSpacing="0" cellPadding="0" width="99%" border="0">
	<tr>
		<td>
		<table class="optionsbar" dir="rtl" cellSpacing="2" width="100%" border="0">
			<tr>
				<td vAlign="center"></td>
				<td class="optionsbar_title" vAlign="center" Align="middle" width="100%">����� ������� �������</td>';
            include("go_to.php");
            echo'
            </tr>
		</table>
		</td>
	</tr>
</table>
</center>
<br>';

$admin_1 = mysql_query("SELECT * FROM " . $Prefix . "CONFIG WHERE VARIABLE = 'FORUM_TITLE' ") or die (mysql_error());
if(mysql_num_rows($admin_1) > 0){
$rs1 = mysql_fetch_array($admin_1);

$Admin_ForumTitle = $rs1['VALUE'];
}

$admin_2 = mysql_query("SELECT * FROM " . $Prefix . "CONFIG WHERE VARIABLE = 'SITE_ADDRESS' ") or die (mysql_error());
if(mysql_num_rows($admin_2) > 0){
$rs2 = mysql_fetch_array($admin_2);

$Admin_SiteAddress = $rs2['VALUE'];
}

$admin_3 = mysql_query("SELECT * FROM " . $Prefix . "CONFIG WHERE VARIABLE = 'COPY_RIGHT' ") or die (mysql_error());
if(mysql_num_rows($admin_3) > 0){
$rs3 = mysql_fetch_array($admin_3);

$Admin_CopyRight = $rs3['VALUE'];
}

$admin_4 = mysql_query("SELECT * FROM " . $Prefix . "CONFIG WHERE VARIABLE = 'IMAGE_FOLDER' ") or die (mysql_error());
if(mysql_num_rows($admin_4) > 0){
$rs4 = mysql_fetch_array($admin_4);

$Admin_ImageFolder = $rs4['VALUE'];
}

$admin_5 = mysql_query("SELECT * FROM " . $Prefix . "CONFIG WHERE VARIABLE = 'ADMIN_FOLDER' ") or die (mysql_error());
if(mysql_num_rows($admin_5) > 0){
$rs5 = mysql_fetch_array($admin_5);

$Admin_AdminFolder = $rs5['VALUE'];
}

$admin_6 = mysql_query("SELECT * FROM " . $Prefix . "CONFIG WHERE VARIABLE = 'PAGE_NUMBER' ") or die (mysql_error());
if(mysql_num_rows($admin_6) > 0){
$rs6 = mysql_fetch_array($admin_6);

$Admin_PageNumber = $rs6['VALUE'];
}

$admin_7 = mysql_query("SELECT * FROM " . $Prefix . "CONFIG WHERE VARIABLE = 'ADMIN_EMAIL' ") or die (mysql_error());
if(mysql_num_rows($admin_7) > 0){
$rs7 = mysql_fetch_array($admin_7);

$Admin_Email = $rs7['VALUE'];
}

echo'
<center>
<table class="grid" border="0" cellspacing="1" cellpadding="4" width="60%">
<form method="post" action="index.php?mode=admin&type=insert_data">
<input type="hidden" name="user_id" value="'.$ppMemberID.'">

	<tr class="fixed">
		<td class="cat"><nobr>��� �������</nobr></td>
		<td class="middle"><input type="text" name="forum_name" size="40" value="'.$Admin_ForumTitle.'"></td>
	</tr>
 	<tr class="fixed">
		<td class="cat"><nobr>����� ������</nobr></td>
		<td class="middle"><input type="text" dir="ltr" name="site_address" size="40" value="'.$Admin_SiteAddress.'"></td>
	</tr>
 	<tr class="fixed">
		<td class="cat"><nobr>���� �������</nobr></td>
		<td class="middle"><input type="text" dir="ltr" name="admin_email" size="40" value="'.$Admin_Email.'"></td>
	</tr>
 	<tr class="fixed">
		<td class="cat"><nobr>���� �������</nobr></td>
		<td class="middle"><input type="text" dir="ltr" name="copy_right" size="40" value="'.$Admin_CopyRight.'"></td>
	</tr>
 	<tr class="fixed">
		<td class="cat"><nobr>��� ���� ���</nobr></td>
		<td class="middle"><input type="text" dir="ltr" name="image_folder" size="40" value="'.$Admin_ImageFolder.'"></td>
	</tr>
 	<tr class="fixed">
		<td class="cat"><nobr>��� ���� �������</nobr></td>
		<td class="middle"><input type="text" dir="ltr" name="admin_folder" size="40" value="'.$Admin_AdminFolder.'"></td>
	</tr>
 	<tr class="fixed">
		<td class="cat"><nobr>��� ����� �� �� ����</nobr></td>
		<td class="middle"><input type="text" name="page_number" size="10" value="'.$Admin_PageNumber.'"></td>
	</tr>
 	<tr class="fixed">
		<td align="middle" colspan="2"><input type="submit" value="����� ������">&nbsp;&nbsp;&nbsp;<input type="reset" value="����� �� ������"></td>
	</tr>
</form>
</table>
</center>';
 }
 else {
 redirect();
 }
}

if ($type == "insert_data") {

 if ($Mlevel == 4) {

$Admin_ForumTitle = $_POST["forum_name"];
$Admin_SiteAddress = $_POST["site_address"];
$Admin_CopyRight = $_POST["copy_right"];
$Admin_ImageFolder = $_POST["image_folder"];
$Admin_AdminFolder = $_POST["admin_folder"];
$Admin_PageNumber = $_POST["page_number"];
$Admin_AdminEmail = $_POST["admin_email"];

if ($error != "") {
	                echo'<br><center>
	                <table width="99%" border="1">
	                   <tr class="normal">
	                       <td class="list_center" colSpan="10"><font size="5" color="red"><br>���<br>'.$error.'..</font><br><br>
	                       <a href="JavaScript:history.go(-1)">-- ���� ��� ������ --</a><br><br>
	                       </td>
	                   </tr>
	                </table>
	                </center>';
}


if ($error == "") {
		$query = "UPDATE " . $Prefix . "CONFIG SET ";
        $query .= "VALUE = '$Admin_ForumTitle' ";
        $query .= "WHERE VARIABLE = 'FORUM_TITLE' ";

        mysql_query($query, $connection) or die (mysql_error());
        
        $query = "UPDATE " . $Prefix . "CONFIG SET ";
        $query .= "VALUE = '$Admin_SiteAddress' ";
        $query .= "WHERE VARIABLE = 'SITE_ADDRESS' ";

        mysql_query($query, $connection) or die (mysql_error());
        
        $query = "UPDATE " . $Prefix . "CONFIG SET ";
        $query .= "VALUE = '$Admin_CopyRight' ";
        $query .= "WHERE VARIABLE = 'COPY_RIGHT' ";

        mysql_query($query, $connection) or die (mysql_error());
        
        $query = "UPDATE " . $Prefix . "CONFIG SET ";
        $query .= "VALUE = '$Admin_ImageFolder' ";
        $query .= "WHERE VARIABLE = 'IMAGE_FOLDER' ";

        mysql_query($query, $connection) or die (mysql_error());
        
        $query = "UPDATE " . $Prefix . "CONFIG SET ";
        $query .= "VALUE = '$Admin_AdminFolder' ";
        $query .= "WHERE VARIABLE = 'ADMIN_FOLDER' ";

        mysql_query($query, $connection) or die (mysql_error());
        
        $query = "UPDATE " . $Prefix . "CONFIG SET ";
        $query .= "VALUE = '$Admin_PageNumber' ";
        $query .= "WHERE VARIABLE = 'PAGE_NUMBER' ";

        mysql_query($query, $connection) or die (mysql_error());
        
        $query = "UPDATE " . $Prefix . "CONFIG SET ";
        $query .= "VALUE = '$Admin_AdminEmail' ";
        $query .= "WHERE VARIABLE = 'ADMIN_EMAIL' ";

        mysql_query($query, $connection) or die (mysql_error());
        
                    echo'
	                <center>
	                <table width="99%" border="1">
	                   <tr class="normal">
	                       <td class="list_center" colSpan="10"><font size="5"><br>�� ����� ������ �����..</font><br><br>
                           <meta http-equiv="Refresh" content="2; URL=index.php?mode=admin&type=home">
                           <a href="index.php?mode=admin&type=home">-- ���� ��� ������ ��� ���� ������� --</a><br><br>
	                       </td>
	                   </tr>
	                </table>
	                </center>';
}


    }
    else {
    redirect();
    }

}


?>
