<?php
/*//////////////////////////////////////////////////////////
// ######################################################///
// # DuhokForum Test Version                            # //
// ###################################################### //
// #                                                    # //
// #       --  DUHOK FORUM IS FREE SOFTWARE  --         # //
// #                                                    # //
// #   ========= Programming By Dilovan ==============  # //
// # Copyright � 2007 Dilovan. All Rights Reserved      # //
// #----------------------------------------------------# //
// #----------------------------------------------------# //
// # If you want any support vist down address:-        # //
// # Email: df@duhoktimes.com                           # //
// # Site: http://df.duhoktimes.com/index.php           # //
// ###################################################### //
//////////////////////////////////////////////////////////*/

require("connect.php");

$config_1 = mysql_query("SELECT * FROM " . $Prefix . "CONFIG WHERE VARIABLE = 'FORUM_TITLE' ") or die (mysql_error());
if(mysql_num_rows($config_1) > 0){
$rs1 = mysql_fetch_array($config_1);

$Admin_ForumTitle = $rs1['VALUE'];
}

$config_2 = mysql_query("SELECT * FROM " . $Prefix . "CONFIG WHERE VARIABLE = 'SITE_ADDRESS' ") or die (mysql_error());
if(mysql_num_rows($config_2) > 0){
$rs2 = mysql_fetch_array($config_2);

$Admin_SiteAddress = $rs2['VALUE'];
}

$config_3 = mysql_query("SELECT * FROM " . $Prefix . "CONFIG WHERE VARIABLE = 'COPY_RIGHT' ") or die (mysql_error());
if(mysql_num_rows($config_3) > 0){
$rs3 = mysql_fetch_array($config_3);

$Admin_CopyRight = $rs3['VALUE'];
}

$config_4 = mysql_query("SELECT * FROM " . $Prefix . "CONFIG WHERE VARIABLE = 'IMAGE_FOLDER' ") or die (mysql_error());
if(mysql_num_rows($config_4) > 0){
$rs4 = mysql_fetch_array($config_4);

$Admin_ImageFolder = $rs4['VALUE'];
}

$config_5 = mysql_query("SELECT * FROM " . $Prefix . "CONFIG WHERE VARIABLE = 'ADMIN_FOLDER' ") or die (mysql_error());
if(mysql_num_rows($config_5) > 0){
$rs5 = mysql_fetch_array($config_5);

$Admin_AdminFolder = $rs5['VALUE'];
}

$config_6 = mysql_query("SELECT * FROM " . $Prefix . "CONFIG WHERE VARIABLE = 'PAGE_NUMBER' ") or die (mysql_error());
if(mysql_num_rows($config_6) > 0){
$rs6 = mysql_fetch_array($config_6);

$Admin_PageNumber = $rs6['VALUE'];
}

$config_7 = mysql_query("SELECT * FROM " . $Prefix . "CONFIG WHERE VARIABLE = 'ADMIN_EMAIL' ") or die (mysql_error());
if(mysql_num_rows($config_7) > 0){
$rs7 = mysql_fetch_array($config_7);

$Admin_Email = $rs7['VALUE'];
}


$forum_title = $Admin_ForumTitle;   // ��� �����
$site_name = $Admin_SiteAddress;     // ����� ����
$copy_right = $Admin_CopyRight;   // ���� �����
$image_folder = $Admin_ImageFolder;       // ���� ���
$max_page = $Admin_PageNumber;             // ��� ����� �� �� ����
$admin_folder = $Admin_AdminFolder;      // ��� ���� �������
$admin_email = $Admin_Email;      // ��� ���� �������
$forum_version = "Test Version";      // ����� �������


?>
