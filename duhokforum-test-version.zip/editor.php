<?
/*//////////////////////////////////////////////////////////
// ######################################################///
// # DuhokForum Test Version                            # //
// ###################################################### //
// #                                                    # //
// #       --  DUHOK FORUM IS FREE SOFTWARE  --         # //
// #                                                    # //
// #   ========= Programming By Dilovan ==============  # //
// # Copyright � 2007 Dilovan. All Rights Reserved      # //
// #----------------------------------------------------# //
// #----------------------------------------------------# //
// # If you want any support vist down address:-        # //
// # Email: df@duhoktimes.com                           # //
// # Site: http://df.duhoktimes.com/index.php           # //
// ###################################################### //
//////////////////////////////////////////////////////////*/

if ($method == "topic") {
    $txt = "����� ����� ����";
}
if ($method == "edit") {
    $txt = "����� �����";
}
if ($method == "reply") {
    $txt = "����� �� ����";
}
if ($method == "editreply") {
    $txt = "����� ��";
}

 $cat = mysql_query("SELECT * FROM " . $Prefix . "CATEGORY WHERE CAT_ID = '$c' ") or die (mysql_error());

 if(mysql_num_rows($cat) > 0){

 $rsc = mysql_fetch_array($cat);

$C_CatID = $rsc['CAT_ID'];
$C_CatStatus = $rsc['CAT_STATUS'];

 }

 $forum = mysql_query("SELECT * FROM " . $Prefix . "FORUM WHERE FORUM_ID = '$f' ") or die (mysql_error());

 if(mysql_num_rows($forum) > 0){

 $rsf = mysql_fetch_array($forum);

$F_CatID = $rsf['CAT_ID'];
$F_ForumID = $rsf['FORUM_ID'];
$F_ForumStatus = $rsf['F_STATUS'];
$F_ForumSubject = $rsf['F_SUBJECT'];
$F_ForumLogo = $rsf['F_LOGO'];

 }

 	$topic = "SELECT * FROM " . $Prefix . "TOPICS ";
    $topic .= " WHERE TOPIC_ID = '$t' ";
	$Rtopic = mysql_query($topic, $connection) or die (mysql_error());

 if(mysql_num_rows($Rtopic) > 0){

 $rst = mysql_fetch_array($Rtopic);

$T_TopicID = $rst['TOPIC_ID'];
$T_TopicSubject = $rst['T_SUBJECT'];
$T_TopicMessage = $rst['T_MESSAGE'];
$T_TopicAuthor = $rst['T_AUTHOR'];
$T_TopicStatus = $rst['T_STATUS'];
$T_TopicSticky = $rst['T_STICKY'];
$T_TopicHidden = $rst['T_HIDDEN'];

 }
 
 	$Tmember = "SELECT * FROM " . $Prefix . "MEMBERS ";
    $Tmember .= " WHERE MEMBER_ID = '$T_TopicAuthor' ";
	$RTmember = mysql_query($Tmember, $connection) or die (mysql_error());

 if(mysql_num_rows($RTmember) > 0){

 $rstm = mysql_fetch_array($RTmember);

 $T_MemberID = $rstm['MEMBER_ID'];
 $T_MemberName = $rstm['M_NAME'];

 }
 
 	$Reply = "SELECT * FROM " . $Prefix . "REPLY ";
    $Reply .= " WHERE REPLY_ID = '$r' ";
	$RReplyr = mysql_query($Reply, $connection) or die (mysql_error());

 if(mysql_num_rows($RReplyr) > 0){

 $rsR = mysql_fetch_array($RReplyr);

 $R_ReplyID = $rsR['REPLY_ID'];
 $R_ReplyMessage = $rsR['R_MESSAGE'];

 }

if ($Mlevel > 0) {



if ($method == "topic") {
    if ($Mlevel == 1 AND $C_CatStatus == 0) {
    go_to("index.php?mode=msg&err=1");
    }
    if ($Mlevel == 1 AND $F_ForumStatus == 0) {
    go_to("index.php?mode=msg&err=2");
    }
}
if ($method == "edit") {
    if ($Mlevel == 1 AND $C_CatStatus == 0) {
    go_to("index.php?mode=msg&err=3");
    }
    if ($Mlevel == 1 AND $F_ForumStatus == 0) {
    go_to("index.php?mode=msg&err=4");
    }
    if ($Mlevel == 1 AND $T_TopicStatus == 0) {
    go_to("index.php?mode=msg&err=5");
    }
    if ($Mlevel == 1 AND $T_TopicAuthor != $DBMemberID) {
    go_to("index.php?mode=msg&err=6");
    }
}
if ($method == "reply") {
    if ($Mlevel == 1 AND $C_CatStatus == 0) {
    go_to("index.php?mode=msg&err=7");
    }
    if ($Mlevel == 1 AND $F_ForumStatus == 0) {
    go_to("index.php?mode=msg&err=8");
    }
    if ($Mlevel == 1 AND $T_TopicStatus == 0) {
    go_to("index.php?mode=msg&err=9");
    }
    if ($Mlevel == 1 AND $T_TopicHidden == 1 AND $T_TopicAuthor != $DBMemberID) {
    go_to("index.php?mode=msg&err=10");
    }
}
if ($method == "editreply") {
    if ($Mlevel == 1 AND $C_CatStatus == 0) {
    go_to("index.php?mode=msg&err=11");
    }
    if ($Mlevel == 1 AND $F_ForumStatus == 0) {
    go_to("index.php?mode=msg&err=12");
    }
}

echo'
<table class="topholder" height="100%" cellSpacing="0" cellPadding="0" width="100%" border="0">
    <tr>
        <td>
        <table background="#f2f2f6" dir="rtl" cellSpacing="2" width="100%" border="0">
        <form name="add_post" method="post" action="index.php?mode=post_info">
        
		<input name="method" type="hidden" value="'.$method.'">
		<input name="r" type="hidden" value="'.$r.'">
		<input name="t" type="hidden" value="'.$t.'">
		<input name="f" type="hidden" value="'.$f.'">
		<input name="c" type="hidden" value="'.$c.'">
		<input name="refer" type="hidden" value="'.$refer.'">
        <input name="host" type="hidden" value="'.$HTTP_HOST.'">';
  
            echo'
            <tr>
                <td><a class="menu" href="index.php?mode=f&f='.$F_ForumID.'">'; icons($F_ForumLogo, ""); echo'</a></td>

                <td class="main" vAlign="center" width="100%"><font size="+1"><a href="index.php?mode=f&f='.$F_ForumID.'">'.$F_ForumSubject.'</a>&nbsp;&nbsp;</font>';

if ($Mlevel > 1) {

if ($method == "edit") {
    if ($T_TopicHidden == 1) {
           echo'<input name="hidden" class="checkbox" type="checkbox" value="1" checked><font color="black" size="2">&nbsp;����&nbsp;&nbsp;</font>';
    }
    if ($T_TopicHidden == 0) {
           echo'<input name="hidden" class="checkbox" type="checkbox" value="1"><font color="black" size="2">&nbsp;����&nbsp;&nbsp;</font>';
    }
    if ($T_TopicStatus == 0) {
           echo'<input name="lock" class="checkbox" type="checkbox" value="1" checked><font color="black" size="2">&nbsp;����&nbsp;&nbsp;</font>';
    }
    if ($T_TopicStatus == 1) {
           echo'<input name="lock" class="checkbox" type="checkbox" value="1"><font color="black" size="2">&nbsp;����&nbsp;&nbsp;</font>';
    }
    if ($T_TopicSticky == 1) {
           echo'<input name="sticky" class="checkbox" type="checkbox" value="1" checked><font color="black" size="2">&nbsp;����</font>';
    }
    if ($T_TopicSticky == 0) {
           echo'<input name="sticky" class="checkbox" type="checkbox" value="1"><font color="black" size="2">&nbsp;����</font>';
    }
}
if ($method == "topic") {
           
           echo'<input name="hidden" class="checkbox" type="checkbox" value="1"><font color="black" size="2">&nbsp;����&nbsp;&nbsp;</font>';
           echo'<input name="lock" class="checkbox" type="checkbox" value="1"><font color="black" size="2">&nbsp;����&nbsp;&nbsp;</font>';
           echo'<input name="sticky" class="checkbox" type="checkbox" value="1"><font color="black" size="2">&nbsp;����</font>';
}

}
                echo'
                </td>

                <td class="menu" align="middle">
                <table cellSpacing="0" cellPadding="6" border="0">
                    <tr>
                        <td align="middle"><nobr><a target="_new" href="index.php?mode=rules"><font size="-1">���� ���<br>������ ����<br>���������</font></a></nobr></td>
                    </tr>
                </table>
                </td>
            </tr>';
if ($method == "reply" OR $method == "editreply") {
            echo'
            <tr>
                <td class="main" colSpan="2"><font size="3"><a href="index.php?mode=t&t='.$T_TopicID.'">�������: '.$T_TopicSubject.'</a></font> - ������: '.$T_MemberName.'</td>
            </tr>';
$T_TopicMessage = $R_ReplyMessage;
}
if ($method == "topic" OR $method == "edit") {

            echo'
            <tr>
                <td colSpan="2">����� �������: <input maxLength="100" name="subject" value="'.$T_TopicSubject.'" style="WIDTH: 400px"></td>
            </tr>';
}
        echo'
        </table>
        </td>
    </tr>
    
    <tr>
        <td>
        <table background: #f2f2f6" cellSpacing="0" cellPadding="0" width="100%" border="0" valign="bottom">
            <tr>
                <td align="textTop" bgcolor="#f2f2f6">
                <textarea style="WIDTH: 100%; HEIGHT: 420px; BACKGROUND: #ffffff" name="message">'.$T_TopicMessage.'</textarea>
                </td>
            </tr>
            <tr height="22">
                <td vAlign="top" noWrap width="100%" bgcolor="#f2f2f6">
                <table dir="rtl" cellSpacing="0" cellPadding="3" width="100%" border="0">
                    <tr>
                        <td align="left" width="100%" bgcolor="#f2f2f6"><input type="submit" value="����� ����">&nbsp;&nbsp;&nbsp;
                        <input type="reset" value="����� ���� ������">&nbsp;&nbsp;&nbsp;
                        <input type="button" value="���� ��������" onclick="window.close();"></td>
                    </tr>
                </table>
                </td>
            </tr>
        </table>
        </td>
    </tr>
</table>
';

}
else {
redirect();
}
    
mysql_close();
?>
