<?php
/*//////////////////////////////////////////////////////////
// ######################################################///
// # DuhokForum Test Version                            # //
// ###################################################### //
// #                                                    # //
// #       --  DUHOK FORUM IS FREE SOFTWARE  --         # //
// #                                                    # //
// #   ========= Programming By Dilovan ==============  # //
// # Copyright � 2007 Dilovan. All Rights Reserved      # //
// #----------------------------------------------------# //
// #----------------------------------------------------# //
// # If you want any support vist down address:-        # //
// # Email: df@duhoktimes.com                           # //
// # Site: http://df.duhoktimes.com/index.php           # //
// ###################################################### //
//////////////////////////////////////////////////////////*/

function redirect() {
echo'
 <script language="JavaScript" type="text/javascript">
	window.location = "index.php";
 </script>';
}

function go_to($link) {
echo'
 <script language="JavaScript" type="text/javascript">
	window.location = "'.$link.'";
 </script>';

}

function icons($url, $title) {

 echo'<img border="0" src="' . $url .'" alt="'. $title. '">';
 
}

function link_profile($m_name, $m_id, $Prefix) {

 $resultLP = mysql_query("SELECT * FROM ".$Prefix."MEMBERS WHERE MEMBER_ID = '$m_id' ") or die (mysql_error());

 if(mysql_num_rows($resultLP) > 0){

 $rsLP = mysql_fetch_array($resultLP);

 $LP_MemberID = $rsLP['MEMBER_ID'];
 $LP_MemberLevel = $rsLP['M_LEVEL'];
 $LP_MemberStatus = $rsLP['M_STATUS'];
 }

 if ($LP_MemberLevel == 1 AND $LP_MemberStatus == 1) {
 echo'<a href="index.php?mode=profile&id='.$m_id.'">'.$m_name.'</a>';
 }
 if ($LP_MemberLevel == 1 AND $LP_MemberStatus == 0) {
 echo'<a href="index.php?mode=profile&id='.$m_id.'"><font color="#999999">'.$m_name.'</font></a>';
 }
 if ($LP_MemberLevel == 2) {
 echo'<a href="index.php?mode=profile&id='.$m_id.'"><font color="#cc0033">'.$m_name.'</font></a>';
 }
 if ($LP_MemberLevel == 3) {
 echo'<a href="index.php?mode=profile&id='.$m_id.'"><font color="#cc8811">'.$m_name.'</font></a>';
 }
 if ($LP_MemberLevel == 4) {
 echo'<a href="index.php?mode=profile&id='.$m_id.'"><font color="blue">'.$m_name.'</font></a>';
 }
 
}

function admin_profile($m_name, $m_id, $Prefix) {

 $resultLP2 = mysql_query("SELECT * FROM ".$Prefix."MEMBERS WHERE MEMBER_ID = '$m_id' ") or die (mysql_error());

 if(mysql_num_rows($resultLP2) > 0){

 $rsLP2 = mysql_fetch_array($resultLP2);

 $LP2_MemberID = $rsLP2['MEMBER_ID'];
 $LP2_MemberLevel = $rsLP2['M_LEVEL'];
 $LP2_MemberStatus = $rsLP2['M_STATUS'];
 }

 if ($LP_MemberLevel == 4) {
 echo'<a href="index.php?mode=profile&id='.$m_id.'">'.$m_name.'</a>';
 }
 if ($LP_MemberLevel < 4) {
 echo'<a href="index.php?mode=profile&id='.$m_id.'">'.$m_name.'</a>';
 }

}

function normal_time($date) {

  $DateYear = date("Y/", $date);
  $NowYear = date("Y/");

  $NormalMonth = date("m/", $date);

  $DateDay = date("d", $date);
  $NowDay = date("d");

  $DateTime = date("H:i", $date);

  if ($DateYear == $NowYear) {
    $NormalYear = "";
  }

  if ($DateDay == $NowDay) {
    echo $DateTime.' - '.'�����';
  }
  else {
    echo $DateTime.' - '.$NormalYear.$NormalMonth.$DateDay;
  }

}

function text_replace($message) {

$message = str_replace("\n", "<br>", $message);
echo $message;

}


?>
