<?
/*//////////////////////////////////////////////////////////
// ######################################################///
// # DuhokForum Test Version                            # //
// ###################################################### //
// #                                                    # //
// #       --  DUHOK FORUM IS FREE SOFTWARE  --         # //
// #                                                    # //
// #   ========= Programming By Dilovan ==============  # //
// # Copyright � 2007 Dilovan. All Rights Reserved      # //
// #----------------------------------------------------# //
// #----------------------------------------------------# //
// # If you want any support vist down address:-        # //
// # Email: df@duhoktimes.com                           # //
// # Site: http://df.duhoktimes.com/index.php           # //
// ###################################################### //
//////////////////////////////////////////////////////////*/

if ($method == "ch") {
$num_forum = $_POST['num_forum'];

include("function.php");

go_to("index.php?mode=f&f=".$num_forum);

}

if ($method != "ch") {

echo '
<form method="post" action="go_to.php?method=ch">
<td class="optionsbar_menus">

<b><nobr>���� ��� �����:</nobr></b>
<select name="num_forum" size="1" onchange="submit();">';
echo '<option value="'.$GOTO_CatID.'">&nbsp;-- ����� ����� �� ������� --</option>';

 	$queryCatGoTo = "SELECT * FROM " . $Prefix . "CATEGORY ";
    $queryCatGoTo .= " WHERE CAT_STATUS = 1 ";
	$queryCatGoTo .= " ORDER BY CAT_ORDER ASC ";

	$resultCatGoTo = mysql_query($queryCatGoTo, $connection) or die (mysql_error());

	$numCatGoTo = mysql_num_rows($resultCatGoTo);


$CatGoTo = 0;
while ($CatGoTo < $numCatGoTo) {

    $GOTO_CatID = mysql_result($resultCatGoTo, $CatGoTo, "CAT_ID");
    $GOTO_CatName = mysql_result($resultCatGoTo, $CatGoTo, "CAT_NAME");
        
    echo '<option value="'.$GOTO_CatID.'">----------------------------</option>';
        
        
 	$queryForumGoTo = "SELECT * FROM " . $Prefix . "FORUM ";
    $queryForumGoTo .= " WHERE F_STATUS = 1 AND CAT_ID = '$GOTO_CatID' ";
	$queryForumGoTo .= " ORDER BY F_ORDER ASC ";

	$resultForumGoTo = mysql_query($queryForumGoTo, $connection) or die (mysql_error());

	$numForumGoTo = mysql_num_rows($resultForumGoTo);


$ForumGoTo = 0;
while ($ForumGoTo < $numForumGoTo) {
        
        
    $GOTO_ForumID = mysql_result($resultForumGoTo, $ForumGoTo, "FORUM_ID");
    $GOTO_ForumName = mysql_result($resultForumGoTo, $ForumGoTo, "F_SUBJECT");

    echo '<option value="'.$GOTO_ForumID.'">'.$GOTO_ForumName.'</option>';

    ++$ForumGoTo;
}
        
        
    ++$CatGoTo;
}





echo '
</select>

</td>
</form>';

}


?>
