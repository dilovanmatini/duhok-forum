<?
/*//////////////////////////////////////////////////////////
// ######################################################///
// # DuhokForum Test Version                            # //
// ###################################################### //
// #                                                    # //
// #       --  DUHOK FORUM IS FREE SOFTWARE  --         # //
// #                                                    # //
// #   ========= Programming By Dilovan ==============  # //
// # Copyright � 2007 Dilovan. All Rights Reserved      # //
// #----------------------------------------------------# //
// #----------------------------------------------------# //
// # If you want any support vist down address:-        # //
// # Email: df@duhoktimes.com                           # //
// # Site: http://df.duhoktimes.com/index.php           # //
// ###################################################### //
//////////////////////////////////////////////////////////*/

if ($method == "login") {

 ob_start();
 setcookie("duhok_user_name" , $_POST["user_name"], time()+999999);
 setcookie("duhok_password" , $_POST["password"], time()+999999);

 go_to("index.php");

}
if ($method == "logout") {
 ob_start();
 setcookie("duhok_user_name");
 setcookie("duhok_password");

 go_to("index.php");
}

 $cookie_user = $HTTP_COOKIE_VARS['duhok_user_name'];
 $cookie_pass = $HTTP_COOKIE_VARS['duhok_password'];

echo'
<html dir="rtl">
<head>
<title>'.$forum_title.'</title>
<link rel="stylesheet" href="styles/style_green.CSS">
<SCRIPT language=JavaScript src="option.js"></SCRIPT>
</head>
<BODY dir="rtl" leftMargin="0" topMargin="0" marginheight="0" marginwidth="0">';

$cookie_pass = MD5($cookie_pass);

 $Start = mysql_query("SELECT * FROM FORUM_MEMBERS WHERE M_NAME = '$cookie_user' AND M_PASSWORD = '$cookie_pass' AND M_STATUS = 1 ") or die (mysql_error());

 if(mysql_num_rows($Start) > 0){
 $rsStart = mysql_fetch_array($Start);

 $DBMemberID = $rsStart['MEMBER_ID'];
 $DBUserName = $rsStart['M_NAME'];
 $DBPassword = $rsStart['M_PASSWORD'];
 $DBMemberPosts = $rsStart['M_POSTS'];
 $Mlevel = $rsStart['M_LEVEL'];
 }
 else {
 $DBMemberID = "0";
 $DBUserName = "0";
 $DBPassword = "0";
 $DBMemberPosts = "0";
 $Mlevel = "0";
 }

 if ($DBUserName == $cookie_user AND $DBPassword == $cookie_pass) {
 $Memberlogin = 1;
 }
 else {
 $Memberlogin = 0;
 }

$LoginLastIP = $REMOTE_ADDR;
$LoginDate = time();

if ($Memberlogin == 1){
 $queryLog = "UPDATE " . $Prefix . "MEMBERS SET M_LAST_IP = '$LoginLastIP', M_LAST_HERE_DATE = '$LoginDate' WHERE MEMBER_ID = '$DBMemberID' ";
 mysql_query($queryLog, $connection) or die (mysql_error());
}

if ($mode != "editor") {

echo'<table class="topholder" dir="rtl" cellSpacing="0" cellPadding="0" width="100%">
       <tr>

           <td>

           <table class="menubar" dir="rtl" cellSpacing="1" cellPadding="0" width="100%">
                  <tr>
                      <td width="100%"><a href="index.php">';
                      icons($logo, "");
                      echo'</td>';

if ($Memberlogin == 1){

                      echo'<td class="optionsbar_menus2" vAlign="top"><nobr><a href="index.php">';
                      icons($Home, "");
                      echo'<br>������ �������</a></nobr></td>';
                      
                      //echo'<td class="optionsbar_menus2" vAlign="top"><nobr><a href="index.php">';
                      //icons($yourposts, "");
                      //echo'<br>��������</a></nobr></td>';
                      
                      echo'<td class="optionsbar_menus2" vAlign="top"><nobr><a href="index.php?mode=members">';
                      icons($members, "");
                      echo'<br>�������</a></nobr></td>';
                      
                      //echo'<td class="optionsbar_menus2" vAlign="top"><nobr><a href="index.php">';
                      //icons($messages, "");
                      //echo'<br>�������</a></nobr></td>';
                      
                      //echo'<td class="optionsbar_menus2" vAlign="top"><nobr><a href="index.php">';
                      //icons($active, "");
                      //echo'<br>������ ����</a></nobr></td>';
                      
                      //echo'<td class="optionsbar_menus2" vAlign="top"><nobr><a href="index.php">';
                      //icons($search, "");
                      //echo'<br>����</a></nobr></td>';
                      
                      //echo'<td class="optionsbar_menus2" vAlign="top"><nobr><a href="index.php">';
                      //icons($help, "");
                      //echo'<br>������</a></nobr></td>';
                      
                      echo'<td class="optionsbar_menus2" vAlign="top"><nobr><a href="index.php?mode=profile&type=details">';
                      icons($details, "");
                      echo'<br>�������</a></nobr></td>';

                      if ($Mlevel == 4) {

                      echo'<td class="optionsbar_menus2" vAlign="top"><nobr><a href="index.php?mode=admin&type=home">';
                      icons($admin, "");
                      echo'<br>�������</a></nobr></td>';
                      }

                      echo'<td class="optionsbar_menus2" vAlign="top"><nobr><a href="index.php?method=logout">';
                      icons($exit, "");
                      echo'<br>����</a></nobr></td>';
}

else {
                      echo'<td class="optionsbar_menus2" vAlign="top"><nobr><a href="index.php">';
                      icons($Home, "");
                      echo'<br>������ �������</a></nobr></td>';
                      
                      echo'<td class="optionsbar_menus2" vAlign="top"><nobr><a href="index.php?mode=members">';
                      icons($members, "");
                      echo'<br>�������</a></nobr></td>';
                      
                      //echo'<td class="optionsbar_menus2" vAlign="top"><nobr><a href="index.php">';
                      //icons($active, "");
                      //echo'<br>������ ����</a></nobr></td>';
                      
                      //echo'<td class="optionsbar_menus2" vAlign="top"><nobr><a href="index.php">';
                      //icons($help, "");
                      //echo'<br>������</a></nobr></td>';
                      
                      echo'<td class="optionsbar_menus2" vAlign="top"><nobr><a href="index.php?mode=register">';
                      icons($details, "");
                      echo'<br>��� ���� ����</a></nobr></td>';

}

                  echo'</tr>
           </table>

           </td>

       </tr>

       <tr>

           <td>

 ';


if ($Memberlogin == 1){



           echo'<table class="userbar" dir="rtl" cellSpacing="0" cellPadding="0" width="100%" border="0">
                  <tr>
                      <td vAlign="center">

                      <table cellSpacing="0" cellPadding="0">

                             <tr>
                                 <td class="user" align="left"><nobr><a href="index.php?mode=profile&type=details">�����:</a></nobr></td>
                                 <td class="user"><nobr><a href="index.php?mode=profile&type=details">&nbsp;<font color="red">'.$DBUserName.'</font></a></nobr></td>
                             </tr>

                             <tr>
                                 <td class="user" align="left"><nobr><a href="index.php?mode=profile&id='.$DBMemberID.'">���������:</a></nobr></td>
                                 <td class="user"><nobr><a href="index.php?mode=profile&id='.$DBMemberID.'">&nbsp;<font color="red">'.$DBMemberPosts.'</font></a></nobr></td>
                             </tr>';
                            /*
                             <tr>
                                 <td class="user" align="left"><nobr><a href="index.php">����� �����:</a></nobr></td>
                                 <td class="user"><nobr><a href="index.php">&nbsp;<font color="red">5</font></a></nobr></td>
                             </tr>
                             */
                      echo'
                      </table>

                      </td>

                      <td width="100%">&nbsp;</td>';

                      /*
                      <td align="left">

                      <table border="0" cellPadding="1" cellSpacing="2">
                             <tr>
                                 <td class="optionsbar_menus"><nobr>������</nobr></td>
                                 <td class="optionsbar_menus"><nobr><a href="index.php">�������</a></nobr></td>
                                 <td class="optionsbar_menus"><nobr>���� ��������</nobr></td>
                             </tr>
                                 <td class="optionsbar_menus"><nobr>������</nobr></td>
                                 <td class="optionsbar_menus"><nobr>�����</nobr></td>
                                 <td class="optionsbar_menus"><nobr>����� ����</nobr></td>
                             <tr>
                      </table>

                      </td>
                      */

                  echo'
                  </tr>
           </table>';

}

else {
				echo'<table class="grid" dir="rtl" height="100%" cellSpacing="0" cellPadding="0" border="0">
                     <form method="POST" action="index.php?method=login">
                     
						<tr>
							<td class="cat" align="middle" colSpan="4">���� �������</td>
						</tr>
						<tr>
							<td class="f2ts" align="left"><font color="red"><b>�����:</b></font></td>
							<td class="f2ts"><input type="text" class="small" style="WIDTH: 100px" name="user_name"></td>
							<td class="f2ts" align="left"><font color="red"><nobr><b>������ ������:</b></nobr></font></td>
							<td class="f2ts"><input type="password" class="small" style="WIDTH: 100px" name="password"></td>
						</tr>
        				<tr>
          					<td colspan="3" class="f2ts" align="right">
							<select name="SavePassword">
							<option value="true">���� ���� ������ ������ �� ��� ������</option>
                            <option value="false">���� ���� - �� ���� ������� �������� �������</option>
							</select>
                            <td class="f2ts" vAlign="top" align="left"><input class="small" src="'.$login.'" type="image" border="0" value="����"></td>
						</tr>
        				<tr>
                            <td colspan="3" class="f2ts" align="right"><a class="menu" href="password.asp"> �� ���� ������ �����ɿ ���� ���..</a></td>
                            <td class="f2ts" align="right"></td>
        				</tr>
					</form>
				</table>';
}


           echo'
           <br></td>
       </tr>
</table>';


}
?>
