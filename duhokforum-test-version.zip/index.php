<?
/*//////////////////////////////////////////////////////////
// ######################################################///
// # DuhokForum Test Version                            # //
// ###################################################### //
// #                                                    # //
// #       --  DUHOK FORUM IS FREE SOFTWARE  --         # //
// #                                                    # //
// #   ========= Programming By Dilovan ==============  # //
// # Copyright � 2007 Dilovan. All Rights Reserved      # //
// #----------------------------------------------------# //
// #----------------------------------------------------# //
// # If you want any support vist down address:-        # //
// # Email: df@duhoktimes.com                           # //
// # Site: http://df.duhoktimes.com/index.php           # //
// ###################################################### //
//////////////////////////////////////////////////////////*/

require("config.php");
include("icons.php");
include("function.php");
include("converts.php");
include("header.php");


if (file_exists("install.php")) {
die("'
                    <br>
                    <center>
	                <table width=\"99%\" border=\"1\">
	                   <tr class=\"normal\">
	                       <td class=\"list_center\" colSpan=\"10\"><font size=\"5\" color=\"red\"><br>���<br>��� �� ��� ���� ��� install.php ���� ��� ���� �� ����� �������..</font><br><br>
	                       <a href=\"JavaScript:history.go(-1)\">-- ���� ��� ������ --</a><br><br>
	                       </td>
	                   </tr>
	                </table>
	                </center>
");
}


switch ($mode) {
     case "":
          include "home.php";
     break;
     case "f":
          include "forum.php";
     break;
     case "register":
          include "register.php";
     break;
     case "members":
          include "members.php";
     break;
     case "profile":
          include "profile.php";
     break;
     case "add_cat_forum":
          include "add_cat_forum.php";
     break;
     case "lock":
          include "lock.php";
     break;
     case "cat_forum_info":
          include "cat_forum_info.php";
     break;
     case "open":
          include "open.php";
     break;
     case "delete":
          include "delete.php";
     break;
     case "order":
          include "order.php";
     break;
     case "editor":
          include "editor.php";
     break;
     case "post_info":
          include "post_info.php";
     break;
     case "msg":
          include "msg.php";
     break;
     case "admin":
          include $admin_folder."/index.php";
     break;
     case "t":
          include "topic.php";
     break;
}


include("footer.php");
?>
