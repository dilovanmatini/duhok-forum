<?
/*//////////////////////////////////////////////////////////
// ######################################################///
// # DuhokForum Test Version                            # //
// ###################################################### //
// #                                                    # //
// #       --  DUHOK FORUM IS FREE SOFTWARE  --         # //
// #                                                    # //
// #   ========= Programming By Dilovan ==============  # //
// # Copyright � 2007 Dilovan. All Rights Reserved      # //
// #----------------------------------------------------# //
// #----------------------------------------------------# //
// # If you want any support vist down address:-        # //
// # Email: df@duhoktimes.com                           # //
// # Site: http://df.duhoktimes.com/index.php           # //
// ###################################################### //
//////////////////////////////////////////////////////////*/

if(!isset($_GET['pg']))
{
$pag = 1;
}
else
{
$pag = $_GET['pg'];
}


$start = (($pag * $max_page) - $max_page);

$total_res = mysql_result(mysql_query("SELECT COUNT(MEMBER_ID) FROM " . $Prefix . "MEMBERS "),0);
$total_col = ceil($total_res / $max_page);

if ($pg == "p") {

$pg = $_POST["numpg"];

echo'<script language="JavaScript" type="text/javascript">
 window.location = "index.php?mode=members&pg='.$pg.'";
 </script>';

}

function paging($total_col, $pag) {

		echo '
        <form method="post" action="index.php?mode=members&pg=p">
        <td class="optionsbar_menus">

		<b>������ :</b>
        <select name="numpg" size="1" onchange="submit();">';


        for($i = 1; $i <= $total_col; $i++) {
            if(($pag) == $i) {
		        echo '<option selected value="'.$i.'">'.$i.' �� '.$total_col.'</option>';
            }
            else {
		        echo '<option value="'.$i.'">'.$i.' �� '.$total_col.'</option>';
            }
        }

		echo '
        </select>

		</td>
		</form>';

}


print $date;


echo'
<center>
<table class="optionsbar" dir="rtl" cellSpacing="2" width="99%" border="0" id="table11">
	<tr>
		<td class="optionsbar_title" Align="middle" vAlign="center" width="100%">���� �����</td>';
  
paging($total_col, $pag);
include("go_to.php");
echo'
	</tr>
</table>
</center>

<table border="0"><tr><td height="5"></td></tr></table>
<center>
<table class="grid" dir="rtl" cellSpacing="1" cellPadding="2" width="99%" border="0">
	<tr>
		<td class="cat">�����</td>
		<td class="cat">�����</td>
		<td class="cat">������</td>
		<td class="cat">���������</td>
		<td class="cat">��� ������</td>
		<td class="cat">��� �����</td>
		<td class="cat">����� �������</td>';

        if ($Mlevel == 4) {
        echo'<td class="cat">������</td>';
        }

	echo'</tr>';

	$query = "SELECT * FROM " . $Prefix . "MEMBERS ";
    $query .= " ORDER BY M_POSTS DESC LIMIT $start, $max_page";   // LIMIT $start, $max_results
	$result = mysql_query($query, $connection) or die (mysql_error());

$num = mysql_num_rows($result);

if ($num == 0) {
    echo'
    <tr class="normal">
		<td class="list_center" vAlign="center" colspan="10"><br>�� ���� �� ��� ���� ���� �������<br><br></td>
    </tr>';
}


$i=0;
while ($i < $num) {


    $MMember_ID = mysql_result($result, $i, "MEMBER_ID");
    $MMemberStatus = mysql_result($result, $i, "M_STATUS");
    $MMemberName = mysql_result($result, $i, "M_NAME");
    $MMemberCountry = mysql_result($result, $i, "M_COUNTRY");
    $MMemberPosts = mysql_result($result, $i, "M_POSTS");
    $MMemberLastPostDate = mysql_result($result, $i, "M_LAST_POST_DATE");
    $MMemberLastHereDate = mysql_result($result, $i, "M_LAST_HERE_DATE");
    $MMemberDate = mysql_result($result, $i, "M_DATE");
    
    $Show_LastPostDate = date("Y/m/d", $MMemberLastPostDate);
    $Show_LastHereDate = date("Y/m/d", $MMemberLastHereDate);
    $Show_date = date("Y/m/d", $MMemberDate);
    
    if ($i % 2) {
	    $bg_color="fixed";
    }
    else
    {
	    $bg_color="normal";
    }
    
    
	echo'
    <tr class="'.$bg_color.'">
		<td class="list_date" vAlign="center">'.$MMember_ID.'</td>
		<td class="list_names"><nobr><a href="index.php?mode=profile&id='.$MMember_ID.'">'.$MMemberName.'</a></nobr></td>
		<td class="list_small">'.$MMemberCountry.'</td>
		<td class="list_small">'.$MMemberPosts.'<br></td>
		<td class="list_date">'.$Show_LastPostDate.'</td>
		<td class="list_small">'.$Show_LastHereDate.'</td>
		<td class="list_date">'.$Show_date.'</td>';
  
        if ($Mlevel == 4) {
        echo'<td class="list_date">';

        if ($MMemberStatus == 1) {
		echo'<a href="javascript:lock_member('.$MMember_ID.')"><img hspace="3" alt="��� �������" border="0" src="' . $icon_lock . '"></a>';
        }
        if ($MMemberStatus == 0) {
        echo'<a href="javascript:open_member('.$MMember_ID.')"><img hspace="3" alt="��� �������" border="0" src="' . $icon_unlock . '"></a>';
        }
        echo'<a href="javascript:del_member('.$MMember_ID.')"><img hspace="3" alt="��� ��� �������" border="0" src="' . $icon_trash . '"></a>';
        echo'</td>';
        }
  
	echo'</tr>';


    ++$i;
}

//echo date('Ymdhi');

echo '
</table>
</center>';


mysql_close();
?>
