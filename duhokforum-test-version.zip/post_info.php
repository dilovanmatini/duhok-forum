<?
/*//////////////////////////////////////////////////////////
// ######################################################///
// # DuhokForum Test Version                            # //
// ###################################################### //
// #                                                    # //
// #       --  DUHOK FORUM IS FREE SOFTWARE  --         # //
// #                                                    # //
// #   ========= Programming By Dilovan ==============  # //
// # Copyright � 2007 Dilovan. All Rights Reserved      # //
// #----------------------------------------------------# //
// #----------------------------------------------------# //
// # If you want any support vist down address:-        # //
// # Email: df@duhoktimes.com                           # //
// # Site: http://df.duhoktimes.com/index.php           # //
// ###################################################### //
//////////////////////////////////////////////////////////*/

$method = $_POST['method'];
$r = $_POST['r'];
$t = $_POST['t'];
$f = $_POST['f'];
$c = $_POST['c'];
$refer = $_POST['refer'];
$host = $_POST['host'];
$hidden = $_POST['hidden'];
$lock = $_POST['lock'];
$sticky = $_POST['sticky'];
$subject = $_POST['subject'];
$message = $_POST['message'];
$date = time();

if ($lock == 1) {
    $lock = 0;
} else {
    $lock = 1;
}

if ($sticky == 1) {
    $sticky = 1;
} else {
    $sticky = 0;
}

if ($hidden == 1) {
    $hidden = 1;
} else {
    $hidden = 0;
}

if ($method == "topic" OR $method == "edit") {
    if ($message == "") {
    $error = "��� ���� ����� �����";
    }

    if ($subject == "") {
    $error = "��� ���� ����� ����� �����";
    }
}

if ($method == "reply" OR $method == "editreply") {
    if ($message == "") {
    $error = "��� ���� ����� ��";
    }
}

if ($host != $HTTP_HOST) {
    redirect();
}


if ($error != "") {
	                echo'<br><center>
	                <table width="99%" border="1">
	                   <tr class="normal">
	                       <td class="list_center" colSpan="10"><font size="5" color="red"><br>���<br>'.$error.'..</font><br><br>
	                       <a href="JavaScript:history.go(-1)">-- ���� ��� ������ --</a><br><br>
	                       </td>
	                   </tr>
	                </table>
	                </center><xml>';
}

if ($error == "") {
    if ($method == "topic") {

     $query1 = "INSERT INTO " . $Prefix . "TOPICS (TOPIC_ID, FORUM_ID, CAT_ID, T_SUBJECT, T_MESSAGE, T_DATE, T_AUTHOR, T_STATUS, T_STICKY, T_HIDDEN, T_LAST_POST_DATE) VALUES (NULL, ";
     $query1 .= " '$f', ";
     $query1 .= " '$c', ";
     $query1 .= " '$subject', ";
     $query1 .= " '$message', ";
     $query1 .= " '$date', ";
     $query1 .= " '$DBMemberID', ";
     $query1 .= " '$lock', ";
     $query1 .= " '$sticky', ";
     $query1 .= " '$hidden', ";
     $query1 .= " '$date') ";

     mysql_query($query1, $connection) or die (mysql_error());
                 
     $query2 = "UPDATE " . $Prefix . "FORUM SET ";
     $query2 .= "F_TOPICS = F_TOPICS + 1, ";
     $query2 .= "F_LAST_POST_DATE = '$date', ";
     $query2 .= "F_LAST_POST_AUTHOR = '$DBMemberID' ";
     $query2 .= "WHERE FORUM_ID = '$f' ";

     mysql_query($query2, $connection) or die (mysql_error());
     
     $query4 = "UPDATE " . $Prefix . "MEMBERS SET ";
     $query4 .= "M_POSTS = M_POSTS + 1, ";
     $query4 .= "M_LAST_POST_DATE = '$date' ";
     $query4 .= "WHERE MEMBER_ID = '$DBMemberID' ";

     mysql_query($query4, $connection) or die (mysql_error());

	                echo'<center>
	                <table width="99%" border="1">
	                   <tr class="normal">
	                       <td class="list_center" colSpan="10"><font size="5"><br>�� ����� ����� �����..</font><br><br>
	                       <meta http-equiv="Refresh" content="2; URL=index.php?mode=f&f='.$f.'">
	                       <a href="index.php?mode=f&f='.$f.'">-- ���� ��� ������ ��� ������� --</a><br><br>
	                       </td>
	                   </tr>
	                </table>
	                </center>';
    }
    if ($method == "edit") {

     $query1 = "UPDATE " . $Prefix . "TOPICS SET ";
     $query1 .= "T_SUBJECT = '$subject', ";
     $query1 .= "T_MESSAGE = '$message', ";
     $query1 .= "T_STATUS = '$lock', ";
     $query1 .= "T_STICKY = '$sticky', ";
     $query1 .= "T_HIDDEN = '$hidden' ";
     $query1 .= "WHERE TOPIC_ID = '$t' ";

     mysql_query($query1, $connection) or die (mysql_error());

	                echo'<center>
	                <table width="99%" border="1">
	                   <tr class="normal">
	                       <td class="list_center" colSpan="10"><font size="5"><br>�� ����� ����� �����..</font><br><br>
	                       <meta http-equiv="Refresh" content="2; URL=index.php?mode=f&f='.$f.'">
                           <a href="index.php?mode=t&t='.$t.'">-- ���� ��� ������ ��� ������� --</a><br>
	                       <a href="index.php?mode=f&f='.$f.'">-- ���� ��� ������ ��� ������� --</a><br><br>
	                       </td>
	                   </tr>
	                </table>
	                </center>';
    }
    if ($method == "reply") {

     $query1 = "INSERT INTO " . $Prefix . "REPLY (REPLY_ID, TOPIC_ID, FORUM_ID, CAT_ID, R_MESSAGE, R_DATE, R_AUTHOR) VALUES (NULL, ";
     $query1 .= " '$t', ";
     $query1 .= " '$f', ";
     $query1 .= " '$c', ";
     $query1 .= " '$message', ";
     $query1 .= " '$date', ";
     $query1 .= " '$DBMemberID') ";

     mysql_query($query1, $connection) or die (mysql_error());

     $query2 = "UPDATE " . $Prefix . "FORUM SET ";
     $query2 .= "F_REPLIES = F_REPLIES + 1, ";
     $query2 .= "F_LAST_POST_DATE = '$date', ";
     $query2 .= "F_LAST_POST_AUTHOR = '$DBMemberID' ";
     $query2 .= "WHERE FORUM_ID = '$f' ";

     mysql_query($query2, $connection) or die (mysql_error());
     
     $query3 = "UPDATE " . $Prefix . "TOPICS SET ";
     $query3 .= "T_REPLIES = T_REPLIES + 1, ";
     $query3 .= "T_LAST_POST_DATE = '$date', ";
     $query3 .= "T_LAST_POST_AUTHOR = '$DBMemberID' ";
     $query3 .= "WHERE TOPIC_ID = '$t' ";

     mysql_query($query3, $connection) or die (mysql_error());
     
     $query4 = "UPDATE " . $Prefix . "MEMBERS SET ";
     $query4 .= "M_POSTS = M_POSTS + 1, ";
     $query4 .= "M_LAST_POST_DATE = '$date' ";
     $query4 .= "WHERE MEMBER_ID = '$DBMemberID' ";

     mysql_query($query4, $connection) or die (mysql_error());
     
	                echo'<center>
	                <table width="99%" border="1">
	                   <tr class="normal">
	                       <td class="list_center" colSpan="10"><font size="5"><br>�� ����� �� �����..</font><br><br>
	                       <meta http-equiv="Refresh" content="2; URL=index.php?mode=f&f='.$f.'">
                           <a href="index.php?mode=t&t='.$t.'">-- ���� ��� ������ ��� ������� --</a><br>
	                       <a href="index.php?mode=f&f='.$f.'">-- ���� ��� ������ ��� ������� --</a><br><br>
	                       </td>
	                   </tr>
	                </table>
	                </center>';
    }
    if ($method == "editreply") {

     $query1 = "UPDATE " . $Prefix . "REPLY SET ";
     $query1 .= "R_MESSAGE = '$message' ";
     $query1 .= "WHERE REPLY_ID = '$r' ";

     mysql_query($query1, $connection) or die (mysql_error());

	                echo'<center>
	                <table width="99%" border="1">
	                   <tr class="normal">
	                       <td class="list_center" colSpan="10"><font size="5"><br>�� ����� �� �����..</font><br><br>
	                       <meta http-equiv="Refresh" content="2; URL=index.php?mode=f&f='.$f.'">
                           <a href="index.php?mode=t&t='.$t.'">-- ���� ��� ������ ��� ������� --</a><br>
	                       <a href="index.php?mode=f&f='.$f.'">-- ���� ��� ������ ��� ������� --</a><br><br>
	                       </td>
	                   </tr>
	                </table>
	                </center>';
    }
}

?>
