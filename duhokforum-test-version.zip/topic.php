<?
/*//////////////////////////////////////////////////////////
// ######################################################///
// # DuhokForum Test Version                            # //
// ###################################################### //
// #                                                    # //
// #       --  DUHOK FORUM IS FREE SOFTWARE  --         # //
// #                                                    # //
// #   ========= Programming By Dilovan ==============  # //
// # Copyright � 2007 Dilovan. All Rights Reserved      # //
// #----------------------------------------------------# //
// #----------------------------------------------------# //
// # If you want any support vist down address:-        # //
// # Email: df@duhoktimes.com                           # //
// # Site: http://df.duhoktimes.com/index.php           # //
// ###################################################### //
//////////////////////////////////////////////////////////*/

$resultTop = mysql_query("SELECT * FROM " . $Prefix . "TOPICS WHERE TOPIC_ID = '$t' ")
or die (mysql_error());

if(mysql_num_rows($resultTop) > 0){
$rsTop = mysql_fetch_array($resultTop);

$TOP_TopicID = $rsTop['TOPIC_ID'];
$TOP_ForumID = $rsTop['FORUM_ID'];
$TOP_CatID = $rsTop['CAT_ID'];
$TOP_TopicStatus = $rsTop['T_STATUS'];
$TOP_TopicSubject = $rsTop['T_SUBJECT'];
$TOP_TopicMessage = $rsTop['T_MESSAGE'];
$TOP_TopicAuthor = $rsTop['T_AUTHOR'];
$TOP_TopicDate = $rsTop['T_DTAE'];
$TOP_TopicHidden = $rsTop['T_HIDDEN'];
}

$resultMTop = mysql_query("SELECT * FROM " . $Prefix . "MEMBERS WHERE MEMBER_ID = '$TOP_TopicAuthor' ")
or die (mysql_error());

if(mysql_num_rows($resultMTop) > 0){
$rsMTop = mysql_fetch_array($resultMTop);

$MTOP_MemberID = $rsMTop['MEMBER_ID'];
$MTOP_MemberName = $rsMTop['M_NAME'];
$MTOP_MemberStatus = $rsMTop['M_STATUS'];
$MTOP_MemberCountry = $rsMTop['M_COUNTRY'];
$MTOP_MemberLevel = $rsMTop['M_LEVEL'];
$MTOP_MemberPosts = $rsMTop['M_POSTS'];
$MTOP_MemberDate = $rsMTop['M_DATE'];
$MTOP_MemberPhotoUrl = $rsMTop['M_PHOTO_URL'];
}

$resultFTop = mysql_query("SELECT * FROM " . $Prefix . "FORUM WHERE FORUM_ID = '$TOP_ForumID' ")
or die (mysql_error());

if(mysql_num_rows($resultFTop) > 0){
$rsFTop = mysql_fetch_array($resultFTop);

$FTOP_ForumID = $rsFTop['FORUM_ID'];
$FTOP_ForumSubject = $rsFTop['F_SUBJECT'];
$FTOP_ForumLogo = $rsFTop['F_LOGO'];
}


$queryCount = "UPDATE " . $Prefix . "TOPICS SET ";
$queryCount .= "T_COUNTS = T_COUNTS + 1 ";
$queryCount .= "WHERE TOPIC_ID = '$TOP_TopicID' ";

     mysql_query($queryCount, $connection) or die (mysql_error());


echo'
<center>
<table dir="rtl" cellSpacing="0" cellPadding="0" width="99%" border="0">
	<tr>
		<td>
		<table cellSpacing="2" width="100%" border="0">
			<tr>
			<td><a class="menu" href="index.php?mode=f&f='.$FTOP_ForumID.'">'; icons($FTOP_ForumLogo, ""); echo'</a></td>
			<td class="main" vAlign="center" width="100%"><a class="menu" href="index.php?mode=f&f='.$FTOP_ForumID.'"><font color="red" size="+1">'.$FTOP_ForumSubject.'</font></a></td>
			<td class="optionsbar_menus" vAlign="top"><nobr><a href="index.php?mode=editor&method=reply&t='.$TOP_TopicID.'&f='.$TOP_ForumID.'&c='.$TOP_CatID.'">'; icons($icon_reply_topic, "�� ��� �������"); echo'<br>��� ��</a></nobr></td>
            <td class="optionsbar_menus" vAlign="top"><nobr><a href="index.php?mode=editor&method=topic&f='.$TOP_ForumID.'&c='.$TOP_CatID.'">'; icons($folder_new, "��� ����� ����"); echo'<br>����� ����</a></nobr></td>';

            include("go_to.php");
            echo'
			</tr>
		</table>
		<table class="optionsbar" dir="rtl" cellSpacing="2" width="100%" border="0">
			<tr>
				<td vAlign="center">&nbsp;'; icons($folder, ""); echo'</td>
				<td class="optionsbar_title" vAlign="center" align="middle" width="100%">&nbsp;'.$TOP_TopicSubject.'</td>
			</tr>
		</table>
		<table class="grid" dir="rtl" cellSpacing="0" cellPadding="0" width="100%" align="center" border="0">
			<tr>
				<td>
				<table dir="rtl" cellSpacing="1" cellPadding="4" width="100%" border="0">';
    
if ($TOP_TopicHidden == 1) {
    if ($Mlevel > 1 AND $DBMemberID == $TOP_TopicAuthor) {
                    echo'
					<tr>
						<td vAlign="top" class="deleted"><b>'; admin_profile($MTOP_MemberName, $MTOP_MemberID, $Prefix); echo'</b><br>';
                    if ($MTOP_MemberStatus == 0) {
                        echo'<font size="1"><nobr>- ����� ������ -</nobr></font>';
                    }
                    else {
                        echo'<font size="-1"><nobr><small>���������: '.$MTOP_MemberPosts.'</small></nobr></font><br>';
                      if ($MTOP_MemberPhotoUrl != "") {
                        echo'<img src="'.$MTOP_MemberPhotoUrl.'" width="100"><br>';
                      }
                      if ($MTOP_MemberCountry != "") {
						echo'<font size="-1"><nobr><small>'.$MTOP_MemberCountry.'</small></nobr><br>';
                      }

						//<font size="-1"><nobr><small>��� ������ ��� ��������: '..'</small></nobr><br>
						//<font size="-1"><nobr><small>���� ��������� �� �����: '..'</small></nobr><br>
      
                        echo'</td>';
                    }
                        echo'
						<td vAlign="top" width="100%" class="deleted" colSpan="3">
						<table cellSpacing="0" cellPadding="0" width="100%">
							<tr>
								<td class="posticon" bgColor="red">
								<table cellSpacing="2" width="100%">
									<tr>
										<td class="posticon"><nobr>'; normal_time($TOP_TopicDate); echo'</nobr></td>
										<td class="posticon"><nobr><a href="index.php?mode=profile&id='.$MTOP_MemberID.'">'; icons($icon_profile, "������� �� �����"); echo'</a></nobr></td>';
                                    if ($Mlevel > 1 AND $DBMemberID == $TOP_TopicAuthor) {
                                        echo'<td class="posticon"><nobr><a href="index.php?mode=editor&method=edit&t='.$TOP_TopicID.'&f='.$TOP_ForumID.'&c='.$TOP_CatID.'">'; icons($icon_edit, "����� �������"); echo'</a></nobr></td>';
                                    }
                                    if ($Mlevel > 1) {
                                      if ($TOP_TopicStatus == 1) {
                                        echo'<td class="posticon"><nobr><a href="javascript:lock_topic('.$TOP_TopicID.', '.$TOP_ForumID.')">'; icons($folder_locked, "��� �������"); echo'</a></nobr></td>';
                                      }
                                      if ($TOP_TopicStatus == 0) {
                                        echo'<td class="posticon"><nobr><a href="javascript:open_topic('.$TOP_TopicID.', '.$TOP_ForumID.')">'; icons($folder_unlocked, "��� �������"); echo'</a></nobr></td>';
                                      }
                                    if ($Mlevel > 2) {
                                        echo'<td class="posticon"><nobr><a href="javascript:del_topic('.$TOP_TopicID.', '.$TOP_ForumID.')">'; icons($folder_delete, "��� �������"); echo'</a></nobr></td>';
                                    }
                                        echo'<td class="posticon"><nobr><a href="javascript:show_topic('.$TOP_TopicID.', '.$TOP_ForumID.')">'; icons($icon_unhidden, "����� �������"); echo'</a></nobr></td>';
                                    }
                                        echo'
										<td class="posticon" width="90%">&nbsp;</td>
									</tr>
								</table>
								</td>
							</tr>
						</table>
						<table dir="rtl" cellSpacing="1" cellPadding="4" width="100%" border="0">
						    <tr>
						        <td vAlign="top" width="100%" bgColor="#aadddd" colSpan="3">
						        <table class="optionsbar" width="100%">
						            <tr>
						                <td class="optionsbar_menus">** �� ����� ��� �������� -- ��������� �� ����� ������ ������� ����� ������� **</td>
						            </tr>
						        </table>
						        </td>
						    </tr>
						</table>
						<table style="TABLE-LAYOUT: fixed">
							<tr>
								<td>';text_replace($TOP_TopicMessage); echo'</td>
							</tr>
						</table>
						</td>
					</tr>';
    }
}
if ($TOP_TopicHidden == 0) {
                    echo'
					<tr>
						<td vAlign="top" bgColor="#ddffdd"><b>'; admin_profile($MTOP_MemberName, $MTOP_MemberID, $Prefix); echo'</b><br>';
                    if ($MTOP_MemberStatus == 0) {
                        echo'<font size="1"><nobr>- ����� ������ -</nobr></font>';
                    }
                    else {
                        echo'<font size="-1"><nobr><small>���������: '.$MTOP_MemberPosts.'</small></nobr></font><br>';
                      if ($MTOP_MemberPhotoUrl != "") {
                        echo'<img src="'.$MTOP_MemberPhotoUrl.'" width="100"><br>';
                      }
                      if ($MTOP_MemberCountry != "") {
						echo'<font size="-1"><nobr><small>'.$MTOP_MemberCountry.'</small></nobr><br>';
                      }

						//<font size="-1"><nobr><small>��� ������ ��� ��������: '..'</small></nobr><br>
						//<font size="-1"><nobr><small>���� ��������� �� �����: '..'</small></nobr><br>

                        echo'</td>';
                    }
                        echo'
						<td vAlign="top" width="100%" bgColor="#ddffdd" colSpan="3">
						<table cellSpacing="0" cellPadding="0" width="100%">
							<tr>
								<td class="posticon" bgColor="red">
								<table cellSpacing="2" width="100%">
									<tr>
										<td class="posticon"><nobr>'; normal_time($TOP_TopicDate); echo'</nobr></td>
										<td class="posticon"><nobr><a href="index.php?mode=profile&id='.$MTOP_MemberID.'">'; icons($icon_profile, "������� �� �����"); echo'</a></nobr></td>';
                                    if ($Mlevel > 1 AND $DBMemberID == $TOP_TopicAuthor) {
                                        echo'<td class="posticon"><nobr><a href="index.php?mode=editor&method=edit&t='.$TOP_TopicID.'&f='.$TOP_ForumID.'&c='.$TOP_CatID.'">'; icons($icon_edit, "����� �������"); echo'</a></nobr></td>';
                                    }
                                    if ($Mlevel > 1) {
                                      if ($TOP_TopicStatus == 1) {
                                        echo'<td class="posticon"><nobr><a href="javascript:lock_topic('.$TOP_TopicID.', '.$TOP_ForumID.')">'; icons($folder_locked, "��� �������"); echo'</a></nobr></td>';
                                      }
                                      if ($TOP_TopicStatus == 0) {
                                        echo'<td class="posticon"><nobr><a href="javascript:open_topic('.$TOP_TopicID.', '.$TOP_ForumID.')">'; icons($folder_unlocked, "��� �������"); echo'</a></nobr></td>';
                                      }
                                    if ($Mlevel > 2) {
                                        echo'<td class="posticon"><nobr><a href="javascript:del_topic('.$TOP_TopicID.', '.$TOP_ForumID.')">'; icons($folder_delete, "��� �������"); echo'</a></nobr></td>';
                                    }
                                        echo'<td class="posticon"><nobr><a href="javascript:hide_topic('.$TOP_TopicID.', '.$TOP_ForumID.')">'; icons($icon_hidden, "����� �������"); echo'</a></nobr></td>';
                                    }
                                        echo'
										<td class="posticon" width="90%">&nbsp;</td>
									</tr>
								</table>
								</td>
							</tr>
						</table>
						<table style="TABLE-LAYOUT: fixed">
							<tr>
								<td>';text_replace($TOP_TopicMessage); echo'</td>
							</tr>
						</table>
						</td>
					</tr>';
}

	$queryRe = "SELECT * FROM " . $Prefix . "REPLY ";
    $queryRe .= " WHERE TOPIC_ID = '$TOP_TopicID' ";
    $queryRe .= " ORDER BY R_DATE DESC ";
	$resultRe = mysql_query($queryRe, $connection) or die (mysql_error());

$numRe = mysql_num_rows($resultRe);

$iRe = 0;
while ($iRe < $numRe) {


    $R_ReplyID = mysql_result($resultRe, $iRe, "REPLY_ID");
    $R_CatID = mysql_result($resultRe, $iRe, "CAT_ID");
    $R_ForumID = mysql_result($resultRe, $iRe, "FORUM_ID");
    $R_TopicID = mysql_result($resultRe, $iRe, "TOPIC_ID");
    $R_Author = mysql_result($resultRe, $iRe, "R_AUTHOR");
    $R_Message = mysql_result($resultRe, $iRe, "R_MESSAGE");
    $R_Date = mysql_result($resultRe, $iRe, "R_DATE");
    $R_Hidden = mysql_result($resultRe, $iRe, "R_HIDDEN");
    
    
$resultRM = mysql_query("SELECT * FROM " . $Prefix . "MEMBERS WHERE MEMBER_ID = '$R_Author' ")
or die (mysql_error());

if(mysql_num_rows($resultRM) > 0){
$rsRM = mysql_fetch_array($resultRM);

$RM_MemberID = $rsRM['MEMBER_ID'];
$RM_MemberName = $rsRM['M_NAME'];
$RM_MemberStatus = $rsRM['M_STATUS'];
$RM_MemberCountry = $rsRM['M_COUNTRY'];
$RM_MemberLevel = $rsRM['M_LEVEL'];
$RM_MemberPosts = $rsRM['M_POSTS'];
$RM_MemberDate = $rsRM['M_DATE'];
$RM_MemberPhotoUrl = $rsRM['M_PHOTO_URL'];
}

if ($R_Hidden == 1) {
    if ($Mlevel > 1 AND $DBMemberID == $R_Author) {

                    echo'
					<tr>
						<td vAlign="top" class="deleted"><b>'; admin_profile($RM_MemberName, $RM_MemberID, $Prefix); echo'</b><br>';
                    if ($RM_MemberStatus == 0) {
                        echo'<font size="1"><nobr>- ����� ������ -</nobr></font>';
                    }
                    else {
                        echo'<font size="-1"><nobr><small>���������: '.$RM_MemberPosts.'</small></nobr></font><br>';
                      if ($RM_MemberPhotoUrl != "") {
                        echo'<img src="'.$RM_MemberPhotoUrl.'" width="100"><br>';
                      }
                      if ($RM_MemberCountry != "") {
						echo'<font size="-1"><nobr><small>'.$RM_MemberCountry.'</small></nobr><br>';
                      }

						//<font size="-1"><nobr><small>��� ������ ��� ��������: '..'</small></nobr><br>
						//<font size="-1"><nobr><small>���� ��������� �� �����: '..'</small></nobr><br>

                        echo'</td>';
                    }
                        echo'
						<td vAlign="top" width="100%" class="deleted" colSpan="3">
						<table cellSpacing="0" cellPadding="0" width="100%">
							<tr>
								<td class="posticon" bgColor="red">
								<table cellSpacing="2" width="100%">
									<tr>
										<td class="posticon"><nobr>'; normal_time($R_Date); echo'</nobr></td>
										<td class="posticon"><nobr><a href="index.php?mode=profile&id='.$MTOP_MemberID.'">'; icons($icon_profile, "������� �� �����"); echo'</a></nobr></td>';
                                    if ($Mlevel > 1 AND $DBMemberID == $R_Author) {
                                        echo'<td class="posticon"><nobr><a href="index.php?mode=editor&method=editreply&r='.$R_ReplyID.'&t='.$R_TopicID.'&f='.$R_ForumID.'&c='.$R_CatID.'">'; icons($icon_edit, "����� ��"); echo'</a></nobr></td>';
                                    }

                                    if ($Mlevel > 1) {
                                      if ($Mlevel > 2 AND $DBMemberID == $R_Author) {
                                        echo'<td class="posticon"><nobr><a href="javascript:del_reply('.$R_ReplyID.', '.$R_TopicID.', '.$R_ForumID.')">'; icons($icon_delete_reply, "��� ��"); echo'</a></nobr></td>';
                                      }
                                        echo'<td class="posticon"><nobr><a href="javascript:show_reply('.$R_ReplyID.', '.$R_TopicID.', '.$R_ForumID.')">'; icons($icon_unhidden, "����� ��"); echo'</a></nobr></td>';
                                    }

                                        echo'
										<td class="posticon" width="90%">&nbsp;</td>
									</tr>
								</table>
								</td>
							</tr>
						</table>
						<table dir="rtl" cellSpacing="1" cellPadding="4" width="100%" border="0">
						    <tr>
						        <td vAlign="top" width="100%" bgColor="#aadddd" colSpan="3">
						        <table class="optionsbar" width="100%">
						            <tr>
						                <td class="optionsbar_menus">** �� ����� ��� �������� -- ��������� �� ����� ������ ������� ����� ������� **</td>
						            </tr>
						        </table>
						        </td>
						    </tr>
						</table>
						<table style="TABLE-LAYOUT: fixed">
							<tr>
								<td>';text_replace($R_Message); echo'</td>
							</tr>
						</table>
						</td>
					</tr>';

    }
}
if ($R_Hidden == 0) {

    if ($iRe % 2) {
	    $bg_color = "fixed";
    }
    else
    {
	    $bg_color = "normal";

    }
    
                    echo'
					<tr>
						<td vAlign="top" class="'.$bg_color.'"><b>'; admin_profile($RM_MemberName, $RM_MemberID, $Prefix); echo'</b><br>';
                    if ($RM_MemberStatus == 0) {
                        echo'<font size="1"><nobr>- ����� ������ -</nobr></font>';
                    }
                    else {
                        echo'<font size="-1"><nobr><small>���������: '.$RM_MemberPosts.'</small></nobr></font><br>';
                      if ($RM_MemberPhotoUrl != "") {
                        echo'<img src="'.$RM_MemberPhotoUrl.'" width="100"><br>';
                      }
                      if ($RM_MemberCountry != "") {
						echo'<font size="-1"><nobr><small>'.$RM_MemberCountry.'</small></nobr><br>';
                      }

						//<font size="-1"><nobr><small>��� ������ ��� ��������: '..'</small></nobr><br>
						//<font size="-1"><nobr><small>���� ��������� �� �����: '..'</small></nobr><br>

                        echo'</td>';
                    }
                        echo'
						<td vAlign="top" width="100%" class="'.$bg_color.'" colSpan="3">
						<table cellSpacing="0" cellPadding="0" width="100%">
							<tr>
								<td class="posticon" bgColor="red">
								<table cellSpacing="2" width="100%">
									<tr>
										<td class="posticon"><nobr>'; normal_time($R_Date); echo'</nobr></td>
										<td class="posticon"><nobr><a href="index.php?mode=profile&id='.$MTOP_MemberID.'">'; icons($icon_profile, "������� �� �����"); echo'</a></nobr></td>';
                                    if ($Mlevel > 1 AND $DBMemberID == $R_Author) {
                                        echo'<td class="posticon"><nobr><a href="index.php?mode=editor&method=editreply&r='.$R_ReplyID.'&t='.$R_TopicID.'&f='.$R_ForumID.'&c='.$R_CatID.'">'; icons($icon_edit, "����� ��"); echo'</a></nobr></td>';
                                    }
                                    
                                    if ($Mlevel > 1) {
                                      if ($Mlevel > 2 AND $DBMemberID == $R_Author) {
                                        echo'<td class="posticon"><nobr><a href="javascript:del_reply('.$R_ReplyID.', '.$R_TopicID.', '.$R_ForumID.')">'; icons($icon_delete_reply, "��� ��"); echo'</a></nobr></td>';
                                      }
                                        echo'<td class="posticon"><nobr><a href="javascript:hide_reply('.$R_ReplyID.', '.$R_TopicID.', '.$R_ForumID.')">'; icons($icon_hidden, "����� ��"); echo'</a></nobr></td>';
                                    }
                                    
                                        echo'
										<td class="posticon" width="90%">&nbsp;</td>
									</tr>
								</table>
								</td>
							</tr>
						</table>
						<table style="TABLE-LAYOUT: fixed">
							<tr>
								<td>';text_replace($R_Message); echo'</td>
							</tr>
						</table>
						</td>
					</tr>';
    
}

    ++$iRe;
}
     
                echo'
				</table>
				</td>
			</tr>
		</table>
		<table class="optionsbar" dir="rtl" cellSpacing="2" width="100%" border="0">
			<tr>
				<td vAlign="center">&nbsp;'; icons($folder, ""); echo'</td>
				<td class="optionsbar_title" vAlign="center" align="middle" width="100%">&nbsp;'.$TOP_TopicSubject.'</td>
			</tr>
		</table>
		<table cellSpacing="2" width="100%" border="0">
			<tr>
			<td><a class="menu" href="index.php?mode=f&f='.$FTOP_ForumID.'">'; icons($FTOP_ForumLogo, ""); echo'</a></td>
			<td class="main" vAlign="center" width="100%"><a class="menu" href="index.php?mode=f&f='.$FTOP_ForumID.'"><font color="red" size="+1">'.$FTOP_ForumSubject.'</font></a></td>
			<td class="optionsbar_menus" vAlign="top"><nobr><a href="index.php?mode=editor&method=reply&t='.$TOP_TopicID.'&f='.$TOP_ForumID.'&c='.$TOP_CatID.'">'; icons($icon_reply_topic, "�� ��� �������"); echo'<br>��� ��</a></nobr></td>
            <td class="optionsbar_menus" vAlign="top"><nobr><a href="index.php?mode=editor&method=topic&f='.$TOP_ForumID.'&c='.$TOP_CatID.'">'; icons($folder_new, "��� ����� ����"); echo'<br>����� ����</a></nobr></td>';

            include("go_to.php");
            echo'
			</tr>
		</table>
		</td>
	</tr>
</table>
</center>
';


?>
